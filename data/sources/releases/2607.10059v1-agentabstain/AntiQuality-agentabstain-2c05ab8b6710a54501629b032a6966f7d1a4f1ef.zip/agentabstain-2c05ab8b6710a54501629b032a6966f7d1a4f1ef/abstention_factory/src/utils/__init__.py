"""Utility helpers for the data generation pipeline."""
