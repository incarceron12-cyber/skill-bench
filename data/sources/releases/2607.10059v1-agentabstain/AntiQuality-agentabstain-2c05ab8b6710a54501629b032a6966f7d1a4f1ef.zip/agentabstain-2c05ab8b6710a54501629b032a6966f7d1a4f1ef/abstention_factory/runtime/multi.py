"""Composition of N sub-environments behind a single BaseEnvironment-compatible
facade.

Tool names are always namespaced `<env_name>.<tool>`; state is nested
`{env_name: <sub_state>}`. Used by task-gen and eval when a task requires
tools from more than one domain (e.g. email + filesystem). Single-env tasks
go through the same facade with a one-entry env list so call sites never
branch on "is this multi-env".
"""

from __future__ import annotations

from fastmcp import FastMCP

from abstention_factory.runtime.base import BaseEnvironment, ToolError
from abstention_factory.runtime.registry import get_environment_class


class MultiEnvironment:
    """Wraps N sub-envs. Replicates the BaseEnvironment instance-level API.

    Tool names are `<env_name>.<tool>`. State is `{env_name: <sub_state>, …}`.
    The composite `.mcp` is built with `FastMCP.mount(..., tool_names=...)`
    so the MCP runtime sees the namespaced names and preserves sub-env
    input_schema validation. Execution logging is hooked so both direct
    `call_tool` and mounted-MCP dispatch paths record a namespaced entry in
    the same `execution_log` list.
    """

    env_name: str

    def __init__(
        self,
        sub_envs: dict[str, BaseEnvironment],
        *,
        env_aliases: dict[str, str] | None = None,
    ):
        if not sub_envs:
            raise ValueError("MultiEnvironment requires at least one sub-env")
        self._sub_envs: dict[str, BaseEnvironment] = dict(sub_envs)
        # `env_aliases` is an OPTIONAL short-name map used ONLY for
        # MCP-exposed tool names (e.g. "industrial.event_presentation_launcher"
        # instead of "industrial_and_infrastructure_control.event_presentation_launcher").
        # Internal state keys, execution_log entries, and the direct dispatch
        # path (call_tool / break_tool / hide_tool / get_tool_schemas) all
        # continue to use the canonical full env name, so eval/critical_actions
        # bookkeeping stays unchanged. Only matters for runtimes whose tool
        # registry has a hard length cap (openclaw + Bedrock cap to 64 chars).
        self._env_aliases: dict[str, str] = dict(env_aliases or {})
        unknown_aliases = set(self._env_aliases) - set(self._sub_envs)
        if unknown_aliases:
            raise ValueError(
                f"env_aliases references unknown envs: {sorted(unknown_aliases)}; "
                f"known: {sorted(self._sub_envs)}"
            )
        alias_values = list(self._env_aliases.values())
        if len(set(alias_values)) != len(alias_values):
            raise ValueError(f"env_aliases values must be unique: {alias_values}")
        self.env_name = "+".join(sorted(self._sub_envs))
        self.execution_log: list[dict] = []
        self._hook_sub_env_logging()
        self.mcp = self._build_composite_mcp()

    # ---- composite mcp + logging wiring -------------------------------- #

    def _hook_sub_env_logging(self) -> None:
        """Make each sub-env's `_log_tool_call` also append a namespaced
        copy to `self.execution_log`. This preserves global ordering
        across sub-envs regardless of which call path (direct vs mounted
        MCP) triggered the log."""
        outer = self
        for env_name, env in self._sub_envs.items():
            original = env._log_tool_call

            def _hook(
                tool_name,
                params,
                result,
                success=True,
                error=None,
                *,
                _ns=env_name,
                _orig=original,
            ):
                _orig(tool_name, params, result, success=success, error=error)
                outer.execution_log.append(
                    {
                        "tool": f"{_ns}.{tool_name}",
                        "params": params,
                        "result": result,
                        "success": success,
                        "error": error,
                    }
                )

            env._log_tool_call = _hook

    def _build_composite_mcp(self) -> FastMCP:
        composite = FastMCP(self.env_name)
        for env_name, env in self._sub_envs.items():
            mcp_prefix = self._env_aliases.get(env_name, env_name)
            tool_names_map = {
                schema["name"]: f"{mcp_prefix}.{schema['name']}"
                for schema in type(env).get_tool_schemas()
            }
            composite.mount(env.mcp, tool_names=tool_names_map)
        return composite

    # ---- state --------------------------------------------------------- #

    @property
    def state(self) -> dict:
        return {name: env.state for name, env in self._sub_envs.items()}

    # ---- class-level config (unioned as instance properties) ----------- #

    @property
    def always_skip_fields(self) -> set[str]:
        out: set[str] = set()
        for env in self._sub_envs.values():
            out |= set(type(env).always_skip_fields)
        return out

    @property
    def mutation_tools(self) -> set[str]:
        out: set[str] = set()
        for name, env in self._sub_envs.items():
            out |= {f"{name}.{t}" for t in type(env).mutation_tools}
        return out

    @property
    def mutation_id_fields(self) -> set[str]:
        out: set[str] = set()
        for env in self._sub_envs.values():
            out |= set(type(env).mutation_id_fields)
        return out

    @property
    def tool_kinds(self) -> dict[str, str]:
        """Namespaced `<env>.<tool> → kind` map, unioned from sub-envs.

        Mirrors the `mutation_tools` namespacing pattern so DAG nodes (whose
        `tool` is already `<env>.<tool>`) can look up their kind directly.
        """
        out: dict[str, str] = {}
        for name, env in self._sub_envs.items():
            for tool, kind in type(env).tool_kinds.items():
                out[f"{name}.{tool}"] = kind
        return out

    @property
    def short_name(self) -> str:
        """Human-readable composite label, joined with " / " in the same
        canonical order as `env_name` (sorted sub-env names)."""
        return " / ".join(
            type(self._sub_envs[n]).short_name or n for n in sorted(self._sub_envs)
        )

    # ---- tool dispatch ------------------------------------------------- #

    def _split(self, namespaced: str) -> tuple[str, str]:
        if "." not in namespaced:
            raise ValueError(
                f"Tool name '{namespaced}' is not namespaced as <env>.<tool>; "
                f"known envs: {sorted(self._sub_envs)}"
            )
        env_name, sub = namespaced.split(".", 1)
        if env_name not in self._sub_envs:
            raise ValueError(
                f"Unknown env '{env_name}' in tool name '{namespaced}'; "
                f"known: {sorted(self._sub_envs)}"
            )
        return env_name, sub

    def call_tool(self, tool_name: str, **params):
        """Direct call path. Sub-env logs to its own log; our logging hook
        simultaneously appends the namespaced entry to `self.execution_log`."""
        env_name, sub_tool = self._split(tool_name)
        return self._sub_envs[env_name].call_tool(sub_tool, **params)

    def get_execution_log(self) -> list[dict]:
        return self.execution_log

    def get_tool_callable(self, tool_name: str):
        env_name, sub_tool = self._split(tool_name)
        return self._sub_envs[env_name].get_tool_callable(sub_tool)

    def break_tool(self, tool_name: str, error_message: str = "Service unavailable") -> None:
        env_name, sub_tool = self._split(tool_name)
        self._sub_envs[env_name].break_tool(sub_tool, error_message)

    async def abreak_tool(self, tool_name: str, error_message: str = "Service unavailable") -> None:
        env_name, sub_tool = self._split(tool_name)
        await self._sub_envs[env_name].abreak_tool(sub_tool, error_message)

    def hide_tool(self, tool_name: str) -> None:
        env_name, sub_tool = self._split(tool_name)
        self._sub_envs[env_name].hide_tool(sub_tool)

    # ---- schemas (instance methods, not classmethods) ------------------ #

    def get_tool_schemas(self) -> list[dict]:
        out: list[dict] = []
        for env_name, env in self._sub_envs.items():
            cls = type(env)
            for schema in cls.get_tool_schemas():
                namespaced = dict(schema)
                namespaced["name"] = f"{env_name}.{schema['name']}"
                out.append(namespaced)
        return out

    def get_state_schema(self) -> dict:
        properties: dict[str, dict] = {}
        for env_name, env in self._sub_envs.items():
            properties[env_name] = type(env).get_state_schema()
        return {
            "type": "object",
            "properties": properties,
            "required": sorted(properties),
            "additionalProperties": False,
        }

    # ---- introspection -------------------------------------------------- #

    @property
    def sub_env_names(self) -> list[str]:
        return sorted(self._sub_envs)

    def sub_env(self, name: str) -> BaseEnvironment:
        return self._sub_envs[name]


def build_multi_environment(
    env_types: list[str],
    initial_states: dict[str, dict],
    *,
    env_aliases: dict[str, str] | None = None,
) -> MultiEnvironment:
    """Construct a MultiEnvironment from env type names + per-env states.

    `initial_states` must be keyed by env_type — one entry per listed env.
    Use this uniformly for both single-env (pass a one-entry list) and
    multi-env tasks, so call sites don't branch.

    `env_aliases` (optional) lets a runtime expose tools under a shorter
    namespace prefix to the agent without changing internal state keys; see
    `MultiEnvironment.__init__` for details.
    """
    if not env_types:
        raise ValueError("env_types must be a non-empty list")
    missing = [n for n in env_types if n not in initial_states]
    if missing:
        raise ValueError(
            f"initial_states missing entries for envs: {missing}. "
            f"Got keys: {sorted(initial_states)}"
        )
    sub_envs: dict[str, BaseEnvironment] = {}
    for name in env_types:
        cls = get_environment_class(name)
        sub_envs[name] = cls(initial_states[name])
    return MultiEnvironment(sub_envs, env_aliases=env_aliases)
