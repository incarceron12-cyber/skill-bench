"""AgentAbstain data generation pipeline package."""
