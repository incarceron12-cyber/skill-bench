"""Shared runtime types and helpers."""
