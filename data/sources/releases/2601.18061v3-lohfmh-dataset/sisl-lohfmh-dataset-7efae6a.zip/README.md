<p align="center">
    <em>Expert Evaluation and the Limits of Human Feedback in Mental Health AI Safety Testing Dataset</em>
</p>

<p align="center">
  <a href="https://openreview.net/forum?id=GhvcXNfXME">
    <img src="https://img.shields.io/badge/Open_Review-FAccT_2026-violet" alt="OpenReview">
</a>
  <a href="https://arxiv.org/abs/2601.18061">
    <img src="https://img.shields.io/badge/arXiv-2601.18061-b31b1b.svg" alt="arXiv">
</a>
</p>

---

This repository contains the dataset and code for the paper "Expert Evaluation and the Limits of Human Feedback in Mental Health AI Safety Testing" published in the ACM Conference on Fairness, Accountability, and Transparency (FAccT) 2026. The dataset contains the human-generated prompts, model-generated responses, and expert evaluations used in the study.