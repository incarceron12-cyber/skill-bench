# XpertBench

Project homepage materials for **XpertBench: Expert Level Tasks with Rubrics-Based Evaluation**.

- Project page: `docs/index.html`
- ArXiv: https://arxiv.org/abs/2604.02368
- Blog / leaderboard: https://xpert.bytedance.com/leaderboard?id=ExpertLevelTask
- Hugging Face release entry: https://huggingface.co/ByteSeedXpert

This repository is intentionally reduced to a static GitHub Pages homepage. It does not include evaluation code.
