# Phase 7 Research — CrewAI Adapter

**Date:** 2026-07-07
**Verdict: GO-WITH-SCOPE.** Third framework adapter (`car.adapters.crewai`), same triple as the
shipped adapters (Recorder + Policy + ToolEnvironment), held to the same `verify_reconstruction`
invariant. Scope: **crewai 1.15.x, the default experimental `AgentExecutor`, native
tool-calling mode, one tool call per assistant turn** — everything else detected and refused
loudly (§7), never silently mis-recorded.
**Method:** the two web-research agents stalled, so all findings below were read directly from
the **crewai 1.15.1 wheel source** (PyPI, unzipped locally) — every claim is verified-in-source
with file:line refs. This is stronger evidence than docs, and it exposed two facts the docs
don't state (§2.3, §2.4).

---

## 1. Capture surface: a `BaseLLM` wrapper (decision)

The executor calls `llm.call(messages, tools=…, available_functions=None, …)` once per loop
iteration with the **full accumulated message history** (`get_llm_response`,
utilities/agent_utils.py:461-511; native call site experimental/agent_executor.py:1479-1491).
`available_functions=None` means **the LLM returns tool calls; the executor executes them** —
so a wrapping `BaseLLM` subclass sees exactly one action per model call, the same shape as the
OpenAI Agents adapter's wrapped `Model`. Wrap-the-LLM also sidesteps `LLM.__new__`'s factory
routing (llm.py:393-486 returns *native provider classes* for most model strings — hooking
`crewai.llm.LLM.call` would miss them; wrapping the user's *instance* catches everything).

Rejected alternatives:
- **Event bus** — lossy where it matters most: when `call()` returns tool_calls to the caller
  (the standard executor path) it returns at llm.py:1300-1301 *without* emitting
  `LLMCallCompletedEvent`; started-events carry pre-normalization messages. Not reconstructable.
- **before/after LLM-call hooks** — see request and response in separate hooks, can be mutated
  by other hooks in between (`_prepare_llm_call` re-reads `executor_context.messages` after
  before-hooks, agent_utils.py:421-425), and are skipped for some calls. The wrapper sees
  request+response atomically at the exact wire boundary.
- **step_callback** — fires with different payload types (text mode fires twice per step), no
  per-call message context.

`BaseLLM` (llms/base_llm.py:129) is a pydantic model; the only abstract method is
`call(messages, tools=None, callbacks=None, available_functions=None, from_task=None,
from_agent=None, response_model=None)`; `acall` has the same signature (not abstract,
default-raises `NotImplementedError`). The wrapper implements both, delegates to the inner LLM,
and must also delegate `supports_function_calling()` (NOT defined on `BaseLLM` — the executor
probes it with `hasattr`, agent_utils.py:1267-1282), `supports_stop_words()`, and
`get_context_window_size()`.

## 2. Executor + message-format facts (the load-bearing findings)

1. **`CrewAgentExecutor` is deprecated and NOT the default.** A plain `Agent(...)` uses
   `crewai.experimental.agent_executor.AgentExecutor` (`executor_class` field default,
   agent/core.py:337-344; a Flow-based state machine, one `llm.call` per iteration in both
   modes). Opting into the deprecated executor emits a `DeprecationWarning`.
2. **Mode selection:** native tool-calling iff `llm.supports_function_calling()` and the agent
   has tools (agent_utils.py:1267-1282); ReAct text parsing is the fallback (and a mid-run
   downgrade path exists on provider errors, agent_executor.py:249-264).
3. **Native-mode message frames on the default executor are exactly CAR-shaped** (this is what
   makes the adapter clean): seeding `[{role:system, cache_breakpoint:True},
   {role:user, cache_breakpoint:True}]` (agent_executor.py:2764-2784), then per step ONE
   assistant message `{"role":"assistant","content":None,"tool_calls":[{"id","type":"function",
   "function":{"name","arguments":<json str>}}]}` (1667-1696) + one
   `{"role":"tool","tool_call_id","name","content"}` per call (1752-1758) — **no
   post-tool-reasoning nudge in native mode** (the nudge exists only in text mode, 1639-1644).
   The final answer is appended as a plain assistant message (rstripped).
   The **deprecated** executor's native mode DOES append a constant
   `{"role":"user"}` nudge (i18n `post_tool_reasoning`) after every tool round
   (crew_agent_executor.py:778-784, 801-806) — a triple, not a pair → detected and refused.
4. **ReAct/text mode is structurally incompatible with the step-pair invariant**: the
   observation is string-concatenated *into the same assistant message* as the model's
   Thought/Action text (`formatted_answer.text += f"\nObservation: {result}"`,
   agent_utils.py:616), plus a nudge user message per step on the experimental executor →
   refused in v1.
5. `llm.call` receives the **live** `state.messages` list (agent_utils.py:424) and mutates
   message dicts in place (o1 role rewrite llm.py:1830-1834; `files` processing 2164-2211) —
   the recorder must **deep-copy** at capture time.
6. **Sampling params are not call args.** Temperature etc. live on the LLM instance; stop
   words are applied via a contextvar override **keyed by `id(llm)`** wrapping the whole
   kickoff (`_llm_stop_words_applied`, agent_executor.py:2792; `call_stop_override`,
   llms/base_llm.py:93-115). Since the executor overrides the *wrapper's* id, naive delegation
   would silently drop stop words — the wrapper re-applies its effective `stop_sequences` to
   the inner LLM via the same contextmanager, and records them in `State.sampling`.
7. **Streaming drops tool-call ids** (reconstructed `ChatCompletionDeltaToolCall` without `id`,
   llm.py:979-992) and can splice tool results into text → `stream=True` inner LLMs refused.
8. Nondeterministic call-ids exist on some providers (fallback `f"call_{id(obj)}"`, always for
   Gemini — agent_utils.py:1191-1231): harmless for replay (ids are linkage only), but Gemini
   batches also attach `raw_tool_call_parts` (non-JSON `Part` objects) to the assistant message
   (agent_executor.py:1694-1695) → refused.

## 3. SCM mapping (the projection)

Recorded at every wrapped `call()`/`acall()`, after deep-copying:

- `State.system_prompt` ← `messages[0]["content"]` when `messages[0]["role"] == "system"`.
- `State.messages` ← the remaining messages with the `cache_breakpoint` key **stripped** — the
  LLM layer strips it before the wire (`_format_messages`, base_llm.py:745-782), so the
  stripped form IS the model-visible request. First entry is then exactly one
  `{"role":"user"}` message, as `verify_reconstruction` requires. This is a *logical/executor-
  level* projection, the same altitude as the LangChain adapter: provider-internal rewrites
  (o1 system→assistant, the Anthropic leading-"." injection, llm.py:2318-2320) happen below it.
- `State.tool_schemas` ← the `tools` call arg verbatim (OpenAI function schemas with
  `"strict": True` and **sanitized, deduped names**, built by `convert_tools_to_openai_schema`,
  agent_utils.py:154-221).
- `State.sampling` ← effective `stop_sequences` at call time + the inner LLM's non-None
  sampling attrs (temperature, top_p, seed, max_tokens, …). `State.model` ← inner `model`;
  provider `"crewai"`.
- `Action` ← the delegated response: `str` → `kind="final"`; a tool-call list → exactly one
  call (else refuse) parsed with the framework's own `extract_tool_call_info`
  (agent_utils.py:1191-1231) so `(call_id, sanitized name, args)` match what the executor
  appends; `Action.raw` mirrors the executor's assistant dict
  (`{"role":"assistant","content":None,"tool_calls":[…]}`, arguments as JSON string) so the
  codec rebuild is digest-identical to the next call's captured history.
- `Observation` ← harvested from later calls' `{"role":"tool"}` messages by `tool_call_id`
  (`name` → `tool_name`, `content` → `result`, `source="real"`) — the same
  harvest-from-next-turn pattern as the OpenAI Agents recorder.

## 4. Codec

CrewAI's native wire format IS the LangChain OpenAI projection: the tool message
`{"role","tool_call_id","name","content"}` matches `LangChainProjectionCodec.tool_result_message`
field-for-field, and the assistant shape matches `OpenAICodec.assistant_message` (content `None`
preserved). So `CrewAICodec(LangChainProjectionCodec)` with **zero method overrides** — defined
for documentation + a distinct `codec_for("crewai")` branch, pure dict shaping in core
`recorder.py` (no crewai import), per the established convention. `forge_action` inherits the
OpenAI shape (`id="call_forced"`).

## 5. Policy

`CrewAIPolicy(inner_llm, tools=…)`: rebuild `[{role:system}] + deepcopy(state.messages)`
(no nudges to re-insert on the default executor; `cache_breakpoint` is model-invisible so not
re-added), re-apply recorded stop via `call_stop_override(inner, stop)`, then
`await asyncio.to_thread(inner.call, messages, tools=state.tool_schemas or None,
available_functions=None)` — crewai's `call` is sync (litellm/native SDKs); `to_thread` keeps
CAR's concurrent rollouts non-blocking. Parse mirrors the recorder (one tool call or final;
BaseModel → `model_dump_json()` as final text, matching the executor at
agent_executor.py:1506-1517).

## 6. ToolEnvironment

`CrewAIToolEnvironment(tools)`: builds `(schemas, available_functions, name→tool map)` with
crewai's own `convert_tools_to_openai_schema` — reusing the framework's name sanitization +
`_2`/`_3` dedup instead of reimplementing it. `observe()` looks up the **sanitized** name,
runs `fn(**args)` in a thread, and formats with `format_native_tool_output_for_agent`
(agent_utils.py:1386-1396) so counterfactual observations are formatted exactly like recorded
ones. Disclosed bypasses (branch = real re-execution): the in-memory tool cache, tool-call
hooks, and `max_usage_count` accounting are NOT replayed.

## 7. Refuse-list (each detected, raises `ReplayError`; PLAN.md §0.9 no-silent-failures)

- **>1 tool call per assistant turn** (parallel batches are routine on the experimental
  executor — "parallel tool calls" refusal, same contract as the other adapters).
- **ReAct/text mode**, incl. mid-run native→text downgrade: detected via inner LLM
  `supports_function_calling()` false, tool-less calls after tool-ful ones, the downgrade
  instruction message, or the i18n `post_tool_reasoning` nudge in history (which also catches
  the deprecated `CrewAgentExecutor`'s native triple).
- **Streaming inner LLMs** (`stream=True`), **multimodal** (`files` key), **Gemini
  `raw_tool_call_parts`**, **context-length summarization** (rewrites history destructively —
  caught by the first-message invariant plus an explicit shrink check), **max-iter forced
  final** (that call arrives without tools and its frame is never persisted,
  agent_executor.py:1362), **planning mode**, **HITL** (effectively unsupported by the
  experimental executor anyway — `_invoke_loop` missing → AttributeError), and
  **`result_as_answer` short-circuits** (leave unpaired `tool_calls` → the standard
  "no recorded output for call_id" refusal).

## 8. Version pin + internal-API exposure

The adapter imports `crewai.llms.base_llm.BaseLLM` (public custom-LLM surface) and three
utilities (`convert_tools_to_openai_schema`, `extract_tool_call_info`,
`format_native_tool_output_for_agent`) plus `call_stop_override` — the latter four are
internal-ish, so pin **`crewai>=1.15,<1.16`** (precedent: openai-agents pinned to one 0.x
minor for the same reason). Revisit the pin on the next crewai minor.

## 9. Fidelity notes for the writeup

- The recorded projection is the executor-level logical request; provider-layer rewrites
  (o1, Anthropic ".") sit below it — identical altitude to the LangChain adapter's
  `convert_to_openai_messages` projection, and replay routes through the same inner LLM so
  those rewrites re-apply identically on branches.
- Observation strings are **not** pure functions of tool output on the deprecated executor
  (every-3rd-use scaffold re-append, tool_usage.py:709-726) — another reason its runs are out
  of scope; the experimental executor's `format_native_tool_output_for_agent` path is pure.
- Tool names in actions are the **sanitized** names (string_utils.py:26-46); the environment
  resolves them via the framework's own mapping, so user tools with exotic names still bind.

## 10. Test-harness facts (offline, scripted, no keys)

- `Agent(llm=<BaseLLM instance>)` passes through `create_llm` **untouched** (identity for
  `BaseLLM`/`LLM` instances, utilities/llm_utils.py:26-27); `create_agent_executor` hands the
  same object to the executor — wrapper state survives a kickoff. Copy paths
  (`kickoff_for_each`, `train`, `test`, `Crew.copy`) shallow-copy the llm → out of scope.
- A scripted test LLM subclassing `BaseLLM` MUST define `supports_function_calling() -> True`
  (not on the base class; absence silently downgrades the run to ReAct text mode).
- Defaults are clean for a recorded run (Crew.memory=False, planning=False, no guardrails,
  human_input=False) **except the tool cache: `Crew.cache=True` AND `Agent.cache=True` by
  default** (shared `CacheHandler`, keyed `f"{tool}-{json.dumps(args)}"`). Tests and recorded
  demos set `cache=False` on both; the adapter's ToolEnvironment never consults it.
- Task prompt = `task.description + "\n" + expected_output slice`; it arrives as the single
  first user message `"\nCurrent Task: {task_prompt}"` (rstripped). System prompt in native
  mode is the `role_playing` slice only: `"You are {role}. {backstory}\nYour personal goal
  is: {goal}"`.
- `Crew.kickoff()` is sync; `kickoff_async` is a thread wrapper; inside a running event loop
  the executor auto-switches to its async path — async tests drive
  `asyncio.to_thread(crew.kickoff)` for the sync recorder path.
- Do NOT register global `after_llm_call` hooks in-process: in 1.15.1 they coerce native
  tool-call list responses through `str()` (agent_utils.py:1744-1795), corrupting the run.

## Sources

crewai 1.15.1 wheel (PyPI, 2026-07-07): experimental/agent_executor.py,
agents/crew_agent_executor.py, agents/parser.py, llm.py, llms/base_llm.py, llms/cache.py,
tools/base_tool.py, tools/structured_tool.py, tools/tool_usage.py, agents/tools_handler.py,
utilities/agent_utils.py, utilities/prompts.py, utilities/types.py, translations/en.json,
agent/core.py. All line refs above are into that wheel.
