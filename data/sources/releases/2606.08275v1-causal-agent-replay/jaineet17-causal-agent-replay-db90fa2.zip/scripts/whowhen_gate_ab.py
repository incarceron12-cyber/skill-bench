"""Offline A/B of ci_locus GATING statistics on stored Who&When rollouts (zero new compute).

The Phase-6 finding: the CI-gated locus rule abstains on 82% of instances at K<=8. Hypothesis
tested here: the gate, not just K, was at fault — "CI excludes 0" tests the wrong null, since
run-forward stochasticity rescues even non-causal steps at a background rate estimable by
pooling the ~750 recorded agent steps.

VERDICT (adversarially verified; see RESEARCH/phase_6_benchmark.md addendum): the hypothesis
does NOT survive honest null decontamination. Excluding each instance's argmax step gives
p0 = 0.031, but that removes the maximum order statistic, not the true locus — a signal-free
simulation reproduces 0.031 from selection bias alone. The honest, ground-truth-decontaminated
null (excluding label steps) is p0 = 0.0495, under which the exact-binomial gate at alpha=0.05
fires 23/121 — indistinguishable from the shipped CLT gate's 22/121. The deeper, load-bearing
finding is the UNCONDITIONAL label-step effect distribution: most annotated mistake steps are
never rescued at all at K<=8 with this surrogate, so no K fixes abstention — the binding
constraint is surrogate rescue ability (or, per MP-Bench, the annotation itself not being the
counterfactual locus).

This script prints the honest version of every number the addendum cites:
  - pooled / label-excluded / argmax-excluded (BIASED, shown for the record) nulls
  - gate A/B under BOTH the label-excluded and biased nulls (null sensitivity)
  - overdispersion: empirical per-step false-fire rate of the r>=2 rule vs its nominal level
  - argmax comparison with MATCHED (latest-max) tie-breaking on the fired subset
  - power on the unconditional label-step effect distribution (plug-in and Jeffreys-smoothed)

Caveat: all analysis is post hoc on the 121 evaluation instances (disclosed exploratory model
selection); the label-excluded null requires ground truth and is an offline diagnostic, not a
deployable gate.

    uv run python scripts/whowhen_gate_ab.py
"""

from __future__ import annotations

import json
from pathlib import Path

import typer
from scipy.stats import binom as binom_dist

REPO_ROOT = Path(__file__).resolve().parent.parent
app = typer.Typer(add_completion=False)


def _load(results: Path) -> list[dict]:
    last: dict[str, dict] = {}
    for line in results.read_text().splitlines():
        if line.strip():
            r = json.loads(line)
            last[r["instance_id"]] = r
    return [r for r in last.values() if "error" not in r]


def _agent_steps(row: dict) -> list[dict]:
    out = []
    for s in row.get("per_step", []):
        if s["env"]:
            continue
        k = int(s["k"])
        rescues = max(0, min(k, round((1.0 - float(s["p_fail"])) * k)))
        out.append({**s, "k": k, "r": rescues})
    return out


def _argmax_step(row: dict, latest: bool = False) -> int | None:
    steps = _agent_steps(row)
    if not steps:
        return None
    best = max(s["r"] / s["k"] for s in steps if s["k"])
    at_best = [s["i"] for s in steps if s["k"] and s["r"] / s["k"] == best]
    return at_best[-1] if latest else at_best[0]


def _pooled_null(rows: list[dict], exclude: str) -> float:
    total_r = total_k = 0
    for row in rows:
        skip = {
            "none": set(),
            "argmax": {_argmax_step(row)},
            "label": {row["label_step"]},
        }[exclude]
        for s in _agent_steps(row):
            if s["i"] in skip:
                continue
            total_r += s["r"]
            total_k += s["k"]
    return total_r / total_k if total_k else 0.0


def _pvalue(r: int, k: int, p0: float) -> float:
    return float(binom_dist.sf(r - 1, k, p0)) if r > 0 else 1.0


def gate_ci2(row: dict, p0: float, alpha: float) -> int | None:
    locus = None
    for s in _agent_steps(row):
        if s["ci"][1] < 0.0 and s["r"] > 0:
            locus = s["i"]
    return locus


def gate_binom(row: dict, p0: float, alpha: float) -> int | None:
    locus = None
    for s in _agent_steps(row):
        if _pvalue(s["r"], s["k"], p0) < alpha:
            locus = s["i"]
    return locus


def _crit(k: int, p0: float, alpha: float) -> int | None:
    return next((r for r in range(1, k + 1) if _pvalue(r, k, p0) < alpha), None)


@app.command()
def main(
    results: Path = typer.Option(REPO_ROOT / "data" / "whowhen" / "results_ag.jsonl"),
) -> None:
    ok = _load(results)
    steps_n = sum(len(_agent_steps(r)) for r in ok)
    p0_all = _pooled_null(ok, "none")
    p0_label = _pooled_null(ok, "label")
    p0_argmax = _pooled_null(ok, "argmax")
    typer.echo(
        f"{len(ok)} instances, {steps_n} agent steps\n"
        f"pooled null p0={p0_all:.4f} | label-excluded (honest, needs GT) p0={p0_label:.4f} | "
        f"argmax-excluded p0={p0_argmax:.4f}  <- BIASED LOW (order-statistic selection)"
    )

    def agent_at(row: dict, step: int | None) -> str | None:
        for s in row.get("per_step", []):
            if s["i"] == step:
                return str(s["agent"])
        return None

    def hits(row: dict, pred: int | None) -> tuple[bool, bool]:
        if pred is None:
            return False, False
        return (agent_at(row, pred) == row["label_agent"], pred == row["label_step"])

    n = len(ok) or 1
    typer.echo(
        f"\n{'gate':26s} {'fires':>7s} {'step(all)':>9s} {'step|fired':>10s} {'argmax|fired*':>13s}"
    )
    combos = [
        ("ci2 (shipped, CLT vs 0)", gate_ci2, p0_label, 0.05),
        (f"binom a=.05, p0={p0_label:.3f}", gate_binom, p0_label, 0.05),
        (f"binom a=.10, p0={p0_label:.3f}", gate_binom, p0_label, 0.10),
        (f"binom a=.05, p0={p0_argmax:.3f}(biased)", gate_binom, p0_argmax, 0.05),
    ]
    for name, gate, p0, alpha in combos:
        fired = [(row, gate(row, p0, alpha)) for row in ok]
        fired = [(row, p) for row, p in fired if p is not None]
        nf = len(fired) or 1
        overall = sum(hits(r, p)[1] for r, p in fired)
        sel = overall / nf
        argm = sum(hits(r, _argmax_step(r, latest=True))[1] for r, _p in fired) / nf
        typer.echo(
            f"{name:26s} {len(fired):3d}/{n:<3d} {overall / n:9.1%} {sel:10.1%} {argm:13.1%}"
        )
    typer.echo("(*argmax with MATCHED latest-max tie-breaking, on the gate's fired subset)")

    # Overdispersion: empirical false-fire rate of the r>=2 rule on ground-truth NON-label steps.
    nonlabel = [s for row in ok for s in _agent_steps(row) if s["i"] != row["label_step"]]
    ff = sum(s["r"] >= 2 for s in nonlabel) / (len(nonlabel) or 1)
    nominal = float(binom_dist.sf(1, 8, p0_label))
    typer.echo(
        f"\noverdispersion: r>=2 fires on {ff:.1%} of {len(nonlabel)} non-label steps "
        f"(nominal binomial at p0={p0_label:.4f}, k=8: {nominal:.1%}) — pooled binomial nulls "
        f"are anti-conservative on this data"
    )

    # Power on the UNCONDITIONAL label-step effect distribution (no selection on detection).
    label_effects = [
        (s["r"], s["k"]) for row in ok for s in _agent_steps(row) if s["i"] == row["label_step"]
    ]
    zeros = sum(r == 0 for r, _k in label_effects)
    mean_p1 = sum(r / k for r, k in label_effects) / (len(label_effects) or 1)
    typer.echo(
        f"\nlabel-step effect distribution (n={len(label_effects)}): "
        f"{zeros}/{len(label_effects)} = {zeros / len(label_effects):.0%} have ZERO rescues at "
        f"K<=8; mean rescue rate {mean_p1:.3f}, median 0.00 — most annotated mistake steps are "
        f"never rescued by this surrogate (or are not the counterfactual locus; MP-Bench)"
    )
    typer.echo(
        f"expected true-locus detection of the exact gate (a=0.05, p0={p0_label:.4f} held "
        f"fixed), averaged over that distribution:"
    )
    typer.echo(f"{'K':>4s} {'plug-in':>8s} {'Jeffreys-smoothed':>18s}")
    for k_new in (8, 16, 32, 64, 128):
        crit = _crit(k_new, p0_label, 0.05)
        if crit is None:
            continue
        plug = sum(float(binom_dist.sf(crit - 1, k_new, r / k)) for r, k in label_effects) / len(
            label_effects
        )
        smooth = sum(
            float(binom_dist.sf(crit - 1, k_new, (r + 0.5) / (k + 1.0))) for r, k in label_effects
        ) / len(label_effects)
        typer.echo(f"{k_new:4d} {plug:8.1%} {smooth:18.1%}")
    typer.echo(
        "(plug-in is biased down by zero-inflation at K<=8 sampling; smoothed biased up — "
        "bracket the truth. No K fixes the zero-rescue majority: the wall is surrogate quality.)"
    )


if __name__ == "__main__":
    app()
