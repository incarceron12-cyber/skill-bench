"""CrewAI adapter: record crew/agent runs, replay them counterfactually.

The capture surface (RESEARCH/phase_7_crewai.md) is a wrapping ``BaseLLM``: CrewAI's default
executor (``crewai.experimental.agent_executor.AgentExecutor``) calls
``llm.call(messages, tools=..., available_functions=None)`` once per loop iteration with the full
accumulated history and expects tool calls *back* — the executor executes tools itself. Wrapping
the user's LLM therefore sees exactly one action per model call, and also catches every provider
(``LLM("gpt-4o")`` is a factory returning native provider classes; the wrapper holds whatever
instance the user built). Wrap it in one line:

    from car.adapters.crewai import CrewAIRecorder

    recorder = CrewAIRecorder(real_llm)
    agent = Agent(role=..., goal=..., backstory=..., llm=recorder, tools=[...])
    Crew(agents=[agent], tasks=[task]).kickoff()
    trajectory = recorder.trajectory("my-run")

Messages are recorded as the executor-level request with the model-invisible
``cache_breakpoint`` markers stripped (the LLM layer strips them before the wire), the leading
``role:"system"`` entry split into ``State.system_prompt``, and tool results harvested from later
calls' ``role:"tool"`` messages by ``tool_call_id`` — CrewAI's native-tool wire format is the
OpenAI projection, so the recording is held to the SAME ``verify_reconstruction`` invariant as
the native recorder via ``codec_for("crewai")``. Stop words are applied by the executor through a
contextvar override keyed by ``id(llm)`` — i.e. keyed to THIS wrapper — so the wrapper re-applies
its effective stop list to the inner LLM and records it in ``State.sampling``.

v1 scope (refused loudly, never silently mis-recorded): native tool-calling mode only (ReAct
text mode fuses observations into assistant text — detected via the post-tool-reasoning nudge,
which also catches the deprecated ``CrewAgentExecutor``); one tool call per assistant turn;
single-agent runs; non-streaming LLMs (streaming drops tool-call ids); no multimodal ``files``,
Gemini ``raw_tool_call_parts``, context-window summarization, max-iter forced finals, planning
mode, or ``result_as_answer`` short-circuits.
"""

from __future__ import annotations

import asyncio
import copy
import json
from typing import TYPE_CHECKING, Any

import structlog
from pydantic import PrivateAttr

from car.schemas.scm import ReplayError
from car.schemas.trajectory import Action, Observation, Provider, State, Step, Trajectory

try:
    from crewai.llms.base_llm import BaseLLM, call_stop_override
    from crewai.utilities.agent_utils import (
        convert_tools_to_openai_schema,
        extract_tool_call_info,
        format_native_tool_output_for_agent,
        is_tool_call_list,
    )
    from crewai.utilities.i18n import I18N_DEFAULT
except ImportError as exc:  # pragma: no cover - exercised only without the extra
    raise ImportError(
        "the CrewAI adapter needs the optional extra: pip install 'causal-agent-replay[crewai]'"
    ) from exc

if TYPE_CHECKING:
    from collections.abc import Sequence

    from crewai.tools.base_tool import BaseTool

log = structlog.get_logger(__name__)

_PARALLEL_REFUSAL = (
    "the model emitted {n} parallel tool calls in one turn; CAR v1 models one action per step "
    "(PLAN.md s5.1). Prompt the agent to act sequentially, or use tools one at a time."
)
_POST_TOOL_NUDGE = I18N_DEFAULT.slice("post_tool_reasoning")
_SAMPLING_ATTRS = (
    "temperature",
    "top_p",
    "seed",
    "max_tokens",
    "frequency_penalty",
    "presence_penalty",
    "n",
)


def _project_messages(messages: Sequence[Any]) -> list[dict[str, Any]]:
    """Deep-copied, model-visible projection of an executor message list; refuses scope edges."""
    projected: list[dict[str, Any]] = []
    for item in messages:
        if not isinstance(item, dict):
            raise ReplayError(f"cannot normalize message of type {type(item).__name__}")
        if "files" in item:
            raise ReplayError("multimodal 'files' messages are outside the v1 adapter scope")
        if "raw_tool_call_parts" in item:
            raise ReplayError(
                "provider-native tool-call parts (Gemini) are outside the v1 adapter scope"
            )
        msg = copy.deepcopy({k: v for k, v in item.items() if k != "cache_breakpoint"})
        tool_calls = msg.get("tool_calls")
        if isinstance(tool_calls, list) and len(tool_calls) > 1:
            raise ReplayError(_PARALLEL_REFUSAL.format(n=len(tool_calls)))
        if msg.get("role") == "user" and msg.get("content") == _POST_TOOL_NUDGE:
            raise ReplayError(
                "found CrewAI's post-tool-reasoning nudge in history: this run used text/ReAct "
                "tool calling or the deprecated CrewAgentExecutor, outside the v1 adapter scope "
                "(RESEARCH phase_7 s7)"
            )
        projected.append(msg)
    return projected


def _action_from_response(response: Any) -> Action:
    """Parse an LLM return value the way the executor does (RESEARCH phase_7 s3)."""
    if isinstance(response, list) and response and is_tool_call_list(response):
        if len(response) > 1:
            raise ReplayError(_PARALLEL_REFUSAL.format(n=len(response)))
        info = extract_tool_call_info(response[0])
        if info is None:
            raise ReplayError(
                f"unrecognized tool-call format {type(response[0]).__name__} in LLM response"
            )
        call_id, name, args = info
        arguments = args if isinstance(args, str) else json.dumps(args)
        try:
            tool_args = json.loads(arguments)
        except json.JSONDecodeError as exc:
            raise ReplayError(f"tool call {name!r} carries non-JSON arguments: {exc}") from exc
        if not isinstance(tool_args, dict):
            raise ReplayError(f"tool call {name!r} arguments are not an object: {arguments!r}")
        return Action(
            kind="tool_call",
            text=None,
            tool_name=name,
            tool_args=tool_args,
            raw={
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": str(call_id),
                        "type": "function",
                        "function": {"name": name, "arguments": arguments},
                    }
                ],
            },
        )
    if isinstance(response, str):
        text = response
    else:
        # Pydantic structured output (no-tools agents) or unknown: mirror AgentFinish coercion.
        dump = getattr(response, "model_dump_json", None)
        text = str(dump()) if callable(dump) else str(response)
    return Action(kind="final", text=text, raw={"role": "assistant", "content": text})


class CrewAIRecorder(BaseLLM):
    """Wraps the agent's ``BaseLLM`` and records each model call into a CAR ``Trajectory``.

    One recorder instance records one run; call :meth:`trajectory` to consume it (or
    :meth:`reset` to discard). Both ``call`` and ``acall`` are implemented, so ``kickoff`` and
    ``kickoff_async`` both record. The inner LLM emits its own events unchanged.
    """

    inner: BaseLLM

    _pending: list[tuple[dict[str, Any], Action]] = PrivateAttr(default_factory=list)
    _observations: dict[str, Observation] = PrivateAttr(default_factory=dict)
    _saw_tools: bool = PrivateAttr(default=False)
    _history_len: int = PrivateAttr(default=0)

    def __init__(self, inner: BaseLLM, **kwargs: Any) -> None:
        super().__init__(
            inner=inner,
            model=inner.model,
            provider=inner.provider,
            stop=list(inner.stop),
            **kwargs,
        )

    # -- capability probes the executor reads off the llm object --------------------------------
    def supports_function_calling(self) -> bool:
        probe = getattr(self.inner, "supports_function_calling", None)
        return bool(probe()) if callable(probe) else False

    def supports_stop_words(self) -> bool:
        return self.inner.supports_stop_words()

    def get_context_window_size(self) -> int:
        return self.inner.get_context_window_size()

    # -- model boundary --------------------------------------------------------------------------
    def call(
        self,
        messages: str | list[Any],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: Any | None = None,
    ) -> str | Any:
        state_kwargs = self._snapshot(messages, tools)
        with call_stop_override(self.inner, list(state_kwargs["sampling"]["stop"])):
            response = self.inner.call(
                messages,
                tools=tools,
                callbacks=callbacks,
                available_functions=available_functions,
                from_task=from_task,
                from_agent=from_agent,
                response_model=response_model,
            )
        self._pending.append((state_kwargs, _action_from_response(response)))
        return response

    async def acall(
        self,
        messages: str | list[Any],
        tools: list[dict[str, Any]] | None = None,
        callbacks: list[Any] | None = None,
        available_functions: dict[str, Any] | None = None,
        from_task: Any | None = None,
        from_agent: Any | None = None,
        response_model: Any | None = None,
    ) -> str | Any:
        state_kwargs = self._snapshot(messages, tools)
        with call_stop_override(self.inner, list(state_kwargs["sampling"]["stop"])):
            response = await self.inner.acall(
                messages,
                tools=tools,
                callbacks=callbacks,
                available_functions=available_functions,
                from_task=from_task,
                from_agent=from_agent,
                response_model=response_model,
            )
        self._pending.append((state_kwargs, _action_from_response(response)))
        return response

    # -- assembly --------------------------------------------------------------------------------
    def trajectory(self, trajectory_id: str) -> Trajectory:
        """Assemble the recorded run; raises (never guesses) if it wasn't a clean tool loop."""
        if not self._pending:
            raise ReplayError("nothing recorded — was the recorder set as the agent's llm?")
        observations = dict(self._observations)
        steps: list[Step] = []
        final_output: str | None = None
        for index, (state_kwargs, action) in enumerate(self._pending):
            state = State(**state_kwargs)
            if action.kind == "final":
                if index != len(self._pending) - 1:
                    raise ReplayError(
                        f"model call {index} produced a final answer but the run continued — "
                        f"not a single-agent tool loop CAR v1 can certify"
                    )
                steps.append(Step(index=index, state_before=state, action=action, observation=None))
                final_output = action.text or ""
                continue
            call_id = str(action.raw["tool_calls"][0]["id"])
            observation = observations.pop(call_id, None)
            if observation is None:
                raise ReplayError(
                    f"step {index}: no recorded tool result for tool_call id {call_id!r} "
                    f"(interrupted run, result_as_answer short-circuit, or a non-linear loop)"
                )
            steps.append(
                Step(index=index, state_before=state, action=action, observation=observation)
            )
        if final_output is None:
            raise ReplayError(
                "the run never produced a final answer; refusing a truncated trajectory (s0.9)"
            )
        log.info("recorded crewai run", trajectory_id=trajectory_id, n_steps=len(steps))
        return Trajectory(trajectory_id=trajectory_id, steps=steps, final_output=final_output)

    def reset(self) -> None:
        self._pending.clear()
        self._observations.clear()
        self._saw_tools = False
        self._history_len = 0

    # -- internals -------------------------------------------------------------------------------
    def _snapshot(
        self, messages: str | list[Any], tools: list[dict[str, Any]] | None
    ) -> dict[str, Any]:
        if getattr(self.inner, "stream", False):
            raise ReplayError(
                "streaming LLMs drop tool-call ids and cannot be recorded faithfully — "
                "construct the LLM with stream=False (RESEARCH phase_7 s2.7)"
            )
        raw_messages: list[Any] = (
            [{"role": "user", "content": messages}] if isinstance(messages, str) else messages
        )
        projected = _project_messages(raw_messages)
        self._harvest_observations(projected)
        system_prompt = ""
        if projected and projected[0].get("role") == "system":
            system_prompt = str(projected[0].get("content") or "")
            projected = projected[1:]
        if len(projected) < self._history_len:
            raise ReplayError(
                "message history shrank between model calls — context-window summarization "
                "rewrites history destructively and is outside the v1 adapter scope"
            )
        self._history_len = len(projected)
        tool_schemas = [copy.deepcopy(dict(t)) for t in (tools or [])]
        if tool_schemas:
            self._saw_tools = True
        elif self._saw_tools:
            raise ReplayError(
                "a model call arrived without tools after tool-calling turns — a max-iter "
                "forced final answer or a native->text downgrade; outside the v1 adapter scope"
            )
        sampling: dict[str, Any] = {"stop": list(self.stop_sequences)}
        for attr in _SAMPLING_ATTRS:
            value = getattr(self.inner, attr, None)
            if value is not None:
                sampling[attr] = value
        return {
            "system_prompt": system_prompt,
            "tool_schemas": tool_schemas,
            "model": self.inner.model,
            "provider": "crewai",
            "sampling": sampling,
            "messages": projected,
        }

    def _harvest_observations(self, projected: Sequence[dict[str, Any]]) -> None:
        for msg in projected:
            if msg.get("role") == "tool":
                call_id = str(msg.get("tool_call_id"))
                if call_id not in self._observations:
                    self._observations[call_id] = Observation(
                        tool_name=str(msg.get("name") or ""),
                        result=str(msg.get("content") or ""),
                        source="real",
                    )


class CrewAIPolicy:
    """pi(a | context) over a CrewAI ``BaseLLM`` — what CAR resamples during replay.

    Rebuilds the executor-level request from a recorded ``State`` (system prompt re-attached as
    the leading system message), re-applies the recorded stop words through CrewAI's own
    contextvar override, and re-invokes the LLM in a worker thread (``call`` is sync).
    """

    provider: Provider = "crewai"

    def __init__(self, llm: BaseLLM, *, model_id: str | None = None) -> None:
        if getattr(llm, "stream", False):
            raise ReplayError(
                "streaming LLMs drop tool-call ids — construct the replay LLM with stream=False"
            )
        self._llm = llm
        self._model_id = model_id or llm.model

    @property
    def model_id(self) -> str:
        return self._model_id

    async def sample(self, state: State) -> Action:
        messages: list[Any] = []  # LLMMessage-shaped dicts (crewai types them as a TypedDict)
        if state.system_prompt:
            messages.append({"role": "system", "content": state.system_prompt})
        messages.extend(copy.deepcopy(m) for m in state.messages)
        tools = [copy.deepcopy(dict(t)) for t in state.tool_schemas] or None
        stop = list(state.sampling.get("stop") or [])

        def _invoke() -> Any:
            with call_stop_override(self._llm, stop):
                return self._llm.call(
                    messages,
                    tools=tools,
                    callbacks=None,
                    available_functions=None,
                    from_task=None,
                    from_agent=None,
                    response_model=None,
                )

        return _action_from_response(await asyncio.to_thread(_invoke))


class CrewAIToolEnvironment:
    """Live observations on counterfactual branches by re-invoking the agent's real tools.

    Uses CrewAI's own ``convert_tools_to_openai_schema`` for the sanitized-name -> callable
    mapping (actions carry sanitized names) and formats results with the framework's
    ``format_native_tool_output_for_agent`` so counterfactual observations match recorded ones.
    Framework-side tool caching, hooks, and usage limits are deliberately NOT replayed: a branch
    is a real re-execution.
    """

    def __init__(self, tools: Sequence[BaseTool]) -> None:
        _schemas, functions, tool_map = convert_tools_to_openai_schema(list(tools))
        self._functions = functions
        self._tools = tool_map

    async def observe(self, action: Action) -> Observation:
        if action.kind != "tool_call" or action.tool_name is None:
            raise ReplayError(f"environment cannot observe a non-tool action: {action.kind}")
        fn = self._functions.get(action.tool_name)
        if fn is None:
            raise ReplayError(
                f"tool {action.tool_name!r} not among the agent's tools {sorted(self._functions)}"
            )
        raw_result = await asyncio.to_thread(fn, **(action.tool_args or {}))
        result = format_native_tool_output_for_agent(self._tools[action.tool_name], raw_result)
        return Observation(tool_name=action.tool_name, result=result, source="real")


__all__ = [
    "CrewAIPolicy",
    "CrewAIRecorder",
    "CrewAIToolEnvironment",
]
