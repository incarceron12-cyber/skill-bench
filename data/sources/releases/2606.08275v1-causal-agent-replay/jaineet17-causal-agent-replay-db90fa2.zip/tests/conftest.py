"""Test-session environment: keep framework SDKs fully offline.

Set before any test module imports crewai (telemetry/tracing read env at import/kickoff time).
"""

import os

os.environ.setdefault("CREWAI_DISABLE_TELEMETRY", "true")
os.environ.setdefault("CREWAI_TRACING_ENABLED", "false")
os.environ.setdefault("OTEL_SDK_DISABLED", "true")
