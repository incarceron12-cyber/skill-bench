# structureclaw-benchmark

LLM agent benchmark suite for [StructureClaw](https://github.com/structureclaw/structureclaw).

This repo is consumed by the main `structureclaw` repo as a git submodule under
`tests/llm-benchmark/`, but it can also be cloned and run standalone against any
StructureClaw checkout.

## What it does

Runs the LangGraph ReAct agent end-to-end across a corpus of structural-engineering
scenarios (text, multimodal images, DXF reverse-engineering, architectural plans/elevations)
and evaluates them with a compact task taxonomy:

| Task family | Count | Purpose |
| --- | ---: | --- |
| `standard_workflow` | 50 | Clear text request → skill selection → model → analysis |
| `interactive_robustness` | 50 | Missing, invalid, ambiguous, conflicting, or multi-turn inputs |
| `multimodal_reverse_engineering` | 50 | Image, drawing, DXF, and plan reverse-engineering |

These correspond to the A/B/C design split: A = standard workflow,
B = interactive robustness, C = multimodal reverse-engineering. Directory names
use the explicit `taskFamily` values so the JSON metadata and file layout stay
aligned.

Each task family is bilingual-balanced: 25 Chinese scenarios and 25 English
scenarios. `npm run validate:scenarios` enforces the 25/25 split, rejects English
prompts that still contain CJK text, and checks for duplicate normalized prompts
within the same task family, benchmark structure type, and input modality.

Task families describe what the user is asking the agent to do. Evaluation
dimensions stay separate and are expressed as typed assertions:

- `structureType` — runtime structure/skill type (`frame` is the steel-frame skill ID)
- `benchmarkStructureType` — reporting taxonomy (`steel-frame`, `concrete-frame`, `continuous-beam`, ...)
- `structural_type` — inferred runtime structure type (beam / frame / truss / ...)
- `has_model` — produced a computable StructureModel
- `has_analysis` — ran analysis
- `engine_match` — ran analysis with the requested analysis skill/engine
- `has_report` — generated a report
- `skill_match` — routed to the expected skill
- `model_matches` — geometry matches a ground-truth model (node/element counts, span, load)
- `has_interaction_questions` — asked for clarification when input is incomplete
- `should_not_analyze` — did not run analysis for unsafe or under-specified input
- `no_bad_model` — did not create a computable model for unsafe or under-specified input
- `natural_language` — LLM-as-Judge semantic check

Standard steel-frame and concrete-frame scenarios may also request a specific
analysis backend. Use `analysisSkillTarget` for the skill ID and
`analysisEngineTarget` for the runtime engine ID:

| Skill target | Engine target |
| --- | --- |
| `opensees-static` | `builtin-opensees` |
| `pkpm-static` | `builtin-pkpm` |
| `yjk-static` | `builtin-yjk` |

Every scenario uses `maxRetries: 0`, so each scenario is attempted once.
Repeated trials should be represented by running the full experiment multiple
times and aggregating those independent runs.

Each scenario run also has a wall-clock timeout shared by all turns and retries.
The default is 900000 ms (15 minutes) and can be overridden with
`defaults.caseTimeoutMs` in `experiments/llm-experiments.local.json`,
`--case-timeout-ms <milliseconds>`, or `LLM_BENCHMARK_CASE_TIMEOUT_MS`. A
timeout records the run as an execution failure; it does not change scoring
thresholds for normal tool usage.

The experiment wrapper runs cases in supervised mode by default. In supervised
mode each scenario uses a separate child process, so a timed-out case is
isolated from later cases even if an in-flight model request keeps running.
The supervising parent gives the child process an additional grace window after
the case timeout so the child can write its failure result before being killed.
Use `--no-supervise` only for single-process debugging.

- `Pass@1` — passed on the single scenario attempt
- `averageToolCalls` — average agent tool calls per scenario run; this is an
  efficiency signal only, with no pass/fail threshold
- `averageDurationMs` — average wall-clock duration per scenario run

The standard executable workflow split is balanced by `benchmarkStructureType`:

| Benchmark structure type | Count |
| --- | ---: |
| `beam` | 9 |
| `steel-frame` | 12 |
| `concrete-frame` | 6 |
| `truss` | 8 |
| `portal-frame` | 6 |
| `continuous-beam` | 5 |
| `column` | 3 |
| `generic` | 1 |

## Skill modes

The default run uses the real system behavior:

- `auto` — the agent routes and selects skills normally.

For experiment tables, the runner can also expand into controlled skill modes:

- `oracle-specialist` — scopes the run to the scenario's `skillTarget` plus the requested static-analysis skill.
- `generic-only` — scopes the run to the generic structure skill plus the requested static-analysis skill.

These produce the comparison columns used for specialist lift and routing gap:

```text
Specialist Lift = oracle-specialist - generic-only
Routing Gap     = oracle-specialist - auto
```

## Layout

```
fixtures/            # Generated ground-truth models, PNG images, DXF drawings
  ground-truth-models.json
  drawings/          # Rendered PNG + DXF (regenerated by fixtures/*-generator.mjs)
lib/                 # evaluate.cjs, judge.cjs, report.cjs, skill-trace.cjs
scenarios/           # One JSON file per scenario, grouped by task family
  standard_workflow/
  interactive_robustness/
  multimodal_reverse_engineering/
runner.cjs           # Entry point
scripts/             # Experiment runners and helper scripts
```

## Running

### As a submodule (from main structureclaw repo)

```bash
node tests/runner.mjs llm-benchmark                          # all scenarios
node tests/runner.mjs llm-benchmark --scenario beam-simple   # one scenario
node tests/runner.mjs llm-benchmark --mode all                # auto + oracle + generic modes where enabled
node tests/runner.mjs llm-benchmark --family standard_workflow
```

### Standalone

```bash
# 1. Point at a structureclaw checkout (must be built: backend/dist exists)
export SCLAW_ROOT=/path/to/structureclaw
export LLM_API_KEY=sk-...

# 2. Run
node runner.cjs
node runner.cjs --scenario beam-simple --output results.json
node runner.cjs --mode all --output results.json
npm run validate:scenarios
```

The runner reads LLM config (`LLM_API_KEY`, `LLM_MODEL`, `LLM_BASE_URL`) from the
SUT's regression context — see `tests/regression/shared.js` in the main repo.

## Experiment LLM configuration

Use the experiment wrapper when comparing multiple model roles. For normal use,
edit only these three selectors in `experiments/llm-experiments.local.json`:

```json
{
  "testModel": "glm-5-turbo",
  "multimodalModel": "glm-4.5V",
  "judgeModel": "DeepSeek-V4-Pro"
}
```

- `test` — the main agent model used by standard, interactive, and multimodal suites.
- `multimodal` — the vision parser used only before image/drawing scenarios. Its
  output is injected as an attachment summary, then the `test` model runs the
  normal StructureClaw agent/tool workflow. This role maps to `LLM_VISION_MODEL`,
  `LLM_VISION_BASE_URL`, and `LLM_VISION_API_KEY`. Model-specific `extraEnv` may
  also set `LLM_VISION_TEMPERATURE` for providers that require a fixed vision
  request temperature. Vision parsing uses the scenario case timeout; it does
  not apply a separate shorter request timeout.
- `judge` — the LLM-as-Judge model, mapped to `LLM_JUDGE_MODEL`,
  `LLM_JUDGE_BASE_URL`, and `LLM_JUDGE_API_KEY`.

The template config stores model names, base URLs, and the environment variable
that holds each API key. It does not store secrets.

```bash
npm run experiment:init

export ZHIPU_API_KEY=...
export PARATERA_API_KEY=...
export OPENAI_API_KEY=...

npm run experiment:list
npm run experiment -- --suite smoke-text --dry-run
npm run experiment -- --suite smoke-text
npm run experiment -- --suite smoke-multimodal --multimodal-model glm-4.5V --judge-model DeepSeek-V4-Pro
npm run experiment -- --suite standard --test-model glm-5-turbo --judge-model DeepSeek-V4-Pro
npm run experiment -- --suite multimodal --multimodal-model glm-4.5V --judge-model DeepSeek-V4-Pro
```

Available suite names in the example config are `smoke-text`,
`smoke-multimodal`, `standard`, `interactive`, `core`, `multimodal`,
`all-auto`, and `all-modes`. Suites containing image tasks use the `multimodal`
role only for pre-agent vision parsing. Additional runner filters can be appended, for
example:

```bash
npm run experiment -- --suite standard --scenario std-beam-4m-point-mid --mode all
```

Results are written under `results/` by default, with the suite, primary model,
judge model, and timestamp in the file name. Use `--output <file>` to override
the path.

For sequential multi-model comparisons, use the batch wrapper. It expands
`models × modes`, calls the normal experiment wrapper for each pair, writes one
UTF-8 log, and updates a summary JSON after each pair completes:

```bash
npm run experiment:batch -- --suite standard \
  --models glm-5-turbo,glm-5.2,DeepSeek-V4-Pro \
  --modes auto,generic-only \
  --case-timeout-ms 900000 \
  --name standard-domestic-text-all
```

## Regenerating fixtures

Ground-truth models and rendered drawings are committed for reproducibility.
To regenerate after editing the model factory or renderers:

```bash
npm run regen-fixtures
```

## License

MIT
