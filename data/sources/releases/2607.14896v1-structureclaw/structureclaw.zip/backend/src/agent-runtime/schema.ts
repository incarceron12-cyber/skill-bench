import { z } from 'zod';

export const skillExecutionSchema = z.object({
  inferredType: z.string().optional(),
  engineeringDraft: z.record(z.string(), z.unknown()).optional(),
  draftPatch: z.record(z.string(), z.unknown()).optional(),
  skillState: z.record(z.string(), z.unknown()).optional(),
  draftIssues: z.array(z.object({
    field: z.string().optional(),
    value: z.unknown().optional(),
    severity: z.enum(['invalid', 'ambiguous', 'unrealistic', 'conflict']),
    reason: z.string(),
    question: z.string().optional(),
  })).optional(),
  missingCritical: z.array(z.string()).optional(),
  missingOptional: z.array(z.string()).optional(),
  questions: z.array(z.object({
    paramKey: z.string(),
    label: z.string(),
    question: z.string(),
    unit: z.string().optional(),
    required: z.boolean(),
    critical: z.boolean(),
  })).optional(),
  defaultProposals: z.array(z.object({
    paramKey: z.string(),
    value: z.unknown(),
    reason: z.string(),
  })).optional(),
  stage: z.enum(['intent', 'model', 'loads', 'analysis', 'code_check', 'report']).optional(),
  supportLevel: z.enum(['supported', 'fallback', 'unsupported']).optional(),
  supportNote: z.string().optional(),
  routingSource: z.enum(['explicit-keyword', 'current-state', 'llm-suggested', 'generic-fallback']).optional(),
  skillId: z.string().optional(),
});

export type SkillExecutionPayload = z.infer<typeof skillExecutionSchema>;
