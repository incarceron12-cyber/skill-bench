/**
 * LangGraph StateGraph for the StructureClaw ReAct agent.
 *
 * Graph structure:
 *   START → agent (LLM reasoning) → [has tool_calls?]
 *     → Yes  → tools (execute tool) → agent (loop back)
 *     → No   → END (final response)
 *
 * Dependency injection: services are passed via config.configurable
 * (AgentConfigurable) so tools and nodes never read globalThis.
 *
 * Artifact-writing tools return Command({ update }) objects to write
 * directly into graph state channels — no intermediary node needed.
 */
import {
  StateGraph,
  START,
  END,
  type LangGraphRunnableConfig,
} from '@langchain/langgraph';
import { ToolNode } from '@langchain/langgraph/prebuilt';
import { AIMessage, HumanMessage, SystemMessage, ToolMessage, type BaseMessage } from '@langchain/core/messages';
import type { BaseCheckpointSaver } from '@langchain/langgraph';
import { createChatModel } from '../utils/llm.js';
import { AgentStateAnnotation, type AgentState } from './state.js';
import { createRegisteredTools, type AgentToolFactoryDeps, type AgentToolDefinition } from './tool-registry.js';
import { loadUserTools } from './user-tool-loader.js';
import { getWorkspaceToolRoot } from './config.js';
import { buildSystemMessages } from './system-prompt.js';
import type { SkillManifest } from '../agent-runtime/types.js';
import type { AgentConfigurable } from './configurable.js';
import { resolveActiveToolIds } from './tool-policy.js';
import type { StructuredToolInterface } from '@langchain/core/tools';
import { getLogger } from '../utils/agent-logger.js';
import { compactMessagesForContext, estimateMessagesCharLength } from './context-window.js';
import { repairToolMessageProtocol } from './message-protocol.js';

function getAgentLogger(config: LangGraphRunnableConfig) {
  return getLogger(config.configurable as Partial<AgentConfigurable> | undefined);
}

// ---------------------------------------------------------------------------
// Max ReAct iterations guard
// ---------------------------------------------------------------------------

export const DEFAULT_MAX_TOOL_CALLS_PER_TURN = 200;

function getMessageType(message: BaseMessage): string | null {
  return typeof (message as any)._getType === 'function'
    ? (message as any)._getType()
    : null;
}

function extractMessageText(message: BaseMessage): string {
  const content = message.content;
  if (typeof content === 'string') {
    return content;
  }
  if (Array.isArray(content)) {
    return content
      .map((block) => {
        if (typeof block === 'string') return block;
        if (block && typeof block === 'object' && 'text' in block) {
          return String((block as { text?: unknown }).text ?? '');
        }
        return '';
      })
      .join('');
  }
  return content == null ? '' : JSON.stringify(content);
}

function getToolName(message: BaseMessage): string | undefined {
  return typeof (message as any).name === 'string' && (message as any).name.trim().length > 0
    ? (message as any).name
    : undefined;
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined;
}

function buildAiMessageFields(content: unknown, name: unknown, source: Record<string, unknown>): Record<string, unknown> {
  const fields: Record<string, unknown> = {
    content: typeof content === 'string' ? content : content as any[],
  };
  if (typeof name === 'string' && name.trim().length > 0) fields.name = name;

  const additionalKwargs = asRecord(source.additional_kwargs);
  if (additionalKwargs) fields.additional_kwargs = additionalKwargs;

  const responseMetadata = asRecord(source.response_metadata);
  if (responseMetadata) fields.response_metadata = responseMetadata;

  if (typeof source.id === 'string' && source.id.trim().length > 0) fields.id = source.id;
  if (source.usage_metadata !== undefined) fields.usage_metadata = source.usage_metadata;
  const additionalToolCalls = Array.isArray(additionalKwargs?.tool_calls)
    ? additionalKwargs.tool_calls
    : undefined;
  if (Array.isArray(source.tool_calls) && source.tool_calls.length > 0) fields.tool_calls = source.tool_calls;
  else if (additionalToolCalls && additionalToolCalls.length > 0) fields.tool_calls = additionalToolCalls;
  else if (Array.isArray(source.tool_calls)) fields.tool_calls = source.tool_calls;
  else if (additionalToolCalls) fields.tool_calls = additionalToolCalls;
  if (Array.isArray(source.invalid_tool_calls)) fields.invalid_tool_calls = source.invalid_tool_calls;

  return fields;
}

function hasRestorableAiMetadata(source: Record<string, unknown>): boolean {
  const additionalKwargs = asRecord(source.additional_kwargs);
  return (
    (Array.isArray(source.tool_calls) && source.tool_calls.length > 0)
    || (Array.isArray(additionalKwargs?.tool_calls) && additionalKwargs.tool_calls.length > 0)
    || (additionalKwargs !== undefined && 'reasoning_content' in additionalKwargs)
  );
}

export function buildEmptyFinalResponseFallback(
  locale: 'zh' | 'en',
  toolNames: string[],
): string {
  const tools = [...new Set(toolNames)].filter(Boolean).join(', ');
  if (locale === 'zh') {
    return tools
      ? `本轮工具已执行完成（${tools}），但模型没有生成最终说明。为避免会话静默结束，请基于这些工具结果继续检查当前模型、荷载或分析状态。`
      : '模型没有生成有效回复。为避免会话静默结束，请继续说明你希望检查的结构、荷载或分析状态。';
  }
  return tools
    ? `The tools for this turn completed (${tools}), but the model did not produce a final explanation. To avoid a silent stop, continue from these tool results and inspect the current model, loads, or analysis state.`
    : 'The model did not produce a valid response. To avoid a silent stop, please continue with the structure, load, or analysis state you want to inspect.';
}

export function shouldReplaceEmptyFinalResponse(response: BaseMessage, currentTurnMessages: BaseMessage[]): boolean {
  const hasToolCalls = 'tool_calls' in response
    && Array.isArray((response as any).tool_calls)
    && (response as any).tool_calls.length > 0;
  if (hasToolCalls) {
    return false;
  }
  if (extractMessageText(response).trim().length > 0) {
    return false;
  }
  return currentTurnMessages.some((message) => getMessageType(message) === 'tool');
}

// ---------------------------------------------------------------------------
// Multimodal: strip image binaries from ToolMessages before the main agent LLM.
// Images are summarized by the independent vision model before reaching the main agent.
// ---------------------------------------------------------------------------

const IMAGE_JSON_REGEX = /"type"\s*:\s*"image"/;

function sanitizeImageToolMessages(messages: BaseMessage[]): BaseMessage[] {
  const result: BaseMessage[] = [];
  for (const message of messages) {
    if (getMessageType(message) !== 'tool') {
      result.push(message);
      continue;
    }
    const content = typeof message.content === 'string' ? message.content : '';
    if (!content || !IMAGE_JSON_REGEX.test(content)) {
      result.push(message);
      continue;
    }
    let parsed: Record<string, unknown>;
    try { parsed = JSON.parse(content); } catch { result.push(message); continue; }
    if (parsed.type !== 'image' || typeof parsed.base64DataUri !== 'string') {
      result.push(message);
      continue;
    }

    const rest = { ...parsed };
    delete rest.base64DataUri;
    const sanitizedContent = JSON.stringify({
      ...rest,
      note: 'Image binary omitted from main agent context. Use the existing attachment vision summary, or ask for missing details if no summary is available.',
    });
    result.push(new ToolMessage({
      content: sanitizedContent,
      tool_call_id: (message as any).tool_call_id || '',
      name: (message as any).name,
    }));
  }
  return result;
}

// ---------------------------------------------------------------------------
// Node: agent (LLM reasoning)
// ---------------------------------------------------------------------------

function createCallModelNode(
  skillManifests: SkillManifest[],
  tools: ReturnType<typeof createRegisteredTools>,
) {
  return async function callModel(
    state: AgentState,
    config: LangGraphRunnableConfig,
  ): Promise<Partial<AgentState>> {
    const log = getAgentLogger(config);
    const configurable = config.configurable as Partial<AgentConfigurable> | undefined;
    // LangGraph's `messages` stream mode installs a callback handler that
    // prefers streaming. LangChain may then make `invoke()` return message
    // chunks; GLM-compatible streaming can yield empty/generic chunks after
    // tool calls. Keep graph state on complete AIMessage instances.
    const model = createChatModel(0, { disableStreaming: true });
    if (!model) {
      return {
        messages: [
          new AIMessage(
            state.locale === 'zh'
              ? 'LLM 未配置，无法处理请求。请检查 LLM_API_KEY 设置。'
              : 'LLM is not configured. Please check LLM_API_KEY settings.',
          ),
        ],
      };
    }

    const skillRuntime = configurable?.skillRuntime;
    if (!skillRuntime) {
      return {
        messages: [
          new AIMessage(
            state.locale === 'zh'
              ? '技能运行时未配置。'
              : 'Skill runtime is not configured.',
          ),
        ],
      };
    }

    const activeTools = resolveActiveTools(tools, configurable);
    const modelWithTools = model.bindTools(activeTools);

    // Build system prompt
    const systemMessages = buildSystemMessages({ state, skillManifests, maxToolCallsPerTurn: configurable.maxToolCallsPerTurn });

    // Validate and reconstruct messages — checkpoint deserialization may
    // strip class methods (_getType), leaving plain objects that the LLM API
    // rejects with "role information cannot be empty". Rebuild them here.
    const rawMsgs: BaseMessage[] = Array.isArray(state.messages) ? state.messages : [];
    const msgs: BaseMessage[] = rawMsgs.map((m): BaseMessage | null => {
      if (m == null || typeof m !== 'object') return null;
      // Check if already a proper class instance with a usable role.
      // ChatMessageChunk / ChatMessage with _getType "generic" and missing
      // role must be reconstructed — the LLM provider rejects them.
      if (typeof (m as any)._getType === 'function') {
        const t = (m as any)._getType();
        if (t === 'generic') {
          // ChatMessage(ChatChunk) — treat as AI if role is missing/assistant
          const role = (m as any).role;
          if (role === 'assistant' || !role) {
            const content = typeof m.content === 'string' ? m.content : JSON.stringify(m.content ?? '');
            if (!content && !hasRestorableAiMetadata(m as unknown as Record<string, unknown>)) return null;
            return new AIMessage(buildAiMessageFields(content, (m as any).name, m as unknown as Record<string, unknown>) as any);
          }
        }
        // AIMessageChunk is not a proper AIMessage — convert it so the LLM
        // provider receives a message with a well-defined role.  Chunk
        // instances have undefined .role which causes "角色信息不能为空"
        // errors on some providers (e.g. GLM).
        if (t === 'ai' && !(m instanceof AIMessage)) {
          const content = typeof m.content === 'string' ? m.content : JSON.stringify(m.content ?? '');
          // Skip empty AIMessageChunks — they are streaming artifacts
          // (e.g. the final empty chunk after tool calls) with no value.
          if (!content && !hasRestorableAiMetadata(m as unknown as Record<string, unknown>)) return null;
          return new AIMessage(buildAiMessageFields(content, (m as any).name, m as unknown as Record<string, unknown>) as any);
        }
        return m;
      }
      // Normalize: LangChain serde uses {lc:1, type:"constructor", id:[...], kwargs:{...}}
      const raw = m as unknown as Record<string, unknown>;
      const isLcFormat = raw.lc === 1 && raw.type === 'constructor';
      const plain = isLcFormat ? (raw.kwargs as Record<string, unknown>) ?? {} : raw;
      const lcId = Array.isArray(raw.id) ? (raw.id as string[]).join('/') : '';
      const id = lcId || (plain.id as string) || '';
      const content = plain.content ?? '';
      const name = plain.name as string | undefined;
      if (id.includes('HumanMessage') || plain.role === 'user' || plain.type === 'human') {
        return typeof content === 'string' ? new HumanMessage({ content, name }) : new HumanMessage({ content: content as any[], name });
      }
      if (id.includes('AIMessage') || plain.role === 'assistant' || plain.type === 'ai') {
        return new AIMessage(buildAiMessageFields(content, name, plain) as any);
      }
      if (id.includes('SystemMessage') || plain.role === 'system' || plain.type === 'system') {
        return new SystemMessage(typeof content === 'string' ? content : JSON.stringify(content));
      }
      if (id.includes('ToolMessage') || plain.role === 'tool' || plain.type === 'tool') {
        return new ToolMessage({
          content: typeof content === 'string' ? content : JSON.stringify(content),
          tool_call_id: (plain.tool_call_id as string) || (plain.id as string) || '',
          name,
        });
      }
      // Unknown — skip
      return null;
    }).filter((m): m is BaseMessage => m !== null);

    // Count prior tool calls in this turn to enforce max iterations.
    // Use the original message array so image-binary stripping does not
    // shift the turn boundary or under-count tool calls.
    let lastHumanIndex = -1;
    for (let i = msgs.length - 1; i >= 0; i--) {
      const m = msgs[i];
      if (typeof m === 'object' && m !== null && '_getType' in m && (m as any)._getType?.() === 'human') {
        lastHumanIndex = i;
        break;
      }
    }
    const currentTurnMessages = lastHumanIndex === -1 ? msgs : msgs.slice(lastHumanIndex + 1);
    const toolCallCount = currentTurnMessages.reduce((count, m) => {
      if (
        m != null
        && typeof m === 'object'
        && 'tool_calls' in m
        && Array.isArray((m as any).tool_calls)
      ) {
        return count + (m as any).tool_calls.length;
      }
      return count;
    }, 0);

    const maxToolCalls = configurable?.maxToolCallsPerTurn ?? DEFAULT_MAX_TOOL_CALLS_PER_TURN;
    if (toolCallCount >= maxToolCalls) {
      log.warn({ node: 'agent', toolCallCount, max: maxToolCalls }, 'max tool call limit reached');
      const warning = state.locale === 'zh'
        ? '已达到本轮最大工具调用次数限制。我将根据已有信息给出回复。'
        : 'Reached the maximum tool call limit for this turn. I will respond with the information gathered so far.';
      return { messages: [new AIMessage(warning)] };
    }

    // Inject current state into configurable so tools can read state channels.
    // Tools access it via config.configurable.agentState.
    // IMPORTANT: mutate config.configurable in-place so the ToolNode (which
    // receives the same config object) also sees agentState.
    const configurableAny = config.configurable as Record<string, unknown>;
    configurableAny.agentState = state;

    // Remove base64 image data from ToolMessages before the main agent LLM.
    // Applied after turn-boundary computation so binary payload stripping
    // does not affect tool-call counting or compaction turn detection.
    const effectiveMsgs = sanitizeImageToolMessages(msgs);

    const compaction = compactMessagesForContext({
      messages: effectiveMsgs,
      locale: state.locale,
      baseCharCount: estimateMessagesCharLength(systemMessages),
    });
    if (compaction.compacted) {
      log.warn({
        node: 'agent',
        originalCharCount: compaction.originalCharCount,
        compactedCharCount: compaction.compactedCharCount,
        compactedMessageCount: compaction.compactedMessageCount,
      }, 'agent context compacted before LLM invocation');
    }

    const protocol = repairToolMessageProtocol(compaction.messages);
    if (protocol.repairedCount > 0) {
      log.warn({
        node: 'agent',
        repairedMessageCount: protocol.repairedCount,
      }, 'agent repaired tool-message protocol before LLM invocation');
    }
    const allMessages = [...systemMessages, ...protocol.messages];

    log.info({ node: 'agent', messageCount: allMessages.length, activeToolCount: activeTools.length, toolCallCount, compacted: compaction.compacted }, 'agent node invoking LLM');
    const llmStart = Date.now();
    const response = await modelWithTools.invoke(allMessages, config);
    const llmDuration = Date.now() - llmStart;

    const hasToolCalls = 'tool_calls' in response && Array.isArray((response as any).tool_calls) && (response as any).tool_calls.length > 0;
    log.info({ node: 'agent', durationMs: llmDuration, hasToolCalls }, 'agent node LLM response received');

    if (shouldReplaceEmptyFinalResponse(response, currentTurnMessages)) {
      const toolNames = currentTurnMessages
        .filter((message) => getMessageType(message) === 'tool')
        .map((message) => getToolName(message))
        .filter((name): name is string => !!name);
      log.warn({ node: 'agent', toolNames }, 'empty final LLM response after tool calls');
      return { messages: [new AIMessage(buildEmptyFinalResponseFallback(state.locale, toolNames))] };
    }

    return { messages: [response] };
  };
}

// ---------------------------------------------------------------------------
// Conditional edge: should we continue or end?
// ---------------------------------------------------------------------------

export function shouldContinue(
  state: AgentState,
): 'tools' | typeof END {
  const msgs = Array.isArray(state.messages) ? state.messages : [];
  const lastMessage = msgs[msgs.length - 1];
  const hasToolCalls = (
    lastMessage != null &&
    'tool_calls' in lastMessage &&
    Array.isArray((lastMessage as any).tool_calls) &&
    (lastMessage as any).tool_calls.length > 0
  );
  return hasToolCalls ? 'tools' : END;
}

// ---------------------------------------------------------------------------
// Graph builder
// ---------------------------------------------------------------------------

export interface GraphDeps extends AgentToolFactoryDeps {
  skillManifests: SkillManifest[];
  checkpointer?: BaseCheckpointSaver;
}

function resolveActiveTools(
  tools: StructuredToolInterface[],
  configurable: Partial<AgentConfigurable> | undefined,
): StructuredToolInterface[] {
  const result = resolveActiveToolIds({
    requestedEnabledToolIds: configurable?.enabledToolIds,
    requestedDisabledToolIds: configurable?.disabledToolIds,
    allowShell: configurable?.allowShell ?? false,
  });
  const activeIds = new Set(result.activeToolIds);
  return tools.filter((toolDefinition) => activeIds.has(toolDefinition.name));
}

export async function buildAgentGraph(deps: GraphDeps) {
  const { skillManifests, checkpointer } = deps;

  // Load user-defined tools from workspace
  let userToolDefinitions: AgentToolDefinition[] = [];
  try {
    const workspaceToolRoot = getWorkspaceToolRoot();
    const result = await loadUserTools(workspaceToolRoot);
    userToolDefinitions = result.tools;
    if (result.failures.length > 0) {
      for (const failure of result.failures) {
        console.warn(`[user-tools] Failed to load tool from ${failure.toolDir}: ${failure.reason} ${failure.detail ?? ''}`);
      }
    }
  } catch (err) {
    console.warn(`[user-tools] Failed to scan workspace tools: ${err instanceof Error ? err.message : err}`);
  }

  // Create tools ONCE — shared between ToolNode and callModel
  const tools = createRegisteredTools({ skillRuntime: deps.skillRuntime, workspaceRoot: deps.workspaceRoot }, userToolDefinitions);
  const callModel = createCallModelNode(skillManifests, tools);

  const log = getLogger(undefined);
  log.info({ toolCount: tools.length, hasCheckpointer: !!checkpointer }, 'building agent graph');

  // Wrap ToolNode so that the current graph state is injected into
  // config.configurable.agentState before each tool runs.  LangGraph
  // does not propagate config mutations across nodes, so the injection
  // done in callModel is invisible to the raw ToolNode.
  const toolsNode = async (state: AgentState, config: LangGraphRunnableConfig) => {
    const nodeLog = getAgentLogger(config);
    const configurableAny = config.configurable as Record<string, unknown>;
    configurableAny.agentState = state;
    // Resolve skill scope once for all tools in this invocation
    configurableAny.skillScope = state.selectedSkillIds?.length
      ? state.selectedSkillIds
      : undefined;
    const activeTools = resolveActiveTools(
      tools,
      config.configurable as Partial<AgentConfigurable> | undefined,
    );
    nodeLog.debug({ node: 'tools', activeToolCount: activeTools.length }, 'tools node executing');
    const toolNode = new ToolNode(activeTools);
    return toolNode.invoke(state, config);
  };

  const workflow = new StateGraph(AgentStateAnnotation)
    .addNode('agent', callModel)
    .addNode('tools', toolsNode)
    .addEdge(START, 'agent')
    .addConditionalEdges('agent', shouldContinue, ['tools', END])
    .addEdge('tools', 'agent');

  return workflow.compile({ checkpointer });
}
