import {
  STRUCTURAL_COORDINATE_SEMANTICS,
} from '../../../agent-runtime/coordinate-semantics.js';
import { buildElementReferenceVectors } from '../../../agent-runtime/reference-vectors.js';
import type {
  DraftAnalysisControl,
  DraftFloorLoad,
  DraftSiteSeismicParams,
  DraftState,
  DraftWindParams,
  EngineeringDraftLoad,
} from '../../../agent-runtime/types.js';
import {
  normalizeSeismicDesignGroup,
  normalizeSeismicSiteCategory,
  normalizeWindTerrainRoughness,
  seismicDesignGroupIndex,
} from './design-conditions.js';
import type { ConcreteFrameOutput } from './types.js';

interface ConcreteMaterial {
  grade: string;   // 如 "C30"
  fck: number;     // 抗压强度标准值 N/mm²
  ftk: number;     // 抗拉强度标准值 N/mm²
  fc: number;      // 抗压强度设计值 N/mm²
  ft: number;      // 抗拉强度设计值 N/mm²
  Ec: number;      // 弹性模量 N/mm²
  ecu: number;     // 极限压应变
  alpha1: number;  // 等效矩形应力图系数
  beta1: number;   // 等效矩形应力图系数
}

interface RebarMaterial {
  grade: string;   // "HRB400"
  fyk: number;     // 屈服强度标准值(N/mm²)
  fstk: number;    // 极限强度标准值(N/mm²)
  fy: number;      // 抗拉强度设计值(N/mm²)
  fy_compression: number; // 抗压强度设计值(N/mm²)
  fyv: number;     // 抗剪强度设计值(N/mm²)
  Es: number;      // 弹性模量(N/mm²)
}

type RectangularSectionShape = { kind: 'rectangular'; B: number; H: number };

// Concrete grades data - strictly according to provided table
const CONCRETE_GRADES: Record<string, ConcreteMaterial> = {
  C20: { grade: 'C20', fck: 13.4, ftk: 1.54, fc: 9.6, ft: 1.10, Ec: 25500, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C25: { grade: 'C25', fck: 16.7, ftk: 1.78, fc: 11.9, ft: 1.27, Ec: 28000, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C30: { grade: 'C30', fck: 20.1, ftk: 2.01, fc: 14.3, ft: 1.43, Ec: 30000, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C35: { grade: 'C35', fck: 23.4, ftk: 2.20, fc: 16.7, ft: 1.57, Ec: 31500, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C40: { grade: 'C40', fck: 26.8, ftk: 2.39, fc: 19.1, ft: 1.71, Ec: 32500, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C45: { grade: 'C45', fck: 29.6, ftk: 2.51, fc: 21.1, ft: 1.80, Ec: 33500, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C50: { grade: 'C50', fck: 32.4, ftk: 2.64, fc: 23.1, ft: 1.89, Ec: 34500, ecu: 0.0033, alpha1: 1.00, beta1: 0.80 },
  C55: { grade: 'C55', fck: 35.5, ftk: 2.74, fc: 25.3, ft: 1.96, Ec: 35500, ecu: 0.0033, alpha1: 0.99, beta1: 0.79 },
  C60: { grade: 'C60', fck: 38.5, ftk: 2.85, fc: 27.5, ft: 2.04, Ec: 36000, ecu: 0.0033, alpha1: 0.98, beta1: 0.78 },
  C65: { grade: 'C65', fck: 41.5, ftk: 2.93, fc: 29.7, ft: 2.09, Ec: 36500, ecu: 0.0033, alpha1: 0.97, beta1: 0.77 },
  C70: { grade: 'C70', fck: 44.5, ftk: 2.99, fc: 31.8, ft: 2.14, Ec: 37000, ecu: 0.0033, alpha1: 0.96, beta1: 0.76 },
  C75: { grade: 'C75', fck: 47.4, ftk: 3.05, fc: 33.8, ft: 2.18, Ec: 37500, ecu: 0.0033, alpha1: 0.95, beta1: 0.75 },
  C80: { grade: 'C80', fck: 50.2, ftk: 3.11, fc: 35.9, ft: 2.22, Ec: 38000, ecu: 0.0033, alpha1: 0.94, beta1: 0.74 },
};

// Rebar grades data - strictly according to provided table
const REBAR_GRADES: Record<string, RebarMaterial> = {
  HPB300: { grade: 'HPB300', fyk: 300, fstk: 420, fy: 270, fy_compression: 270, fyv: 270, Es: 210000 },
  HRB400: { grade: 'HRB400', fyk: 400, fstk: 540, fy: 360, fy_compression: 360, fyv: 360, Es: 200000 },
  HRBF400: { grade: 'HRBF400', fyk: 400, fstk: 540, fy: 360, fy_compression: 360, fyv: 360, Es: 200000 },
  RRB400: { grade: 'RRB400', fyk: 400, fstk: 540, fy: 360, fy_compression: 360, fyv: 360, Es: 200000 },
  HRB500: { grade: 'HRB500', fyk: 500, fstk: 630, fy: 435, fy_compression: 400, fyv: 360, Es: 200000 },
  HRBF500: { grade: 'HRBF500', fyk: 500, fstk: 630, fy: 435, fy_compression: 400, fyv: 360, Es: 200000 },
};

// Rebar diameters
const REBAR_DIAMETERS = [6, 8, 10, 12, 14, 16, 18, 20, 22, 25, 28, 32];

/**
 * Get concrete material properties by grade.
 * @param grade Concrete grade string (e.g., "C30")
 * @returns ConcreteMaterial object
 * @throws Error if grade is invalid
 */
export function getConcreteMaterial(grade: string): ConcreteMaterial {
  const normalized = grade.toUpperCase();
  const material = CONCRETE_GRADES[normalized];
  if (!material) {
    throw new Error(`Invalid concrete grade: ${grade}. Valid grades are: ${Object.keys(CONCRETE_GRADES).join(', ')}`);
  }
  return material;
}

/**
 * Get rebar material properties by grade.
 * @param grade Rebar grade string (e.g., "HRB400")
 * @returns RebarMaterial object
 * @throws Error if grade is invalid
 */
export function getRebarMaterial(grade: string): RebarMaterial {
  const normalized = grade.toUpperCase();
  const material = REBAR_GRADES[normalized];
  if (!material) {
    throw new Error(`Invalid rebar grade: ${grade}. Valid grades are: ${Object.keys(REBAR_GRADES).join(', ')}`);
  }
  return material;
}

/**
 * Get rebar compressive strength based on loading condition.
 * According to GB/T 50010-2010 (2024):
 * - For HRB500 grade, the compressive strength is limited to 400 N/mm² for axial compression
 * - For all other grades, use the standard compressive strength
 * 
 * @param grade Rebar grade string (e.g., "HRB500")
 * @param loadingType Loading condition type
 * @returns Compressive strength design value (N/mm²)
 */
export function getRebarCompressiveStrength(
  grade: string, 
  loadingType: 'axial-compression' | 'bending' | 'general'
): number {
  const material = getRebarMaterial(grade);
  
  // HRB500 and HRBF500 have special limitation for axial compression
  if ((grade.toUpperCase() === 'HRB500' || grade.toUpperCase() === 'HRBF500') && 
      loadingType === 'axial-compression') {
    return 400; // Special limitation for HRB500 in axial compression
  }
  
  // For all other cases, return the standard compressive strength
  return material.fy_compression;
}

/**
 * Check if a concrete grade is valid.
 * @param grade Concrete grade string
 * @returns true if grade exists in CONCRETE_GRADES
 */
export function isValidConcreteGrade(grade: string): boolean {
  return grade.toUpperCase() in CONCRETE_GRADES;
}

/**
 * Check if a rebar grade is valid.
 * @param grade Rebar grade string
 * @returns true if grade exists in REBAR_GRADES
 */
export function isValidRebarGrade(grade: string): boolean {
  return grade.toUpperCase() in REBAR_GRADES;
}

/**
 * Get available rebar diameters.
 * @returns Array of rebar diameters in mm
 */
export function getRebarDiameters(): number[] {
  return [...REBAR_DIAMETERS];
}

/**
 * Normalize a concrete grade string.
 * @param raw Raw grade input (e.g., "c30", "C30")
 * @returns Normalized uppercase grade
 */
export function normalizeConcreteGrade(raw: string): string {
  const upper = raw.toUpperCase().replace(/\s+/g, '');
  return Object.keys(CONCRETE_GRADES).find((grade) => grade === upper) ?? upper;
}

/**
 * Normalize a section name string (same as steel frame).
 * @param raw Raw section input (e.g., "400x500", "B400H600")
 * @returns Normalized uppercase section name
 */
export function normalizeSectionName(raw: string): string {
  return raw.trim().toUpperCase().replace(/\s+/g, '').replace(/[×x*]/gi, 'X');
}

/**
 * Get default column section based on story count.
 * @param storyCount Number of stories
 * @returns Default rectangular column section string (e.g., "500X500")
 */
export function getDefaultColumnSection(storyCount: number): string {
  if (storyCount > 10) return '700X700';
  if (storyCount > 5) return '600X600';
  return '500X500';
}

/**
 * Get default beam section based on story count.
 * @param storyCount Number of stories
 * @returns Default rectangular beam section string (e.g., "300X600")
 */
export function getDefaultBeamSection(storyCount: number): string {
  if (storyCount > 10) return '400X800';
  if (storyCount > 5) return '350X700';
  return '300X600';
}

/**
 * Parse a rectangular section string.
 * @param raw Raw section string (e.g., "400X500", "B400H600", "RECT400X500")
 * @returns Object with B (width) and H (height) in mm, or null if parsing fails
 */
export function parseRectangularSection(raw: string): { B: number; H: number } | null {
  const normalized = normalizeSectionName(raw);
  const plain = normalized.match(/^(?:RECT|R)?(\d+(?:\.\d+)?)X(\d+(?:\.\d+)?)$/);
  const bh = normalized.match(/^B(\d+(?:\.\d+)?)H(\d+(?:\.\d+)?)$/);
  const match = plain ?? bh;
  if (!match) return null;
  const B = Number.parseFloat(match[1]!);
  const H = Number.parseFloat(match[2]!);
  if (B > 0 && H > 0) return { B, H };
  return null;
}

/**
 * Compute torsion constant for solid rectangular section.
 * @param B Width (mm)
 * @param H Height (mm)
 * @returns Torsion constant J (mm⁴)
 */
function computeSolidRectangularTorsionConstant(B: number, H: number): number {
  const a = Math.max(B, H);
  const b = Math.min(B, H);
  const aspect = b / a;
  return a * b ** 3 * ((1 / 3) - 0.21 * aspect * (1 - (b ** 4) / (12 * a ** 4)));
}

/**
 * Compute rectangular section properties.
 * @param B Width (mm)
 * @param H Height (mm)
 * @param G Shear modulus (N/mm²)
 * @returns Object with A (m²), Iy, Iz, J (m⁴) and G
 */
function computeRectangularSectionProps(B: number, H: number, G: number): {
  A: number;
  Iy: number;
  Iz: number;
  J: number;
  G: number;
} {
  const A = B * H;                               // mm²
  const Iy = (B * H ** 3) / 12;                  // mm⁴
  const Iz = (H * B ** 3) / 12;                  // mm⁴
  const J = computeSolidRectangularTorsionConstant(B, H); // mm⁴
  return {
    A: A / 1e6,   // m²
    Iy: Iy / 1e12, // m⁴
    Iz: Iz / 1e12, // m⁴
    J: J / 1e12,   // m⁴
    G,
  };
}

type ConcreteMaterialProps = ConcreteMaterial & { E: number; G: number; nu: number; rho: number; category: 'concrete' };
type RebarMaterialProps = RebarMaterial & { category: 'rebar' };

/**
 * Resolve concrete material properties with derived elastic constants.
 * @param grade Concrete grade (e.g., "C30")
 * @returns ConcreteMaterialProps with E, G, nu, rho
 */
export function resolveConcreteMaterialProps(grade: string): ConcreteMaterialProps {
  const concrete = getConcreteMaterial(grade);
  const E = concrete.Ec; // Elastic modulus from table (N/mm²)
  const nu = 0.2; // Poisson's ratio for concrete
  const G = E / (2 * (1 + nu)); // Shear modulus (N/mm²)
  const rho = 2500; // Density (kg/m³)
  return {
    ...concrete,
    E,
    G,
    nu,
    rho,
    category: 'concrete' as const,
  };
}

/**
 * Resolve rebar material properties.
 * @param grade Rebar grade (e.g., "HRB400")
 * @returns RebarMaterialProps with category 'rebar'
 */
export function resolveRebarMaterialProps(grade: string): RebarMaterialProps {
  const rebar = getRebarMaterial(grade);
  return {
    ...rebar,
    category: 'rebar' as const,
  };
}

type SectionProps = {
  name: string;
  type: 'rectangular';
  A: number;
  Iy: number;
  Iz: number;
  J: number;
  G: number;
  shape: RectangularSectionShape;
  width?: number;
  height?: number;
  substituted?: string;
};

/**
 * Resolve rectangular section properties.
 * @param rawSection Section string (e.g., "500X500")
 * @param G Shear modulus (N/mm²)
 * @returns SectionProps object
 */
export function resolveSectionProps(rawSection: string, G: number): SectionProps {
  const parsed = parseRectangularSection(rawSection);
  if (!parsed) {
    throw new Error(`Invalid rectangular section: ${rawSection}. Expected format like "500X500" or "B500H500".`);
  }
  const { B, H } = parsed;
  const props = computeRectangularSectionProps(B, H, G);
  return {
    name: rawSection,
    type: 'rectangular',
    ...props,
    shape: { kind: 'rectangular', B, H },
    width: B,
    height: H,
  };
}

type ConcreteFrameModel = {
  schema_version: '2.0.0';
  unit_system: 'SI';
  project: Record<string, unknown>;
  structure_system: Record<string, unknown>;
  site_seismic?: Record<string, unknown>;
  wind?: Record<string, unknown>;
  analysis_control?: Record<string, unknown>;
  nodes: Array<Record<string, unknown>>;
  elements: Array<Record<string, unknown>>;
  stories: Array<Record<string, unknown>>;
  load_cases: Array<Record<string, unknown>>;
  load_combinations: Array<Record<string, unknown>>;
  metadata: Record<string, unknown>;
  extensions: Record<string, unknown>;
  storyCount: number;
  bayCount?: number;
  bayCountX?: number;
  bayCountY?: number;
  storyHeightsM: number[];
  bayWidthsM?: number[];
  bayWidthsXM?: number[];
  bayWidthsYM?: number[];
  frameDimension: '2d' | '3d';
  frameConcreteGrade: string;
  frameRebarGrade: string;
  frameColumnSection: string;
  frameBeamSection: string;
  concreteProps: ConcreteMaterialProps;
  rebarProps: RebarMaterialProps;
  columnProps: SectionProps;
  beamProps: SectionProps;
  floorLoads?: Array<{ story: number; verticalKN?: number; liveLoadKN?: number; lateralXKN?: number; lateralYKN?: number }>;
  frameBaseSupportType?: string;
  materials?: Array<{
    id: string;
    name: string;
    grade: string;
    category: 'concrete' | 'rebar';
    E: number;
    G?: number;
    nu: number;
    rho: number;
    fc?: number;
    fy?: number;
  }>;
  sections?: Array<{
    id: string;
    name: string;
    type: 'rectangular';
    purpose: 'column' | 'beam';
    width: number;
    height: number;
    shape: { kind: 'rectangular'; B: number; H: number };
    properties: {
      A: number;
      Iy: number;
      Iz: number;
      J: number;
      G: number;
    };
  }>;
};

function deriveCharacteristicPeriod(designGroup: string | undefined, siteCategory: string | undefined): number | undefined {
  const group = seismicDesignGroupIndex(designGroup);
  const category = normalizeSeismicSiteCategory(siteCategory);
  if (!group || !category) return undefined;
  const table: Record<1 | 2 | 3, Record<string, number>> = {
    1: { I: 0.25, II: 0.35, III: 0.45, IV: 0.65 },
    2: { I: 0.30, II: 0.40, III: 0.55, IV: 0.75 },
    3: { I: 0.35, II: 0.45, III: 0.65, IV: 0.90 },
  };
  return table[group][category];
}

function deriveMaxInfluenceCoefficient(accelerationG: number | undefined): number | undefined {
  if (accelerationG === undefined) return undefined;
  const known = [
    { accelerationG: 0.05, alphaMax: 0.04 },
    { accelerationG: 0.10, alphaMax: 0.08 },
    { accelerationG: 0.15, alphaMax: 0.12 },
    { accelerationG: 0.20, alphaMax: 0.16 },
    { accelerationG: 0.30, alphaMax: 0.24 },
    { accelerationG: 0.40, alphaMax: 0.32 },
  ];
  const matched = known.find((item) => Math.abs(item.accelerationG - accelerationG) < 0.001);
  return matched?.alphaMax;
}

function buildSiteSeismicRecord(input: DraftSiteSeismicParams | undefined): Record<string, unknown> | undefined {
  if (!input || Object.keys(input).length === 0) return undefined;
  const designGroup = normalizeSeismicDesignGroup(input.designGroup);
  const siteCategory = normalizeSeismicSiteCategory(input.siteCategory);
  const characteristicPeriod = input.characteristicPeriod
    ?? deriveCharacteristicPeriod(designGroup, siteCategory);
  const maxInfluenceCoefficient = input.maxInfluenceCoefficient
    ?? deriveMaxInfluenceCoefficient(input.accelerationG);
  return {
    ...(input.intensity !== undefined && { intensity: input.intensity }),
    ...(designGroup !== undefined && { design_group: designGroup }),
    ...(siteCategory !== undefined && { site_category: siteCategory }),
    ...(characteristicPeriod !== undefined && { characteristic_period: characteristicPeriod }),
    ...(maxInfluenceCoefficient !== undefined && { max_influence_coefficient: maxInfluenceCoefficient }),
    damping_ratio: input.dampingRatio ?? 0.05,
    extra: {
      ...(input.accelerationG !== undefined && { acceleration_g: input.accelerationG }),
    },
  };
}

function buildWindRecord(input: DraftWindParams | undefined): Record<string, unknown> | undefined {
  if (!input || Object.keys(input).length === 0) return undefined;
  const terrainRoughness = normalizeWindTerrainRoughness(input.terrainRoughness);
  return {
    ...(input.basicPressureKNM2 !== undefined && { basic_pressure: input.basicPressureKNM2 }),
    ...(terrainRoughness !== undefined && { terrain_roughness: terrainRoughness }),
    ...(input.shapeFactor !== undefined && { shape_factor: input.shapeFactor }),
    ...(input.heightVariationFactor !== undefined && { height_variation_factor: input.heightVariationFactor }),
  };
}

function buildAnalysisControlRecord(input: DraftAnalysisControl | undefined): Record<string, unknown> | undefined {
  const base: Record<string, unknown> = {
    p_delta: input?.pDelta ?? false,
    rigid_floor: input?.rigidFloor ?? true,
    consideration_torsion: input?.considerationTorsion ?? true,
  };
  if (input?.periodReductionFactor !== undefined) base.period_reduction_factor = input.periodReductionFactor;
  if (input?.accidentalEccentricity !== undefined) base.accidental_eccentricity = input.accidentalEccentricity;
  if (input?.modalCount !== undefined) base.modal_count = input.modalCount;
  if (input?.basementCount !== undefined) base.basement_count = input.basementCount;
  if (input?.liveLoadReduction !== undefined) base.live_load_reduction = input.liveLoadReduction;
  if (input?.structureImportanceFactor !== undefined) base.structure_importance_factor = input.structureImportanceFactor;
  if (input?.dampingRatioWind !== undefined) base.damping_ratio_wind = input.dampingRatioWind;
  if (input?.designParams !== undefined) base.design_params = input.designParams;
  return Object.keys(base).length ? base : undefined;
}

function accumulateCoords(lengths: number[]): number[] {
  const coords = [0];
  for (const value of lengths) {
    coords.push(coords[coords.length - 1] + value);
  }
  return coords;
}

function buildBaseRestraint(baseSupport: string): boolean[] {
  return baseSupport === 'pinned'
    ? [true, true, true, false, false, false]
    : [true, true, true, true, true, true];
}

function n2dId(storyIdx: number, bayNodeIdx: number): string {
  return `N${storyIdx}_${bayNodeIdx}`;
}

function n3dId(storyIdx: number, xIdx: number, yIdx: number): string {
  return `N${storyIdx}_${xIdx}_${yIdx}`;
}

function buildStoryFloorLoadFields(deadLoad: number | undefined, liveLoad: number | undefined): Record<string, unknown> {
  const roundedDeadLoad = deadLoad ? Math.round(deadLoad * 100) / 100 : undefined;
  const roundedLiveLoad = liveLoad ? Math.round(liveLoad * 100) / 100 : undefined;
  const floorLoads = [
    ...(roundedDeadLoad ? [{ type: 'dead', value: roundedDeadLoad }] : []),
    ...(roundedLiveLoad ? [{ type: 'live', value: roundedLiveLoad }] : []),
  ];

  return {
    ...(floorLoads.length ? { floor_loads: floorLoads } : {}),
    ...(roundedDeadLoad ? { dead_load: roundedDeadLoad } : {}),
    ...(roundedLiveLoad ? { live_load: roundedLiveLoad } : {}),
  };
}

function buildStoryGravityNodalLoads(
  storyId: string,
  nodeIds: string[],
  totalLoadKN: number | undefined,
  loadKind: 'dead' | 'live',
): Array<Record<string, unknown>> {
  if (typeof totalLoadKN !== 'number' || !Number.isFinite(totalLoadKN) || totalLoadKN === 0 || nodeIds.length === 0) {
    return [];
  }
  const fzPerNode = -Math.abs(totalLoadKN) / nodeIds.length;
  return nodeIds.map((node) => ({
    type: 'nodal',
    node,
    fz: fzPerNode,
    story: storyId,
    source: 'story_floor_loads',
    load_kind: loadKind,
  }));
}

function normalizeFloorLoadsByStory(floorLoads: DraftFloorLoad[]): DraftFloorLoad[] {
  const merged = new Map<number, DraftFloorLoad>();
  for (const load of floorLoads) {
    if (typeof load.story !== 'number' || !Number.isFinite(load.story)) continue;
    const current = merged.get(load.story);
    merged.set(load.story, {
      story: load.story,
      verticalKN: load.verticalKN ?? current?.verticalKN,
      liveLoadKN: load.liveLoadKN ?? current?.liveLoadKN,
      lateralXKN: load.lateralXKN ?? current?.lateralXKN,
      lateralYKN: load.lateralYKN ?? current?.lateralYKN,
    });
  }
  return Array.from(merged.values()).sort((left, right) => left.story - right.story);
}

function hasFloorLoadValue(floorLoads: DraftFloorLoad[] | undefined): boolean {
  return Boolean(floorLoads?.some((load) => (
    (typeof load.verticalKN === 'number' && Number.isFinite(load.verticalKN) && load.verticalKN !== 0)
    || (typeof load.liveLoadKN === 'number' && Number.isFinite(load.liveLoadKN) && load.liveLoadKN !== 0)
    || (typeof load.lateralXKN === 'number' && Number.isFinite(load.lateralXKN) && load.lateralXKN !== 0)
    || (typeof load.lateralYKN === 'number' && Number.isFinite(load.lateralYKN) && load.lateralYKN !== 0)
  )));
}

function isLineEngineeringLoad(load: EngineeringDraftLoad): boolean {
  return load.kind === 'line' || load.kind === 'distributed' || load.unit === 'kN/m';
}

function isGravityLineLoad(load: EngineeringDraftLoad): boolean {
  return isLineEngineeringLoad(load)
    && load.magnitude > 0
    && (load.direction === undefined || load.direction === 'gravity' || load.direction === 'globalZ');
}

export function hasConcreteFrameAnalysisLoadInput(state: Pick<DraftState, 'floorLoads' | 'engineeringDraft' | 'wind'>): boolean {
  if (hasFloorLoadValue(state.floorLoads)) return true;
  if (typeof state.wind?.basicPressureKNM2 === 'number' && Number.isFinite(state.wind.basicPressureKNM2) && state.wind.basicPressureKNM2 > 0) {
    return true;
  }
  return Boolean(state.engineeringDraft?.loads?.some((load) => (
    load.magnitude > 0
    && Number.isFinite(load.magnitude)
    && isGravityLineLoad(load)
  )));
}

function isTopStoryLineLoadTarget(target: string): boolean {
  const trimmed = target.trim();
  const text = trimmed.toLowerCase();
  return text.includes('roof')
    || /屋面|屋顶|楼顶|顶层|顶楼/u.test(trimmed)
    || trimmed === '顶';
}

function parseLineLoadStory(target: string | undefined, storyCount: number): number | undefined {
  if (!target) return undefined;
  const text = target.toLowerCase();
  if (isTopStoryLineLoadTarget(target)) return storyCount;
  const numericMatch = text.match(/(?:floor|story|level)\s*([0-9]+)/i)
    ?? target.match(/第?\s*([0-9]+)\s*层/u);
  if (numericMatch?.[1]) {
    const parsed = Number.parseInt(numericMatch[1], 10);
    return parsed >= 1 && parsed <= storyCount ? parsed : undefined;
  }
  const chineseMatch = target.match(/第?\s*([一二两三四五六七八九十廿]+)\s*层/u);
  if (!chineseMatch?.[1]) return undefined;
  const table: Record<string, number> = {
    一: 1,
    二: 2,
    两: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9,
    十: 10,
    廿: 20,
  };
  const raw = chineseMatch[1];
  let parsed: number | undefined;
  if (raw === '十' || raw === '廿') {
    parsed = table[raw];
  } else if (raw.startsWith('十')) {
    parsed = 10 + (table[raw[1]] ?? 0);
  } else if (raw.startsWith('廿')) {
    parsed = 20 + (table[raw[1]] ?? 0);
  } else if (raw.endsWith('十')) {
    parsed = (table[raw[0]] ?? 1) * 10;
  } else if (raw.includes('十')) {
    const [tens, ones] = raw.split('十');
    parsed = (table[tens] ?? 1) * 10 + (table[ones] ?? 0);
  } else {
    parsed = table[raw];
  }
  return parsed !== undefined && parsed >= 1 && parsed <= storyCount ? parsed : undefined;
}

type ResolvedConcreteFrameLineLoad = {
  load: EngineeringDraftLoad;
  story: number;
};

function resolveConcreteFrameLineLoadsByStory(
  engineeringDraft: DraftState['engineeringDraft'] | undefined,
  storyCount: number,
): ResolvedConcreteFrameLineLoad[] {
  const lineLoads = engineeringDraft?.loads?.filter(isGravityLineLoad) ?? [];
  if (!lineLoads.length || storyCount <= 0) return [];

  const resolved: ResolvedConcreteFrameLineLoad[] = [];
  const untargeted = lineLoads.filter((load) => parseLineLoadStory(load.target, storyCount) === undefined);
  for (const load of lineLoads) {
    const explicitStory = parseLineLoadStory(load.target, storyCount);
    if (explicitStory !== undefined) {
      resolved.push({ load, story: explicitStory });
      continue;
    }
    if (untargeted.length > 1) {
      const index = untargeted.indexOf(load);
      if (index >= 0 && index < storyCount) {
        resolved.push({ load, story: index + 1 });
      }
      continue;
    }
    for (let story = 1; story <= storyCount; story += 1) {
      resolved.push({ load, story });
    }
  }
  return resolved;
}

function build2dConcreteBeamLineLoads(
  engineeringDraft: DraftState['engineeringDraft'] | undefined,
  storyCount: number,
  elements: Array<Record<string, unknown>>,
): Array<Record<string, unknown>> {
  const resolved = resolveConcreteFrameLineLoadsByStory(engineeringDraft, storyCount);
  if (!resolved.length) return [];

  const loads: Array<Record<string, unknown>> = [];
  for (const item of resolved) {
    const storyId = `F${item.story}`;
    for (const element of elements) {
      if (element.type !== 'beam' || element.story !== storyId) continue;
      loads.push({
        type: 'distributed',
        element: element.id,
        wz: -Math.abs(item.load.magnitude),
        story: storyId,
        source: 'engineering_draft_line_loads',
      });
    }
  }
  return loads;
}

function lineLoadTargetAxis(target: string | undefined): 'x' | 'y' | undefined {
  if (!target) return undefined;
  const text = target.toLowerCase();
  if (/(?:x\s*(?:direction|axis)|x[-\s]?[向轴]|沿\s*x)/iu.test(text)) return 'x';
  if (/(?:y\s*(?:direction|axis)|y[-\s]?[向轴]|沿\s*y)/iu.test(text)) return 'y';
  return undefined;
}

function build3dConcreteBeamLineLoads(
  engineeringDraft: DraftState['engineeringDraft'] | undefined,
  storyCount: number,
  elements: Array<Record<string, unknown>>,
): Array<Record<string, unknown>> {
  const resolved = resolveConcreteFrameLineLoadsByStory(engineeringDraft, storyCount);
  if (!resolved.length) return [];

  const loads: Array<Record<string, unknown>> = [];
  for (const item of resolved) {
    const storyId = `F${item.story}`;
    const axis = lineLoadTargetAxis(item.load.target);
    for (const element of elements) {
      if (element.type !== 'beam' || element.story !== storyId) continue;
      const id = String(element.id ?? '');
      if (axis === 'x' && !id.startsWith('BX')) continue;
      if (axis === 'y' && !id.startsWith('BY')) continue;
      loads.push({
        type: 'distributed',
        element: element.id,
        wz: -Math.abs(item.load.magnitude),
        story: storyId,
        source: 'engineering_draft_line_loads',
      });
    }
  }
  return loads;
}

function buildConcreteLoadCaseBundle(
  deadLoads: Array<Record<string, unknown>>,
  liveLoads: Array<Record<string, unknown>>,
  lineLoads: Array<Record<string, unknown>>,
  lateralLoads: Array<Record<string, unknown>>,
  options: { includeWind?: boolean; includeSeismic?: boolean; frameDimension?: '2d' | '3d' } = {},
): { load_cases: Array<Record<string, unknown>>; load_combinations: Array<Record<string, unknown>> } {
  const loadCases: Array<Record<string, unknown>> = [];

  if (deadLoads.length) {
    loadCases.push({ id: 'D', type: 'dead', loads: deadLoads, description: 'Equivalent nodal dead loads from stories.floor_loads' });
  }
  if (liveLoads.length) {
    loadCases.push({ id: 'L', type: 'live', loads: liveLoads, description: 'Equivalent nodal live loads from stories.floor_loads' });
  }
  if (lineLoads.length) {
    loadCases.push({ id: 'LINE', type: 'other', loads: lineLoads, description: 'Concrete frame beam line loads' });
  }
  if (lateralLoads.length) {
    loadCases.push({ id: 'LAT', type: 'other', loads: lateralLoads, description: 'Lateral story loads' });
  }
  if (options.includeWind) {
    loadCases.push({ id: 'WX', type: 'wind', loads: [], description: 'X-direction wind load generated by commercial engine parameters' });
    if (options.frameDimension === '3d') {
      loadCases.push({ id: 'WY', type: 'wind', loads: [], description: 'Y-direction wind load generated by commercial engine parameters' });
    }
  }
  if (options.includeSeismic) {
    loadCases.push({ id: 'EX', type: 'seismic', loads: [], description: 'X-direction seismic action generated by commercial engine parameters' });
    if (options.frameDimension === '3d') {
      loadCases.push({ id: 'EY', type: 'seismic', loads: [], description: 'Y-direction seismic action generated by commercial engine parameters' });
    }
  }
  if (!loadCases.length) {
    loadCases.push({ id: 'LC1', type: 'other', loads: [] });
  }

  const factors = Object.fromEntries(loadCases.map((loadCase) => [String(loadCase.id), 1.0]));
  return {
    load_cases: loadCases,
    load_combinations: [{ id: 'ULS', factors, combination_type: 'uls', code_reference: 'GB50010' }],
  };
}

function buildConcreteMaterialRecord(concreteProps: ConcreteMaterialProps): Record<string, unknown> {
  return {
    id: '1',
    name: concreteProps.grade,
    grade: concreteProps.grade,
    category: 'concrete',
    E: concreteProps.Ec,
    G: concreteProps.G,
    nu: concreteProps.nu,
    rho: concreteProps.rho,
    fc: concreteProps.fc,
    ft: concreteProps.ft,
    ftk: concreteProps.ftk,
    ecu: concreteProps.ecu,
    alpha1: concreteProps.alpha1,
    beta1: concreteProps.beta1,
    fck: concreteProps.fck,
  };
}

function buildRebarMaterialRecord(rebarProps: RebarMaterialProps): Record<string, unknown> {
  return {
    id: '2',
    name: rebarProps.grade,
    grade: rebarProps.grade,
    category: 'rebar',
    E: rebarProps.Es,
    nu: 0.3,
    rho: 7850,
    fy: rebarProps.fy,
    fyv: rebarProps.fyv,
    fyk: rebarProps.fyk,
    fstk: rebarProps.fstk,
    fy_compression: rebarProps.fy_compression,
    Es: rebarProps.Es,
  };
}

function buildConcreteSectionRecord(id: string, purpose: 'column' | 'beam', props: SectionProps): Record<string, unknown> {
  return {
    id,
    name: props.name,
    type: props.type,
    purpose,
    width: props.width ?? 0,
    height: props.height ?? 0,
    shape: props.shape,
    properties: { A: props.A, Iy: props.Iy, Iz: props.Iz, J: props.J, G: props.G },
  };
}

function buildCommonModelFields(options: {
  frameConcreteGrade: string;
  frameRebarGrade: string;
  frameColumnSection: string;
  frameBeamSection: string;
  frameBaseSupportType: string;
  storyCount: number;
  concreteProps: ConcreteMaterialProps;
  rebarProps: RebarMaterialProps;
  columnProps: SectionProps;
  beamProps: SectionProps;
  siteSeismic?: Record<string, unknown>;
  wind?: Record<string, unknown>;
  analysisControl?: Record<string, unknown>;
  metadata: Record<string, unknown>;
}): Pick<ConcreteFrameModel, 'schema_version' | 'unit_system' | 'project' | 'structure_system' | 'site_seismic' | 'wind' | 'analysis_control' | 'materials' | 'sections' | 'metadata' | 'extensions'> {
  return {
    schema_version: '2.0.0',
    unit_system: 'SI',
    project: {
      code_standard: 'GB50010-2010',
      extra: {
        designCode: 'GB50010',
      },
    },
    structure_system: {
      type: 'frame',
      seismic_grade: 'none',
      extra: {
        materialSystem: 'reinforced-concrete',
      },
    },
    ...(options.siteSeismic !== undefined && { site_seismic: options.siteSeismic }),
    ...(options.wind !== undefined && { wind: options.wind }),
    ...(options.analysisControl !== undefined && { analysis_control: options.analysisControl }),
    materials: [
      buildConcreteMaterialRecord(options.concreteProps),
      buildRebarMaterialRecord(options.rebarProps),
    ] as ConcreteFrameModel['materials'],
    sections: [
      buildConcreteSectionRecord('1', 'column', options.columnProps),
      buildConcreteSectionRecord('2', 'beam', options.beamProps),
    ] as ConcreteFrameModel['sections'],
    metadata: {
      ...options.metadata,
      coordinateSemantics: STRUCTURAL_COORDINATE_SEMANTICS,
      source: 'concrete-frame-skill-draft',
      inferredType: 'frame',
      structuralTypeKey: 'concrete-frame',
      materialSystem: 'reinforced-concrete',
      designCode: 'GB50010',
      baseSupport: options.frameBaseSupportType,
      concreteGrade: options.frameConcreteGrade,
      rebarGrade: options.frameRebarGrade,
      columnSection: options.frameColumnSection,
      beamSection: options.frameBeamSection,
      storyCount: options.storyCount,
      ...(options.siteSeismic !== undefined && { siteSeismic: options.siteSeismic }),
      ...(options.wind !== undefined && { wind: options.wind }),
    },
    extensions: {
      pkpm: {
        materialSystem: 'reinforced-concrete',
        designCode: 'GB50010',
        ...(options.siteSeismic !== undefined && { site_seismic: options.siteSeismic }),
        ...(options.wind !== undefined && { wind: options.wind }),
      },
      yjk: {
        materialSystem: 'reinforced-concrete',
        designCode: 'GB50010',
      },
      concreteDesign: {
        concreteGrade: options.frameConcreteGrade,
        rebarGrade: options.frameRebarGrade,
      },
    },
  };
}

function buildConcreteFrame2dLocalModel(options: {
  storyCount: number;
  bayCount: number;
  storyHeightsM: number[];
  bayWidthsM: number[];
  floorLoads: NonNullable<ConcreteFrameModel['floorLoads']>;
  frameBaseSupportType: string;
  frameConcreteGrade: string;
  frameRebarGrade: string;
  frameColumnSection: string;
  frameBeamSection: string;
  concreteProps: ConcreteMaterialProps;
  rebarProps: RebarMaterialProps;
  columnProps: SectionProps;
  beamProps: SectionProps;
  siteSeismic?: Record<string, unknown>;
  wind?: Record<string, unknown>;
  analysisControl?: Record<string, unknown>;
  engineeringDraft?: DraftState['engineeringDraft'];
}): ConcreteFrameModel {
  const xCoords = accumulateCoords(options.bayWidthsM);
  const zCoords = accumulateCoords(options.storyHeightsM);
  const floorLoads = normalizeFloorLoadsByStory(options.floorLoads);
  const nodes: Array<Record<string, unknown>> = [];
  const elements: Array<Record<string, unknown>> = [];
  const deadLoads: Array<Record<string, unknown>> = [];
  const liveLoads: Array<Record<string, unknown>> = [];
  const lateralLoads: Array<Record<string, unknown>> = [];
  let elementId = 1;

  for (let storyIdx = 0; storyIdx < zCoords.length; storyIdx++) {
    for (let bayIdx = 0; bayIdx < xCoords.length; bayIdx++) {
      const node: Record<string, unknown> = {
        id: n2dId(storyIdx, bayIdx),
        x: xCoords[bayIdx],
        y: 0,
        z: zCoords[storyIdx],
        ...(storyIdx > 0 ? { story: `F${storyIdx}` } : {}),
      };
      if (storyIdx === 0) node.restraints = buildBaseRestraint(options.frameBaseSupportType);
      nodes.push(node);
    }
  }

  for (let storyIdx = 1; storyIdx < zCoords.length; storyIdx++) {
    for (let bayIdx = 0; bayIdx < xCoords.length; bayIdx++) {
      elements.push({
        id: `C${elementId}`,
        type: 'column',
        nodes: [n2dId(storyIdx - 1, bayIdx), n2dId(storyIdx, bayIdx)],
        material: '1',
        section: '1',
        story: `F${storyIdx}`,
        concrete_grade: options.frameConcreteGrade,
        rebar_grade: options.frameRebarGrade,
      });
      elementId += 1;
    }
  }

  for (let storyIdx = 1; storyIdx < zCoords.length; storyIdx++) {
    for (let bayIdx = 0; bayIdx < options.bayWidthsM.length; bayIdx++) {
      elements.push({
        id: `B${elementId}`,
        type: 'beam',
        nodes: [n2dId(storyIdx, bayIdx), n2dId(storyIdx, bayIdx + 1)],
        material: '1',
        section: '2',
        story: `F${storyIdx}`,
        concrete_grade: options.frameConcreteGrade,
        rebar_grade: options.frameRebarGrade,
      });
      elementId += 1;
    }
  }

  const levelNodeCount = xCoords.length;
  for (const load of floorLoads) {
    const storyIdx = load.story;
    if (storyIdx <= 0 || storyIdx >= zCoords.length) continue;
    const storyId = `F${storyIdx}`;
    const nodeIds = xCoords.map((_x, bayIdx) => n2dId(storyIdx, bayIdx));
    deadLoads.push(...buildStoryGravityNodalLoads(storyId, nodeIds, load.verticalKN, 'dead'));
    liveLoads.push(...buildStoryGravityNodalLoads(storyId, nodeIds, load.liveLoadKN, 'live'));
    const lPerNode = load.lateralXKN !== undefined ? load.lateralXKN / levelNodeCount : undefined;
    for (let bayIdx = 0; bayIdx < xCoords.length; bayIdx++) {
      const nodeLoad: Record<string, unknown> = {
        type: 'nodal',
        node: n2dId(storyIdx, bayIdx),
        story: storyId,
        source: 'story_lateral_loads',
      };
      if (lPerNode !== undefined) nodeLoad.fx = lPerNode;
      if (nodeLoad.fx !== undefined) lateralLoads.push(nodeLoad);
    }
  }

  const stories = options.storyHeightsM.map((height, index) => {
    const storyIdx = index + 1;
    const fl = floorLoads.find((load) => load.story === storyIdx);
    const floorAreaM2 = Math.max(xCoords[xCoords.length - 1], 1);
    const deadLoad = fl?.verticalKN ? Math.abs(fl.verticalKN) / floorAreaM2 : undefined;
    const liveLoad = fl?.liveLoadKN ? Math.abs(fl.liveLoadKN) / floorAreaM2 : undefined;
    return {
      id: `F${storyIdx}`,
      height,
      elevation: zCoords[index],
      standard_floor_group: 'SF1',
      ...buildStoryFloorLoadFields(deadLoad, liveLoad),
    };
  });
  const lineLoads = build2dConcreteBeamLineLoads(options.engineeringDraft, options.storyCount, elements);
  const loadCaseBundle = buildConcreteLoadCaseBundle(deadLoads, liveLoads, lineLoads, lateralLoads, {
    includeWind: options.wind !== undefined,
    includeSeismic: options.siteSeismic !== undefined,
    frameDimension: '2d',
  });
  const common = buildCommonModelFields({
    ...options,
    metadata: {
      frameDimension: '2d',
      bayCount: options.bayCount,
      geometry: { storyHeightsM: options.storyHeightsM, bayWidthsM: options.bayWidthsM },
    },
  });

  return {
    ...common,
    nodes,
    elements,
    stories,
    ...loadCaseBundle,
    storyCount: options.storyCount,
    bayCount: options.bayCount,
    storyHeightsM: options.storyHeightsM,
    bayWidthsM: options.bayWidthsM,
    frameDimension: '2d',
    frameConcreteGrade: options.frameConcreteGrade,
    frameRebarGrade: options.frameRebarGrade,
    frameColumnSection: options.frameColumnSection,
    frameBeamSection: options.frameBeamSection,
    concreteProps: options.concreteProps,
    rebarProps: options.rebarProps,
    columnProps: options.columnProps,
    beamProps: options.beamProps,
    floorLoads,
    frameBaseSupportType: options.frameBaseSupportType,
  };
}

function buildConcreteFrame3dLocalModel(options: {
  storyCount: number;
  bayCountX: number;
  bayCountY: number;
  storyHeightsM: number[];
  bayWidthsXM: number[];
  bayWidthsYM: number[];
  floorLoads: NonNullable<ConcreteFrameModel['floorLoads']>;
  frameBaseSupportType: string;
  frameConcreteGrade: string;
  frameRebarGrade: string;
  frameColumnSection: string;
  frameBeamSection: string;
  concreteProps: ConcreteMaterialProps;
  rebarProps: RebarMaterialProps;
  columnProps: SectionProps;
  beamProps: SectionProps;
  siteSeismic?: Record<string, unknown>;
  wind?: Record<string, unknown>;
  analysisControl?: Record<string, unknown>;
  engineeringDraft?: DraftState['engineeringDraft'];
}): ConcreteFrameModel {
  const xCoords = accumulateCoords(options.bayWidthsXM);
  const yCoords = accumulateCoords(options.bayWidthsYM);
  const zCoords = accumulateCoords(options.storyHeightsM);
  const floorLoads = normalizeFloorLoadsByStory(options.floorLoads);
  const nodes: Array<Record<string, unknown>> = [];
  const elements: Array<Record<string, unknown>> = [];
  const deadLoads: Array<Record<string, unknown>> = [];
  const liveLoads: Array<Record<string, unknown>> = [];
  const lateralLoads: Array<Record<string, unknown>> = [];
  let elementId = 1;

  for (let storyIdx = 0; storyIdx < zCoords.length; storyIdx++) {
    for (let xIdx = 0; xIdx < xCoords.length; xIdx++) {
      for (let yIdx = 0; yIdx < yCoords.length; yIdx++) {
        const node: Record<string, unknown> = {
          id: n3dId(storyIdx, xIdx, yIdx),
          x: xCoords[xIdx],
          y: yCoords[yIdx],
          z: zCoords[storyIdx],
          ...(storyIdx > 0 ? { story: `F${storyIdx}` } : {}),
        };
        if (storyIdx === 0) node.restraints = buildBaseRestraint(options.frameBaseSupportType);
        nodes.push(node);
      }
    }
  }

  for (let storyIdx = 1; storyIdx < zCoords.length; storyIdx++) {
    for (let xIdx = 0; xIdx < xCoords.length; xIdx++) {
      for (let yIdx = 0; yIdx < yCoords.length; yIdx++) {
        elements.push({
          id: `C${elementId}`,
          type: 'column',
          nodes: [n3dId(storyIdx - 1, xIdx, yIdx), n3dId(storyIdx, xIdx, yIdx)],
          material: '1',
          section: '1',
          story: `F${storyIdx}`,
          concrete_grade: options.frameConcreteGrade,
          rebar_grade: options.frameRebarGrade,
        });
        elementId += 1;
      }
    }
  }

  for (let storyIdx = 1; storyIdx < zCoords.length; storyIdx++) {
    for (let xIdx = 0; xIdx < options.bayWidthsXM.length; xIdx++) {
      for (let yIdx = 0; yIdx < yCoords.length; yIdx++) {
        elements.push({
          id: `BX${elementId}`,
          type: 'beam',
          nodes: [n3dId(storyIdx, xIdx, yIdx), n3dId(storyIdx, xIdx + 1, yIdx)],
          material: '1',
          section: '2',
          story: `F${storyIdx}`,
          concrete_grade: options.frameConcreteGrade,
          rebar_grade: options.frameRebarGrade,
        });
        elementId += 1;
      }
    }
  }

  for (let storyIdx = 1; storyIdx < zCoords.length; storyIdx++) {
    for (let xIdx = 0; xIdx < xCoords.length; xIdx++) {
      for (let yIdx = 0; yIdx < options.bayWidthsYM.length; yIdx++) {
        elements.push({
          id: `BY${elementId}`,
          type: 'beam',
          nodes: [n3dId(storyIdx, xIdx, yIdx), n3dId(storyIdx, xIdx, yIdx + 1)],
          material: '1',
          section: '2',
          story: `F${storyIdx}`,
          concrete_grade: options.frameConcreteGrade,
          rebar_grade: options.frameRebarGrade,
        });
        elementId += 1;
      }
    }
  }

  const levelNodeCount = xCoords.length * yCoords.length;
  for (const load of floorLoads) {
    const storyIdx = load.story;
    if (storyIdx <= 0 || storyIdx >= zCoords.length) continue;
    const storyId = `F${storyIdx}`;
    const nodeIds = xCoords.flatMap((_x, xIdx) => yCoords.map((_y, yIdx) => n3dId(storyIdx, xIdx, yIdx)));
    deadLoads.push(...buildStoryGravityNodalLoads(storyId, nodeIds, load.verticalKN, 'dead'));
    liveLoads.push(...buildStoryGravityNodalLoads(storyId, nodeIds, load.liveLoadKN, 'live'));
    const lxPerNode = load.lateralXKN !== undefined ? load.lateralXKN / levelNodeCount : undefined;
    const lyPerNode = load.lateralYKN !== undefined ? load.lateralYKN / levelNodeCount : undefined;
    for (let xIdx = 0; xIdx < xCoords.length; xIdx++) {
      for (let yIdx = 0; yIdx < yCoords.length; yIdx++) {
        const nodeLoad: Record<string, unknown> = {
          type: 'nodal',
          node: n3dId(storyIdx, xIdx, yIdx),
          story: storyId,
          source: 'story_lateral_loads',
        };
        if (lxPerNode !== undefined) nodeLoad.fx = lxPerNode;
        if (lyPerNode !== undefined) nodeLoad.fy = lyPerNode;
        if (nodeLoad.fx !== undefined || nodeLoad.fy !== undefined) lateralLoads.push(nodeLoad);
      }
    }
  }

  const elementReferenceVectors = buildElementReferenceVectors(elements, nodes);
  const stories = options.storyHeightsM.map((height, index) => {
    const storyIdx = index + 1;
    const fl = floorLoads.find((load) => load.story === storyIdx);
    const floorAreaM2 = Math.max(xCoords[xCoords.length - 1], 1) * Math.max(yCoords[yCoords.length - 1], 1);
    const deadLoad = fl?.verticalKN ? Math.abs(fl.verticalKN) / floorAreaM2 : undefined;
    const liveLoad = fl?.liveLoadKN ? Math.abs(fl.liveLoadKN) / floorAreaM2 : undefined;
    return {
      id: `F${storyIdx}`,
      height,
      elevation: zCoords[index],
      standard_floor_group: 'SF1',
      ...buildStoryFloorLoadFields(deadLoad, liveLoad),
    };
  });
  const lineLoads = build3dConcreteBeamLineLoads(options.engineeringDraft, options.storyCount, elements);
  const loadCaseBundle = buildConcreteLoadCaseBundle(deadLoads, liveLoads, lineLoads, lateralLoads, {
    includeWind: options.wind !== undefined,
    includeSeismic: options.siteSeismic !== undefined,
    frameDimension: '3d',
  });
  const common = buildCommonModelFields({
    ...options,
    metadata: {
      frameDimension: '3d',
      elementReferenceVectors,
      bayCountX: options.bayCountX,
      bayCountY: options.bayCountY,
      geometry: {
        storyHeightsM: options.storyHeightsM,
        bayWidthsXM: options.bayWidthsXM,
        bayWidthsYM: options.bayWidthsYM,
      },
    },
  });

  return {
    ...common,
    nodes,
    elements,
    stories,
    ...loadCaseBundle,
    storyCount: options.storyCount,
    bayCountX: options.bayCountX,
    bayCountY: options.bayCountY,
    storyHeightsM: options.storyHeightsM,
    bayWidthsXM: options.bayWidthsXM,
    bayWidthsYM: options.bayWidthsYM,
    frameDimension: '3d',
    frameConcreteGrade: options.frameConcreteGrade,
    frameRebarGrade: options.frameRebarGrade,
    frameColumnSection: options.frameColumnSection,
    frameBeamSection: options.frameBeamSection,
    concreteProps: options.concreteProps,
    rebarProps: options.rebarProps,
    columnProps: options.columnProps,
    beamProps: options.beamProps,
    floorLoads,
    frameBaseSupportType: options.frameBaseSupportType,
  };
}

/**
 * Build code-check metadata summary for injection into model metadata.
 */
function buildCodeCheckMetadata(codeCheckResults: ConcreteFrameOutput): Record<string, unknown> {
  return {
    beamCount: codeCheckResults.concreteBeams.length,
    columnCount: codeCheckResults.concreteColumns.length,
    slabCount: codeCheckResults.concreteSlabs.length,
    beams: codeCheckResults.concreteBeams.map((b) => ({
      id: b.id, type: b.type, spanM: b.spanM,
      heightMM: b.heightMM, widthMM: b.widthMM,
    })),
    columns: codeCheckResults.concreteColumns.map((c) => ({
      id: c.id, type: c.type, heightM: c.heightM,
      axialLoadRatio: c.axialLoadRatio,
      widthMM: c.widthMM, heightMM: c.heightMM, diameterMM: c.diameterMM,
    })),
  };
}

/**
 * Build a concrete frame model from draft state.
 * Returns a full mesh model (nodes + elements + materials + sections + load cases)
 * suitable for OpenSees analysis, plus GB 50010 code-check results.
 * @param state Draft state with concrete frame parameters
 * @param codeCheckResults Optional code-check results from generateMembers
 * @returns Record ready for analysis engine (schema 2.0), or undefined if critical geometry missing
 */
export function buildConcreteFrameModel(
  state: DraftState,
  codeCheckResults?: ConcreteFrameOutput,
): ConcreteFrameModel | undefined {
  const storyCount = state.storyCount;
  const storyHeightsM = state.storyHeightsM;

  if (storyCount === undefined || !storyHeightsM?.length) {
    return undefined;
  }
  if (storyHeightsM.length !== storyCount) {
    return undefined;
  }

  const frameDimension = state.frameDimension || '2d';
  const floorLoads = state.floorLoads ?? [];

  // M1: Separate concrete and rebar grade handling
  const rawFrameConcreteGrade = (state.frameConcreteGrade as string | undefined);
  const rawFrameRebarGrade = (state.frameRebarGrade as string | undefined);

  const frameConcreteGrade = rawFrameConcreteGrade && isValidConcreteGrade(rawFrameConcreteGrade)
    ? normalizeConcreteGrade(rawFrameConcreteGrade)
    : 'C30';
  const frameRebarGrade = rawFrameRebarGrade && isValidRebarGrade(rawFrameRebarGrade)
    ? rawFrameRebarGrade.toUpperCase().replace(/\s+/g, '')
    : 'HRB400';

  const frameColumnSection = (state.frameColumnSection as string | undefined) || getDefaultColumnSection(storyCount);
  const frameBeamSection = (state.frameBeamSection as string | undefined) || getDefaultBeamSection(storyCount);
  const frameBaseSupportType = (state.frameBaseSupportType as string | undefined) || 'fixed';

  const concreteProps = resolveConcreteMaterialProps(frameConcreteGrade);
  const rebarProps = resolveRebarMaterialProps(frameRebarGrade);
  const columnProps = resolveSectionProps(frameColumnSection, concreteProps.G);
  const beamProps = resolveSectionProps(frameBeamSection, concreteProps.G);
  const siteSeismic = buildSiteSeismicRecord(state.siteSeismic as DraftSiteSeismicParams | undefined);
  const wind = buildWindRecord(state.wind as DraftWindParams | undefined);
  const analysisControl = siteSeismic || wind || state.analysisControl
    ? buildAnalysisControlRecord(state.analysisControl as DraftAnalysisControl | undefined)
    : undefined;

  // Compute rebar design metadata from code parameters (GB50010 minimums).
  // These flow through element.metadata → entry.ts → elementData → Python code-check.
  const beamH = beamProps.height ?? 500;
  const beamB = beamProps.width ?? 300;
  const beamH0 = beamH - 40;
  const beamRhoMin = Math.max(0.002, 0.45 * concreteProps.ft / rebarProps.fy);
  const beamAs = Math.max(beamB * beamH0 * beamRhoMin, Math.PI * 14 * 14 / 2);
  const beamMainDia = beamH >= 600 ? 25 : (beamH >= 400 ? 20 : 16);
  const beamBarArea = Math.PI * beamMainDia * beamMainDia / 4;
  const beamBarCount = Math.max(2, Math.ceil(beamAs / beamBarArea));
  // GB50010-2010 §9.2.1: 净距 sₙ — available width minus bar footprint
  const beamAvailableWidth = beamB - 2 * (20 + 8); // cover + stirrup on both sides
  const beamSn = beamBarCount > 1
    ? Math.max(0, (beamAvailableWidth - beamBarCount * beamMainDia) / (beamBarCount - 1))
    : 0;
  const beamRebarMeta: Record<string, unknown> = {
    As: Math.round(beamAs),
    Asv: Math.round(Math.PI * 8 * 8 / 2),          // 2-leg Φ8
    stirrup_dia: 8,
    stirrup_spacing: 200,
    main_dia: beamMainDia,
    bar_count: beamBarCount,
    sn: Math.round(beamSn),
    cover: 20,
    crack_cover: 25,
  };

  const colB = columnProps.width ?? 500;
  const colH = columnProps.height ?? 500;
  const colRhoMin = Math.max(0.006, 0.55 * concreteProps.ft / rebarProps.fy);
  const colAs = Math.max(colB * colH * colRhoMin, Math.PI * 20 * 20);
  const colMainDia = 20;
  const colBarArea = Math.PI * colMainDia * colMainDia / 4;
  const colBarCount = Math.max(4, Math.ceil(colAs / colBarArea));
  // GB50010-2010 §9.3.1: 净距 sₙ per side face
  // Corner bars are shared between adjacent sides.
  // ceil(total/4) gives spaces per side; +1 for the corner bar at far end.
  const colBarCountPerSide = Math.ceil(colBarCount / 4) + 1;
  const colMinSide = Math.min(colB, colH);
  const colAvailableWidth = colMinSide - 2 * (20 + 8); // cover + stirrup on both sides
  const colSn = colBarCountPerSide > 1
    ? Math.max(0, (colAvailableWidth - colBarCountPerSide * colMainDia) / (colBarCountPerSide - 1))
    : 0;
  const colRebarMeta: Record<string, unknown> = {
    As: Math.round(colAs),
    Asv: Math.round(Math.PI * 8 * 8 / 2),          // 2-leg Φ8
    stirrup_dia: 8,
    stirrup_spacing: 200,
    main_dia: colMainDia,
    bar_count: colBarCount,
    sn: Math.round(colSn),
    cover: 20,
  };

  /** Attach rebar design metadata to each element. */
  function attachRebarMetadata(elements: Array<Record<string, unknown>>): void {
    for (const elem of elements) {
      const meta = elem['type'] === 'column' ? colRebarMeta : beamRebarMeta;
      const existing = (typeof elem['metadata'] === 'object' && elem['metadata'] !== null)
        ? elem['metadata'] as Record<string, unknown> : {};
      elem['metadata'] = { ...existing, ...meta };
    }
  }

  if (frameDimension === '3d') {
    const bayWidthsXM = state.bayWidthsXM?.length ? state.bayWidthsXM : state.bayWidthsM;
    const bayWidthsYM = state.bayWidthsYM?.length ? state.bayWidthsYM : state.bayWidthsM;
    const bayCountX = state.bayCountX ?? bayWidthsXM?.length;
    const bayCountY = state.bayCountY ?? bayWidthsYM?.length;

    if (bayCountX === undefined || bayCountY === undefined || !bayWidthsXM?.length || !bayWidthsYM?.length) {
      return undefined;
    }
    if (bayWidthsXM.length !== bayCountX || bayWidthsYM.length !== bayCountY) {
      return undefined;
    }

    const model3d = buildConcreteFrame3dLocalModel({
      storyCount,
      bayCountX,
      bayCountY,
      storyHeightsM,
      bayWidthsXM,
      bayWidthsYM,
      floorLoads,
      frameBaseSupportType,
      frameConcreteGrade,
      frameRebarGrade,
      frameColumnSection,
      frameBeamSection,
      concreteProps,
      rebarProps,
      columnProps,
      beamProps,
      siteSeismic,
      wind,
      analysisControl,
      engineeringDraft: state.engineeringDraft,
    });

    attachRebarMetadata(model3d.elements);

    if (codeCheckResults) {
      model3d.metadata = {
        ...model3d.metadata,
        codeCheckResults: buildCodeCheckMetadata(codeCheckResults),
      };
    }

    return model3d;
  }

  const bayCount = state.bayCount;
  const bayWidthsM = state.bayWidthsM;

  if (bayCount === undefined || !bayWidthsM?.length) {
    return undefined;
  }
  if (bayWidthsM.length !== bayCount) {
    return undefined;
  }

  const model2d = buildConcreteFrame2dLocalModel({
    storyCount,
    bayCount,
    storyHeightsM,
    bayWidthsM,
    floorLoads,
    frameBaseSupportType,
    frameConcreteGrade,
    frameRebarGrade,
    frameColumnSection,
    frameBeamSection,
    concreteProps,
    rebarProps,
    columnProps,
    beamProps,
    siteSeismic,
    wind,
    analysisControl,
    engineeringDraft: state.engineeringDraft,
  });

  attachRebarMetadata(model2d.elements);

  if (codeCheckResults) {
    model2d.metadata = {
      ...model2d.metadata,
      codeCheckResults: buildCodeCheckMetadata(codeCheckResults),
    };
  }

  return model2d;
}
