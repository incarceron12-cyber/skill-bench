# Approval Intake Form

_evidence_id_: `E-001`
_kind_: `form`

---

Approval Intake Form for case_id CASE-2026-0040.
Project Name: Indigo Cloud Migration
Applicant Department: Brand & Creative
Application Date: 2026-05-03

This intake originates from Brand & Creative, which submitted the case via the standard approval-orchestrator pipeline on 2026-05-03. The submission flags **Procurement Team Alignment** as the operative review area and routes the case for specialist adjudication. Operational context for the request: the team has prepared a 2 parallel review tracks based on the documented parameters (`annual_spend_usd`=30000, `business_division`=Sales, `data_categories`=All other User Information, and additional fields below). All gating values stated below were captured directly from the upstream business-system record at the time of submission and have not been altered in transit.

Submitted parameters:
- `annual_spend_usd`: 30000
- `business_division`: Sales
- `data_categories`: All other User Information
- `processing_scale`: large_scale
- `recipient_type`: third_party
- `data_processing_activity`: collect
- `data_processed_or_stored_outside_gitlab_systems`: True

Intake routing topics (agents apply the assigned policy_docs to these topics):
- Procurement Team Alignment
- Law Enforcement User Information Request

Next-step expectations: each assigned specialist reads this intake plus the supporting evidence attached to this submission, applies the policy passages indicated by their reference document, and returns a decision keyed to the rules actually triggered by the parameters above. If a gating fact required by a rule is not present in this intake, the specialist should mark the matter `require_docs` listing the missing field rather than infer or default a value. The applicant has authorised contact via the Brand & Creative intake queue should additional clarification be needed before final adjudication.
