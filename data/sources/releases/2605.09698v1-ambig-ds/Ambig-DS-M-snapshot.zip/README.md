---
license: cc-by-nc-4.0
task_categories:
  - text-generation
language:
  - en
tags:
  - benchmark
  - ambiguity
  - ml-engineering
  - kaggle
  - metric-ambiguity
pretty_name: "Ambig-DS-M: Metric Ambiguity Benchmark for ML Engineering Agents"
size_categories:
  - n<1K
configs:
  - config_name: tasks_index
    data_files:
      - split: train
        path: tasks.csv
    default: true
---

# Ambig-DS-M: Metric Ambiguity Benchmark

A benchmark for measuring how well ML engineering agents handle **ambiguous evaluation metrics** in Kaggle-style competitions.

Each task is a Kaggle competition from [MLE-bench](https://github.com/openai/mle-bench) (OpenAI, 2024). For every task we provide two prompt variants — one in which the true evaluation metric is named, and one in which it is redacted. The agent must produce a submission CSV that is graded against the **true** metric using MLE-bench's grading infrastructure.

The benchmark contains **61 paired tasks**.

## Variants

| Variant | File | Description |
|---------|------|-------------|
| **Full** | `prompts/{slug}/full.md` | Original Kaggle competition description — includes the exact evaluation metric, formula, and optimization direction. |
| **Ambiguous** | `prompts/{slug}/ambig_metric.md` | Same description with metric information redacted — the Evaluation section body is replaced with *"Submissions are scored against the held-out ground truth on this task."*; inline metric mentions and submission-format hints (e.g. "predict a probability") are neutralized; submission column names and data-field descriptions are preserved verbatim. |

The `Full` arm establishes the upper baseline; the `Ambiguous` arm is the diagnostic condition. The gap between the two is the *bite* of metric ambiguity.

## Layout

```
prompts/
  {slug}/
    full.md              # Full competition description (metric included)
    ambig_metric.md      # Metric-redacted version
task_list.txt            # 61 competition slugs (one per line)
metric_manifest.json     # Structured ground-truth metric metadata per task
_verify/
  {slug}.json            # Per-task LLM-judge verdict on the four-item retention checklist
  _summary.json          # Aggregate pass counts and per-slug verdicts
  rejected.txt           # Slugs that ever failed any check (empty in the shipped release)
```

## Setup: getting the competition data

This dataset contains **prompts and metadata only** — not the Kaggle competition data (train/test CSVs, images, etc.). To download the data, install MLE-bench and run:

```bash
pip install -e git+https://github.com/openai/mle-bench.git
mlebench prepare --list task_list.txt --data-dir ./cache
```

This requires a [Kaggle API key](https://www.kaggle.com/docs/api) and acceptance of each competition's rules.

## Metric manifest

`metric_manifest.json` is a JSON dict keyed by competition slug (61 entries). It is the **clarification oracle's source of truth**: in the *clarify* experimental condition, an answerer LLM responds to the agent's clarifying questions about the metric using only these fields. It is intentionally **never given to the agent** in the *ambig* (no-clarify) condition.

Per-task fields:

| Field | Purpose |
|---|---|
| `metric_name` | Canonical name of the true grading metric. |
| `metric_description` | One-paragraph definition, including quirks (clipping, partial-column scoring, K-cutoffs, …). |
| `submission_format` | Exact column layout the grader expects (column names + value type/range). |
| `is_lower_better` | Optimization direction (boolean). |
| `notes` | Sample-submission gotchas, common failure modes, residual leaks. |

Example entry:

```json
{
  "spooky-author-identification": {
    "metric_name": "Multi-class log loss",
    "metric_description": "Multi-class logarithmic loss over the three author classes (EAP, HPL, MWS). Predictions must be per-class probabilities; argmax/one-hot submissions are clipped but heavily penalised.",
    "submission_format": "id, EAP, HPL, MWS — one probability per author class per row. Probabilities do not need to sum to one (the metric clips to [eps, 1-eps]).",
    "is_lower_better": true,
    "notes": "Sample submission rows are 0.33,0.33,0.33 (uniform), hinting at probability output."
  }
}
```


## Validation (`_verify/`)

Every shipped `ambig_metric.md` was audited by an LLM-judge panel against the four-item retention checklist from the paper (Section 3.3, "Verification and Filtering"). For each task, judges saw `full.md`, `ambig_metric.md`, and the manifest entry, and produced structured verdicts on:

1. **Plausible alternatives** — given only the redacted prompt and implied data, list the metrics that remain consistent with the task. Each shipped task has ≥2 plausible alternatives, confirming the redaction does not collapse the metric to a unique inference.
2. **Ambiguity preservation** — the redacted variant does not leak the true metric (no formulas, optimization-direction wording, metric-identifying column semantics, or paper citations naming the metric).
3. **Decision relevance** — resolving the ambiguity changes a real solver-level choice (hard labels vs probabilities, optimization direction, top-K behaviour, clipping, column aggregation, …).
4. **Task preservation** — only metric-related information was removed; data files, columns, submission column names, timeline, prizes, and citation are kept verbatim.

Per-slug verdicts (with rationales, plausible-alternative lists, and any flagged leak quotes) live in `_verify/{slug}.json`; the aggregate is in `_verify/_summary.json`. **All 61 shipped tasks pass all four checks.**

The `_verify/` files are an audit artefact only — they are **not** consumed at evaluation time and are **never** shown to agents in any condition.

## Tasks (61)

| # | Competition | True metric | Direction |
|---|---|---|---|
| 1 | `3d-object-detection-for-autonomous-vehicles` | Mean Average Precision (mAP) | ↑ higher |
| 2 | `alaska2-image-steganalysis` | Weighted AUC | ↑ higher |
| 3 | `aptos2019-blindness-detection` | Quadratic Weighted Kappa | ↑ higher |
| 4 | `billion-word-imputation` | Mean Levenshtein Distance | ↓ lower |
| 5 | `bms-molecular-translation` | Mean Levenshtein Distance | ↓ lower |
| 6 | `champs-scalar-coupling` | Log of the Mean Absolute Error | ↓ lower |
| 7 | `denoising-dirty-documents` | Root Mean Squared Error | ↓ lower |
| 8 | `detecting-insults-in-social-commentary` | AUC (ROC) | ↑ higher |
| 9 | `dog-breed-identification` | Multi-class log loss | ↓ lower |
| 10 | `facebook-recruiting-iii-keyword-extraction` | Mean F1-Score | ↑ higher |
| 11 | `google-quest-challenge` | Mean column-wise Spearman's correlation coefficient | ↑ higher |
| 12 | `google-research-identify-contrails-reduce-global-warming` | Global Dice coefficient | ↑ higher |
| 13 | `h-and-m-personalized-fashion-recommendations` | MAP@12 | ↑ higher |
| 14 | `herbarium-2020-fgvc7` | Macro F1 Score | ↑ higher |
| 15 | `herbarium-2021-fgvc8` | Macro F1 Score | ↑ higher |
| 16 | `herbarium-2022-fgvc9` | Macro F1 Score | ↑ higher |
| 17 | `histopathologic-cancer-detection` | AUC (ROC) | ↑ higher |
| 18 | `hms-harmful-brain-activity-classification` | Kullback-Leibler Divergence | ↓ lower |
| 19 | `hotel-id-2021-fgvc8` | MAP@5 | ↑ higher |
| 20 | `icecube-neutrinos-in-deep-ice` | Mean Angular Error | ↓ lower |
| 21 | `imet-2020-fgvc7` | Micro-averaged F1 Score | ↑ higher |
| 22 | `iwildcam-2020-fgvc7` | Accuracy | ↑ higher |
| 23 | `jigsaw-toxic-comment-classification-challenge` | Mean column-wise ROC AUC (multi-label AUC) | ↑ higher |
| 24 | `jigsaw-unintended-bias-in-toxicity-classification` | Jigsaw Unintended Bias Score | ↑ higher |
| 25 | `kuzushiji-recognition` | F1 Score | ↑ higher |
| 26 | `leaf-classification` | Multi-class log loss | ↓ lower |
| 27 | `learning-agency-lab-automated-essay-scoring-2` | Quadratic Weighted Kappa | ↑ higher |
| 28 | `lmsys-chatbot-arena` | Multi-class log loss with eps=auto | ↓ lower |
| 29 | `mlsp-2013-birds` | ROC AUC (single AUC pooled over all (recording, species) rows) | ↑ higher |
| 30 | `movie-review-sentiment-analysis-kernels-only` | Classification accuracy (5 classes) | ↑ higher |
| 31 | `new-york-city-taxi-fare-prediction` | RMSE | ↓ lower |
| 32 | `nfl-player-contact-detection` | Matthews Correlation Coefficient | ↑ higher |
| 33 | `nomad2018-predict-transparent-conductors` | Mean column-wise RMSLE over 2 target columns | ↓ lower |
| 34 | `osic-pulmonary-fibrosis-progression` | Modified Laplace Log Likelihood | ↑ higher |
| 35 | `petfinder-pawpularity-score` | Root Mean Squared Error (RMSE) | ↓ lower |
| 36 | `plant-pathology-2020-fgvc7` | Mean column-wise ROC AUC | ↑ higher |
| 37 | `plant-pathology-2021-fgvc8` | Mean F1-Score (Micro F1-Score) | ↑ higher |
| 38 | `plant-seedlings-classification` | Micro-averaged F1-score | ↑ higher |
| 39 | `predict-volcanic-eruptions-ingv-oe` | Mean Absolute Error (MAE) | ↓ lower |
| 40 | `random-acts-of-pizza` | AUC (area under ROC curve) | ↑ higher |
| 41 | `ranzcr-clip-catheter-line-classification` | Mean AUC (ROC) | ↑ higher |
| 42 | `rsna-2022-cervical-spine-fracture-detection` | Weighted Multi-label Log Loss | ↓ lower |
| 43 | `rsna-breast-cancer-detection` | Probabilistic F1 Score (pF1) | ↑ higher |
| 44 | `rsna-miccai-brain-tumor-radiogenomic-classification` | AUC (ROC) | ↑ higher |
| 45 | `siim-covid19-detection` | mean Average Precision (mAP) | ↑ higher |
| 46 | `siim-isic-melanoma-classification` | AUC (ROC) | ↑ higher |
| 47 | `smartphone-decimeter-2022` | Mean of 50th and 95th percentile horizontal distance error | ↓ lower |
| 48 | `spooky-author-identification` | Multi-class log loss | ↓ lower |
| 49 | `stanford-covid-vaccine` | MCRMSE (mean column-wise RMSE) over 3 of 5 target columns | ↓ lower |
| 50 | `statoil-iceberg-classifier-challenge` | Binary log loss | ↓ lower |
| 51 | `tensorflow2-question-answering` | Micro F1 | ↑ higher |
| 52 | `text-normalization-challenge-english-language` | Accuracy | ↑ higher |
| 53 | `text-normalization-challenge-russian-language` | Accuracy | ↑ higher |
| 54 | `tgs-salt-identification-challenge` | Mean Average Precision at different IoU thresholds | ↑ higher |
| 55 | `the-icml-2013-whale-challenge-right-whale-redux` | Area Under the ROC Curve (AUC) | ↑ higher |
| 56 | `tweet-sentiment-extraction` | Word-level Jaccard | ↑ higher |
| 57 | `us-patent-phrase-to-phrase-matching` | Pearson correlation coefficient | ↑ higher |
| 58 | `uw-madison-gi-tract-image-segmentation` | dice-hausdorff-combo | ↑ higher |
| 59 | `ventilator-pressure-prediction` | Mean Absolute Error (MAE) on inspiratory phase only | ↓ lower |
| 60 | `vesuvius-challenge-ink-detection` | F0.5 Score | ↑ higher |
| 61 | `whale-categorization-playground` | Mean Average Precision @ 5 (MAP@5) | ↑ higher |

## Citation

```bibtex
@article{ambig-ds-2026,
  title  = {Ambig-DS: Diagnosing Unflagged Misframings in Data-Science Agents},
  year   = {2026},
  note   = {NeurIPS 2026 Datasets \& Benchmarks submission (under review)}
}
```

## License

The contents of this repository (prompts, manifest, task list) are released under **CC-BY-NC-4.0** to conservatively respect upstream non-commercial dataset terms and per-competition Kaggle rules (MLE-bench code is MIT). The `full.md` files are derivative paraphrases of publicly available Kaggle competition descriptions, redistributed following the precedent set by [MLE-bench](https://github.com/openai/mle-bench) (MIT). The `ambig_metric.md` files, the `metric_manifest.json` ground-truth metadata, and the redaction protocol are original contributions.

The underlying Kaggle competition datasets are **not** redistributed here. They must be downloaded separately via `mlebench prepare` and remain subject to each competition's individual rules and terms of use.
