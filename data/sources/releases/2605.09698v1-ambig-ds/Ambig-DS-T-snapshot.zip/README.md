---
license: cc-by-nc-4.0
task_categories:
  - tabular-classification
  - tabular-regression
language:
  - en
tags:
  - benchmark
  - ambiguity
  - ml-engineering
  - kaggle
  - target-ambiguity
  - data-science
  - llm-agents
pretty_name: "Ambig-DS-T: Target Ambiguity Benchmark for Data-Science Agents"
size_categories:
  - n<1K
configs:
  - config_name: tasks_index
    data_files:
      - split: train
        path: tasks.csv
    default: true
---

# Ambig-DS-T: Target Ambiguity Benchmark

A benchmark for measuring how well data-science agents handle **ambiguous prediction targets** in tabular Kaggle competitions.

Each task is a Kaggle competition derived from [DSBench](https://github.com/LiqiangJing/DSBench). For every task we provide two prompt variants — one in which the target column is named, and one in which the target is hidden behind two candidate columns. The agent must select and predict the **true** target; submissions are graded by the original competition metric using DSBench's per-task evaluator.

The benchmark contains **51 paired tasks** (33 classification, 18 regression).

## Variants

| Variant | File | Description |
|---------|------|-------------|
| **Full** | `tasks/{slug}/task.txt` | Original task description — names the target column verbatim and lists features under their semantic names. |
| **Ambiguous** | `tasks/{slug}/task_ambig.txt` | Same description with **target identity hidden**: feature names are anonymized to `f_01, f_02, …`, the original target name is removed, and training data exposes **two** candidate target columns `val_1` and `val_2`. Exactly one is the true target; the other is a feature-predictable decoy with the same marginal distribution. |

The `Full` arm establishes the upper baseline; the `Ambiguous` arm is the diagnostic condition. The failure mode the benchmark measures: an agent that silently picks the decoy column will train a model with normal-looking cross-validation behaviour but score poorly on the held-out test, because the decoy is constructed to be approximately uncorrelated with the true target.

## Layout

```
tasks/
  {slug}/
    task.txt              # Full task description (target named)
    task_ambig.txt        # Target-redacted version (val_1 + val_2 decoy)
    eval.py               # Per-task evaluator (DSBench CLI; metric varies by task)
    _manifest.json        # Provenance + decoy recipe + diagnostics
tasks.csv                 # Flat 51-row index (slug, task_type, n_train, n_test, oracle target column, …)
```

## Setup: getting the competition data

This dataset contains **prompts, evaluators, and decoy recipes only** — not the Kaggle competition data (train/test CSVs). To respect each competition's terms of use, the redistributed contents are deterministic *recipes* over data the user must download themselves.

To run the benchmark:

1. Accept each competition's rules in your browser (the `source.rules_url` field of `_manifest.json` links straight there).
2. Download the data via the official Kaggle CLI (`kaggle competitions download -c <slug>`).
3. Use the build script (published separately on GitHub) to apply the deterministic recipe in `_manifest.json.ambig_recipe`. This rebuilds the ambig CSVs bit-identically using the recorded `seeds.master` and `seeds.decoy`.

## Manifest

`tasks/{slug}/_manifest.json` records, per task:

| Section | Purpose |
|---|---|
| `source` | `platform`, `url`, `rules_url`, `wave` (all 51 are `dsbench_original`). |
| `task` | `task_type` (classification/regression), `id_column`, **`true_target_column_in_ambig`** (oracle: `val_1` or `val_2`), `decoy_column_in_ambig`, `original_target_name`, `n_features`, `n_train`, `n_test`. |
| `ambig_recipe` | Deterministic decoy generation. `method` (e.g. `rank_map_lowcorr_pool+label_noise`), full `feature_map` (original→anon), `anon_feature_columns`, `decoy_pool_anon_features` and their `decoy_pool_abs_spearman_with_truth`, label-noise fractions, `seeds.master` / `seeds.decoy`. |
| `diagnostics` | `cv_true`, `cv_decoy`, `cv_ratio_decoy_over_true`, `correlation_truth_vs_decoy`, `marginal_match_exact`. The decoy is calibrated so that its values are approximately uncorrelated with the true target while remaining roughly as feature-predictable. |
| `eval` | Pointer to the local `eval.py` and its CLI signature. |

The `task.true_target_column_in_ambig` field is the **clarification oracle's source of truth**: in the *clarify* experimental condition, an answerer LLM resolves the agent's questions about which column to predict using only this field. It is intentionally **never given to the agent** in the *ambig* (no-clarify) condition.

Example `task` and `diagnostics` (from `bike-sharing-demand`):

```json
{
  "task": {
    "task_type": "regression",
    "id_column": "datetime",
    "true_target_column_in_ambig": "val_1",
    "decoy_column_in_ambig": "val_2",
    "original_target_name": "count",
    "n_features": 8,
    "n_train": 8708,
    "n_test": 2178
  },
  "diagnostics": {
    "cv_true": 0.34,
    "cv_decoy": 0.64,
    "cv_ratio_decoy_over_true": 1.90,
    "correlation_truth_vs_decoy": 0.01,
    "marginal_match_exact": true
  }
}
```

`cv_decoy` matches `cv_true` in feature-predictability (median ratio across the benchmark $\approx 1.0$) while `correlation_truth_vs_decoy ≈ 0` (median $|\rho_{\mathrm{Spearman}}| = 0.017$): the two columns are equally learnable but almost orthogonal, so an agent that picks the wrong column still gets a high CV score on data that is unrelated to the true target.

## Evaluating a submission

Every `eval.py` accepts the same DSBench-style CLI:

```bash
python eval.py --answer_file data/test_answer.csv \
               --predict_file my_submission.csv \
               --path out --name <slug>
```

…and writes a single float (the competition's original metric — RMSLE / AUC / RMSE / accuracy / …) to `out/<slug>/result.txt`.

## Tasks (51)

| # | Competition | Type | True column | n_train | n_test | n_features |
|---|---|---|---|---|---|---|
| 1 | `bike-sharing-demand` | regression | `val_1` | 8,708 | 2,178 | 8 |
| 2 | `cat-in-the-dat` | classification | `val_1` | 240,000 | 60,000 | 23 |
| 3 | `cat-in-the-dat-ii` | classification | `val_2` | 480,000 | 120,000 | 23 |
| 4 | `dont-overfit-ii` | classification | `val_1` | 200 | 50 | 300 |
| 5 | `instant-gratification` | classification | `val_2` | 209,715 | 52,429 | 256 |
| 6 | `playground-series-s3e1` | regression | `val_1` | 29,709 | 7,428 | 8 |
| 7 | `playground-series-s3e10` | classification | `val_1` | 94,051 | 23,513 | 8 |
| 8 | `playground-series-s3e11` | regression | `val_1` | 288,268 | 72,068 | 15 |
| 9 | `playground-series-s3e12` | classification | `val_1` | 331 | 83 | 6 |
| 10 | `playground-series-s3e13` | classification | `val_2` | 565 | 142 | 64 |
| 11 | `playground-series-s3e14` | regression | `val_2` | 12,231 | 3,058 | 16 |
| 12 | `playground-series-s3e16` | regression | `val_2` | 59,240 | 14,811 | 8 |
| 13 | `playground-series-s3e17` | classification | `val_2` | 109,143 | 27,286 | 12 |
| 14 | `playground-series-s3e2` | classification | `val_2` | 12,243 | 3,061 | 10 |
| 15 | `playground-series-s3e20` | regression | `val_1` | 63,218 | 15,805 | 75 |
| 16 | `playground-series-s3e22` | classification | `val_1` | 988 | 247 | 27 |
| 17 | `playground-series-s3e23` | classification | `val_1` | 81,410 | 20,353 | 21 |
| 18 | `playground-series-s3e24` | classification | `val_1` | 127,404 | 31,852 | 22 |
| 19 | `playground-series-s3e25` | regression | `val_1` | 8,325 | 2,082 | 11 |
| 20 | `playground-series-s3e3` | classification | `val_2` | 1,341 | 336 | 33 |
| 21 | `playground-series-s3e4` | classification | `val_2` | 175,303 | 43,826 | 30 |
| 22 | `playground-series-s3e5` | classification | `val_1` | 1,644 | 412 | 11 |
| 23 | `playground-series-s3e6` | regression | `val_2` | 18,184 | 4,546 | 16 |
| 24 | `playground-series-s3e7` | classification | `val_2` | 33,680 | 8,420 | 17 |
| 25 | `playground-series-s3e8` | regression | `val_1` | 154,858 | 38,715 | 9 |
| 26 | `playground-series-s3e9` | regression | `val_1` | 4,325 | 1,082 | 8 |
| 27 | `playground-series-s4e1` | classification | `val_1` | 132,027 | 33,007 | 12 |
| 28 | `playground-series-s4e2` | classification | `val_2` | 16,606 | 4,152 | 16 |
| 29 | `playground-series-s4e4` | classification | `val_2` | 72,492 | 18,123 | 8 |
| 30 | `playground-series-s4e5` | regression | `val_2` | 500,000 | 223,592 | 20 |
| 31 | `playground-series-s4e6` | classification | `val_1` | 61,214 | 15,304 | 36 |
| 32 | `porto-seguro-safe-driver-prediction` | classification | `val_2` | 476,169 | 119,043 | 57 |
| 33 | `santander-customer-satisfaction` | classification | `val_1` | 60,816 | 15,204 | 369 |
| 34 | `santander-customer-transaction-prediction` | classification | `val_1` | 160,000 | 40,000 | 201 |
| 35 | `santander-value-prediction-challenge` | regression | `val_1` | 3,567 | 892 | 4,991 |
| 36 | `spaceship-titanic` | classification | `val_1` | 6,954 | 1,739 | 12 |
| 37 | `tabular-playground-series-apr-2021` | classification | `val_2` | 80,000 | 20,000 | 10 |
| 38 | `tabular-playground-series-aug-2021` | regression | `val_1` | 200,000 | 50,000 | 100 |
| 39 | `tabular-playground-series-aug-2022` | classification | `val_1` | 21,256 | 5,314 | 24 |
| 40 | `tabular-playground-series-feb-2021` | regression | `val_1` | 240,000 | 60,000 | 24 |
| 41 | `tabular-playground-series-feb-2022` | classification | `val_2` | 66,900 | 16,725 | 286 |
| 42 | `tabular-playground-series-jan-2021` | regression | `val_1` | 240,000 | 60,000 | 14 |
| 43 | `tabular-playground-series-mar-2021` | classification | `val_1` | 240,000 | 60,000 | 30 |
| 44 | `tabular-playground-series-mar-2022` | regression | `val_1` | 500,000 | 169,767 | 4 |
| 45 | `tabular-playground-series-may-2022` | classification | `val_1` | 720,000 | 180,000 | 31 |
| 46 | `tabular-playground-series-nov-2021` | classification | `val_2` | 480,000 | 120,000 | 100 |
| 47 | `tabular-playground-series-oct-2021` | classification | `val_2` | 500,000 | 200,000 | 285 |
| 48 | `tabular-playground-series-sep-2021` | classification | `val_2` | 416,946 | 104,237 | 118 |
| 49 | `titanic` | classification | `val_1` | 712 | 179 | 10 |
| 50 | `tmdb-box-office-prediction` | regression | `val_1` | 2,400 | 600 | 21 |
| 51 | `ventilator-pressure-prediction` | regression | `val_1` | 500,000 | 1,207,200 | 6 |

The `True column` column is the answer the clarification oracle returns when an agent asks which of `val_1`/`val_2` to predict; it is never shown to the agent in the *ambig* condition.

## Citation

```bibtex
@article{ambig-ds-2026,
  title  = {Ambig-DS: Diagnosing Unflagged Misframings in Data-Science Agents},
  year   = {2026},
  note   = {NeurIPS 2026 Datasets \& Benchmarks submission (under review)}
}
```

## License

The contents of this repository (prompts, manifests, task index, decoy recipes) are released under **CC-BY-NC-4.0**, inheriting the non-commercial research-use restriction from the upstream DSBench dataset terms (DSBench code is MIT). The `task.txt` files are factual paraphrases of publicly available Kaggle competition descriptions; the `task_ambig.txt` files, the decoy-generation recipes in `_manifest.json.ambig_recipe`, and the per-task diagnostics are original contributions.

The per-task `eval.py` evaluators are **redistributed unchanged from [DSBench](https://github.com/LiqiangJing/DSBench)** (Jing et al., 2024) so that grading remains bit-identical to upstream. Some still contain inline comments in Chinese — these are upstream artefacts.

The underlying Kaggle competition datasets are **not** redistributed here. They must be downloaded separately via the Kaggle API and remain subject to each competition's individual rules and terms of use.
