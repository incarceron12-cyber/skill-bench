"""Tests for annotation API."""
