"""Tests for scores package."""
