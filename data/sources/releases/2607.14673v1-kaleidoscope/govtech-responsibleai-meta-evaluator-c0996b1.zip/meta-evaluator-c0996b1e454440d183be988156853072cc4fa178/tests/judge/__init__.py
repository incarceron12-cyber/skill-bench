"""All judge tests."""
