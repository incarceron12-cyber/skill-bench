---
license: mit
task_categories:
- question-answering
- text-classification
- text-retrieval
language:
- en
tags:
- academic
- questions
- evidence
- papers
size_categories:
- 1K<n<10K
---
# ELAIPBench Dataset

## Description
This dataset contains academic questions with evidence passages extracted from research papers. Each question is paired with a relevant passage from the source paper that provides evidence for answering the question.It was officially adopted as the dataset for the [CCKS 2025 Academic Paper Question Answering Challenge](https://tianchi.aliyun.com/competition/entrance/532359).

## Dataset Structure
The dataset contains 403 questions with the following fields:
- `paper_id`: ID of the source paper (corresponds to PDF filename in papers.zip)
- `question_type`: Type of question (SA-MCQ, MA-MCQ, etc.)
- `question`: The question text
- `answer`: The correct answer
- `relevant_passage`: Evidence passage extracted from the paper
- `paper_content`: Full text content of the source paper

## Usage
```python
from datasets import load_dataset
# Load the dataset
dataset = load_dataset("KangKang625/ELAIPBench")
# Access the data
data = dataset['test']
print(f"Number of questions: {len(data)}")
print(f"First question: {data[0]['question']}")
print(f"Paper content length: {len(data[0]['paper_content'])}")
```

## Citation
If you use this dataset, please cite the original ELAIPBench paper.

## License
MIT License
