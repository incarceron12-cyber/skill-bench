# The Scenario

I'm a **Vice President at Halberd Capital Partners**, a US mid-market private equity firm with approximately $8B AUM and a generalist platform. I'm supporting the deal team's preliminary outside-in commercial due diligence on **Aurora Eggs Ltd**, a privately-held New Zealand egg producer being evaluated as a trans-Pacific tuck-in for Halberd's existing North American agri-platform.

---

## Deal Context

The deal is at **pre-LOI / indicative-bid prep** stage. Halberd's preliminary review must form an initial view and surface the open questions that confirmatory DD would need to answer before any LOI.

---

## The NZ Egg Industry in Transition

The New Zealand egg industry is mid-way through a two-phase shift in production-system mix.

- **Phase 1: conventional cages banned.** Battery cages were phased out by end of 2022 under the Animal Welfare (Layer Hens) Code of Welfare. Producers transitioned to colony cages, barn, or free-range systems.
- **Phase 2: retailer-driven cage-free transition.** Major NZ supermarkets have committed to removing caged eggs, including colony cages, from packaged shell-egg shelves. This is not a regulatory mandate - it is a private-sector commitment driven by retailer ESG positioning and consumer pressure. It forces the remaining colony-cage cohort to convert systems to retain shelf access at major retailers.
- **Avian influenza cost overlay.** A 2024-25 H7N6 outbreak in the Otago region drove culls, cleaning, repopulation delays, and biosecurity costs.
- **Free-range premium compression.** As barn supply scales to fill the colony exit gap, the historic free-range price premium is showing signs of compression. The trajectory is contested across sources.

The industry is highly fragmented and largely family-owned. The national layer flock is approximately 3.4-3.9M hens. There is no listed NZ pure-play egg producer; the closest listed comparables are international.

---

## The Asset - Aurora Eggs Ltd

Aurora Eggs is a privately-held NZ shell-egg producer. The McKenna family has run the business for three generations. Approximate scale lands Aurora as the **#2 player by volume** (behind Mainland Poultry, ahead of the rest of the public producer roster), with a production mix weighted toward colony-cage exposure that must convert under the 2027 retailer pledge. Because Aurora is privately held, its volume share is invisible in public analyst coverage and is recovered by triangulating across interview anchors and the public-tracked roster. The family is reportedly considering a partial sale to fund the cage-to-barn capex program.

The asset's central tension is its production-system mix and its ability to execute a colony-to-barn conversion program on time. The seller side and Aurora's public material position the transition plan as straightforward. Industry expert commentary surfaces material operational complexity in capex magnitude, day-old chick supply lead times, and resource-consent processes.

Because Aurora is privately held, it may not appear by name in public market reports.

---

## The Halberd Platform

Halberd already owns a North American agri-platform operating in adjacent food-protein categories. The Sector Partner sees Aurora as a possible trans-Pacific tuck-in - small relative to a typical Halberd deal but strategic if the unit economics support it. The preliminary review must determine whether the asset and the deal economics warrant moving to confirmatory DD.

---

## My Mission

Over a single week, I'll produce four parallel CDD deliverables. Each is a workstream that another VP or analyst on a typical CDD team would own; here I own all four. **Each deliverable must be independently completable from the source pool alone - they do not depend on each other's outputs.**

The deliverables surface the strengths, weaknesses, opportunities, and risks that the Investment Committee will use to decide.

---

## Halberd Capital Partners - Deal Team

| Name | Role | Perspective |
|------|------|-------------|
| Hugh Pemberton | Managing Partner | Deal sponsor; convenes IC. Pragmatic about cross-border tuck-ins where the platform synergy is real. Author of the firm's preliminary-stage methodology. |
| Vivian Holst | Sector Partner - Consumer & Agri | Deal champion. Holds a thesis on the trans-Pacific protein platform and has shared specific must-test hypotheses with the deal team. |
| Daniel Reyes | Principal | Deal lead. Owns end-to-end DD coordination and Halberd-side communication. |
| Maya Okonkwo | Senior Associate | Peer collaborator on the deal team. |
| Theo Lindgren | Associate | Junior team member. Sometimes wrong; check his claims against authoritative sources. |
| Marcus Vale | Operating Partner - Operations | Will weigh in on operational separability and capex realism. |
| Priya Iyer | Operating Partner - Commercial | Will weigh in on retail / foodservice channel dynamics. |
| Iris Beaumont | Research Analyst | Halberd internal; takes notes on commissioned expert interviews. |

---

## Listed Comparables (for benchmarking only)

| Company | Listing | Position | Notes |
|---|---|---|---|
| Cal-Maine Foods | NYSE | Largest US egg producer by volume | Global pure-play. Substantially larger scale than Aurora; mind the scale gap when benchmarking. |
| Inghams Group | ASX | Australian + NZ poultry meat | Adjacency, not a direct egg comp; broiler economics differ from layer. |

There is no listed NZ shell-egg pure-play. Recent NZ-egg precedent transactions are limited and fragmented; treat them as directional, not definitive.

---

## What You Have Access To

You will be provided with:

- **Shared reference materials** - scenario-wide documents available throughout the engagement (in `shared/`)
- **Week-specific documents** - source materials for the current week's tasks (in `week/`)

This scenario overview and a week-specific overview are provided to you at the start of each week.
