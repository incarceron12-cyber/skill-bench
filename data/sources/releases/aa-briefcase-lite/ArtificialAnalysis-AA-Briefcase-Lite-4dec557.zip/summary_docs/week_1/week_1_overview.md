# Week 1: Preliminary Outside-In CDD

This week, I'll produce four parallel preliminary CDD deliverables for the Aurora Eggs opportunity: a market overview rendered as a single-page LaTeX-TikZ depiction, an Excel market-sizing and cage-ban transition model, a target-assessment slide deck, and a short briefing video with subtitles. Each deliverable is independently gradeable from the source pool - they do not depend on each other's outputs, and I should assume that any one deliverable does not need to reference another's work product.

The deliverables describe what is true, surface what is contested across sources, quantify where I can, and identify the questions confirmatory DD would need to answer.
