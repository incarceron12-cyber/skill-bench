import argparse
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy.stats import beta, pearsonr
from sklearn.metrics import (
    accuracy_score,             # high is good
    brier_score_loss,           # low is good
    log_loss,                   # low is good
)

root_dir = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(root_dir))

from src.metrics import (  # noqa: E402
    ece_binary_classification,
    mce_binary_classification,
    rauc_binary_classification,
    error_detection_binary_classification,
)
from src.metrics.utility import (  # noqa: E402
    binary_decision_pwu,
    binary_decision_utility,
    topk_utility_binary_classification,
    topk_utility_binary_classification_pwu,
)
from src.utils import compute_metric_correlation, top1_agreement, topk_agreement  # noqa: E402


def _compute_metrics_for_one_model(
    y_true: np.ndarray,
    probs: np.ndarray,
    alpha_param_c: float,
    beta_param_c: float,
    alpha_param_k: float,
    beta_param_k: float,
    c_vec: np.ndarray,
    c_vec_name: np.ndarray,
    k_frac_vec: List[float],
    k_frac_name: np.ndarray,
) -> Dict[str, float]:
    y_pred = (probs > 0.5).astype(int)

    nll = log_loss(y_true, probs)
    brier = brier_score_loss(y_true, probs)
    acc = accuracy_score(y_true, y_pred)
    ece = ece_binary_classification(y_true, probs, n_bins=10)
    mce = mce_binary_classification(y_true, probs, n_bins=10)

    eps = 1e-12
    probs_clipped = np.clip(probs, eps, 1 - eps)
    entropy = -probs_clipped * np.log(probs_clipped) - (1 - probs_clipped) * np.log(
        1 - probs_clipped
    )
    _, _, rauc = rauc_binary_classification(
        y_true, y_pred, uncertainty=entropy, num_points=101
    )
    e_det = error_detection_binary_classification(y_true, y_pred, uncertainty=entropy)

    bd_p = binary_decision_pwu(probs, y_true, alpha_param_c, beta_param_c)
    topk_p = topk_utility_binary_classification_pwu(
        probs, y_true, alpha_param_k, beta_param_k
    )

    out = {
        "NLL ↓": float(nll),
        "Brier ↓": float(brier),
        "Acc ↑": float(acc),
        "ECE ↓": float(ece),
        "MCE ↓": float(mce),
        "R-AUC ↓": float(rauc),
        "E-Det ↑": float(e_det),
        "BD-PWU ↓": float(bd_p),
        "TopK-PWU ↓": float(topk_p),
    }

    for i, c in enumerate(c_vec):
        out[f"u_c, c={c_vec_name[i]:.2f} ↑"] = float(
            binary_decision_utility(probs, y_true, c)
        )

    for i, k_frac in enumerate(k_frac_vec):
        k = int(np.ceil(len(y_true) * k_frac))
        out[f"u_k, k/n={k_frac_name[i]:.2f} ↑"] = float(
            topk_utility_binary_classification(probs, y_true, k)
        )

    return out


def main(dataset: Optional[str] = "bank"):
    PRED_PATH = Path(
        str(root_dir)
        + f"/experiments/benchmark_datasets/binary_classification/predictions/{dataset}"
    )

    # configure utilities
    alpha_param_c = 2.0
    beta_param_c = 10.0
    n_c_samples = 5
    alpha_param_k = 1.2
    beta_param_k = 20.8
    n_k_samples = 5
    rng = np.random.default_rng(
        0
    )  # Fix the c_vec once (global across repeats) for comparability
    c_vec = beta.rvs(alpha_param_c, beta_param_c, size=n_c_samples, random_state=rng)
    c_vec_name = np.round(c_vec, 2)
    k_frac_vec = beta.rvs(
        alpha_param_k, beta_param_k, size=n_k_samples, random_state=rng
    )
    k_frac_name = np.round(k_frac_vec, 2)

    RESULT_PATH = Path(
        str(root_dir)
        + f"/experiments/benchmark_datasets/binary_classification/results/{dataset}"
    )
    RESULT_PATH.mkdir(parents=True, exist_ok=True)

    files = sorted(PRED_PATH.glob("repeat_*/fold_*/predictions.csv"))
    if len(files) == 0:
        raise FileNotFoundError(f"No predictions.csv files found under {PRED_PATH}")

    rows = []
    for fp in files:
        repeat_str = fp.parents[1].name.replace("repeat_", "")
        fold_str = fp.parents[0].name.replace("fold_", "")
        repeat, fold = int(repeat_str), int(fold_str)

        df = pd.read_csv(fp)
        if "y_true" not in df.columns:
            raise ValueError(f"{fp} is missing y_true column.")

        y_true = df["y_true"].to_numpy().astype(int)
        model_cols = [
            c
            for c in df.columns
            if c not in {"repeat", "fold", "seed", "test_idx", "y_true"}
        ]

        for model in model_cols:
            probs = df[model].to_numpy().astype(float)
            metrics = _compute_metrics_for_one_model(
                y_true=y_true,
                probs=probs,
                alpha_param_c=alpha_param_c,
                beta_param_c=beta_param_c,
                alpha_param_k=alpha_param_k,
                beta_param_k=beta_param_k,
                c_vec=c_vec,
                c_vec_name=c_vec_name,
                k_frac_vec=k_frac_vec,
                k_frac_name=k_frac_name,
            )
            rows.append(
                {
                    "repeat": repeat,
                    "fold": fold,
                    "model": model,
                    **metrics,
                }
            )

    metrics_df = pd.DataFrame(rows)

    # ---- Aggregate over folds to get per-repeat, per-model metrics ----
    # Mean over folds within each repeat and model
    metric_cols = [
        c for c in metrics_df.columns if c not in {"repeat", "fold", "model"}
    ]
    metric_values_by_repeat = metrics_df.groupby(["repeat", "model"], as_index=False)[
        metric_cols
    ].mean()

    # Contains per-repeat, per-model metric values; averaged over folds
    metric_values_by_repeat.to_csv(
        RESULT_PATH / "metric_values_by_repeat.csv", index=False
    )

    # ---- Ranking + alignment per repeat ----
    # Identify which metrics should be ascending or descending
    smaller_is_better = {
        "NLL ↓": True,
        "Brier ↓": True,
        "Acc ↑": False,
        "ECE ↓": True,
        "MCE ↓": True,
        "R-AUC ↓": True,
        "E-Det ↑": False,
        "BD-PWU ↓": True,
        "TopK-PWU ↓": True,
    }
    for i in range(len(c_vec)):
        smaller_is_better[f"u_c, c={c_vec_name[i]:.2f} ↑"] = False
    for i in range(len(k_frac_vec)):
        smaller_is_better[f"u_k, k/n={k_frac_name[i]:.2f} ↑"] = False

    # Clean names (remove arrows) for output tables
    def clean_metric_name(name: str) -> str:
        return name.replace("↑", "").replace("↓", "").strip()

    base_metrics = [
        clean_metric_name(m)
        for m in [
            "NLL ↓",
            "Brier ↓",
            "Acc ↑",
            "ECE ↓",
            "MCE ↓",
            "R-AUC ↓",
            "E-Det ↑",
            "BD-PWU ↓",
            "TopK-PWU ↓",
        ]
    ]
    utilities = [clean_metric_name(f"u_c, c={c:.2f} ↑") for c in c_vec_name] + [
        clean_metric_name(f"u_k, k/n={k_frac:.2f} ↑") for k_frac in k_frac_name
    ]

    # Store rankings per repeat (as strings for easy inspection)
    ranking_rows = []

    # Store kendall per repeat (utility x metric)
    tau_rows = []

    repeats = sorted(metric_values_by_repeat["repeat"].unique().tolist())

    for r in repeats:
        sub = metric_values_by_repeat[metric_values_by_repeat["repeat"] == r].set_index(
            "model"
        )

        # Build rank dict
        rank_dict = {}

        for metric, asc in smaller_is_better.items():
            indices_ordered_models = (
                sub[metric].sort_values(ascending=asc).index.tolist()
            )  # lowest index is best model
            rank_dict[clean_metric_name(metric)] = indices_ordered_models

        # Save ranking list as a single string "A>B>C>D>E" for CSV friendliness
        row = {"repeat": r}
        for metric, order in rank_dict.items():
            row[metric] = ">".join(order)
        ranking_rows.append(row)

        for m in base_metrics:
            for u in utilities:
                tau = compute_metric_correlation(
                    ranking_m=rank_dict[m], ranking_u=rank_dict[u]
                )
                t1 = top1_agreement(ranking_m=rank_dict[m], ranking_u=rank_dict[u])
                t3 = topk_agreement(ranking_m=rank_dict[m], ranking_u=rank_dict[u], k=3)
                tau_rows.append(
                    {"repeat": r, "utility": u, "metric": m, "kendall_tau": tau, "top1": t1, "top3": t3}
                )

    ranking_df = pd.DataFrame(ranking_rows)
    ranking_df.to_csv(RESULT_PATH / "model_rankings_by_repeat.csv", index=False)
    tau_df = pd.DataFrame(tau_rows)
    tau_df.to_csv(RESULT_PATH / "kendall_by_repeat.csv", index=False)

    # ---- Summary over repeats (mean + quantiles) ----
    def summarize_alignment(df: pd.DataFrame, value_col: str) -> pd.DataFrame:
        g = df.groupby(["utility", "metric"])[value_col]
        out = g.agg(
            mean="mean",
            median="median",
            q05=lambda x: np.quantile(x, 0.05),
            q95=lambda x: np.quantile(x, 0.95),
        ).reset_index()
        return out

    for value_col in ["kendall_tau", "top1", "top3"]:
        summary = summarize_alignment(tau_df, value_col)
        summary.to_csv(RESULT_PATH / f"{value_col}_summary_over_repeats.csv", index=False)

    pearson_rows = []

    # Map clean names back to original column names
    clean_to_orig = {clean_metric_name(m): m for m in smaller_is_better.keys()}

    for r in repeats:
        sub = metric_values_by_repeat[metric_values_by_repeat["repeat"] == r]

        for m in base_metrics:
            m_values = sub[clean_to_orig[m]].to_numpy()
            for u in utilities:
                u_values = sub[clean_to_orig[u]].to_numpy()
                sign = -1.0 if smaller_is_better[clean_to_orig[m]] else 1.0
                corr, pval = pearsonr(sign * m_values, u_values)
                pearson_rows.append({
                    "repeat": r,
                    "utility": u,
                    "metric": m,
                    "pearson_r": corr,
                    "pearson_pval": pval,
                })

    pearson_df = pd.DataFrame(pearson_rows)
    pearson_df.to_csv(RESULT_PATH / "pearson_by_repeat.csv", index=False)

    pearson_summary = summarize_alignment(pearson_df, "pearson_r")
    pearson_summary.to_csv(RESULT_PATH / "pearson_summary_over_repeats.csv", index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", type=str, default="bank", help="Which dataset to use."
    )

    args = parser.parse_args()
    main(**vars(args))
