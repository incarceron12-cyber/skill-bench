# CLEAR for Agentic Workflows

Evaluate agentic workflows component by component — agents, tools, nodes, or any span grouping you define — from raw traces to interactive dashboards.

## Table of Contents

1. [Overview](#overview)
2. [Quick Start](#quick-start)
3. [Input Data Formats](#input-data-formats)
4. [Running the Pipeline](#running-the-pipeline)
5. [Configuration Reference](#configuration-reference)
6. [Output Structure](#output-structure)
7. [Dashboard](#dashboard)
8. [Examples](#examples)

---

## Overview

CLEAR for Agentic Workflows provides two complementary analysis modes:

| Analysis Type | Description | Use Case |
|---------------|-------------|----------|
| **Step-by-Step** | Evaluates individual agent interactions using CLEAR methodology | Understanding agent-level quality issues |
| **Full Trajectory** | Evaluates complete task trajectories (success, quality, rubric-based) | Assessing overall task completion and quality |

Both analyses share a centralized CSV intermediate representation and produce results viewable in an interactive dashboard.

### Supported Frameworks

The pipeline includes built-in preprocessors for the following combinations:

| Agent Framework | Observability Platform | Status |
|-----------------|------------------------|--------|
| LangGraph | MLflow | Supported |
| LangGraph | Langfuse | Supported |
| CrewAI | Langfuse | Supported |

For other frameworks or observability platforms, preprocess your traces to the CSV format described below and use `--from-raw-traces false`.

---

## Quick Start

### 1. Install from Source

```bash
git clone <repository-url>
cd CLEAR
pip install -e .
```

### 2. Set Up Credentials

Configure your LLM provider credentials. See the [Providers and Credentials Guide](../../../docs/providers.md) for provider-specific setup instructions.

### 3. Generating Traces (Prerequisite)

CLEAR evaluates traces from your agent's runs. In real scenarios you run your own agent with observability enabled and export the resulting traces.

See [`examples/run_agent/`](../../../examples/run_agent/) for a complete working example — a LangGraph agent with MLflow or Langfuse tracing that exports JSON traces ready for CLEAR. For MLflow-specific tracing requirements, see the [MLflow Tracing Requirements](../../../docs/agentic/mlflow-tracing.md).

**Using a different agent framework or observability platform?** You can preprocess your traces into the CSV intermediate representation and run with `--from-raw-traces false`. See [`research_agent_results/mlflow/my_experiment/traces_data/`](../sample_data/agentic/research_agent_results/mlflow/my_experiment/traces_data/) for concrete examples, and the [Intermediate Representation Reference](../../../docs/agentic/intermediate-representation.md) for the full schema.

The repo also ships pre-generated traces (produced by that example agent) so you can try CLEAR without running an agent yourself:

```
src/clear_eval/sample_data/agentic/
├── research_agent_traces/
│   ├── mlflow/                 # 20 MLflow JSON traces
│   └── langfuse/               # 5 Langfuse JSON traces (examples)
└── research_agent_results/
    └── mlflow/                 # Pre-computed CLEAR results (20 traces)
```

### 4. Quick Smoke Test (3 Traces)

Run CLEAR on a small subset of the sample traces to verify your installation:

```bash
run-clear-agentic-eval \
    --data-dir src/clear_eval/sample_data/agentic/research_agent_traces/mlflow \
    --results-dir my_smoke_test_results \
    --from-raw-traces true \
    --agent-framework langgraph \
    --observability-framework mlflow \
    --run-name smoke_test \
    --max-files 3 \
    --eval-model-name gpt-4o \
    --provider openai
```

**Note:** Adjust `--provider` and `--eval-model-name` to match your setup. See the [Providers and Credentials Guide](../../../docs/PROVIDERS.md).

### 5. View Pre-Computed Results (All 20 Traces)

To explore complete results over all 20 traces without re-running evaluation, launch the dashboard and upload the pre-computed results:

```bash
run-clear-agentic-dashboard
# Upload: src/clear_eval/sample_data/agentic/research_agent_results/mlflow/my_experiment/unified_ui_results.zip
```

The dashboard shows step-by-step CLEAR analysis per agent node, full trajectory evaluations and scores, interactive workflow visualization, path analysis, and temporal trends.

**Large-scale results (CUGA agent on AppWorld benchmark):**

```bash
# Download from GitHub Release (~259MB)
gh release download cuga-appworld-output-v1 --pattern "*.zip"

# Launch dashboard and upload the downloaded ZIP
run-clear-agentic-dashboard
```

### 6. Run the Pipeline on Your Own Data

**Using Python module:**
```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/my_traces \
    --results-dir results \
    --from-raw-traces true \
    --eval-model-name gpt-4o \
    --provider openai
```

**Using CLI command:**
```bash
run-clear-agentic-eval \
    --data-dir data/my_traces \
    --results-dir results \
    --from-raw-traces true \
    --eval-model-name gpt-4o \
    --provider openai
```

### 7. Launch the Dashboard

**Using Python module:**
```bash
python -m clear_eval.agentic.dashboard.launch_dashboard
```

**Using CLI command:**
```bash
run-clear-agentic-dashboard
```

Upload the generated `unified_ui_results.zip` from your results directory.

---

## Input Data Formats

### Option 1: Raw JSON Traces

Use `--from-raw-traces true` to process JSON trace files from your observability platform.

**Directory Structure:**
```
my_traces/
├── trace_001.json
├── trace_002.json
└── ...
```

**Trace Format (MLflow example):**
```json
{
  "trace_id": "tr-abc123",
  "spans": [
    {
      "span_id": "span-001",
      "name": "agent_name",
      "span_type": "CHAT_MODEL",
      "parent_span_id": null,
      "inputs": {"messages": [...]},
      "outputs": {"content": "..."},
      "attributes": {
        "llm.model_name": "gpt-4o",
        "llm.token_count.prompt": 100,
        "llm.token_count.completion": 50
      }
    }
  ]
}
```

### Option 2: Preprocessed CSV Files

Use `--from-raw-traces false` to use existing CSV files directly.

**CSV Schema:**

Each CSV file represents one trajectory (`task_id`). Each row represents one LLM call. The `Name` column identifies the component (agent/node) that made the call — CLEAR analysis is performed separately for each unique component.

For the full intermediate representation reference, see [Intermediate Representation Reference](docs/INTERMEDIATE_REPR.md).
---

## Running the Pipeline

### Both Analyses (Default)

Run both step-by-step and full trajectory analysis:

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/my_traces \
    --results-dir results \
    --from-raw-traces true \
    --eval-model-name gpt-4o \
    --provider openai
```

### Step-by-Step Analysis Only

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/my_traces \
    --results-dir results \
    --from-raw-traces true \
    --run-step-by-step true \
    --run-full-trajectory false \
    --eval-model-name gpt-4o \
    --provider openai
```

### Full Trajectory Evaluation Only

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/my_traces \
    --results-dir results \
    --from-raw-traces true \
    --run-step-by-step false \
    --run-full-trajectory true \
    --eval-types task_success full_trajectory \
    --eval-model-name gpt-4o \
    --provider openai
```

### Using a Configuration File

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --agentic-config-path my_config.yaml
```

---

## Configuration Reference

See [`pipeline/setup/default_agentic_config.yaml`](pipeline/setup/default_agentic_config.yaml) for all available options.

### Required Parameters

| Parameter | CLI Flag | Description |
|-----------|----------|-------------|
| `data_dir` | `--data-dir` | Input directory (raw traces or trajectory CSVs) |
| `results_dir` | `--results-dir` | Output directory for results |
| `eval_model_name` | `--eval-model-name` | Model identifier (e.g., `gpt-4o`) |

### Pipeline Control

| Parameter | CLI Flag | Default | Description |
|-----------|----------|---------|-------------|
| `run_step_by_step` | `--run-step-by-step` | `true` | Enable step-by-step analysis |
| `run_full_trajectory` | `--run-full-trajectory` | `true` | Enable trajectory evaluation |
| `from_raw_traces` | `--from-raw-traces` | `false` | `true` = process JSON traces, `false` = use CSV files |

### Model Configuration

| Parameter | CLI Flag | Default | Description                                                                |
|-----------|----------|---------|----------------------------------------------------------------------------|
| `provider` | `--provider` | `openai` | LLM provider                                                               |
| `inference_backend` | `--inference-backend` | `litellm` | Backend: `litellm`, `langchain`                               |
| `eval_model_params` | `--eval-model-params` | `{}` | Model parameters (JSON)                                                    |

### Preprocessing (when `from_raw_traces=true`)

| Parameter | CLI Flag | Default | Description |
|-----------|----------|---------|-------------|
| `agent_framework` | `--agent-framework` | `langgraph` | Agent framework (`langgraph`, `crewai`) |
| `observability_framework` | `--observability-framework` | `langfuse` | Platform (`mlflow`, `langfuse`) |

### Full Trajectory Evaluation

| Parameter | CLI Flag | Default                      | Description |
|-----------|----------|------------------------------|-------------|
| `eval_types` | `--eval-types` | `full_trajectory`, `rubrics` | Evaluations: `task_success`, `full_trajectory`, `rubric`, `all` |
| `generate_rubrics` | `--generate-rubrics` | `true`                       | Generate rubrics before evaluation |
| `rubric_dir` | `--rubric-dir` | None                         | Path to existing rubrics |
| `clear_analysis_types` | `--clear-analysis-types` | `issues`                     | CLEAR analyses: `root_cause`, `issues`, `all`, `none` |
| `context_tokens` | `--context-tokens` | None | Context window; truncates long trajectories in full trajectory evaluation  |

**Note on Rubric Evaluation:**
- Requires trajectories to have a valid `intent` field
- Automatically skipped if no trajectories have intent data
- Runs only on trajectories with valid (non-empty) intent

### Execution

| Parameter | CLI Flag | Default | Description |
|-----------|----------|---------|-------------|
| `run_name` | `--run-name` | `null` | Run identifier. If null, a timestamp is generated (always fresh). |
| `overwrite` | `--overwrite` | `false` | Re-run steps even if their outputs already exist |
| `max_workers` | `--max-workers` | `10` | Parallel workers |
| `max_files` | `--max-files` | `null` | Maximum number of files to evaluate (null = all) |

**Resuming runs:** If `--run-name` points to an existing directory, the pipeline resumes into it. Use `--overwrite false` to skip already-completed steps (e.g. after a failure). Always use the same input data and configuration when resuming.

**Note on `max_files`:** Limits the number of trajectory CSV files to process (first N sorted by name). Preprocessing always runs fully; the limit applies when converting/evaluating. Works in both step-by-step analysis and full trajectory evaluation. Useful for quick testing on a subset of data.

### Advanced: Custom Evaluation Criteria

CLEAR supports customizable evaluation criteria at two levels:

#### Step-by-Step Analysis Criteria

`evaluation_criteria` (alias: `step_evaluation_criteria`) defines **how individual steps are judged** in the step-by-step analysis. Each criterion is a name-description pair — the judge model scores every record against all specified criteria.

```yaml
# In your config YAML
evaluation_criteria:
  reasoning_clarity: "Agent provides clear step-by-step reasoning"
  tool_selection: "Agent selects appropriate tools for the task"
  instruction_following: "Agent follows the user's instructions accurately"
```

When `null`, CLEAR applies default criteria appropriate for the mode (4 agentic criteria for `agent_mode`, 3 general criteria otherwise).

#### Full Trace Evaluation Criteria

`full_trace_evaluation_criteria` defines **how full trajectories are scored** in the full trajectory evaluation. When set, it replaces all 14 default dimensions (9 step-quality + 5 trajectory-level) with a flat list of custom dimensions.

```yaml
# In your config YAML
full_trace_evaluation_criteria:
  Correctness: "Responses produce accurate, logically sound results"
  Goal_Alignment: "Agent stayed aligned with the user's high-level goal"
  Efficiency: "Solution avoids unnecessary complexity or redundant steps"
  Error_Recovery: "Agent recovers effectively from errors and unexpected states"
```

When `null`, CLEAR uses the default 14 dimensions grouped into step-quality and trajectory-level categories.

#### Predefined Issues

`predefined_issues` skips automatic issue discovery in CLEAR analysis and uses a provided list directly. This applies to both step-by-step and full trajectory CLEAR analysis pipelines.

```yaml
predefined_issues:
  - "Incomplete reasoning - jumps to conclusions"
  - "Incorrect tool selection for the task"
  - "Fails to recover from API errors"
```

#### Parameters Summary

| Parameter | CLI Flag | Default | Description |
|-----------|----------|---------|-------------|
| `evaluation_criteria` | `--evaluation-criteria` | `null` (uses built-in agent criteria) | Step-by-step analysis criteria: `{"name": "description", ...}` |
| `step_evaluation_criteria` | — | `null` | Alias for `evaluation_criteria` (config file only) |
| `full_trace_evaluation_criteria` | `--full-trace-evaluation-criteria` | `null` (uses 14 default dimensions) | Full trace evaluation criteria: `{"name": "description", ...}` |
| `predefined_issues` | `--predefined-issues` | `null` | List of known issues to skip automatic discovery |

### Configuration Precedence

1. Default config ([`pipeline/setup/default_agentic_config.yaml`](pipeline/setup/default_agentic_config.yaml))
2. User config file (`--agentic-config-path`)
3. CLI arguments (highest priority)

---

## Output Structure

```
results/
└── <run_name>/
    ├── traces_data/              # Preprocessed CSV files (if from_raw_traces=true)
    │   ├── trace_001.csv
    │   └── ...
    │
    ├── step_by_step/             # Step-by-step CLEAR results
    │   ├── clear_data/           # CLEAR format grouped by agent
    │   │   ├── agent_1.csv
    │   │   └── statistics.json
    │   ├── clear_results/        # CLEAR analysis per agent
    │   │   ├── agent_1/
    │   │   │   ├── analysis_results_*.csv
    │   │   │   ├── per_record_evaluations_*.csv
    │   │   │   └── shortcoming_list_*_dedup.json
    │   │   └── agent_2/
    │   └── clear_results.json    # Comprehensive JSON output
    │
    ├── full_trajectory/          # Full trajectory results
    │   ├── task_success/         # Binary success evaluation
    │   ├── full_trajectory/      # Multi-dimensional quality scores
    │   ├── rubric_generation/    # Generated rubrics (if enabled)
    │   ├── rubric/               # Rubric-based evaluation
    │   └── clear_analysis/       # CLEAR analysis of results
    │       ├── root_cause/       # Analysis of failure causes
    │       └── issues/           # Analysis of quality issues
    │
    ├── unified_ui_results.zip    # Dashboard input
    └── pipeline_summary.json     # Execution metadata
```

### Key Output Files

| File | Description |
|------|-------------|
| `unified_ui_results.zip` | Dashboard-ready package containing all results |
| `clear_results.json` | Comprehensive JSON with issues mapped to spans, per-agent summaries, and pass/fail metrics |
| `pipeline_summary.json` | Execution summary and configuration |
| `analysis_results_*.csv` | Aggregated CLEAR analysis results |
| `shortcoming_list_*_dedup.json` | Deduplicated list of discovered issues |

---

## Dashboard

See [docs/agentic/dashboard.md](../../../docs/agentic/dashboard.md) for detailed documentation.

### Quick Launch

**Using CLI command:**
```bash
run-clear-agentic-dashboard
```

**Using Python module:**
```bash
python -m clear_eval.agentic.dashboard.launch_dashboard
```

Upload `unified_ui_results.zip` from your results directory.

### CLI Options

```bash
run-clear-agentic-dashboard --port 8080 --host 0.0.0.0 --no-open
```

| Flag | Description | Default |
|------|-------------|---------|
| `--port` | Port to run the dashboard on | `8080` |
| `--host` | Host address to bind to | `0.0.0.0` |
| `--no-open` | Disable automatic browser launch | `False` |

### Features

- **Workflow View**: Interactive graph of agents and transitions
- **Node Analysis**: CLEAR analysis results per agent
- **Trajectory Explorer**: Browse individual trajectories with filtering
- **Path Analysis**: Common path patterns and success/failure analysis
- **Temporal Analysis**: Agent position and score progression
- **Score Prediction**: ROC analysis for trajectory success prediction

**Note:** The dashboard requires at least step-by-step analysis results. Full trajectory analysis adds trajectory-level scores and evaluations.

---

## Examples

### Complete Analysis from Raw Traces

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/mlflow_traces \
    --results-dir results \
    --from-raw-traces true \
    --agent-framework langgraph \
    --observability-framework mlflow \
    --run-name my_experiment \
    --eval-model-name gpt-4o \
    --provider openai

# Launch dashboard
python -m clear_eval.agentic.dashboard.launch_dashboard
# Upload: results/my_experiment/unified_ui_results.zip
```

### Testing with Limited Files

```bash
# Analyze only the first 10 files for quick testing
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/mlflow_traces \
    --results-dir results \
    --from-raw-traces true \
    --max-files 10 \
    --eval-model-name gpt-4o \
    --provider openai
```

### Rubric-Based Evaluation

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/traces \
    --results-dir results \
    --from-raw-traces true \
    --run-step-by-step false \
    --run-full-trajectory true \
    --eval-types rubric \
    --generate-rubrics true \
    --eval-model-name gpt-4o \
    --provider openai
```

### Using Existing Rubrics

```bash
python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --data-dir data/traces \
    --results-dir results \
    --eval-types rubric \
    --rubric-dir path/to/rubrics \
    --eval-model-name gpt-4o
```

### Using a Configuration File

```bash
cp src/clear_eval/agentic/pipeline/setup/default_agentic_config.yaml my_config.yaml
# Edit my_config.yaml

python -m clear_eval.agentic.pipeline.run_clear_agentic_eval \
    --agentic-config-path my_config.yaml
```
