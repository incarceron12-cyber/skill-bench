"""
Extract LLM calls from MLflow/OTel JSON traces.

Focus: LangGraph-style traces (agent/chain/node functions), using parent/child
relationships to reconstruct order and ownership.

Supports input files that contain:
  - a single trace dict
  - a list of trace dicts
  - a wrapper {"traces": [...]}

Output fields match the unified CSV schema:
  Name, intent, task_id, step_in_trace_general, llm_call_index,
  model_input, response, tool_or_agent, api_spec, meta_data, traj_score
"""

import json
from typing import Any, Dict, List, Optional

from .trace_utils import (
    safe_json,
    extract_messages_from_input,
    normalize_input_messages,
    normalize_response,
    extract_tool_calls,
    extract_from_output_messages,
    extract_api_spec,
    extract_intent_from_input,
    truncate_middle,
    build_csv_rows,
    _INTENT_LIMIT,
)


# ----------------- helpers -----------------

def _get(d: Dict[str, Any], path: List[Any], default=None):
    """Safely navigate nested dict by path, auto-parsing JSON strings."""
    cur = d
    for p in path:
        if isinstance(cur, str):
            cur = safe_json(cur)
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return default
    return safe_json(cur) if isinstance(cur, str) else cur

def _parse_attrs(attrs: Dict[str, Any]) -> Dict[str, Any]:
    """Parse all JSON-string values in an attributes dict."""
    return {k: safe_json(v) if isinstance(v, str) else v for k, v in attrs.items()}


def get_by_any_key(s: Dict[str, Any], keys: list[str]):
    for k in keys:
        if k in s:
            return s[k]
    return None

def get_parent_id(s):
     return get_by_any_key(s, ["parent_id", "parent_span_id", "parentSpanId"])

def get_start_time(s):
    return get_by_any_key(s, ["start_time_unix_nano", "start_time_ns", "start_time"])

def get_end_time(s):
    return get_by_any_key(s, ["end_time_unix_nano", "end_time_ns", "end_time"])

# ----------------- span semantics -----------------

def _span_type(s: Dict[str, Any]) -> Optional[str]:
    return _get(s, ["attributes", "mlflow.spanType"]) or _get(s, ["attributes", "span.type"])


_WRAPPER_TYPES = {"CHAIN", "AGENT", "TOOL"}
_MODEL_TYPES = {"CHAT_MODEL", "MODEL", "GENERATION"}


def _is_wrapper_span(s: Dict[str, Any]) -> bool:
    return (_span_type(s) in _WRAPPER_TYPES)# or bool(_get(s, ["attributes", "langgraph.node"]))


def _is_model_call_span(s: Dict[str, Any]) -> bool:
    st = _span_type(s)
    if st in _MODEL_TYPES:
        return True
    if _get(s, ["attributes", "gen_ai.operation.name"]):
        return True
    outputs_obj = s.get("outputs")
    if isinstance(outputs_obj, dict) and "choices" in outputs_obj:
        return True
    if _get(s, ["attributes", "gen_ai.output.messages"]):
        return True
    return False


def _get_span_name(s: Dict[str, Any]) -> Optional[str]:
    return (
      #  _get(s, ["attributes", "langgraph.node"]) or
        _get(s, ["attributes", "mlflow.spanFunctionName"]) or
        s.get("name")
    )


# ----------------- payload extraction -----------------

def _extract_model_name(attrs: Dict[str, Any], inputs: Dict[str, Any], outputs_obj: Any) -> Optional[str]:
    return (
        attrs.get("model") or
        inputs.get("model") or
        attrs.get("gen_ai.request.model") or
        attrs.get("gen_ai.response.model") or
        (outputs_obj.get("model") if isinstance(outputs_obj, dict) else None)
    )


def _extract_input_output_from_span(
    s: Dict[str, Any],
    system_trunc_limit: int = 50_000
) -> tuple:
    """
    Extract model_input, response_text, tool_calls, api_spec, and meta_data from a span.

    Returns:
        (model_input_str, response_text, tool_calls, api_spec, meta_data)
    """
    attrs = _parse_attrs(s.get("attributes", {}))
    inputs = s.get("inputs", {}) or safe_json(attrs.get("mlflow.spanInputs")) or {}
    outputs_obj = s.get("outputs", {}) or safe_json(attrs.get("mlflow.spanOutputs")) or {}

    # Extract bound tools (API spec)
    # Check inputs first, then LangChain-specific attribute locations
    api_spec = extract_api_spec(inputs)
    if not api_spec:
        invocation_params = attrs.get("invocation_params", {})
        if isinstance(invocation_params, dict):
            api_spec = extract_api_spec(invocation_params)
    if not api_spec:
        chat_tools = attrs.get("mlflow.chat.tools")
        if isinstance(chat_tools, list):
            api_spec = extract_api_spec({"tools": chat_tools})

    # Extract input messages (OpenAI/Anthropic: messages, Gemini: contents)
    # extract_messages_from_input handles separate system prompts (Anthropic/Gemini)
    messages = (
        extract_messages_from_input(inputs) or
        inputs.get("prompt") or
        _get(attrs, ["gen_ai.input.messages"]) or
        _get(attrs, ["gen_ai.prompt"]) or
        inputs.get("input")
    )
    if messages is None and isinstance(s.get("events"), list):
        for ev in s["events"]:
            if ev.get("name") == "gen_ai.client.inference.operation.details":
                ev_attrs = _parse_attrs(ev.get("attributes", {}))
                messages = _get(ev_attrs, ["gen_ai.input.messages"]) or _get(ev_attrs, ["gen_ai.prompt"])
                if messages is not None:
                    break

    # Normalize input and serialize
    if messages:
        model_input_normalized = normalize_input_messages(messages, system_trunc_limit)
    else:
        model_input_normalized = normalize_input_messages(inputs, system_trunc_limit) if inputs else []

    # Serialize: if already string keep as-is, otherwise JSON encode
    if isinstance(model_input_normalized, str):
        model_input_str = model_input_normalized
    else:
        model_input_str = json.dumps(model_input_normalized, ensure_ascii=False)

    # Extract response and tool calls
    response_text = ""
    tool_calls = []

    if isinstance(outputs_obj, dict) and outputs_obj:
        response_text = normalize_response(outputs_obj)
        tool_calls = extract_tool_calls(outputs_obj)

    # Fallback: check gen_ai.output.messages in attributes
    if not response_text:
        out_msgs = _get(attrs, ["gen_ai.output.messages"]) or _get(attrs, ["gen_ai.completion"])
        if out_msgs is not None:
            response_text, extra_tool_calls = extract_from_output_messages(out_msgs)
            if not tool_calls and extra_tool_calls:
                tool_calls = extra_tool_calls

    # Fallback: check events (OTel-style instrumentation)
    if not response_text and isinstance(s.get("events"), list):
        for ev in s["events"]:
            if ev.get("name") == "gen_ai.client.inference.operation.details":
                ev_attrs = _parse_attrs(ev.get("attributes", {}))
                out_msgs = _get(ev_attrs, ["gen_ai.output.messages"]) or _get(ev_attrs, ["gen_ai.completion"])
                if out_msgs is not None:
                    response_text, extra_tool_calls = extract_from_output_messages(out_msgs)
                    if not tool_calls and extra_tool_calls:
                        tool_calls = extra_tool_calls
                    break

    # Build metadata (model-level, span-level added separately)
    meta_data = {
        "model": _extract_model_name(attrs, inputs, outputs_obj),
        "provider": attrs.get("gen_ai.provider.name") or attrs.get("gen_ai.system") or attrs.get("provider"),
        "operation": attrs.get("gen_ai.operation.name") or attrs.get("operation"),
        "response_format": attrs.get("response_format") or inputs.get("response_format"),
        "tokens": {
            "prompt": attrs.get("gen_ai.usage.input_tokens") or _get(outputs_obj, ["usage", "prompt_tokens"]),
            "completion": attrs.get("gen_ai.usage.output_tokens") or _get(outputs_obj, ["usage", "completion_tokens"]),
            "total": attrs.get("gen_ai.usage.total_tokens") or _get(outputs_obj, ["usage", "total_tokens"]),
        },
    }

    return model_input_str, response_text, tool_calls, api_spec, meta_data


def _extract_status(s: Dict[str, Any]) -> Optional[str]:
    """Extract span status, handling both OTel nested and MLflow flat formats."""
    status = s.get("status")
    if isinstance(status, dict):
        return status.get("status_code") or status.get("code")
    if isinstance(status, str):
        return status
    return None


def _build_span_metadata(s: Dict[str, Any], model_meta: Dict[str, Any]) -> Dict[str, Any]:
    """
    Build complete metadata including span-level information.

    Args:
        s: The span dict
        model_meta: Model-level metadata from _extract_input_output_from_span

    Returns:
        Complete metadata dict with span info
    """
    attrs = _parse_attrs(s.get("attributes", {}))

    # Calculate duration if timestamps available
    duration_ms = s.get("duration_ms")
    if duration_ms is None:
        start_ns = get_start_time(s)
        end_ns = get_end_time(s)
        if start_ns is not None and end_ns is not None:
            duration_ms = (end_ns - start_ns) / 1_000_000

    span_meta = {
        "span_id": s.get("span_id"),
        "span_name": s.get("name"),
        "span_type": _span_type(s),
        "parent_span_id": get_parent_id(s),
        "duration_ms": duration_ms,
        "status": _extract_status(s),
    }

    # Merge span metadata with model metadata
    return {**span_meta, **model_meta}


# ----------------- core extraction -----------------

# Names to skip when walking up parent chain for calling context.
# These are generic LLM client / wrapper class names from LangChain and
# provider SDKs that appear as span names but don't represent the actual
# LangGraph node that initiated the call.
_SKIP_NAMES = {
    # LangChain model wrapper classes
    "ChatOpenAI", "AzureChatOpenAI", "ChatAnthropic", "ChatGoogleGenerativeAI",
    "ChatVertexAI", "ChatBedrock", "BedrockChat", "ChatLiteLLM", "ChatOllama",
    "ChatCohere", "ChatMistralAI", "ChatFireworks", "ChatTogether", "ChatGroq",
    "ChatWatsonx", "ChatHuggingFace", "ChatNVIDIA",
    # LangChain runnable / chain wrappers
    "RunnableSequence", "RunnableLambda", "RunnableParallel",
    "RunnablePassthrough", "RunnableBranch", "RunnableWithFallbacks",
    "LLMChain", "ConversationChain",
    # Provider SDK internals
    "Completions", "ChatCompletions", "Chat", "Messages",
    # Common custom wrapper function names
    "get_llm", "openai_call", "llm_invoke", "call_llm", "invoke_llm",
    "create_completion", "run_llm",
}


def _extract_trace_intent(
    trace: Dict[str, Any],
    spans: List[Dict[str, Any]],
    by_id: Dict[str, Dict[str, Any]],
) -> str:
    """
    Extract a single intent for the entire trace.

    Resolution order (first non-empty wins):
      1. Explicit trace-level metadata/tags (intent, user_query, task, goal).
      2. Root span's input — the first user message or plain-text input.
      3. First user message found in the earliest (by start_time) span.
    """
    intent = _extract_intent_from_trace_metadata(trace)
    if intent:
        return truncate_middle(intent, _INTENT_LIMIT)

    # --- 2. Root span's input ---
    root_spans = [s for s in spans if not get_parent_id(s)]
    if not root_spans:
        root_spans = [s for s in spans if get_parent_id(s) not in by_id]
    if not root_spans:
        root_spans = spans[:1]

    root_spans.sort(key=lambda s: get_start_time(s) or float("inf"))

    for root in root_spans:
        intent = extract_intent_from_input(
            root.get("inputs"), _parse_attrs(root.get("attributes") or {})
        )
        if intent:
            return intent

    # --- 3. First user message in any span (earliest by start_time) ---
    sorted_spans = sorted(spans, key=lambda s: get_start_time(s) or float("inf"))
    for s in sorted_spans:
        intent = extract_intent_from_input(
            s.get("inputs"), _parse_attrs(s.get("attributes") or {})
        )
        if intent:
            return intent

    return ""


_CONTAINER_KEYS = ("tags", "metadata", "trace_metadata", "request_metadata")
_INTENT_FIELDS = ("intent", "user_query", "task", "goal", "query", "question",
                   "request", "request_preview", "input", "mlflow.note.content")
_SCORE_FIELDS = ("traj_score", "score", "quality", "rating", "correctness")


def _get_trace_containers(trace: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Collect all dict containers that may hold intent/score/metadata fields."""
    info = trace.get("info", {}) or {}
    seen = []
    for source in (trace, info):
        for key in _CONTAINER_KEYS:
            c = source.get(key)
            if isinstance(c, dict) and c not in seen:
                seen.append(c)
    return seen


def _search_trace_field(trace: Dict[str, Any], field_names: tuple) -> Any:
    """
    Search for the first non-empty value across top-level trace keys,
    data.* keys, and all metadata containers.
    """
    for field in field_names:
        # Top-level and data.*
        val = trace.get(field) or _get(trace, ["data", field])
        if val is not None and val != "":
            return val
        # Containers
        for container in _get_trace_containers(trace):
            val = container.get(field)
            if val is not None and val != "":
                return val
    return None


def _get_spans(trace: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Get spans from either flat or native (info/data) format."""
    return trace.get("spans", []) or _get(trace, ["data", "spans"]) or []


def _get_trace_id(trace: Dict[str, Any]) -> Optional[str]:
    """Get trace_id from either flat or native format."""
    return (
        trace.get("trace_id") or
        trace.get("id") or
        _get(trace, ["info", "trace_id"]) or
        _get(trace, ["info", "request_id"])
    )


def _extract_intent_from_trace_metadata(trace: Dict[str, Any]) -> str:
    """Check trace-level metadata/tags and top-level fields for an explicit intent."""
    val = _search_trace_field(trace, _INTENT_FIELDS)
    if val and isinstance(val, str) and val.strip():
        return val.strip()
    return ""


def _get_traj_score(trace: Dict[str, Any]) -> Any:
    """
    Get trajectory score from any known location.

    Checks _SCORE_FIELDS across top-level, data.*, and containers,
    then falls back to MLflow assessments.
    """
    val = _search_trace_field(trace, _SCORE_FIELDS)
    if val is not None:
        return val

    # MLflow assessments (native format: info.assessments, or top-level)
    assessments = trace.get("assessments") or _get(trace, ["info", "assessments"]) or []
    for a in assessments:
        if not isinstance(a, dict):
            continue
        val = a.get("numeric_value")
        if val is not None:
            return val
        val = a.get("value")
        if val is not None:
            return val

    return None


def extract_llm_calls_from_mlflow_trace(
    trace: Dict[str, Any],
    file_name: str,
    system_trunc_limit: int = 50_000
) -> List[Dict[str, Any]]:
    """
    Extract LLM calls from an MLflow trace.

    Accepts both flat and native (info/data envelope) MLflow trace formats.

    Uses parent_id to:
    1. Find calling node name by walking up the parent chain
    2. Order LLM calls by start_time, with parent hierarchy as context

    Args:
        trace: The trace dict containing spans (flat or native format)
        file_name: Fallback name for trace_id
        system_trunc_limit: Max chars for system messages before truncation

    Returns:
        List of row dicts matching the unified CSV schema
    """
    trace_id = _get_trace_id(trace) or file_name or "unknown"
    spans: List[Dict[str, Any]] = _get_spans(trace)

    if not spans:
        return []

    # Build span index
    by_id: Dict[str, Dict[str, Any]] = {}
    for i, s in enumerate(spans):
        sid = s.get("span_id") or f"_idx_{i}"
        s["span_id"] = sid
        by_id[sid] = s

    def get_parent(s: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Get parent span if exists."""
        pid = get_parent_id(s)
        return by_id.get(pid) if pid else None

    def find_calling_node_name(s: Dict[str, Any]) -> str:
        """
        Walk up parent chain to find the first meaningful calling node name.
        Skips generic names like 'Completions', 'get_llm', etc.
        """
        current = s
        visited = set()

        while current:
            sid = current.get("span_id")
            if sid in visited:
                break
            visited.add(sid)

            # Get candidate name
            name = _get(current, ["attributes", "mlflow.spanFunctionName"]) or current.get("name")

            # Check if this is a meaningful name (not a generic LLM wrapper)
            if name and name not in _SKIP_NAMES:
                span_type = _span_type(current)
                # Prefer LLM-type spans (these are the decorated functions)
                # or any span with a function name that's not a model call
                if span_type == "LLM" or (span_type not in _MODEL_TYPES and name):
                    return name

            current = get_parent(current)

        # Fallback to span's own name
        return _get_span_name(s) or "unknown"

    # Extract intent once for the entire trace
    trace_intent = _extract_trace_intent(trace, spans, by_id)
    traj_score = _get_traj_score(trace)

    # Find all model call spans
    model_spans = [s for s in spans if _is_model_call_span(s)]

    # Sort by start_time if available, otherwise by original order
    def sort_key(s: Dict[str, Any]) -> tuple:
        start_time = get_start_time(s)
        if start_time is not None:
            return (0, start_time)
        return (1, spans.index(s) if s in spans else 0)

    model_spans.sort(key=sort_key)

    # Extract one record per LLM call (framework-specific field extraction only)
    llm_calls: List[Dict[str, Any]] = []

    for s in model_spans:
        agent_name = find_calling_node_name(s)
        model_input_str, response_text, tool_calls, api_spec, model_meta = _extract_input_output_from_span(
            s, system_trunc_limit
        )

        # Fallback: if no tool_calls found but finish_reason indicates tool_calls,
        # check the parent span's output (LangChain autolog strips tool_calls from
        # generations[].message but the parent LangGraph node span preserves them)
        if not tool_calls:
            parent = get_parent(s)
            if parent and not _is_model_call_span(parent):
                parent_outputs = parent.get("outputs", {})
                if isinstance(parent_outputs, dict):
                    parent_tool_calls = extract_tool_calls(parent_outputs)
                    if parent_tool_calls:
                        tool_calls = parent_tool_calls

        meta_data = _build_span_metadata(s, model_meta)

        llm_calls.append({
            "agent_name": agent_name,
            "task_id": trace_id,
            "intent": trace_intent,
            "model_input": model_input_str,
            "response_text": response_text,
            "tool_calls": tool_calls,
            "api_spec": api_spec,
            "meta_data": meta_data,
            "traj_score": traj_score,
        })

    return build_csv_rows(llm_calls)
