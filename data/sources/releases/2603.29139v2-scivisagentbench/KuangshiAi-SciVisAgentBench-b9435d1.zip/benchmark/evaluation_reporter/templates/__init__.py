"""Templates for evaluation reporter."""
