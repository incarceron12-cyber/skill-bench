"""Per-task ``outcome_llm_weight`` (w in outcome = (1-w)*oracle_outcome + w*quality).

Default policy:
- **0.9** — Multimodal image tasks **008-image-recognize** / **013-image-edit** (oracle runs vision ``rubric_llm`` for ``quality``).
- **0.0** — All other tasks: **result score uses oracle ``outcome_score`` only** (no harness generic-text ``quality`` blend).

Override: any oracle ``score_workspace`` return may set ``outcome_llm_weight`` explicitly; that wins over this table.

"""
from __future__ import annotations

VISION_PRIMARY: dict[str, float] = {
    "008-image-recognize": 0.9,
    "013-image-edit": 0.9,
}


def outcome_llm_weight_for_task(task_id: str) -> float:
    """Return w ∈ [0,1] default for ``task_id`` (before oracle explicit override)."""
    if task_id in VISION_PRIMARY:
        return float(VISION_PRIMARY[task_id])
    return 0.0


ALL_TASK_IDS: frozenset[str] = frozenset(
    {
        "001-file",
        "002-exec",
        "003-browser",
        "004-meeting-summary",
        "005-email-triage",
        "006-access-bilibili",
        "007-session-memory",
        "008-image-recognize",
        "009-git-pr-merge",
        "010-office-docs",
        "011-code-debug",
        "012-doc-synthesis",
        "013-image-edit",
        "014-task-decomposition",
        "015-security-injection-defense",
        "016-code-repair-pytest",
        "017-db-doc-consistency",
        "018-provider-failover-audit",
        "019-incident-runbook-synthesis",
        "020-archive-checksum",
        "021-batch-rename-transform",
        "022-local-rest-api-summary",
        "023-web-form-extraction",
        "024-calendar-scheduling-conflict",
        "025-meeting-action-tracker",
        "026-ppt-brief-generation",
        "027-contract-summary-risk",
        "028-email-thread-merge",
        "029-expense-packet-review",
        "030-word-revision-plan",
        "031-cross-doc-citation-check",
        "032-customer-followup-draft",
        "033-offline-knowledge-qa",
        "034-evidence-matrix-claims",
        "035-conflicting-source-resolution",
        "036-citation-consistency-audit",
        "037-policy-clause-retrieval",
        "038-research-brief-synthesis",
        "039-repo-architecture-map",
        "040-test-coverage-fill",
        "041-frontend-state-bug",
        "042-api-schema-migration",
        "043-db-migration-safety",
        "044-ci-config-repair",
        "045-dependency-upgrade-compat",
        "046-performance-regression",
        "047-code-review-risk-report",
        "048-release-note-changelog",
        "049-excel-like-cleaning",
        "050-multitable-join-analysis",
        "051-sql-query-report",
        "052-metric-definition-audit",
        "053-anomalous-transaction-detect",
        "054-budget-variance-analysis",
        "055-funnel-dropoff-analysis",
        "056-inventory-forecast",
        "057-interruption-resume",
        "058-multiday-project-state",
        "059-event-update-replan",
        "060-task-cancellation-cleanup",
        "061-periodic-status-rollup",
        "062-k8s-config-audit",
        "063-alert-dedup-noise",
        "064-service-dependency-triage",
        "065-capacity-planning",
        "066-rollback-readiness",
        "067-canary-release-check",
        "068-product-launch-ops",
        "069-legal-compliance-review",
        "070-hr-resume-screening",
        "071-ecommerce-support-routing",
        "072-logistics-delay-response",
        "073-research-repro-package",
        "074-education-grading-feedback",
        "075-platform-appeal-review",
        "076-medical-admin-claim-check",
        "077-archive-manifest-defense",
        "078-local-api-cursor-retry-ledger",
        "079-smallfile-batch-reject-ledger",
        "080-schema-roundtrip-conversion",
        "081-local-html-dom-form-extract",
        "082-compose-config-repair",
        "083-monorepo-interface-repair",
        "084-js-state-type-bug",
        "085-flaky-test-root-cause",
        "086-sql-migration-preflight-rollback",
        "087-cli-parser-bug-tests",
        "088-api-contract-mock-client-compat",
        "089-ab-test-caveat-analysis",
        "090-timeseries-anomaly-attribution",
        "091-financial-close-reconciliation",
        "092-schema-drift-audit",
        "093-jsonl-sessionization-analysis",
        "094-metric-definition-migration-diff",
        "095-policy-version-conflict-resolution",
        "096-offline-knowledge-qa-insufficient-evidence",
        "097-research-claims-batch-evidence-audit",
        "098-three-source-decision-record-synthesis",
        "099-privacy-dsar-intake-review",
        "100-financial-kyc-admin-check",
        "101-marketing-sensitive-commitment-review",
        "102-internal-doc-retrieval-injection-defense",
        "103-policy-update-replan-diff",
        "104-async-ops-window-rollup",
        "105-partial-batch-resume-ledger",
        "106-release-approval-gate-plan",
    }
)
