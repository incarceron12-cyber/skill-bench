"""Tool tests for AutomationBench."""
