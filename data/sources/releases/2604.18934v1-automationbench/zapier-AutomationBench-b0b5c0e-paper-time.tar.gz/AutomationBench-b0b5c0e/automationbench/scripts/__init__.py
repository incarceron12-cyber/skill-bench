"""AutomationBench CLI scripts."""
