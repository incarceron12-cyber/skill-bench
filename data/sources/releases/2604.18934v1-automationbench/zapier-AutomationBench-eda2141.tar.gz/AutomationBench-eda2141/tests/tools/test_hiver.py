"""Tests for Hiver tools (read-only)."""

import json

from automationbench.schema.hiver import HiverConversation, HiverUser
from automationbench.schema.world import WorldState
from automationbench.tools.hiver import (
    hiver_get_conversation,
    hiver_get_conversations,
    hiver_get_users,
)


class TestHiverGetConversations:
    """Tests for hiver_get_conversations."""

    def test_get_conversations_empty(self):
        """Get conversations returns empty list when none exist."""
        world = WorldState()

        result = hiver_get_conversations(world=world)

        result_dict = json.loads(result)
        assert result_dict["success"] is True
        assert result_dict["count"] == 0

    def test_get_conversations_returns_all(self):
        """Get conversations returns all conversations."""
        world = WorldState()
        # Directly add conversations since Hiver is read-only
        world.hiver.conversations.append(
            HiverConversation(subject="Conv 1", customer_email="c1@example.com")
        )
        world.hiver.conversations.append(
            HiverConversation(subject="Conv 2", customer_email="c2@example.com")
        )

        result = hiver_get_conversations(world=world)

        result_dict = json.loads(result)
        assert result_dict["success"] is True
        assert result_dict["count"] == 2


class TestHiverGetConversation:
    """Tests for hiver_get_conversation."""

    def test_get_conversation_success(self):
        """Get conversation by ID succeeds."""
        world = WorldState()
        conv = HiverConversation(subject="Test Conv")
        world.hiver.conversations.append(conv)

        result = hiver_get_conversation(world=world, conversation_id=conv.id)

        result_dict = json.loads(result)
        assert result_dict["success"] is True
        assert result_dict["conversation"]["subject"] == "Test Conv"

    def test_get_conversation_not_found(self):
        """Get non-existent conversation fails."""
        world = WorldState()

        result = hiver_get_conversation(world=world, conversation_id="nonexistent")

        result_dict = json.loads(result)
        assert result_dict["success"] is False
        assert "not found" in result_dict["error"]


class TestHiverGetUsers:
    """Tests for hiver_get_users."""

    def test_get_users_empty(self):
        """Get users returns empty list when none exist."""
        world = WorldState()

        result = hiver_get_users(world=world)

        result_dict = json.loads(result)
        assert result_dict["success"] is True
        assert result_dict["count"] == 0

    def test_get_users_returns_all(self):
        """Get users returns all users."""
        world = WorldState()
        world.hiver.users.append(HiverUser(name="User 1", email="u1@example.com"))
        world.hiver.users.append(HiverUser(name="User 2", email="u2@example.com"))

        result = hiver_get_users(world=world)

        result_dict = json.loads(result)
        assert result_dict["success"] is True
        assert result_dict["count"] == 2
