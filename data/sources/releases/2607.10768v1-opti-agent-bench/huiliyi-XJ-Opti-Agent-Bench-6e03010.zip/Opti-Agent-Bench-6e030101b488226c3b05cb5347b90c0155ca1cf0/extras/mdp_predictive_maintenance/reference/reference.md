# 问题三解答：生产线设备预测性维护

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    """
    值迭代算法。

    参数
    ----
    S : int  状态数
    A : int  动作数
    P : np.ndarray, shape (S, A, S)  转移概率 P[s,a,s']
    R : np.ndarray, shape (S, A)     即时奖励 R[s,a]
    gamma : float  折扣因子
    tol : float    收敛阈值
    max_iter : int 最大迭代次数

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略 (每个状态的最优动作索引)
    history : list               每轮迭代的 max|V_new - V_old|
    """
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)            # shape (S, A)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history

def policy_iteration(S, A, P, R, gamma=0.99, max_iter=200):
    """
    策略迭代算法。

    参数
    ----
    同 value_iteration。

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略
    history : list               每轮策略评估后的 max|V_new - V_old|
    """
    pi = np.zeros(S, dtype=int)
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        # --- 策略评估: 解线性方程组 V = R_pi + gamma * P_pi @ V ---
        R_pi = np.array([R[s, pi[s]] for s in range(S)])
        P_pi = np.array([P[s, pi[s], :] for s in range(S)])
        V_new = np.linalg.solve(np.eye(S) - gamma * P_pi, R_pi)
        history.append(np.max(np.abs(V_new - V)))
        V = V_new
        # --- 策略改进 ---
        Q = R + gamma * (P @ V)
        pi_new = np.argmax(Q, axis=1)
        if np.array_equal(pi_new, pi):
            break
        pi = pi_new
    return V, pi, history
```

## 题目专属实现

```python
def generate_maintenance_data(seed=42):
    """
    生成生产线设备预测性维护的 MDP 数据。

    返回
    ----
    mdp : dict
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    degrad_levels = ["全新", "良好", "轻微磨损", "中度磨损", "严重磨损", "故障停机"]
    backlog_levels = ["低积压", "中积压", "高积压"]
    n_degrad = len(degrad_levels)
    n_backlog = len(backlog_levels)
    S = n_degrad * n_backlog  # 18

    action_names = ["满负荷", "降负荷", "在线保养", "停机小修", "停机大修"]
    A = len(action_names)

    def encode(d, b):
        return d * n_backlog + b

    def decode(s):
        return s // n_backlog, s % n_backlog

    # --- 各动作参数 ---
    # 产出率 (相对满负荷的比例)
    output_rate = [1.0, 0.7, 0.5, 0.0, 0.0]
    # 维修费用
    maint_cost = [0.0, 0.0, 2.0, 8.0, 20.0]
    # 退化概率 (从当前级别退化到下一级的概率)
    degrad_prob = {
        0: [0.25, 0.12, 0.08, 0.0, 0.0],   # 全新状态下各动作的退化概率
        1: [0.30, 0.15, 0.10, 0.0, 0.0],
        2: [0.35, 0.18, 0.12, 0.0, 0.0],
        3: [0.45, 0.25, 0.15, 0.0, 0.0],
        4: [0.60, 0.35, 0.20, 0.0, 0.0],   # 严重磨损下满负荷运行退化概率很高
        5: [0.0, 0.0, 0.0, 0.0, 0.0],       # 故障状态
    }
    # 修复效果 (修复的等级数)
    repair_levels = {2: 1, 3: 2, 4: 5}  # 在线保养修1级, 小修修2级, 大修恢复全新(修5级)

    # 订单积压转移 (与动作有关: 停产增加积压概率)
    backlog_base = np.array([
        [0.6, 0.3, 0.1],   # 低积压 → ...
        [0.2, 0.5, 0.3],   # 中积压 → ...
        [0.1, 0.3, 0.6],   # 高积压 → ...
    ])

    # --- 产出收益 (取决于设备状态和积压) ---
    base_revenue = 15.0  # 满负荷全新设备的周收益
    quality_penalty = [0.0, 0.0, -1.0, -3.0, -6.0, 0.0]  # 磨损导致质量下降
    backlog_penalty = [0.0, -2.0, -8.0]  # 高积压时延迟交付罚款
    breakdown_cost = -60.0  # 故障停机的紧急抢修+报废+安全事故损失

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        d, b = decode(s)
        for a in range(A):
            # === 奖励 ===
            if d == 5:  # 故障状态
                # 故障状态下: 只能选择小修或大修 (其他动作也强制进入抢修)
                R[s, a] = breakdown_cost
            else:
                revenue = base_revenue * output_rate[a] * (1.0 - 0.05 * d)
                R[s, a] = revenue + quality_penalty[d] + backlog_penalty[b] - maint_cost[a]

            # === 设备退化转移 ===
            if d == 5:
                # 故障: 小修恢复到"中度磨损", 大修恢复"全新", 其他也强制大修
                if a == 3:  # 小修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[3] = 0.7   # 修到中度磨损
                    d_next_probs[2] = 0.3   # 运气好修到轻微磨损
                elif a == 4:  # 大修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[0] = 1.0   # 恢复全新
                else:
                    # 其他动作在故障状态下 = 强制紧急大修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[1] = 0.5   # 抢修质量不如计划性大修
                    d_next_probs[2] = 0.5
            else:
                d_next_probs = np.zeros(n_degrad)
                if a in repair_levels:
                    # 修复动作
                    repair = repair_levels[a]
                    d_new = max(0, d - repair)
                    d_next_probs[d_new] = 0.8
                    d_next_probs[max(0, d_new - 1)] += 0.1  # 可能修得更好
                    d_next_probs[min(n_degrad - 2, d_new + 1)] += 0.1  # 也可能没修好
                else:
                    # 运行动作: 有概率退化
                    dp = degrad_prob[d][a]
                    if d < n_degrad - 1:
                        d_next_probs[min(d + 1, n_degrad - 1)] = dp
                        d_next_probs[d] = 1 - dp
                    else:
                        d_next_probs[d] = 1.0

                d_next_probs = np.maximum(d_next_probs, 0)
                d_next_probs /= d_next_probs.sum()

            # === 订单积压转移 ===
            b_trans = backlog_base[b].copy()
            # 停产动作增加积压
            if a >= 3:  # 停机
                b_trans = np.array([0.1, 0.3, 0.6]) if b >= 1 else np.array([0.3, 0.4, 0.3])
            b_trans /= b_trans.sum()

            # === 联合转移 ===
            for d_next in range(n_degrad):
                for b_next in range(n_backlog):
                    s_next = encode(d_next, b_next)
                    P[s, a, s_next] = d_next_probs[d_next] * b_trans[b_next]

            P[s, a] /= P[s, a].sum()

    state_names = [f"{degrad_levels[d]}|{backlog_levels[b]}"
                   for d in range(n_degrad) for b in range(n_backlog)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.98,
        'state_names': state_names, 'action_names': action_names,
        'n_degrad': n_degrad, 'n_backlog': n_backlog,
        'degrad_levels': degrad_levels, 'backlog_levels': backlog_levels,
        'decode': decode,
    }

def problem3_maintenance():
    """问题三: 设备预测性维护 (Value Iteration vs Policy Iteration)"""
    print("\n" + "=" * 60)
    print("问题三: 生产线设备预测性维护 (制造MDP)")
    print("=" * 60)

    mdp = generate_maintenance_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_degrad']}退化级别 × {mdp['n_backlog']}订单积压)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Value Iteration ---
    V_vi, pi_vi, hist_vi = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration: {len(hist_vi)} 轮收敛")

    # --- Policy Iteration ---
    V_pi, pi_pi, hist_pi = policy_iteration(S, A, P, R, gamma)
    print(f"Policy Iteration: {len(hist_pi)} 轮收敛")

    # --- 对比 ---
    policy_match = np.sum(pi_vi == pi_pi)
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")
    print(f"值函数最大差异: {np.max(np.abs(V_vi - V_pi)):.6f}")

    # --- 输出最优策略 ---
    print(f"\n最优维护策略 (Value Iteration):")
    decode = mdp['decode']
    for d in range(mdp['n_degrad']):
        print(f"  【{mdp['degrad_levels'][d]}】")
        for b in range(mdp['n_backlog']):
            s = d * mdp['n_backlog'] + b
            act = mdp['action_names'][pi_vi[s]]
            print(f"    {mdp['backlog_levels'][b]:8s} → {act:8s}  (V={V_vi[s]:.1f})")

    return mdp, V_vi, pi_vi, hist_vi, V_pi, pi_pi, hist_pi
```
