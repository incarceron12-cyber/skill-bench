# 问题三：生产线设备预测性维护

原始标题：生产线设备预测性维护

【业务背景】
某汽车零部件工厂有一条关键的 CNC 数控机床生产线，负责加工发动机缸体。
该设备价值 800 万元，是全厂产能瓶颈。设备经理每周排产前都要根据设备
健康评级和订单积压压力，决定本周是继续生产、降低负载，还是安排维护。

设备健康评级分为 6 档：

  等级0 "全新":
      设备刚完成大修或投产，产能和加工精度都处于最佳状态。

  等级1 "良好":
      设备运行稳定，暂未观察到明显质量波动。

  等级2 "轻微磨损":
      部分刀具和传动部件开始磨损，继续高负载运行会增加质量风险。

  等级3 "中度磨损":
      加工精度下降，质量罚款和非计划停机风险明显上升。

  等级4 "严重磨损":
      已接近故障边缘，满负荷生产虽然能暂时增加产出，但极容易触发停机。

  等级5 "故障停机":
      设备无法正常生产，需要紧急抢修或大修。

订单积压压力分为 3 档：

  等级0 "低积压": 订单充裕但不紧急，有余裕安排维护。
  等级1 "中积压": 正常生产压力，需要平衡产出与维修。
  等级2 "高积压": 交付压力大，停产会带来延期罚款。

设备经理每周可以选择以下运行或维修方式。表中的收益、成本和罚款均为
相对经营分值，可理解为把产出收入、维修费用和交付损失归一化后的同一
计量口径，不是设备维修报价本身。

  决策方式     当周产出率    维修成本扣分    直接修复效果
  满负荷生产     1.0            0.0           不修复
  降负荷生产     0.7            0.0           不修复
  在线保养       0.5            2.0           尝试修复 1 档，不停机
  停机小修       0.0            8.0           尝试修复 2 档
  停机大修       0.0           20.0           尝试恢复到全新

当设备未故障且选择继续生产时，设备健康评级可能在下一周恶化 1 档。不同
健康评级下的恶化概率如下：

  当前健康评级      满负荷生产    降负荷生产
  全新                 0.25          0.12
  良好                 0.30          0.15
  轻微磨损             0.35          0.18
  中度磨损             0.45          0.25
  严重磨损             0.60          0.35

在线保养、小修和大修会尝试改善设备健康评级，但维修结果并非完全确定：

  在线保养:
      先按修复 1 档计算目标健康评级；80% 的权重落在该目标评级，
      10% 的权重表示修得更好 1 档，10% 的权重表示修复效果不及预期。

  停机小修:
      先按修复 2 档计算目标健康评级；80% 的权重落在该目标评级，
      10% 的权重表示修得更好 1 档，10% 的权重表示修复效果不及预期。

  停机大修:
      目标是恢复到全新；90% 的权重恢复到"全新"，10% 的权重恢复到"良好"，
      表示大修质量仍可能存在轻微波动。

如果设备已经处于"故障停机"，不同处置方式的结果如下：

  · 停机小修后，70% 的概率恢复到"中度磨损"，30% 的概率恢复到"轻微磨损"。
  · 停机大修后，恢复到"全新"。
  · 如果在故障状态下仍选择生产或在线保养，会被迫紧急抢修，结果通常不如
    计划维修：50% 恢复到"良好"，50% 恢复到"轻微磨损"，且当周产生严重损失。

订单积压压力本身也会随市场需求波动。若本周不停产，下一周订单压力变化
可参考以下历史统计：

  当前订单压力    低积压    中积压    高积压
  低积压           0.60      0.30      0.10
  中积压           0.20      0.50      0.30
  高积压           0.10      0.30      0.60

如果选择停机小修或停机大修，订单积压更容易上升：

  · 当前为低积压时，下一周为低/中/高积压的概率分别为 0.30、0.40、0.30。
  · 当前为中积压或高积压时，下一周为低/中/高积压的概率分别为 0.10、0.30、0.60。

每周经营评分由产出收益、质量罚款、积压罚款、维修成本和故障损失共同构成。
满负荷且设备全新时的基础周收益为 15.0 分；其他情况下，产出收益按

  基础周收益 × 当周产出率 × (1 - 0.05 × 当前健康等级编号)

计算。设备磨损导致的质量罚款如下：

  健康评级       全新    良好    轻微磨损    中度磨损    严重磨损    故障停机
  质量罚款        0.0     0.0      -1.0        -3.0        -6.0        0.0

订单积压罚款如下：

  订单压力       低积压    中积压    高积压
  积压罚款        0.0      -2.0      -8.0

若设备进入故障停机，当周会产生紧急抢修、工件报废和安全事故相关损失，
合计为 -60.0 分。

工厂希望制定一套长期周度运行与维修规则，使未来多周的经营评分尽可能高。
需要注意，高积压时继续满负荷生产并不总是合理；当设备已经严重磨损时，
一次故障停机可能比计划停机维修造成更大的交付损失。

---

## 评分 Rubric

**PF Validity Score**: TD.1=0.5, TD.2=0.5, TD.3=1.0, TD.4=0.5, Overall=0.625

### Problem Analysis

这是周度生产与维修联合决策问题。决策是满负荷、降负荷、在线保养、小修或大修；系统状态应包含设备健康评级和订单积压压力。目标是长期经营评分，综合产出、质量、积压、维修和故障损失。

主要陷阱是高积压并不一定应该满负荷生产，严重磨损下故障停机会造成巨大损失；停机维修会降低当周产出并推高积压，但可能降低未来故障风险。

### Evaluation Rubric

| No. | Dimension | Checkpoint | Pass Criteria | Fail Criteria | Severity |
|:---:|-----------|------------|---------------|---------------|:--------:|
| 1 | Problem Type Identification | 识别为动态维护与生产控制 | 说明当前维修/生产选择影响未来健康评级和订单压力 | 当成单周维修排序或静态成本最小化 | Critical |
| 2 | Problem Type Identification | 正确识别决策变量 | 每周选择满负荷、降负荷、在线保养、停机小修或停机大修 | 把健康等级或订单积压当成可直接控制变量 | Critical |
| 3 | Objective Function Understanding | 正确构造经营评分 | 纳入产出收益、维修成本、质量罚款、积压罚款和故障损失 | 只最大化产出或只最小化维修费用 | Critical |
| 4 | Constraint Formulation | 正确处理健康评级演化 | 运行时按当前健康评级和负载使用恶化概率；维修时按修复概率改善 | 健康评级确定性变化，或忽略负载影响 | Major |
| 5 | Constraint Formulation | 正确处理故障状态 | 故障状态下小修、大修和强制抢修有不同恢复结果及 -60 损失 | 允许故障设备正常生产，或忽略紧急抢修损失 | Critical |
| 6 | Dynamic / Uncertainty Handling | 正确处理订单积压变化 | 使用基础积压转移，并在停机动作下提高高积压概率 | 把订单积压固定不变，或不区分停机影响 | Major |
| 7 | Objective Function Understanding | 正确计算产出收益衰减 | 产出收益应随产出率和健康等级衰减 | 满负荷收益固定为 15，不随磨损变化 | Major |
| 8 | Solution Approach | 方法匹配有限状态随机决策 | 可用动态规划/策略迭代/值迭代或仿真优化，并比较长期期望 | 用“高积压就生产、低积压就修”的贪心规则作为最终解 | Major |

### Expected Failure Modes

- 高积压一律满负荷生产。
- 忽略严重磨损导致的故障停机尾部损失。
- 把小修/大修结果当成完全确定。
- 不让停机影响下一周订单积压。

---

# 参考答案

# 问题三解答：生产线设备预测性维护

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    """
    值迭代算法。

    参数
    ----
    S : int  状态数
    A : int  动作数
    P : np.ndarray, shape (S, A, S)  转移概率 P[s,a,s']
    R : np.ndarray, shape (S, A)     即时奖励 R[s,a]
    gamma : float  折扣因子
    tol : float    收敛阈值
    max_iter : int 最大迭代次数

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略 (每个状态的最优动作索引)
    history : list               每轮迭代的 max|V_new - V_old|
    """
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)            # shape (S, A)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history

def policy_iteration(S, A, P, R, gamma=0.99, max_iter=200):
    """
    策略迭代算法。

    参数
    ----
    同 value_iteration。

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略
    history : list               每轮策略评估后的 max|V_new - V_old|
    """
    pi = np.zeros(S, dtype=int)
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        # --- 策略评估: 解线性方程组 V = R_pi + gamma * P_pi @ V ---
        R_pi = np.array([R[s, pi[s]] for s in range(S)])
        P_pi = np.array([P[s, pi[s], :] for s in range(S)])
        V_new = np.linalg.solve(np.eye(S) - gamma * P_pi, R_pi)
        history.append(np.max(np.abs(V_new - V)))
        V = V_new
        # --- 策略改进 ---
        Q = R + gamma * (P @ V)
        pi_new = np.argmax(Q, axis=1)
        if np.array_equal(pi_new, pi):
            break
        pi = pi_new
    return V, pi, history
```

## 题目专属实现

```python
def generate_maintenance_data(seed=42):
    """
    生成生产线设备预测性维护的 MDP 数据。

    返回
    ----
    mdp : dict
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    degrad_levels = ["全新", "良好", "轻微磨损", "中度磨损", "严重磨损", "故障停机"]
    backlog_levels = ["低积压", "中积压", "高积压"]
    n_degrad = len(degrad_levels)
    n_backlog = len(backlog_levels)
    S = n_degrad * n_backlog  # 18

    action_names = ["满负荷", "降负荷", "在线保养", "停机小修", "停机大修"]
    A = len(action_names)

    def encode(d, b):
        return d * n_backlog + b

    def decode(s):
        return s // n_backlog, s % n_backlog

    # --- 各动作参数 ---
    # 产出率 (相对满负荷的比例)
    output_rate = [1.0, 0.7, 0.5, 0.0, 0.0]
    # 维修费用
    maint_cost = [0.0, 0.0, 2.0, 8.0, 20.0]
    # 退化概率 (从当前级别退化到下一级的概率)
    degrad_prob = {
        0: [0.25, 0.12, 0.08, 0.0, 0.0],   # 全新状态下各动作的退化概率
        1: [0.30, 0.15, 0.10, 0.0, 0.0],
        2: [0.35, 0.18, 0.12, 0.0, 0.0],
        3: [0.45, 0.25, 0.15, 0.0, 0.0],
        4: [0.60, 0.35, 0.20, 0.0, 0.0],   # 严重磨损下满负荷运行退化概率很高
        5: [0.0, 0.0, 0.0, 0.0, 0.0],       # 故障状态
    }
    # 修复效果 (修复的等级数)
    repair_levels = {2: 1, 3: 2, 4: 5}  # 在线保养修1级, 小修修2级, 大修恢复全新(修5级)

    # 订单积压转移 (与动作有关: 停产增加积压概率)
    backlog_base = np.array([
        [0.6, 0.3, 0.1],   # 低积压 → ...
        [0.2, 0.5, 0.3],   # 中积压 → ...
        [0.1, 0.3, 0.6],   # 高积压 → ...
    ])

    # --- 产出收益 (取决于设备状态和积压) ---
    base_revenue = 15.0  # 满负荷全新设备的周收益
    quality_penalty = [0.0, 0.0, -1.0, -3.0, -6.0, 0.0]  # 磨损导致质量下降
    backlog_penalty = [0.0, -2.0, -8.0]  # 高积压时延迟交付罚款
    breakdown_cost = -60.0  # 故障停机的紧急抢修+报废+安全事故损失

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        d, b = decode(s)
        for a in range(A):
            # === 奖励 ===
            if d == 5:  # 故障状态
                # 故障状态下: 只能选择小修或大修 (其他动作也强制进入抢修)
                R[s, a] = breakdown_cost
            else:
                revenue = base_revenue * output_rate[a] * (1.0 - 0.05 * d)
                R[s, a] = revenue + quality_penalty[d] + backlog_penalty[b] - maint_cost[a]

            # === 设备退化转移 ===
            if d == 5:
                # 故障: 小修恢复到"中度磨损", 大修恢复"全新", 其他也强制大修
                if a == 3:  # 小修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[3] = 0.7   # 修到中度磨损
                    d_next_probs[2] = 0.3   # 运气好修到轻微磨损
                elif a == 4:  # 大修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[0] = 1.0   # 恢复全新
                else:
                    # 其他动作在故障状态下 = 强制紧急大修
                    d_next_probs = np.zeros(n_degrad)
                    d_next_probs[1] = 0.5   # 抢修质量不如计划性大修
                    d_next_probs[2] = 0.5
            else:
                d_next_probs = np.zeros(n_degrad)
                if a in repair_levels:
                    # 修复动作
                    repair = repair_levels[a]
                    d_new = max(0, d - repair)
                    d_next_probs[d_new] = 0.8
                    d_next_probs[max(0, d_new - 1)] += 0.1  # 可能修得更好
                    d_next_probs[min(n_degrad - 2, d_new + 1)] += 0.1  # 也可能没修好
                else:
                    # 运行动作: 有概率退化
                    dp = degrad_prob[d][a]
                    if d < n_degrad - 1:
                        d_next_probs[min(d + 1, n_degrad - 1)] = dp
                        d_next_probs[d] = 1 - dp
                    else:
                        d_next_probs[d] = 1.0

                d_next_probs = np.maximum(d_next_probs, 0)
                d_next_probs /= d_next_probs.sum()

            # === 订单积压转移 ===
            b_trans = backlog_base[b].copy()
            # 停产动作增加积压
            if a >= 3:  # 停机
                b_trans = np.array([0.1, 0.3, 0.6]) if b >= 1 else np.array([0.3, 0.4, 0.3])
            b_trans /= b_trans.sum()

            # === 联合转移 ===
            for d_next in range(n_degrad):
                for b_next in range(n_backlog):
                    s_next = encode(d_next, b_next)
                    P[s, a, s_next] = d_next_probs[d_next] * b_trans[b_next]

            P[s, a] /= P[s, a].sum()

    state_names = [f"{degrad_levels[d]}|{backlog_levels[b]}"
                   for d in range(n_degrad) for b in range(n_backlog)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.98,
        'state_names': state_names, 'action_names': action_names,
        'n_degrad': n_degrad, 'n_backlog': n_backlog,
        'degrad_levels': degrad_levels, 'backlog_levels': backlog_levels,
        'decode': decode,
    }

def problem3_maintenance():
    """问题三: 设备预测性维护 (Value Iteration vs Policy Iteration)"""
    print("\n" + "=" * 60)
    print("问题三: 生产线设备预测性维护 (制造MDP)")
    print("=" * 60)

    mdp = generate_maintenance_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_degrad']}退化级别 × {mdp['n_backlog']}订单积压)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Value Iteration ---
    V_vi, pi_vi, hist_vi = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration: {len(hist_vi)} 轮收敛")

    # --- Policy Iteration ---
    V_pi, pi_pi, hist_pi = policy_iteration(S, A, P, R, gamma)
    print(f"Policy Iteration: {len(hist_pi)} 轮收敛")

    # --- 对比 ---
    policy_match = np.sum(pi_vi == pi_pi)
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")
    print(f"值函数最大差异: {np.max(np.abs(V_vi - V_pi)):.6f}")

    # --- 输出最优策略 ---
    print(f"\n最优维护策略 (Value Iteration):")
    decode = mdp['decode']
    for d in range(mdp['n_degrad']):
        print(f"  【{mdp['degrad_levels'][d]}】")
        for b in range(mdp['n_backlog']):
            s = d * mdp['n_backlog'] + b
            act = mdp['action_names'][pi_vi[s]]
            print(f"    {mdp['backlog_levels'][b]:8s} → {act:8s}  (V={V_vi[s]:.1f})")

    return mdp, V_vi, pi_vi, hist_vi, V_pi, pi_pi, hist_pi
```
