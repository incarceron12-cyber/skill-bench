# 问题二解答：慢性病动态用药管理

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def policy_iteration(S, A, P, R, gamma=0.99, max_iter=200):
    """
    策略迭代算法。

    参数
    ----
    同 value_iteration。

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略
    history : list               每轮策略评估后的 max|V_new - V_old|
    """
    pi = np.zeros(S, dtype=int)
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        # --- 策略评估: 解线性方程组 V = R_pi + gamma * P_pi @ V ---
        R_pi = np.array([R[s, pi[s]] for s in range(S)])
        P_pi = np.array([P[s, pi[s], :] for s in range(S)])
        V_new = np.linalg.solve(np.eye(S) - gamma * P_pi, R_pi)
        history.append(np.max(np.abs(V_new - V)))
        V = V_new
        # --- 策略改进 ---
        Q = R + gamma * (P @ V)
        pi_new = np.argmax(Q, axis=1)
        if np.array_equal(pi_new, pi):
            break
        pi = pi_new
    return V, pi, history
```

## 题目专属实现

```python
def generate_diabetes_data(seed=42):
    """
    生成 II 型糖尿病动态用药管理的 MDP 数据。

    返回
    ----
    mdp : dict
        包含 S, A, P, R, gamma 以及状态/动作名称等。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    hba1c_levels = ["达标(<7%)", "轻度偏高(7-8%)", "中度偏高(8-9.5%)", "重度偏高(9.5-11%)", "危险(>11%)"]
    kidney_levels = ["正常(≥90)", "轻度下降(60-89)", "中度下降(30-59)", "重度下降(<30)"]
    side_effect_levels = ["无/轻微", "中度", "严重"]

    n_hba1c = len(hba1c_levels)
    n_kidney = len(kidney_levels)
    n_side = len(side_effect_levels)
    S = n_hba1c * n_kidney * n_side  # 60

    action_names = ["维持方案", "加强用药", "减量换药", "强化胰岛素"]
    A = len(action_names)

    def encode(h, k, se):
        return h * n_kidney * n_side + k * n_side + se

    def decode(s):
        h = s // (n_kidney * n_side)
        rem = s % (n_kidney * n_side)
        k = rem // n_side
        se = rem % n_side
        return h, k, se

    # --- 治疗对 HbA1c 的效果 (降低的期望等级数) ---
    # 维持: 不变; 加强: 降1-2级; 减量: 可能升0-1级; 强化胰岛素: 降2-3级
    hba1c_shift_mean = {0: 0.0, 1: -1.2, 2: 0.5, 3: -2.0}

    # --- 治疗对副作用的影响 ---
    side_shift_mean = {0: 0.0, 1: 0.6, 2: -0.5, 3: 0.8}

    # --- 肾功能自然退化 + 药物影响 ---
    kidney_degrade_prob = {0: 0.02, 1: 0.06, 2: 0.01, 3: 0.10}

    # --- 奖励参数 ---
    hba1c_reward = [10.0, 4.0, -2.0, -8.0, -20.0]
    kidney_reward = [0.0, -3.0, -10.0, -30.0]
    side_reward = [0.0, -3.0, -8.0]
    action_cost = [1.0, 4.0, 2.0, 6.0]

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        h, k, se = decode(s)
        for a in range(A):
            # 奖励
            R[s, a] = hba1c_reward[h] + kidney_reward[k] + side_reward[se] - action_cost[a]

            # --- HbA1c 转移 ---
            shift = hba1c_shift_mean[a]
            target_h = h + shift
            h_low = max(0, min(n_hba1c - 1, int(np.floor(target_h))))
            h_high = max(0, min(n_hba1c - 1, h_low + 1))
            frac = target_h - np.floor(target_h)
            frac = max(0, min(1, frac))
            # 加入随机噪声: ±1级的概率
            h_probs = np.zeros(n_hba1c)
            for dh, pdh in [(-1, 0.10), (0, 0.55), (1, 0.10)]:
                hh = max(0, min(n_hba1c - 1, h_low + dh))
                h_probs[hh] += pdh * (1 - frac)
                hh2 = max(0, min(n_hba1c - 1, h_high + dh))
                h_probs[hh2] += pdh * frac
            # 补充剩余概率到当前等级
            missing = 1.0 - h_probs.sum()
            h_probs[h] += max(0, missing)
            h_probs = np.maximum(h_probs, 0)
            h_probs /= h_probs.sum()

            # --- 肾功能转移 ---
            deg_p = kidney_degrade_prob[a]
            # HbA1c 高时肾功能恶化更快
            if h >= 3:
                deg_p += 0.05
            if h >= 4:
                deg_p += 0.10
            deg_p = min(deg_p, 0.5)
            k_probs = np.zeros(n_kidney)
            k_next = min(k + 1, n_kidney - 1)
            k_probs[k_next] += deg_p
            k_probs[k] += (1 - deg_p)

            # --- 副作用转移 ---
            se_shift = side_shift_mean[a]
            se_target = se + se_shift
            se_low = max(0, min(n_side - 1, int(np.floor(se_target))))
            se_high = max(0, min(n_side - 1, se_low + 1))
            se_frac = se_target - np.floor(se_target)
            se_frac = max(0, min(1, se_frac))
            se_probs = np.zeros(n_side)
            se_probs[se_low] += (1 - se_frac) * 0.7
            se_probs[se_high] += se_frac * 0.7
            se_probs[se] += 0.3
            se_probs = np.maximum(se_probs, 0)
            se_probs /= se_probs.sum()

            # --- 联合转移 (三维独立) ---
            for h_next in range(n_hba1c):
                for k_next in range(n_kidney):
                    for se_next in range(n_side):
                        s_next = encode(h_next, k_next, se_next)
                        P[s, a, s_next] += h_probs[h_next] * k_probs[k_next] * se_probs[se_next]

            # 归一化
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

    state_names = []
    for s in range(S):
        h, k, se = decode(s)
        state_names.append(f"{hba1c_levels[h]}|{kidney_levels[k]}|{side_effect_levels[se]}")

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.95,
        'state_names': state_names, 'action_names': action_names,
        'n_hba1c': n_hba1c, 'n_kidney': n_kidney, 'n_side': n_side,
        'hba1c_levels': hba1c_levels, 'kidney_levels': kidney_levels,
        'side_effect_levels': side_effect_levels, 'decode': decode,
    }

def problem2_diabetes():
    """问题二: 慢性病动态用药管理 (Policy Iteration)"""
    print("\n" + "=" * 60)
    print("问题二: 慢性病动态用药管理 (医疗MDP)")
    print("=" * 60)

    mdp = generate_diabetes_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_hba1c']} HbA1c × {mdp['n_kidney']} 肾功能 × {mdp['n_side']} 副作用)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Policy Iteration ---
    V, pi, hist = policy_iteration(S, A, P, R, gamma)
    print(f"\nPolicy Iteration 收敛于 {len(hist)} 轮")

    # --- 输出典型患者的最优用药策略 ---
    print(f"\n最优用药策略 (副作用=无/轻微 时):")
    decode = mdp['decode']
    for k in range(mdp['n_kidney']):
        print(f"\n  肾功能: {mdp['kidney_levels'][k]}")
        for h in range(mdp['n_hba1c']):
            s = h * mdp['n_kidney'] * mdp['n_side'] + k * mdp['n_side'] + 0
            act = mdp['action_names'][pi[s]]
            print(f"    HbA1c {mdp['hba1c_levels'][h]:20s} → {act:8s}  (V={V[s]:.1f})")

    return mdp, V, pi, hist
```
