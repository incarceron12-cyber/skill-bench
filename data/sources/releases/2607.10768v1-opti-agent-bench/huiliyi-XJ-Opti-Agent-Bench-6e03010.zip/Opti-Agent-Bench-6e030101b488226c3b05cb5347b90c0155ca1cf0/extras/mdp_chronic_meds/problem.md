# 问题二：慢性病动态用药管理

原始标题：慢性病动态用药管理

【业务背景】
某三甲医院的内分泌科管理着大量 II 型糖尿病患者。患者每 3 个月复诊一次，
医生需要根据最新检查结果调整下一阶段治疗方案。长期管理不能只追求短期
降糖速度，还要兼顾肾功能保护、药物副作用、患者依从性和医疗费用。

每位患者的复诊信息由三个维度描述：

1. **糖化血红蛋白 (HbA1c) 水平** — 反映过去 2-3 个月的平均血糖控制
   情况。根据临床管理需要划分为 5 档：

   等级0 "达标" (< 7.0%):
       血糖控制良好，并发症风险相对较低，是多数患者希望维持的目标区间。

   等级1 "轻度偏高" (7.0-8.0%):
       血糖略高，需要关注生活方式和用药依从性，通常不需要激进干预。

   等级2 "中度偏高" (8.0-9.5%):
       血糖控制不佳，医生通常需要考虑增加剂量或联合用药。

   等级3 "重度偏高" (9.5-11.0%):
       并发症风险明显上升，肾功能恶化风险也会加快。

   等级4 "危险" (> 11.0%):
       属于高风险状态，需要尽快改善血糖控制，但强化治疗也可能带来更高
       副作用和用药负担。

2. **肾功能 (eGFR) 等级** — 糖尿病是慢性肾病的重要诱因，而部分降糖药
   需要根据肾功能调整剂量或禁用：

   等级0 "正常" (eGFR ≥ 90)
   等级1 "轻度下降" (eGFR 60-89)
   等级2 "中度下降" (eGFR 30-59)
   等级3 "重度下降" (eGFR < 30)

3. **药物副作用累积等级** — 长期用药可能导致低血糖事件、胃肠道反应、
   体重增加等问题，进而影响患者依从性：

   等级0 "无/轻微"
   等级1 "中度"
   等级2 "严重"

医生每次复诊后可以选择以下治疗调整方向：

  治疗方案           对 HbA1c 的平均影响     对副作用的平均影响     基础肾功能恶化风险     治疗成本扣分（相对单位）
  维持当前方案        0.0 级                  0.0 级                0.02                  1.0
  加强用药           -1.2 级                 +0.6 级               0.06                  4.0
  减量/换药          +0.5 级                 -0.5 级               0.01                  2.0
  强化胰岛素治疗     -2.0 级                 +0.8 级               0.10                  6.0

表中 HbA1c 的负数表示血糖分档改善，正数表示血糖分档恶化；副作用的正数
表示副作用加重，负数表示副作用缓解。举例来说，当前 HbA1c 为"重度偏高"
时，选择"强化胰岛素治疗"的平均效果是向更好的方向改善约 2 个等级，但
副作用平均会加重约 0.8 个等级。

由于患者体质、饮食运动、依从性等因素不同，同一种治疗方案的实际效果
并不完全确定。对 HbA1c 来说，先根据上表得到一个目标分档；如果平均变化
不是整数，则按小数部分在相邻目标分档之间分摊。随后还会叠加个体差异：
相对目标分档再改善 1 级的概率为 0.10，落在目标附近的概率为 0.55，
相对目标分档恶化 1 级的概率为 0.10，其余概率保留在当前 HbA1c 分档。
最终 HbA1c 分档截断在 [0, 4] 区间内。

肾功能通常只会保持或下降，不会在一个复诊周期内自然改善。每种治疗方案
有表中的基础肾功能恶化风险；如果患者当前 HbA1c 已达到"重度偏高"，该风险
额外增加 0.05；如果达到"危险"，则在此基础上再额外增加 0.10。肾功能恶化
风险最高不超过 0.50。若恶化发生，肾功能等级下降 1 档；若已为"重度下降"，
则保持在最差等级。

副作用变化也存在滞后和个体差异。先根据治疗方案对副作用的平均影响得到
目标等级；如果平均变化不是整数，则按小数部分在相邻目标等级之间分摊。
随后，70% 的权重按治疗方案影响落到目标等级附近，30% 的权重保留在当前
副作用等级。最终副作用等级截断在 [0, 2] 区间内。

医院使用一套综合健康评分评估每个复诊周期的管理效果。评分由血糖控制、
肾功能、副作用和治疗成本共同构成。这里的治疗成本扣分不是直接药品价格，
而是把医疗费用、随访管理复杂度和患者用药负担合并后的相对扣分单位：

  HbA1c 评分:
              达标    轻度偏高    中度偏高    重度偏高    危险
              10.0      4.0        -2.0        -8.0      -20.0

  肾功能评分:
              正常    轻度下降    中度下降    重度下降
               0.0      -3.0       -10.0       -30.0

  副作用评分:
              无/轻微    中度    严重
                0.0     -3.0    -8.0

  每次治疗调整还要扣除相应治疗成本扣分：
              维持当前方案    加强用药    减量/换药    强化胰岛素治疗
                   1.0          4.0        2.0             6.0

医院希望制定一套长期复诊用药调整规则，使患者在未来多次复诊中的综合健康
评分尽可能高。需要注意，血糖越高并不一定意味着越应该选择最强治疗方案；
对于肾功能较差或副作用严重的患者，短期强力降糖可能带来更高的长期风险。

---

## 评分 Rubric

**PF Validity Score**: TD.1=0.5, TD.2=0.5, TD.3=1.0, TD.4=0.5, Overall=0.625

### Problem Analysis

这是复诊周期上的慢性病治疗调整问题。决策是每 3 个月选择一种治疗调整方向；系统状态应包含 HbA1c 分档、肾功能分档和副作用分档。目标是长期综合健康评分，而不是单次血糖下降最大。

主要陷阱是强化治疗虽然改善 HbA1c，但会增加副作用和肾功能恶化风险；减量/换药可能短期升高 HbA1c，却改善副作用并降低肾功能风险。

### Evaluation Rubric

| No. | Dimension | Checkpoint | Pass Criteria | Fail Criteria | Severity |
|:---:|-----------|------------|---------------|---------------|:--------:|
| 1 | Problem Type Identification | 识别为多周期随机治疗决策 | 说明复诊方案会影响未来 HbA1c、肾功能和副作用 | 当成单次临床分类或静态打分排序 | Critical |
| 2 | Problem Type Identification | 正确识别决策变量 | 决策为维持、加强、减量/换药、强化胰岛素四类治疗调整 | 把 HbA1c、eGFR 或副作用等级当成决策 | Critical |
| 3 | Objective Function Understanding | 正确理解长期健康评分 | 组合 HbA1c 评分、肾功能评分、副作用评分和治疗成本扣分 | 只最小化 HbA1c 或只选短期降糖最强方案 | Critical |
| 4 | Constraint Formulation | 正确使用治疗影响表 | 使用各方案对 HbA1c、副作用、肾功能风险和成本的不同影响 | 把四种方案视为只有强弱顺序，没有副作用/成本差异 | Major |
| 5 | Dynamic / Uncertainty Handling | 正确处理 HbA1c 随机响应 | 根据平均变化、相邻分档分摊和个体差异概率更新 HbA1c | 用确定性等级变化替代全部随机响应 | Major |
| 6 | Constraint Formulation | 正确处理肾功能不可自然改善 | 肾功能只保持或恶化，并在高 HbA1c 时增加恶化风险 | 允许肾功能自然改善，或忽略高血糖加速恶化 | Major |
| 7 | Dynamic / Uncertainty Handling | 正确处理副作用滞后 | 使用 70% 治疗影响、30% 保留当前等级的结构，并截断边界 | 副作用只由当前治疗确定，或忽略减量缓解副作用 | Major |
| 8 | Solution Approach | 方法适配离散随机动态决策 | 可用动态规划/策略优化/仿真学习，并说明长期期望评分比较 | 用简单阈值规则替代且不验证长期后果 | Major |

### Expected Failure Modes

- HbA1c 越高越机械地选择强化胰岛素。
- 忽略肾功能恶化风险和副作用累积。
- 把治疗成本扣分误解为药品价格并单独优化。
- 用单期最高评分代替长期策略。

---

# 参考答案

# 问题二解答：慢性病动态用药管理

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def policy_iteration(S, A, P, R, gamma=0.99, max_iter=200):
    """
    策略迭代算法。

    参数
    ----
    同 value_iteration。

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略
    history : list               每轮策略评估后的 max|V_new - V_old|
    """
    pi = np.zeros(S, dtype=int)
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        # --- 策略评估: 解线性方程组 V = R_pi + gamma * P_pi @ V ---
        R_pi = np.array([R[s, pi[s]] for s in range(S)])
        P_pi = np.array([P[s, pi[s], :] for s in range(S)])
        V_new = np.linalg.solve(np.eye(S) - gamma * P_pi, R_pi)
        history.append(np.max(np.abs(V_new - V)))
        V = V_new
        # --- 策略改进 ---
        Q = R + gamma * (P @ V)
        pi_new = np.argmax(Q, axis=1)
        if np.array_equal(pi_new, pi):
            break
        pi = pi_new
    return V, pi, history
```

## 题目专属实现

```python
def generate_diabetes_data(seed=42):
    """
    生成 II 型糖尿病动态用药管理的 MDP 数据。

    返回
    ----
    mdp : dict
        包含 S, A, P, R, gamma 以及状态/动作名称等。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    hba1c_levels = ["达标(<7%)", "轻度偏高(7-8%)", "中度偏高(8-9.5%)", "重度偏高(9.5-11%)", "危险(>11%)"]
    kidney_levels = ["正常(≥90)", "轻度下降(60-89)", "中度下降(30-59)", "重度下降(<30)"]
    side_effect_levels = ["无/轻微", "中度", "严重"]

    n_hba1c = len(hba1c_levels)
    n_kidney = len(kidney_levels)
    n_side = len(side_effect_levels)
    S = n_hba1c * n_kidney * n_side  # 60

    action_names = ["维持方案", "加强用药", "减量换药", "强化胰岛素"]
    A = len(action_names)

    def encode(h, k, se):
        return h * n_kidney * n_side + k * n_side + se

    def decode(s):
        h = s // (n_kidney * n_side)
        rem = s % (n_kidney * n_side)
        k = rem // n_side
        se = rem % n_side
        return h, k, se

    # --- 治疗对 HbA1c 的效果 (降低的期望等级数) ---
    # 维持: 不变; 加强: 降1-2级; 减量: 可能升0-1级; 强化胰岛素: 降2-3级
    hba1c_shift_mean = {0: 0.0, 1: -1.2, 2: 0.5, 3: -2.0}

    # --- 治疗对副作用的影响 ---
    side_shift_mean = {0: 0.0, 1: 0.6, 2: -0.5, 3: 0.8}

    # --- 肾功能自然退化 + 药物影响 ---
    kidney_degrade_prob = {0: 0.02, 1: 0.06, 2: 0.01, 3: 0.10}

    # --- 奖励参数 ---
    hba1c_reward = [10.0, 4.0, -2.0, -8.0, -20.0]
    kidney_reward = [0.0, -3.0, -10.0, -30.0]
    side_reward = [0.0, -3.0, -8.0]
    action_cost = [1.0, 4.0, 2.0, 6.0]

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        h, k, se = decode(s)
        for a in range(A):
            # 奖励
            R[s, a] = hba1c_reward[h] + kidney_reward[k] + side_reward[se] - action_cost[a]

            # --- HbA1c 转移 ---
            shift = hba1c_shift_mean[a]
            target_h = h + shift
            h_low = max(0, min(n_hba1c - 1, int(np.floor(target_h))))
            h_high = max(0, min(n_hba1c - 1, h_low + 1))
            frac = target_h - np.floor(target_h)
            frac = max(0, min(1, frac))
            # 加入随机噪声: ±1级的概率
            h_probs = np.zeros(n_hba1c)
            for dh, pdh in [(-1, 0.10), (0, 0.55), (1, 0.10)]:
                hh = max(0, min(n_hba1c - 1, h_low + dh))
                h_probs[hh] += pdh * (1 - frac)
                hh2 = max(0, min(n_hba1c - 1, h_high + dh))
                h_probs[hh2] += pdh * frac
            # 补充剩余概率到当前等级
            missing = 1.0 - h_probs.sum()
            h_probs[h] += max(0, missing)
            h_probs = np.maximum(h_probs, 0)
            h_probs /= h_probs.sum()

            # --- 肾功能转移 ---
            deg_p = kidney_degrade_prob[a]
            # HbA1c 高时肾功能恶化更快
            if h >= 3:
                deg_p += 0.05
            if h >= 4:
                deg_p += 0.10
            deg_p = min(deg_p, 0.5)
            k_probs = np.zeros(n_kidney)
            k_next = min(k + 1, n_kidney - 1)
            k_probs[k_next] += deg_p
            k_probs[k] += (1 - deg_p)

            # --- 副作用转移 ---
            se_shift = side_shift_mean[a]
            se_target = se + se_shift
            se_low = max(0, min(n_side - 1, int(np.floor(se_target))))
            se_high = max(0, min(n_side - 1, se_low + 1))
            se_frac = se_target - np.floor(se_target)
            se_frac = max(0, min(1, se_frac))
            se_probs = np.zeros(n_side)
            se_probs[se_low] += (1 - se_frac) * 0.7
            se_probs[se_high] += se_frac * 0.7
            se_probs[se] += 0.3
            se_probs = np.maximum(se_probs, 0)
            se_probs /= se_probs.sum()

            # --- 联合转移 (三维独立) ---
            for h_next in range(n_hba1c):
                for k_next in range(n_kidney):
                    for se_next in range(n_side):
                        s_next = encode(h_next, k_next, se_next)
                        P[s, a, s_next] += h_probs[h_next] * k_probs[k_next] * se_probs[se_next]

            # 归一化
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

    state_names = []
    for s in range(S):
        h, k, se = decode(s)
        state_names.append(f"{hba1c_levels[h]}|{kidney_levels[k]}|{side_effect_levels[se]}")

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.95,
        'state_names': state_names, 'action_names': action_names,
        'n_hba1c': n_hba1c, 'n_kidney': n_kidney, 'n_side': n_side,
        'hba1c_levels': hba1c_levels, 'kidney_levels': kidney_levels,
        'side_effect_levels': side_effect_levels, 'decode': decode,
    }

def problem2_diabetes():
    """问题二: 慢性病动态用药管理 (Policy Iteration)"""
    print("\n" + "=" * 60)
    print("问题二: 慢性病动态用药管理 (医疗MDP)")
    print("=" * 60)

    mdp = generate_diabetes_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_hba1c']} HbA1c × {mdp['n_kidney']} 肾功能 × {mdp['n_side']} 副作用)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Policy Iteration ---
    V, pi, hist = policy_iteration(S, A, P, R, gamma)
    print(f"\nPolicy Iteration 收敛于 {len(hist)} 轮")

    # --- 输出典型患者的最优用药策略 ---
    print(f"\n最优用药策略 (副作用=无/轻微 时):")
    decode = mdp['decode']
    for k in range(mdp['n_kidney']):
        print(f"\n  肾功能: {mdp['kidney_levels'][k]}")
        for h in range(mdp['n_hba1c']):
            s = h * mdp['n_kidney'] * mdp['n_side'] + k * mdp['n_side'] + 0
            act = mdp['action_names'][pi[s]]
            print(f"    HbA1c {mdp['hba1c_levels'][h]:20s} → {act:8s}  (V={V[s]:.1f})")

    return mdp, V, pi, hist
```
