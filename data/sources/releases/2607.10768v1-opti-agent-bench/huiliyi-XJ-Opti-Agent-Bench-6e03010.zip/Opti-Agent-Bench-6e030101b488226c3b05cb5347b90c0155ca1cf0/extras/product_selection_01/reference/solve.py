#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


DEFAULT_WEEKS = 20
DEFAULT_ITEMS_PER_WEEK = 30


@dataclass(frozen=True)
class Product:
    sku: str
    price: float
    cost: float
    m: float
    alpha: float

    @property
    def margin(self) -> float:
        return self.price - self.cost

    @property
    def prior_mean_demand(self) -> float:
        return self.m / self.alpha

    @property
    def prior_expected_profit(self) -> float:
        return self.margin * self.prior_mean_demand


@dataclass
class PosteriorState:
    m: Dict[str, float]
    alpha: Dict[str, float]
    observed_weeks: Dict[str, int]
    observed_sales: Dict[str, int]

    @classmethod
    def from_products(cls, products: Sequence[Product]) -> "PosteriorState":
        return cls(
            m={p.sku: float(p.m) for p in products},
            alpha={p.sku: float(p.alpha) for p in products},
            observed_weeks={p.sku: 0 for p in products},
            observed_sales={p.sku: 0 for p in products},
        )

    def copy(self) -> "PosteriorState":
        return PosteriorState(
            m=dict(self.m),
            alpha=dict(self.alpha),
            observed_weeks=dict(self.observed_weeks),
            observed_sales=dict(self.observed_sales),
        )

    def posterior_mean(self, sku: str) -> float:
        return self.m[sku] / self.alpha[sku]

    def update(self, sku: str, sales: int) -> None:
        if sales < 0:
            raise ValueError(f"sales must be non-negative for sku={sku}, got {sales}")
        self.m[sku] += int(sales)
        self.alpha[sku] += 1.0
        self.observed_weeks[sku] += 1
        self.observed_sales[sku] += int(sales)


class Policy:
    name = "policy"

    def select(
        self,
        products: Sequence[Product],
        state: PosteriorState,
        items_per_week: int,
        rng: np.random.Generator,
    ) -> List[str]:
        raise NotImplementedError


class ThompsonSamplingPolicy(Policy):
    name = "thompson_sampling"

    def __init__(self, shape_floor: float = 1e-9) -> None:
        self.shape_floor = shape_floor

    def select(
        self,
        products: Sequence[Product],
        state: PosteriorState,
        items_per_week: int,
        rng: np.random.Generator,
    ) -> List[str]:
        scores: List[Tuple[float, str]] = []
        for product in products:
            shape = max(state.m[product.sku], self.shape_floor)
            rate = state.alpha[product.sku]
            sampled_lambda = float(rng.gamma(shape=shape, scale=1.0 / rate))
            score = product.margin * sampled_lambda
            scores.append((score, product.sku))
        return top_k_skus(scores, items_per_week)


class PosteriorMeanGreedyPolicy(Policy):
    name = "posterior_mean_greedy"

    def select(
        self,
        products: Sequence[Product],
        state: PosteriorState,
        items_per_week: int,
        rng: np.random.Generator,
    ) -> List[str]:
        del rng
        scores = [
            (product.margin * state.posterior_mean(product.sku), product.sku)
            for product in products
        ]
        return top_k_skus(scores, items_per_week)


class StaticPriorGreedyPolicy(Policy):
    name = "static_prior_greedy"

    def __init__(self, products: Sequence[Product]) -> None:
        scores = [(product.prior_expected_profit, product.sku) for product in products]
        self.fixed_selection = top_k_skus(scores, len(products))

    def select(
        self,
        products: Sequence[Product],
        state: PosteriorState,
        items_per_week: int,
        rng: np.random.Generator,
    ) -> List[str]:
        del products, state, rng
        return list(self.fixed_selection[:items_per_week])


def top_k_skus(scores: Sequence[Tuple[float, str]], k: int) -> List[str]:
    return [
        sku
        for _, sku in sorted(scores, key=lambda item: (item[0], item[1]), reverse=True)[:k]
    ]


def _normalized_header(name: str) -> str:
    return "".join(ch for ch in name.strip().lower() if ch.isalnum())


def _find_column(fieldnames: Sequence[str], aliases: Sequence[str]) -> str:
    normalized_to_original = {_normalized_header(name): name for name in fieldnames}
    for alias in aliases:
        normalized = _normalized_header(alias)
        if normalized in normalized_to_original:
            return normalized_to_original[normalized]
    raise ValueError(
        f"missing required column; accepted aliases={list(aliases)}, "
        f"actual columns={list(fieldnames)}"
    )


def load_products(path: Path) -> List[Product]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"{path} is empty or has no header")

        sku_col = _find_column(
            reader.fieldnames,
            ("sku", "id", "product_id", "product", "item_id", "s"),
        )
        price_col = _find_column(reader.fieldnames, ("price", "unit_price"))
        cost_col = _find_column(reader.fieldnames, ("cost", "unit_cost"))
        m_col = _find_column(reader.fieldnames, ("m", "shape", "prior_m"))
        alpha_col = _find_column(
            reader.fieldnames,
            ("alpha", "a", "rate", "prior_alpha", "weeks", "observed_weeks"),
        )

        products = []
        seen = set()
        for row_number, row in enumerate(reader, start=2):
            if not any((value or "").strip() for value in row.values()):
                continue
            sku = str(row[sku_col]).strip()
            if not sku:
                raise ValueError(f"row {row_number}: sku is empty")
            if sku in seen:
                raise ValueError(f"row {row_number}: duplicate sku={sku}")
            seen.add(sku)

            product = Product(
                sku=sku,
                price=float(row[price_col]),
                cost=float(row[cost_col]),
                m=float(row[m_col]),
                alpha=float(row[alpha_col]),
            )
            products.append(product)

    validate_products(products)
    return products


def validate_products(products: Sequence[Product]) -> None:
    if not products:
        raise ValueError("products must not be empty")
    for product in products:
        values = {
            "price": product.price,
            "cost": product.cost,
            "m": product.m,
            "alpha": product.alpha,
        }
        for name, value in values.items():
            if not math.isfinite(value):
                raise ValueError(f"sku={product.sku}: {name} must be finite, got {value}")
        if product.price < 0 or product.cost < 0:
            raise ValueError(f"sku={product.sku}: price and cost must be non-negative")
        if product.m < 0:
            raise ValueError(f"sku={product.sku}: m must be non-negative")
        if product.alpha <= 0:
            raise ValueError(f"sku={product.sku}: alpha must be positive")


def generate_synthetic_products(
    n_products: int = 100,
    seed: int = 20260507,
) -> List[Product]:
    rng = np.random.default_rng(seed)
    products: List[Product] = []
    for i in range(n_products):
        price = float(rng.uniform(39.0, 229.0))
        margin_rate = float(rng.uniform(0.18, 0.72))
        cost = price * (1.0 - margin_rate)
        prior_mean = float(rng.lognormal(mean=2.15, sigma=0.55))
        alpha = float(rng.integers(1, 13))
        m = max(prior_mean * alpha, 1e-6)
        products.append(
            Product(
                sku=f"SKU{i + 1:03d}",
                price=round(price, 2),
                cost=round(cost, 2),
                m=round(m, 6),
                alpha=alpha,
            )
        )
    validate_products(products)
    return products


def sample_true_lambdas(
    products: Sequence[Product],
    rng: np.random.Generator,
    shape_floor: float = 1e-9,
) -> Dict[str, float]:
    true_lambdas = {}
    for product in products:
        shape = max(product.m, shape_floor)
        true_lambdas[product.sku] = float(
            rng.gamma(shape=shape, scale=1.0 / product.alpha)
        )
    return true_lambdas


def simulate_season(
    products: Sequence[Product],
    policy: Policy,
    weeks: int = DEFAULT_WEEKS,
    items_per_week: int = DEFAULT_ITEMS_PER_WEEK,
    seed: int = 20260507,
    true_lambdas: Optional[Dict[str, float]] = None,
    demand_table: Optional[Sequence[Dict[str, int]]] = None,
    keep_trace: bool = True,
) -> Dict[str, object]:
    validate_season_args(products, weeks, items_per_week)
    truth_rng = np.random.default_rng(seed)
    decision_rng = np.random.default_rng(seed + 1)
    sales_rng = np.random.default_rng(seed + 2)
    product_by_sku = {product.sku: product for product in products}
    if true_lambdas is None:
        true_lambdas = sample_true_lambdas(products, truth_rng)
    if demand_table is not None and len(demand_table) != weeks:
        raise ValueError(f"demand_table must have {weeks} weekly rows")

    state = PosteriorState.from_products(products)
    weekly_trace = []
    total_profit = 0.0
    total_sales = 0

    for week in range(1, weeks + 1):
        selected = policy.select(products, state, items_per_week, decision_rng)
        if len(selected) != items_per_week:
            raise RuntimeError(
                f"{policy.name} selected {len(selected)} items; expected {items_per_week}"
            )
        if len(set(selected)) != len(selected):
            raise RuntimeError(f"{policy.name} selected duplicated SKUs in week {week}")

        observed_sales: Dict[str, int] = {}
        week_profit = 0.0
        for sku in selected:
            product = product_by_sku[sku]
            if demand_table is None:
                sales = int(sales_rng.poisson(true_lambdas[sku]))
            else:
                sales = int(demand_table[week - 1][sku])
            observed_sales[sku] = sales
            state.update(sku, sales)
            week_profit += product.margin * sales
            total_sales += sales
        total_profit += week_profit

        if keep_trace:
            weekly_trace.append(
                {
                    "week": week,
                    "selected_skus": selected,
                    "observed_sales": observed_sales,
                    "realized_profit": round(week_profit, 6),
                }
            )

    return {
        "policy": policy.name,
        "weeks": weeks,
        "items_per_week": items_per_week,
        "total_realized_profit": round(total_profit, 6),
        "total_sales": total_sales,
        "weekly_trace": weekly_trace,
        "posterior_summary": posterior_summary(products, state),
    }


def posterior_summary(
    products: Sequence[Product],
    state: PosteriorState,
    top_n: int = 30,
) -> List[Dict[str, object]]:
    rows = []
    for product in products:
        rows.append(
            {
                "sku": product.sku,
                "posterior_m": round(state.m[product.sku], 6),
                "posterior_alpha": round(state.alpha[product.sku], 6),
                "posterior_mean_lambda": round(state.posterior_mean(product.sku), 6),
                "unit_margin": round(product.margin, 6),
                "posterior_expected_weekly_profit": round(
                    product.margin * state.posterior_mean(product.sku), 6
                ),
                "observed_weeks": state.observed_weeks[product.sku],
                "observed_sales": state.observed_sales[product.sku],
            }
        )
    rows.sort(
        key=lambda row: (row["posterior_expected_weekly_profit"], row["sku"]),
        reverse=True,
    )
    return rows[:top_n]


def perfect_information_expected_profit(
    products: Sequence[Product],
    true_lambdas: Dict[str, float],
    weeks: int,
    items_per_week: int,
) -> float:
    scores = [
        (product.margin * true_lambdas[product.sku], product.sku)
        for product in products
    ]
    selected = set(top_k_skus(scores, items_per_week))
    return weeks * sum(
        product.margin * true_lambdas[product.sku]
        for product in products
        if product.sku in selected
    )


def generate_demand_table(
    products: Sequence[Product],
    true_lambdas: Dict[str, float],
    weeks: int,
    rng: np.random.Generator,
) -> List[Dict[str, int]]:
    return [
        {product.sku: int(rng.poisson(true_lambdas[product.sku])) for product in products}
        for _ in range(weeks)
    ]


def summarize_profit_samples(
    profits: np.ndarray,
    upper_bounds: np.ndarray,
) -> Dict[str, float]:
    episodes = int(len(profits))
    mean_profit = float(np.mean(profits))
    std_profit = float(np.std(profits, ddof=1)) if episodes > 1 else 0.0
    ci_half_width = 1.96 * std_profit / math.sqrt(episodes) if episodes > 1 else 0.0
    mean_upper = float(np.mean(upper_bounds))
    regret = mean_upper - mean_profit

    return {
        "episodes": episodes,
        "mean_realized_profit": round(mean_profit, 6),
        "std_realized_profit": round(std_profit, 6),
        "ci95_low": round(mean_profit - ci_half_width, 6),
        "ci95_high": round(mean_profit + ci_half_width, 6),
        "mean_perfect_information_upper_bound": round(mean_upper, 6),
        "mean_regret_to_upper_bound": round(regret, 6),
        "upper_bound_ratio": round(mean_profit / mean_upper, 6)
        if abs(mean_upper) > 1e-12
        else float("nan"),
    }


def evaluate_policy(
    products: Sequence[Product],
    policy_factory,
    weeks: int,
    items_per_week: int,
    episodes: int,
    seed: int,
) -> Dict[str, float]:
    validate_season_args(products, weeks, items_per_week)
    if episodes <= 0:
        raise ValueError("episodes must be positive")

    profits = np.empty(episodes, dtype=float)
    upper_bounds = np.empty(episodes, dtype=float)
    root_rng = np.random.default_rng(seed)

    for episode in range(episodes):
        episode_seed = int(root_rng.integers(0, np.iinfo(np.int64).max))
        true_rng = np.random.default_rng(episode_seed)
        true_lambdas = sample_true_lambdas(products, true_rng)
        demand_rng = np.random.default_rng(episode_seed + 1)
        demand_table = generate_demand_table(products, true_lambdas, weeks, demand_rng)
        result = simulate_season(
            products=products,
            policy=policy_factory(),
            weeks=weeks,
            items_per_week=items_per_week,
            seed=episode_seed + 17,
            true_lambdas=true_lambdas,
            demand_table=demand_table,
            keep_trace=False,
        )
        profits[episode] = float(result["total_realized_profit"])
        upper_bounds[episode] = perfect_information_expected_profit(
            products, true_lambdas, weeks, items_per_week
        )

    return summarize_profit_samples(profits, upper_bounds)


def evaluate_reference_policies(
    products: Sequence[Product],
    weeks: int,
    items_per_week: int,
    episodes: int,
    seed: int,
) -> Dict[str, Dict[str, float]]:
    policies = {
        "thompson_sampling": lambda: ThompsonSamplingPolicy(),
        "posterior_mean_greedy": lambda: PosteriorMeanGreedyPolicy(),
        "static_prior_greedy": lambda: StaticPriorGreedyPolicy(products),
    }
    if episodes <= 0:
        raise ValueError("episodes must be positive")

    profits = {
        name: np.empty(episodes, dtype=float)
        for name in policies
    }
    upper_bounds = np.empty(episodes, dtype=float)
    root_rng = np.random.default_rng(seed)

    for episode in range(episodes):
        episode_seed = int(root_rng.integers(0, np.iinfo(np.int64).max - 10000000))
        true_rng = np.random.default_rng(episode_seed)
        true_lambdas = sample_true_lambdas(products, true_rng)
        demand_rng = np.random.default_rng(episode_seed + 1)
        demand_table = generate_demand_table(products, true_lambdas, weeks, demand_rng)
        upper_bounds[episode] = perfect_information_expected_profit(
            products, true_lambdas, weeks, items_per_week
        )

        for policy_index, (name, factory) in enumerate(policies.items()):
            result = simulate_season(
                products=products,
                policy=factory(),
                weeks=weeks,
                items_per_week=items_per_week,
                seed=episode_seed + 1009 * (policy_index + 1),
                true_lambdas=true_lambdas,
                demand_table=demand_table,
                keep_trace=False,
            )
            profits[name][episode] = float(result["total_realized_profit"])

    return {
        name: summarize_profit_samples(policy_profits, upper_bounds)
        for name, policy_profits in profits.items()
    }


def load_observations(path: Path) -> List[Tuple[str, int]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"{path} is empty or has no header")
        sku_col = _find_column(reader.fieldnames, ("sku", "id", "product_id", "s"))
        sales_col = _find_column(reader.fieldnames, ("sales", "n", "quantity", "units"))
        observations = []
        for row_number, row in enumerate(reader, start=2):
            sku = str(row[sku_col]).strip()
            sales = int(float(row[sales_col]))
            if sales < 0:
                raise ValueError(f"row {row_number}: sales must be non-negative")
            observations.append((sku, sales))
    return observations


def recommend_next_week(
    products: Sequence[Product],
    observations: Iterable[Tuple[str, int]],
    items_per_week: int,
    seed: int,
) -> Dict[str, object]:
    state = PosteriorState.from_products(products)
    valid_skus = {product.sku for product in products}
    for sku, sales in observations:
        if sku not in valid_skus:
            raise ValueError(f"observation contains unknown sku={sku}")
        state.update(sku, sales)

    rng = np.random.default_rng(seed)
    selected = ThompsonSamplingPolicy().select(products, state, items_per_week, rng)
    return {
        "policy": ThompsonSamplingPolicy.name,
        "selected_skus": selected,
        "posterior_summary": posterior_summary(products, state),
    }


def validate_season_args(
    products: Sequence[Product],
    weeks: int,
    items_per_week: int,
) -> None:
    if weeks <= 0:
        raise ValueError("weeks must be positive")
    if items_per_week <= 0:
        raise ValueError("items_per_week must be positive")
    if len(products) < items_per_week:
        raise ValueError(
            f"need at least {items_per_week} products, got {len(products)}"
        )


def maybe_load_products(args: argparse.Namespace) -> Tuple[List[Product], str]:
    if args.products:
        return load_products(Path(args.products)), str(Path(args.products))

    local_candidates = [
        Path.cwd() / "products.csv",
        Path.cwd() / "problem" / "products.csv",
        Path(__file__).resolve().parent.parent / "problem" / "products.csv",
    ]
    for candidate in local_candidates:
        if candidate.exists():
            return load_products(candidate), str(candidate)

    if not args.synthetic:
        raise FileNotFoundError(
            "products.csv not found. Pass --products PATH or use --synthetic "
            "to run the built-in demonstration instance."
        )
    return generate_synthetic_products(seed=args.seed), "synthetic"


def parse_args(argv: Optional[Sequence[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Reference reference implementation for the Gamma-Poisson CMAB "
            "fashion product selection problem."
        )
    )
    parser.add_argument("--products", type=str, help="path to products.csv")
    parser.add_argument(
        "--synthetic",
        action="store_true",
        help="use a reproducible synthetic 100-product instance if products.csv is absent",
    )
    parser.add_argument("--weeks", type=int, default=DEFAULT_WEEKS)
    parser.add_argument("--items-per-week", type=int, default=DEFAULT_ITEMS_PER_WEEK)
    parser.add_argument("--episodes", type=int, default=300)
    parser.add_argument("--seed", type=int, default=20260507)
    parser.add_argument(
        "--observations",
        type=str,
        help="optional CSV with sku,sales rows; if provided, output next-week recommendation",
    )
    parser.add_argument(
        "--export-plan",
        type=str,
        help="optional path to write one simulated Thompson Sampling season as JSON",
    )
    parser.add_argument(
        "--export-eval",
        type=str,
        help="optional path to write Monte Carlo evaluation summary as JSON",
    )
    return parser.parse_args(argv)


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = parse_args(argv)
    products, source = maybe_load_products(args)
    validate_season_args(products, args.weeks, args.items_per_week)

    if args.observations:
        recommendation = recommend_next_week(
            products=products,
            observations=load_observations(Path(args.observations)),
            items_per_week=args.items_per_week,
            seed=args.seed,
        )
        print(json.dumps(recommendation, ensure_ascii=False, indent=2))
        return 0

    plan = simulate_season(
        products=products,
        policy=ThompsonSamplingPolicy(),
        weeks=args.weeks,
        items_per_week=args.items_per_week,
        seed=args.seed,
        keep_trace=True,
    )
    plan["product_source"] = source

    evaluation = evaluate_reference_policies(
        products=products,
        weeks=args.weeks,
        items_per_week=args.items_per_week,
        episodes=args.episodes,
        seed=args.seed + 911,
    )

    print(f"product_source: {source}")
    print(f"products: {len(products)}")
    print(f"weeks: {args.weeks}, items_per_week: {args.items_per_week}")
    print("\nMonte Carlo evaluation")
    print(
        "policy, mean_profit, ci95_low, ci95_high, "
        "perfect_info_upper, regret, upper_bound_ratio"
    )
    for policy_name, row in evaluation.items():
        print(
            f"{policy_name}, "
            f"{row['mean_realized_profit']:.2f}, "
            f"{row['ci95_low']:.2f}, "
            f"{row['ci95_high']:.2f}, "
            f"{row['mean_perfect_information_upper_bound']:.2f}, "
            f"{row['mean_regret_to_upper_bound']:.2f}, "
            f"{row['upper_bound_ratio']:.4f}"
        )

    print("\nOne simulated Thompson Sampling season")
    print(f"total_realized_profit: {plan['total_realized_profit']:.2f}")
    print(f"week_1_selection: {plan['weekly_trace'][0]['selected_skus']}")

    if args.export_plan:
        Path(args.export_plan).write_text(
            json.dumps(plan, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    if args.export_eval:
        Path(args.export_eval).write_text(
            json.dumps(evaluation, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
