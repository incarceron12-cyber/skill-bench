# 选品问题 1 Reference 答案

本题是一个有限时域的组合多臂老虎机问题：每周动作是从 100 个 SKU 中选择 30 个，状态是所有 SKU 的 Gamma-Poisson 后验参数，目标是最大化 20 周累计期望利润。

设单件毛利为 \(r_s=price_s-cost_s\)。第 \(t\) 周选择集合 \(A_t\)，\(|A_t|=30\)。若 SKU \(s\in A_t\)，销量观测为
\[
n_{s,t}\sim Poisson(\lambda_s)
\]
周利润为
\[
\sum_{s\in A_t} r_s n_{s,t}
\]
先验和后验采用 shape-rate 口径：
\[
\lambda_s\sim Gamma(m_s,\alpha_s),\qquad
\lambda_s\mid n_{s,t}\sim Gamma(m_s+n_{s,t},\alpha_s+1)
\]
没有上架的 SKU 本周没有新观测，后验不变。

参考策略采用 Thompson Sampling。每周对每个 SKU 从当前后验采样
\[
\tilde\lambda_s\sim Gamma(m_s,\alpha_s)
\]
计算采样利润分数
\[
score_s=(price_s-cost_s)\tilde\lambda_s
\]
选择分数最高的 30 个 SKU；周末用真实观测销量 \(n_{s,t}\) 更新被选 SKU 的后验。这个实现有真实的探索-利用机制：不确定性大的 SKU 会自然获得探索机会，而高后验利润 SKU 会逐渐进入稳定利用。

代码位于 `reference/solve.py`，包含：

- `ThompsonSamplingPolicy`：主策略。
- `PosteriorMeanGreedyPolicy` 和 `StaticPriorGreedyPolicy`：对照基线。
- `simulate_season`：独立仿真，先从先验一次性采样固定真实 \(\lambda_s\)，再按 Poisson 生成销量。
- `evaluate_reference_policies`：蒙特卡洛评估，报告均值、95% 置信区间、完美信息上界和 regret。
- `recommend_next_week`：给定历史 `sku,sales` 观测后输出下一周 30 个 SKU。

运行方式：

```bash
python3 reference/solve.py --products products.csv --episodes 1000 --export-plan plan.json --export-eval eval.json
```

若题目目录没有提供 `products.csv`，可运行内置可复现实例做自检：

```bash
python3 reference/solve.py --synthetic --episodes 300
```

线上使用时，每周收集实际销量后放入观测 CSV：

```csv
sku,sales
SKU001,18
SKU014,7
```

再运行：

```bash
python3 reference/solve.py --products products.csv --observations observed_sales.csv
```

注意：如果真实 \(\lambda_s\) 已知，逐周选择 \(r_s\lambda_s\) 最高的 30 个 SKU 才是完美信息上界；实际业务中 \(\lambda_s\) 不可见，因此该上界只用于评估，不是可部署策略。提交的可部署 reference 是 Thompson Sampling + Gamma-Poisson 闭环更新。
