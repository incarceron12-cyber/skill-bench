# Extras

Problems beyond the core Opti-Agent-Bench evaluation suite.
Useful for broader coverage / future papers; **not required** for the main leaderboard.

| Folder | Domain |
|--------|--------|
| `product_selection_01`–`03` | CMAB 选品 |
| `sdp_*` | 半正定规划 |
| `nonsmooth_*` | 非平滑优化（附录题） |
| `mdp_*` | 额外 MDP 场景 |

Each folder typically has `problem.md`, `metadata.json`, and optionally `reference/`.
