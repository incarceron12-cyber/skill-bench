# sdp2 问题三 制造供应链鲁棒优化

## 3. 分析与解法

### 【数学建模 — 为什么是 SDP？】

与投资组合完全类似，将"产能比例"类比"投资权重"，"利润率波动"
类比"收益率波动"。

鲁棒产能分配问题:

min max\_{Σ∈U} wᵀ Σ w

s.t. wᵀ μ ≥ r\_target, Σ w\_i = 1, 0 ≤ w\_i ≤ 0.4

利用 Frobenius 范数球的闭式解:

max\_{Σ∈U} wᵀ Σ w = wᵀ Σ̂ w + ρ · ‖w‖₂²

SDP 形式（Schur 补）:

min t

s.t. ⎡ t wᵀ ⎤
     ⎣ w (Σ̂+ρI)⁻¹ ⎦ ⪰ 0

wᵀ μ ≥ r\_target, Σ w\_i = 1, 0 ≤ w\_i ≤ 0.4

### 求解函数

```python
def problem3_manufacturing_robust():
    """问题三: 多品种制造供应链鲁棒优化"""
    print("\n" + "=" * 60)
    print("问题三: 多品种制造供应链鲁棒优化 (鲁棒SDP)")
    print("=" * 60)

    # --- 数据 ---
    products, mu, Sigma_hat, rho, target_profit, max_single = generate_manufacturing_data(
        n_products=7, n_months=24, target_profit=0.10, uncertainty_pct=0.12, seed=42
    )
    n = len(products)

    print(f"\n产品: {products}")
    print(f"样本估计年化利润率: {[f'{x:.2%}' for x in mu]}")
    print(f"不确定性半径 ρ = {rho:.6f}")
    print(f"目标利润率: {target_profit:.2%}")
    print(f"单产品产能上限: {max_single:.0%}")

    # --- 经典 Markowitz ---
    w_classic = cp.Variable(n)
    prob_classic = cp.Problem(
        cp.Minimize(cp.quad_form(w_classic, Sigma_hat)),
        [w_classic >= 0, w_classic <= max_single,
         cp.sum(w_classic) == 1, mu @ w_classic >= target_profit]
    )
    prob_classic.solve()
    w_classic_opt = w_classic.value
    risk_classic = prob_classic.value

    print(f"\n--- 经典产能分配（忽略不确定性）---")
    print(f"最优产能比: {dict(zip(products, [f'{x:.2%}' for x in w_classic_opt]))}")
    print(f"利润波动风险(方差): {risk_classic:.6f}")

    # --- 鲁棒SDP ---
    w = cp.Variable(n)
    t = cp.Variable()

    Sigma_robust = Sigma_hat + rho * np.eye(n)
    Sigma_inv = np.linalg.inv(Sigma_robust)

    constraints = [
        w >= 0,
        w <= max_single,
        cp.sum(w) == 1,
        mu @ w >= target_profit,
        cp.bmat([
            [cp.reshape(t, (1, 1)), cp.reshape(w, (1, n))],
            [cp.reshape(w, (n, 1)), Sigma_inv]
        ]) >> 0
    ]

    prob_robust = cp.Problem(cp.Minimize(t), constraints)
    prob_robust.solve(solver=cp.SCS)

    w_robust_opt = w.value
    risk_robust = t.value

    print(f"\n--- 鲁棒产能分配（考虑最坏情况）---")
    print(f"最优产能比: {dict(zip(products, [f'{x:.2%}' for x in w_robust_opt]))}")
    print(f"最坏情况风险(方差): {risk_robust:.6f}")

    print(f"\n--- 对比 ---")
    print(f"经典风险:   {risk_classic:.6f}")
    print(f"鲁棒风险:   {risk_robust:.6f}")
    print(f"鲁棒代价:   +{(risk_robust / risk_classic - 1) * 100:.1f}%")

    # 检查分散化程度
    hhi_classic = np.sum(w_classic_opt ** 2)
    hhi_robust = np.sum(w_robust_opt ** 2)
    print(f"\n产能集中度 (HHI): 经典={hhi_classic:.4f}, 鲁棒={hhi_robust:.4f}")
    print(f"  (HHI 越低越分散，鲁棒方案通常更分散)")

    return products, mu, Sigma_hat, w_classic_opt, w_robust_opt, risk_classic, risk_robust
```
