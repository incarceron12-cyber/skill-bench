# 评估 Rubric（10 项）

| No. | 维度 | 检查点 | 通过标准 | 失败标准 | 严重度 |
|:---:|------|--------|----------|----------|:------:|
| 1 | Problem Type | 识别 Lead Time 是核心约束 | 明确理解“决策延迟生效” | 把问题当普通动态选品 | Critical |
| 2 | Problem Type | 识别在途陈列不可更改 | 能正确处理 pipeline / in-transit 状态 | 完全无在途状态 | Critical |
| 3 | Modeling | 贝叶斯后验更新正确 | Gamma-Poisson 更新无根本错误 | 更新公式错误 | Major |
| 4 | Modeling | TS / 探索利用机制真实 | 学习机制不是伪装出来的 | 伪 TS 或探索方向反了 | Critical |
| 5 | Constraints | Lead Time 在代码中真正生效 | 本周销售由更早决策决定 | 队列存在但不影响销售 | Critical |
| 6 | Constraints | 货架与季节节奏约束完整 | `S`、`N`、`T` 等约束正确 | 基本运营节奏错乱 | Major |
| 7 | Solution Approach | 方法与延迟学习匹配 | 至少有合理的 delayed bandit 近似 | 完全忽略延迟反馈效应 | Major |
| 8 | Code Quality | 代码可运行且核心机制一致 | 代码、报告、输出相互支撑 | 文档-代码严重脱节 | Critical |
| 9 | Result Quality | 利润结果可信 | 数值与场景规模基本匹配 | 利润高估明显或无法验证 | Major |
| 10 | Evaluation Quality | 对自身限制有诚实诊断 | 愿意承认 lead time 实现缺陷 | 硬包装不自知 | Minor |
