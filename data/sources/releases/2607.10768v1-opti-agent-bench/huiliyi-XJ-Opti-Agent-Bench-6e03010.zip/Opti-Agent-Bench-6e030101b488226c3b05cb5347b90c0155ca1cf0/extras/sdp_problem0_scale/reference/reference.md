# Reference 说明（问题0）

这个 `reference/solve.py` 使用混合策略：

1. **SDP 松弛上界（可选）**：若环境有 `cvxpy`，先解带业务约束的 Max-Cut SDP 松弛；
2. **Goemans-Williamson 舍入**：从 SDP 解做随机超平面舍入，生成高质量初始解；
3. **CP-SAT 精修**：用 OR-Tools 在硬约束下继续搜索可行高值解。

即使没有 `cvxpy`，脚本也可运行（自动跳过 SDP，直接走 GW 随机 + CP-SAT）。

## 用法

```bash
python3 reference/solve.py data/public_80.json results/reference/public_80/solution.json
```

## 常用参数

```bash
python3 reference/solve.py \
  data/public_200.json \
  results/reference/public_200/solution.json \
  --time-limit 1200 \
  --workers 8 \
  --rounds 1200 \
  --presolve-restarts 6 \
  --presolve-time 8
```

- `--time-limit`：主 CP-SAT 预算（秒），越大越容易逼近最优。
- `--rounds`：GW 舍入次数，越大初始解通常更好。
- `--presolve-restarts` / `--presolve-time`：短时多次预热，帮助提升主求解初始质量。
- `--sdp-solver` / `--sdp-max-iters`：仅在 `cvxpy` 可用时生效。

## 输出格式

与评测模型一致：

```json
{
  "line_a": [...],
  "line_b": [...],
  "objective": 1234,
  "method": "sdp_gw_cpsat_reference",
  "feasible": true,
  "reference_meta": { ... }
}
```

可直接用现有 checker 验证：

```bash
python3 scripts/check_solution.py data/public_80.json results/reference/public_80/solution.json
```
