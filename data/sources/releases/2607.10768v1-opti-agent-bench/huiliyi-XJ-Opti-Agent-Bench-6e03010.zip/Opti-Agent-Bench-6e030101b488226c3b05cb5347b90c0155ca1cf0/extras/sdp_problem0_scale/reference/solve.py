#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
LOCAL_DEPS = ROOT / ".deps" / "python"
if LOCAL_DEPS.exists():
    sys.path.insert(0, str(LOCAL_DEPS))

try:
    import cvxpy as cp  # optional
except Exception:  # pragma: no cover - optional dependency
    cp = None

from ortools.sat.python import cp_model


@dataclass
class CompStats:
    members: list[int]  # 0-based employee ids
    size: int
    frontend: int
    senior: int


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def build_components(data: dict[str, Any]) -> tuple[list[CompStats], list[int]]:
    """Union-find mentor pairs so same component must be same line."""
    n = len(data["employees"])
    departments = data["departments"]
    seniority = data["seniority"]
    mentor_pairs = data["mentor_pairs"]

    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        pa = find(a)
        pb = find(b)
        if pa != pb:
            parent[pb] = pa

    for mentor, mentee in mentor_pairs:
        union(int(mentor) - 1, int(mentee) - 1)

    groups: dict[int, list[int]] = {}
    for i in range(n):
        r = find(i)
        groups.setdefault(r, []).append(i)

    roots = sorted(groups)
    root_to_gid = {r: gid for gid, r in enumerate(roots)}
    comp_of_emp = [0] * n
    components: list[CompStats] = []

    for root in roots:
        members = sorted(groups[root])
        gid = root_to_gid[root]
        for emp in members:
            comp_of_emp[emp] = gid
        components.append(
            CompStats(
                members=members,
                size=len(members),
                frontend=sum(1 for i in members if departments[i] == "前端"),
                senior=sum(1 for i in members if seniority[i] == "高级"),
            )
        )

    return components, comp_of_emp


def aggregate_weights(w: list[list[int]], comp_of_emp: list[int], g: int) -> np.ndarray:
    """Aggregate edge weights to mentor-components."""
    c = np.zeros((g, g), dtype=np.int64)
    n = len(w)
    for i in range(n):
        gi = comp_of_emp[i]
        row = w[i]
        for j in range(i + 1, n):
            gj = comp_of_emp[j]
            if gi == gj:
                continue
            wij = int(row[j])
            c[gi, gj] += wij
            c[gj, gi] += wij
    return c


def cut_value(comp_w: np.ndarray, assign_a: np.ndarray) -> int:
    """assign_a[k] in {0,1}. Return cross-line objective."""
    g = comp_w.shape[0]
    total = 0
    for i in range(g):
        ai = int(assign_a[i])
        row = comp_w[i]
        for j in range(i + 1, g):
            if ai != int(assign_a[j]):
                total += int(row[j])
    return int(total)


def materialize_partition(components: list[CompStats], assign_a: np.ndarray) -> tuple[list[int], list[int]]:
    line_a: list[int] = []
    line_b: list[int] = []
    for gid, comp in enumerate(components):
        if int(assign_a[gid]) == 1:
            line_a.extend(emp + 1 for emp in comp.members)  # 1-based ids
        else:
            line_b.extend(emp + 1 for emp in comp.members)
    line_a.sort()
    line_b.sort()
    return line_a, line_b


def counts_for_assignment(components: list[CompStats], assign_a: np.ndarray, n: int) -> dict[str, int]:
    size_a = 0
    front_a = 0
    senior_a = 0
    for gid, comp in enumerate(components):
        if int(assign_a[gid]) == 1:
            size_a += comp.size
            front_a += comp.frontend
            senior_a += comp.senior
    return {
        "size_a": size_a,
        "size_b": n - size_a,
        "front_a": front_a,
        "front_b": sum(c.frontend for c in components) - front_a,
        "senior_a": senior_a,
        "senior_b": sum(c.senior for c in components) - senior_a,
    }


def is_feasible_assignment(components: list[CompStats], assign_a: np.ndarray, n: int) -> bool:
    min_size = 3
    max_size = int(math.floor(0.7 * n))
    c = counts_for_assignment(components, assign_a, n)
    return (
        min_size <= c["size_a"] <= max_size
        and min_size <= c["size_b"] <= max_size
        and c["front_a"] >= 1
        and c["front_b"] >= 1
        and c["senior_a"] >= 2
        and c["senior_b"] >= 2
    )


def improve_feasible_assignment(
    components: list[CompStats],
    comp_w: np.ndarray,
    assign_a: np.ndarray,
    n: int,
    max_iters: int = 200,
) -> tuple[np.ndarray, int]:
    """Greedy single-flip local search under hard constraints."""
    g = len(components)
    current = assign_a.copy()
    current_obj = cut_value(comp_w, current)
    counts = counts_for_assignment(components, current, n)
    min_size = 3
    max_size = int(math.floor(0.7 * n))

    def feasible_after_flip(i: int, to_a: int) -> bool:
        comp = components[i]
        size_a = counts["size_a"]
        front_a = counts["front_a"]
        senior_a = counts["senior_a"]
        if to_a == 1:
            size_a += comp.size
            front_a += comp.frontend
            senior_a += comp.senior
        else:
            size_a -= comp.size
            front_a -= comp.frontend
            senior_a -= comp.senior
        size_b = n - size_a
        front_b = sum(c.frontend for c in components) - front_a
        senior_b = sum(c.senior for c in components) - senior_a
        return (
            min_size <= size_a <= max_size
            and min_size <= size_b <= max_size
            and front_a >= 1
            and front_b >= 1
            and senior_a >= 2
            and senior_b >= 2
        )

    for _ in range(max_iters):
        best_gain = 0
        best_idx = -1

        for i in range(g):
            old_side = int(current[i])
            new_side = 1 - old_side
            if not feasible_after_flip(i, new_side):
                continue

            # Objective gain for flipping i
            gain = 0
            row = comp_w[i]
            if old_side == 1:
                for j in range(g):
                    if i == j:
                        continue
                    if int(current[j]) == 1:
                        gain += int(row[j])
                    else:
                        gain -= int(row[j])
            else:
                for j in range(g):
                    if i == j:
                        continue
                    if int(current[j]) == 0:
                        gain += int(row[j])
                    else:
                        gain -= int(row[j])

            if gain > best_gain:
                best_gain = gain
                best_idx = i

        if best_idx < 0 or best_gain <= 0:
            break

        # Apply best flip
        i = best_idx
        if int(current[i]) == 1:
            current[i] = 0
            counts["size_a"] -= components[i].size
            counts["front_a"] -= components[i].frontend
            counts["senior_a"] -= components[i].senior
        else:
            current[i] = 1
            counts["size_a"] += components[i].size
            counts["front_a"] += components[i].frontend
            counts["senior_a"] += components[i].senior
        counts["size_b"] = n - counts["size_a"]
        counts["front_b"] = sum(c.frontend for c in components) - counts["front_a"]
        counts["senior_b"] = sum(c.senior for c in components) - counts["senior_a"]
        current_obj += int(best_gain)

    return current, int(current_obj)


def solve_sdp_relaxation(
    components: list[CompStats],
    comp_w: np.ndarray,
    n: int,
    sdp_solver: str,
    sdp_max_iters: int,
) -> dict[str, Any] | None:
    """Solve constrained Max-Cut SDP relaxation (optional: needs cvxpy)."""
    if cp is None:
        return None

    g = len(components)
    min_size = 3
    max_size = int(math.floor(0.7 * n))
    size_vec = np.array([c.size for c in components], dtype=float)
    front_vec = np.array([c.frontend for c in components], dtype=float)
    senior_vec = np.array([c.senior for c in components], dtype=float)
    total_front = float(front_vec.sum())
    total_senior = float(senior_vec.sum())

    y = cp.Variable((g + 1, g + 1), symmetric=True)
    x = y[0, 1:]
    gram = y[1:, 1:]

    constraints = [y >> 0, cp.diag(y) == 1]

    size_a = 0.5 * (n + size_vec @ x)
    front_a = 0.5 * (total_front + front_vec @ x)
    senior_a = 0.5 * (total_senior + senior_vec @ x)
    size_b = n - size_a
    front_b = total_front - front_a
    senior_b = total_senior - senior_a

    constraints.extend(
        [
            size_a >= min_size,
            size_a <= max_size,
            size_b >= min_size,
            size_b <= max_size,
            front_a >= 1,
            front_b >= 1,
            senior_a >= 2,
            senior_b >= 2,
        ]
    )

    const_term = 0.25 * float(comp_w.sum())
    objective = cp.Maximize(const_term - 0.25 * cp.trace(comp_w @ gram))
    prob = cp.Problem(objective, constraints)

    solver_name = sdp_solver.upper()
    solve_kwargs: dict[str, Any] = {"verbose": False}
    if solver_name == "SCS":
        solve_kwargs["max_iters"] = int(sdp_max_iters)

    try:
        prob.solve(solver=solver_name, **solve_kwargs)
    except Exception:
        return None

    if prob.status not in {"optimal", "optimal_inaccurate"}:
        return None
    if y.value is None:
        return None

    y_val = np.array(y.value, dtype=float)
    gram_val = np.array(y_val[1:, 1:], dtype=float)
    gram_val = 0.5 * (gram_val + gram_val.T)
    x_val = np.array(y_val[0, 1:], dtype=float)

    return {
        "status": prob.status,
        "upper_bound": float(prob.value),
        "y": y_val,
        "gram": gram_val,
        "x": x_val,
    }


def gw_rounding_hint(
    comp_w: np.ndarray,
    sdp_result: dict[str, Any] | None,
    rounds: int,
    seed: int,
) -> np.ndarray:
    """Generate one high-quality 0/1 assignment hint from SDP/GW."""
    g = comp_w.shape[0]
    rng = np.random.default_rng(seed)

    # Baseline random assignment.
    best = (rng.random(g) > 0.5).astype(int)
    best_score = cut_value(comp_w, best)

    if not sdp_result:
        return best

    # Deterministic threshold from relaxed x.
    x = sdp_result["x"]
    assign_from_x = (x >= 0).astype(int)
    score_x = cut_value(comp_w, assign_from_x)
    if score_x > best_score:
        best = assign_from_x
        best_score = score_x

    gram = np.array(sdp_result["gram"], dtype=float)
    eigvals, eigvecs = np.linalg.eigh(gram)
    eigvals = np.maximum(eigvals, 0.0)
    eps = 1e-12
    active = eigvals > eps
    if not np.any(active):
        return best

    v = eigvecs[:, active] @ np.diag(np.sqrt(eigvals[active]))
    d = v.shape[1]

    for _ in range(max(1, rounds)):
        r = rng.standard_normal(d)
        proj = v @ r
        z = np.sign(proj)
        z[z == 0] = 1
        candidate = (z > 0).astype(int)
        score = cut_value(comp_w, candidate)
        if score > best_score:
            best = candidate
            best_score = score

    return best


def solve_cpsat_exact(
    components: list[CompStats],
    comp_w: np.ndarray,
    n: int,
    hint: np.ndarray | None,
    time_limit: float,
    workers: int,
    seed: int,
) -> dict[str, Any]:
    g = len(components)
    min_size = 3
    max_size = int(math.floor(0.7 * n))
    size = [c.size for c in components]
    front = [c.frontend for c in components]
    senior = [c.senior for c in components]
    total_front = sum(front)
    total_senior = sum(senior)

    model = cp_model.CpModel()
    x = [model.NewBoolVar(f"x_{i}") for i in range(g)]  # 1 means line A

    size_a_expr = sum(size[i] * x[i] for i in range(g))
    front_a_expr = sum(front[i] * x[i] for i in range(g))
    senior_a_expr = sum(senior[i] * x[i] for i in range(g))

    model.Add(size_a_expr >= min_size)
    model.Add(size_a_expr <= max_size)
    model.Add(n - size_a_expr >= min_size)
    model.Add(n - size_a_expr <= max_size)
    model.Add(front_a_expr >= 1)
    model.Add(total_front - front_a_expr >= 1)
    model.Add(senior_a_expr >= 2)
    model.Add(total_senior - senior_a_expr >= 2)

    y: dict[tuple[int, int], cp_model.IntVar] = {}
    objective_terms: list[cp_model.LinearExpr] = []
    for i in range(g):
        for j in range(i + 1, g):
            w_ij = int(comp_w[i, j])
            if w_ij == 0:
                continue
            y_ij = model.NewBoolVar(f"y_{i}_{j}")
            y[(i, j)] = y_ij
            model.Add(y_ij >= x[i] - x[j])
            model.Add(y_ij >= x[j] - x[i])
            model.Add(y_ij <= x[i] + x[j])
            model.Add(y_ij <= 2 - x[i] - x[j])
            objective_terms.append(w_ij * y_ij)

    model.Maximize(sum(objective_terms))

    if hint is not None and len(hint) == g:
        for i in range(g):
            model.AddHint(x[i], int(hint[i]))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = float(max(1.0, time_limit))
    solver.parameters.num_search_workers = int(max(1, workers))
    solver.parameters.random_seed = int(seed)

    status = solver.Solve(model)
    status_name = solver.StatusName(status)

    feasible = status in (cp_model.OPTIMAL, cp_model.FEASIBLE)
    assignment = None
    objective = None
    if feasible:
        assignment = np.array([int(solver.Value(x[i])) for i in range(g)], dtype=int)
        objective = cut_value(comp_w, assignment)

    return {
        "status": status_name,
        "feasible": feasible,
        "assignment": assignment,
        "objective": objective,
        "best_bound": float(solver.BestObjectiveBound()),
        "proven_optimal": status == cp_model.OPTIMAL,
    }


def solve_reference(
    data: dict[str, Any],
    seed: int,
    rounds: int,
    time_limit: float,
    workers: int,
    presolve_restarts: int,
    presolve_time: float,
    sdp_solver: str,
    sdp_max_iters: int,
) -> dict[str, Any]:
    n = len(data["employees"])
    components, comp_of_emp = build_components(data)
    comp_w = aggregate_weights(data["W"], comp_of_emp, len(components))

    sdp_result = solve_sdp_relaxation(
        components=components,
        comp_w=comp_w,
        n=n,
        sdp_solver=sdp_solver,
        sdp_max_iters=sdp_max_iters,
    )
    hint = gw_rounding_hint(comp_w=comp_w, sdp_result=sdp_result, rounds=rounds, seed=seed)

    # Short multi-start CP-SAT warmup: find a stronger hint quickly.
    warmup_best = hint.copy()
    warmup_best_obj = cut_value(comp_w, warmup_best)
    warmup_trials = max(0, int(presolve_restarts))
    warmup_time = float(max(0.0, presolve_time))
    if warmup_trials > 0 and warmup_time > 0:
        warmup_workers = max(1, min(workers, 4))
        for t in range(warmup_trials):
            trial_seed = seed + 1009 * t
            trial_hint = gw_rounding_hint(
                comp_w=comp_w,
                sdp_result=sdp_result,
                rounds=max(50, rounds // 4),
                seed=trial_seed,
            )
            trial = solve_cpsat_exact(
                components=components,
                comp_w=comp_w,
                n=n,
                hint=trial_hint,
                time_limit=warmup_time,
                workers=warmup_workers,
                seed=trial_seed,
            )
            if trial["feasible"] and int(trial["objective"]) > warmup_best_obj:
                warmup_best = trial["assignment"]
                warmup_best_obj = int(trial["objective"])

    hint = warmup_best
    cp_res = solve_cpsat_exact(
        components=components,
        comp_w=comp_w,
        n=n,
        hint=hint,
        time_limit=time_limit,
        workers=workers,
        seed=seed,
    )

    if cp_res["feasible"]:
        assignment = cp_res["assignment"]
    elif is_feasible_assignment(components, hint, n):
        assignment = hint
    else:
        assignment = None

    if assignment is None:
        return {
            "line_a": [],
            "line_b": [],
            "objective": 0,
            "method": "sdp_gw_cpsat_reference",
            "feasible": False,
            "reference_meta": {
                "components": len(components),
                "sdp_available": cp is not None,
                "sdp_status": None if sdp_result is None else sdp_result["status"],
                "sdp_upper_bound": None if sdp_result is None else sdp_result["upper_bound"],
                "cp_sat_status": cp_res["status"],
                "cp_sat_best_bound": cp_res["best_bound"],
                "cp_sat_proven_optimal": cp_res["proven_optimal"],
            },
        }

    assignment, improved_obj = improve_feasible_assignment(
        components=components,
        comp_w=comp_w,
        assign_a=assignment,
        n=n,
        max_iters=300,
    )
    line_a, line_b = materialize_partition(components, assignment)
    objective = int(sum(data["W"][i - 1][j - 1] for i in line_a for j in line_b))
    feasible = True

    sdp_upper = None if sdp_result is None else float(sdp_result["upper_bound"])
    reference_meta = {
        "components": len(components),
        "sdp_available": cp is not None,
        "sdp_status": None if sdp_result is None else sdp_result["status"],
        "sdp_upper_bound": sdp_upper,
        "cp_sat_status": cp_res["status"],
        "cp_sat_objective": cp_res["objective"],
        "cp_sat_best_bound": cp_res["best_bound"],
        "cp_sat_proven_optimal": cp_res["proven_optimal"],
        "local_search_objective": improved_obj,
        "warmup_restarts": warmup_trials,
        "warmup_time_sec_each": warmup_time,
        "warmup_best_objective": warmup_best_obj,
        "gw_rounds": int(rounds),
        "seed": int(seed),
    }
    if sdp_upper is not None:
        reference_meta["gap_to_sdp_upper_bound"] = float(sdp_upper - objective)

    return {
        "line_a": line_a,
        "line_b": line_b,
        "objective": objective,
        "method": "sdp_gw_cpsat_reference",
        "feasible": feasible,
        "reference_meta": reference_meta,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Reference solver: constrained SDP relaxation + GW rounding + CP-SAT polish"
    )
    parser.add_argument(
        "input_json",
        nargs="?",
        default=str(ROOT / "data" / "public_80.json"),
        help="输入实例 JSON",
    )
    parser.add_argument(
        "output_json",
        nargs="?",
        default=str(ROOT / "results" / "reference" / "public_80" / "solution.json"),
        help="输出解 JSON",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--rounds", type=int, default=500, help="GW 随机舍入次数")
    parser.add_argument("--time-limit", type=float, default=600.0, help="CP-SAT 时间上限（秒）")
    parser.add_argument("--workers", type=int, default=8, help="CP-SAT 线程数")
    parser.add_argument("--presolve-restarts", type=int, default=4, help="短时预热次数")
    parser.add_argument("--presolve-time", type=float, default=5.0, help="每次预热时长（秒）")
    parser.add_argument(
        "--sdp-solver",
        default="SCS",
        help="cvxpy SDP 求解器（默认 SCS；若 cvxpy 不可用将自动跳过 SDP）",
    )
    parser.add_argument("--sdp-max-iters", type=int, default=15000, help="SCS 最大迭代次数")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    data_path = Path(args.input_json).resolve()
    out_path = Path(args.output_json).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    data = load_json(data_path)
    result = solve_reference(
        data=data,
        seed=args.seed,
        rounds=args.rounds,
        time_limit=args.time_limit,
        workers=args.workers,
        presolve_restarts=args.presolve_restarts,
        presolve_time=args.presolve_time,
        sdp_solver=args.sdp_solver,
        sdp_max_iters=args.sdp_max_iters,
    )

    out_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(out_path)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
