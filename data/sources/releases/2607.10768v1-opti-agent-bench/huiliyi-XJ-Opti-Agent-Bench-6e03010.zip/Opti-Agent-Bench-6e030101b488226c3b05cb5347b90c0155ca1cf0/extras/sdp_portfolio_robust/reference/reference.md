# sdp1 问题三 投资组合稳健配置

## 3. 分析与解法

### 【数学建模 — 为什么是 SDP？】

经典 Markowitz 问题:

min wᵀ Σ̂ w

s.t. wᵀ μ ≥ r\_target, Σ w\_i = 1, w ≥ 0

题目要求方案在市场波动联动关系与历史数据存在偏差时仍然可控，即需要考虑不确定性。将"偏差容许范围 ρ"解读为真实协方差矩阵 Σ 与估计值 Σ̂ 的 Frobenius 范数偏差上界，不确定集为 U = { Σ : Σ ⪰ 0, ‖Σ − Σ̂‖\_F ≤ ρ }。

鲁棒版本（"最不利情形下风险最小"）:

min max\_{Σ ∈ U} wᵀ Σ w

s.t. wᵀ μ ≥ r\_target, Σ w\_i = 1, w ≥ 0, w\_i ≤ 0.35, Σ\_{i∈equity} w\_i ≤ 0.60

当不确定集为 Frobenius 范数球时，内层最大化有闭式解:

max\_{Σ ∈ U} wᵀ Σ w = wᵀ Σ̂ w + ρ · ‖w‖₂²

因此鲁棒问题等价于:

min wᵀ (Σ̂ + ρI) w

s.t. 同上

为展示 SDP 形式，将二次目标用 Schur 补写成线性目标 + 半正定矩阵约束:

min t

s.t. ⎡ t wᵀ ⎤

⎣ w (Σ̂+ρI)⁻¹ ⎦ ⪰ 0 （Schur 补 ⇔ t ≥ wᵀ(Σ̂+ρI)w）

wᵀ μ ≥ r\_target, Σ w\_i = 1, w ≥ 0, w\_i ≤ 0.35, Σ\_{i∈equity} w\_i ≤ 0.60

这是一个标准的 SDP 问题，额外包含权益类资产合计上限和单一资产上限两个线性约束。

### 求解代码

```python
def problem3_robust_portfolio():
    """问题三: 投资组合稳健配置"""
    print("\n" + "=" * 60)
    print("问题三: 投资组合稳健配置 (鲁棒SDP)")
    print("=" * 60)

    # --- 数据 ---
    stocks = ["沪深300ETF", "创业板ETF", "国债ETF", "黄金ETF", "纳斯达克100ETF", "REITs地产ETF"]
    asset_class = ["权益", "权益", "固收", "商品", "权益", "另类"]

    mu = np.array([-0.001715, -0.034976, -0.004608,  0.238355,  0.141640,  0.162441])

    Sigma_hat = np.array([
        [ 2.711659e-02,  2.774823e-02, -5.024402e-04, -8.850427e-04,  6.507306e-03,  1.019024e-02],
        [ 2.774823e-02,  4.399629e-02,  1.403240e-05, -3.555954e-04,  4.366492e-03,  7.429361e-03],
        [-5.024402e-04,  1.403240e-05,  1.137694e-03,  1.253967e-03, -1.123984e-03, -3.537899e-04],
        [-8.850427e-04, -3.555954e-04,  1.253967e-03,  1.809406e-02, -4.706548e-03,  1.042552e-03],
        [ 6.507306e-03,  4.366492e-03, -1.123984e-03, -4.706548e-03,  4.036867e-02,  1.758557e-02],
        [ 1.019024e-02,  7.429361e-03, -3.537899e-04,  1.042552e-03,  1.758557e-02,  2.584169e-02],
    ])

    rho = 0.008917
    target_return = 0.07
    equity_indices = [0, 1, 4]
    max_equity_total = 0.60
    max_single = 0.35
    n = len(stocks)

    print(f"\n资产: {stocks}")
    print(f"资产分类: {asset_class}")
    print(f"预期年化收益率: {[f'{x:.2%}' for x in mu]}")
    print(f"偏差容许范围 ρ = {rho:.6f}")
    print(f"目标收益率: {target_return:.2%}")
    print(f"权益类合计上限: {max_equity_total:.0%}")
    print(f"单一资产上限: {max_single:.0%}")

    # --- 经典配置 (不含鲁棒性) ---
    w_classic = cp.Variable(n)
    prob_classic = cp.Problem(
        cp.Minimize(cp.quad_form(w_classic, Sigma_hat)),
        [
            w_classic >= 0,
            cp.sum(w_classic) == 1,
            mu @ w_classic >= target_return,
            cp.sum(w_classic[equity_indices]) <= max_equity_total,
            w_classic <= max_single,
        ]
    )
    prob_classic.solve()
    w_classic_opt = w_classic.value
    risk_classic = prob_classic.value

    print(f"\n--- 经典配置 (无鲁棒性) ---")
    print(f"最优权重: {dict(zip(stocks, [f'{x:.2%}' for x in w_classic_opt]))}")
    print(f"风险(方差): {risk_classic:.6f}")

    # --- 稳健SDP配置 ---
    w = cp.Variable(n)
    t = cp.Variable()

    Sigma_robust = Sigma_hat + rho * np.eye(n)
    Sigma_inv = np.linalg.inv(Sigma_robust)

    constraints = [
        w >= 0,
        cp.sum(w) == 1,
        mu @ w >= target_return,
        cp.sum(w[equity_indices]) <= max_equity_total,
        w <= max_single,
        cp.bmat([
            [cp.reshape(t, (1, 1)), cp.reshape(w, (1, n))],
            [cp.reshape(w, (n, 1)), Sigma_inv]
        ]) >> 0
    ]

    prob_robust = cp.Problem(cp.Minimize(t), constraints)
    prob_robust.solve(solver=cp.SCS)

    w_robust_opt = w.value
    risk_robust = t.value

    print(f"\n--- 稳健SDP配置 ---")
    print(f"最优权重: {dict(zip(stocks, [f'{x:.2%}' for x in w_robust_opt]))}")
    print(f"最坏情况风险(方差): {risk_robust:.6f}")

    # 检查约束满足情况
    equity_weight = sum(w_robust_opt[i] for i in equity_indices)
    max_w = max(w_robust_opt)
    print(f"\n--- 约束检查 ---")
    print(f"权益类合计: {equity_weight:.2%} (上限 {max_equity_total:.0%}) {'✓' if equity_weight <= max_equity_total + 1e-6 else '✗'}")
    print(f"单一最大持仓: {max_w:.2%} (上限 {max_single:.0%}) {'✓' if max_w <= max_single + 1e-6 else '✗'}")
    print(f"预期收益: {mu @ w_robust_opt:.2%} (下限 {target_return:.0%}) {'✓' if mu @ w_robust_opt >= target_return - 1e-6 else '✗'}")

    print(f"\n--- 对比 ---")
    print(f"经典风险:   {risk_classic:.6f}")
    print(f"稳健风险:   {risk_robust:.6f}")
    print(f"稳健代价:   +{(risk_robust / risk_classic - 1) * 100:.1f}%")

    return stocks, mu, Sigma_hat, asset_class, w_classic_opt, w_robust_opt, risk_classic, risk_robust
```
