## 问题一：粮食品质近红外光谱建模 — LASSO / L1 正则化（农业）

### 数学建模 — 为什么是非光滑优化？

LASSO 问题:

min_w  (1/2n) ‖Xw − y‖₂²  +  λ ‖w‖₁

其中:
- X ∈ R^{n×p}: 光谱数据矩阵, n=80 个样品, p=256 个波长通道
- y ∈ R^n: 蛋白质含量 (%), 范围约 9%-15%
- w ∈ R^p: 回归系数向量
- λ > 0: 正则化参数, 控制稀疏度
- ‖w‖₁ = Σ|w_j|: L1 范数, 非光滑项 (在 w_j=0 处不可微)

**非光滑性分析：**
- 目标函数 = 光滑项 f(w) + 非光滑项 g(w)
- f(w) = (1/2n)‖Xw-y‖₂² 是可微的, 梯度 ∇f(w) = (1/n)Xᵀ(Xw-y)
- g(w) = λ‖w‖₁ 在任何 w_j=0 处不可微 (左导数=-λ, 右导数=+λ)
- 因此标准梯度下降法不适用, 需要使用近端梯度类方法

### 求解方法

**方法 A — ISTA (Iterative Shrinkage-Thresholding Algorithm, 近端梯度下降):**

重复:
  w ← prox_{(λ/L)‖·‖₁}( w − (1/L) ∇f(w) )

其中 L = ‖XᵀX‖₂/n 是 f 的 Lipschitz 常数, prox 为软阈值算子。收敛速率: O(1/k)

**方法 B — FISTA (Fast ISTA, 加速近端梯度):**

在 ISTA 基础上加入 Nesterov 动量加速:
  z ← w + ((t_k-1)/t_{k+1}) (w - w_prev)
  w ← prox_{(λ/L)‖·‖₁}( z − (1/L) ∇f(z) )

收敛速率: O(1/k²), 比 ISTA 快一个量级。

**方法 C — CVXPY 精确求解 (基准):**

直接调用凸优化求解器求得精确最优解, 用于验证手写算法的正确性。

### 求解代码

```python
def solve_lasso_ista(X, y, lam, max_iter=3000, tol=1e-6):
    """ISTA (近端梯度下降) 求解 LASSO。"""
    n, p = X.shape
    L = np.linalg.norm(X.T @ X / n, 2)  # Lipschitz 常数
    w = np.zeros(p)
    history = []

    for k in range(max_iter):
        grad = X.T @ (X @ w - y) / n
        w_new = prox_l1(w - grad / L, lam / L)
        obj = 0.5 / n * np.sum((X @ w_new - y) ** 2) + lam * np.sum(np.abs(w_new))
        history.append(obj)
        if np.max(np.abs(w_new - w)) < tol:
            break
        w = w_new

    return w, history


def solve_lasso_fista(X, y, lam, max_iter=3000, tol=1e-6):
    """FISTA (加速近端梯度) 求解 LASSO。"""
    n, p = X.shape
    L = np.linalg.norm(X.T @ X / n, 2)
    w = np.zeros(p)
    w_prev = w.copy()
    t = 1.0
    history = []

    for k in range(max_iter):
        t_new = (1 + np.sqrt(1 + 4 * t ** 2)) / 2
        z = w + ((t - 1) / t_new) * (w - w_prev)
        grad = X.T @ (X @ z - y) / n
        w_new = prox_l1(z - grad / L, lam / L)
        obj = 0.5 / n * np.sum((X @ w_new - y) ** 2) + lam * np.sum(np.abs(w_new))
        history.append(obj)
        if np.max(np.abs(w_new - w)) < tol:
            break
        w_prev = w
        w = w_new
        t = t_new

    return w, history


def solve_lasso_cvxpy(X, y, lam):
    """CVXPY 精确求解 LASSO (基准)。"""
    n, p = X.shape
    w = cp.Variable(p)
    objective = cp.Minimize(0.5 / n * cp.sum_squares(X @ w - y) + lam * cp.norm1(w))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return w.value, prob.value
```

### 问题执行函数

```python
def problem1_nir_lasso():
    """问题一: 粮食品质近红外光谱建模 (LASSO)"""
    print("=" * 60)
    print("问题一: 粮食品质近红外光谱建模 (LASSO)")
    print("=" * 60)

    X, y, w_true, wavelengths, lam = generate_nir_data()
    n, p = X.shape

    print(f"\n样品数 n={n}, 波长通道数 p={p}")
    print(f"真实非零系数数: {np.sum(w_true != 0)}")
    print(f"正则化参数 λ = {lam:.6f}")

    # --- 方法 A: ISTA ---
    t0 = time.time()
    w_ista, hist_ista = solve_lasso_ista(X, y, lam)
    t_ista = time.time() - t0
    nnz_ista = np.sum(np.abs(w_ista) > 1e-4)

    # --- 方法 B: FISTA ---
    t0 = time.time()
    w_fista, hist_fista = solve_lasso_fista(X, y, lam)
    t_fista = time.time() - t0
    nnz_fista = np.sum(np.abs(w_fista) > 1e-4)

    # --- 方法 C: CVXPY ---
    t0 = time.time()
    w_cvx, obj_cvx = solve_lasso_cvxpy(X, y, lam)
    t_cvx = time.time() - t0
    nnz_cvx = np.sum(np.abs(w_cvx) > 1e-4)

    print(f"\n{'方法':<10} {'目标值':<14} {'非零系数':<10} {'迭代/耗时':<15}")
    print("-" * 50)
    print(f"{'ISTA':<10} {hist_ista[-1]:<14.6f} {nnz_ista:<10} {len(hist_ista)}轮/{t_ista:.3f}s")
    print(f"{'FISTA':<10} {hist_fista[-1]:<14.6f} {nnz_fista:<10} {len(hist_fista)}轮/{t_fista:.3f}s")
    print(f"{'CVXPY':<10} {obj_cvx:<14.6f} {nnz_cvx:<10} {t_cvx:.3f}s")

    return X, y, w_true, wavelengths, lam, w_ista, w_fista, w_cvx, hist_ista, hist_fista
```

---
