## 问题四: 电网负荷模式分解 — 鲁棒PCA (能源)

### 数学建模 — 为什么是非光滑优化？

鲁棒 PCA (Robust Principal Component Analysis):

min_{L,S}  ‖L‖_* + λ ‖S‖₁
s.t.       L + S = M

其中:
- ‖L‖_* = Σ σ_i(L): 核范数 (所有奇异值之和), 促进 L 低秩
- ‖S‖₁ = Σ|S_{ij}|: 元素级 L1 范数, 促进 S 稀疏
- λ > 0: 权衡参数, 理论推荐值 λ = 1/√max(m,d)

非光滑性分析:
- 核范数 ‖L‖_* 在奇异值为零处不可微 (类似 L1 范数在零处不可微, 但作用在奇异值上)
- ‖S‖₁ 在任何 S_{ij}=0 处不可微
- 两个非光滑项的联合优化, 标准梯度法完全无法使用

### 求解方法

**方法 A — 不精确增广 Lagrange 乘子法 (Inexact ALM):**

增广 Lagrange 函数:

L_μ = ‖L‖_* + λ‖S‖₁ + <Y, M-L-S> + (μ/2)‖M-L-S‖_F²

初始化: Y = M/max(‖M‖₂, ‖M‖_∞/λ), μ₀ = 1.25/‖M‖₂

迭代:
- L ← prox_{(1/μ)‖·‖_*}(M - S + Y/μ)    [奇异值软阈值]
- S ← prox_{(λ/μ)‖·‖₁}(M - L + Y/μ)     [元素级软阈值]
- Y ← Y + μ(M - L - S)                    [对偶更新]
- μ ← min(ρ·μ, μ̄)                         [自适应增大惩罚, ρ=1.5]

**方法 B — CVXPY 精确求解 (基准)。**

### 求解代码

```python
def solve_rpca_admm(M, lam, max_iter=1000, tol=1e-7):
    """
    不精确增广 Lagrange 乘子法 (Inexact ALM) 求解鲁棒 PCA。
    参考: Lin, Chen & Ma (2010) — The Augmented Lagrange Multiplier Method
          for Exact Recovery of Corrupted Low-Rank Matrices.
    """
    m, d = M.shape
    norm_M = np.linalg.norm(M, 'fro')
    norm_two = np.linalg.norm(M, 2)          # 谱范数
    norm_inf = np.max(np.abs(M)) / lam
    dual_norm = max(norm_two, norm_inf)

    # 初始化: Y / dual_norm, mu 自适应
    Y = M / dual_norm
    mu = 1.25 / norm_two
    mu_bar = mu * 1e7
    rho_update = 1.5            # mu 每轮增长因子

    L = np.zeros_like(M)
    S = np.zeros_like(M)
    history = []

    for k in range(max_iter):
        # L 步: 奇异值软阈值
        L = prox_nuclear(M - S + Y / mu, 1.0 / mu)
        # S 步: 元素级软阈值
        S = prox_l1(M - L + Y / mu, lam / mu)
        # 对偶更新
        residual = M - L - S
        Y = Y + mu * residual
        # 自适应增大 mu
        mu = min(rho_update * mu, mu_bar)

        obj = np.sum(np.linalg.svd(L, compute_uv=False)) + lam * np.sum(np.abs(S))
        history.append(obj)

        if np.linalg.norm(residual, 'fro') / (norm_M + 1e-10) < tol:
            break

    return L, S, history


def solve_rpca_cvxpy(M, lam):
    """CVXPY 精确求解鲁棒 PCA。"""
    m, d = M.shape
    L = cp.Variable((m, d))
    S = cp.Variable((m, d))
    objective = cp.Minimize(cp.normNuc(L) + lam * cp.norm1(S))
    constraints = [L + S == M]
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS, max_iters=5000)
    return L.value, S.value, prob.value
```

### 问题执行函数

```python
def problem4_power_rpca():
    """问题四: 电网负荷模式分解 (鲁棒PCA)"""
    print("=" * 60)
    print("问题四: 电网负荷模式分解 (鲁棒PCA)")
    print("=" * 60)

    M, L_true, S_true, lam = generate_power_load_data()
    m, d = M.shape

    print(f"\n负荷矩阵: {m}城市 × {d}天")
    print(f"真实低秩部分: rank={np.linalg.matrix_rank(L_true, tol=1e-3)}")
    print(f"真实稀疏部分: {np.sum(S_true != 0)} 个非零元素 ({np.sum(S_true != 0)/(m*d):.1%})")
    print(f"λ = {lam:.4f}")

    # --- ADMM ---
    t0 = time.time()
    L_admm, S_admm, hist_admm = solve_rpca_admm(M, lam)
    t_admm = time.time() - t0
    rank_admm = np.linalg.matrix_rank(L_admm, tol=10)
    nnz_admm = np.sum(np.abs(S_admm) > 10)

    # --- CVXPY ---
    t0 = time.time()
    L_cvx, S_cvx, obj_cvx = solve_rpca_cvxpy(M, lam)
    t_cvx = time.time() - t0
    rank_cvx = np.linalg.matrix_rank(L_cvx, tol=10)
    nnz_cvx = np.sum(np.abs(S_cvx) > 10)

    err_L_admm = np.linalg.norm(L_admm - L_true, 'fro') / np.linalg.norm(L_true, 'fro')
    err_L_cvx = np.linalg.norm(L_cvx - L_true, 'fro') / np.linalg.norm(L_true, 'fro')

    print(f"\n{'方法':<8} {'目标值':<14} {'L秩':<6} {'S非零':<8} {'L误差':<10} {'耗时':<8}")
    print("-" * 54)
    print(f"{'ADMM':<8} {hist_admm[-1]:<14.2f} {rank_admm:<6} {nnz_admm:<8} {err_L_admm:<10.4f} {t_admm:.3f}s")
    print(f"{'CVXPY':<8} {obj_cvx:<14.2f} {rank_cvx:<6} {nnz_cvx:<8} {err_L_cvx:<10.4f} {t_cvx:.3f}s")

    return M, L_true, S_true, L_admm, S_admm, L_cvx, S_cvx, hist_admm
```

---
