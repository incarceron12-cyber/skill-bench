# sdp1 问题二 室内WiFi定位

## 3. 分析与解法

### 【数学建模 — 为什么是 SDP？】

设节点 i 的位置为 p\_i ∈ R²。欧氏距离约束为：‖p\_i − p\_j‖² = d\_ij²

展开后：

p\_iᵀ p\_i + p\_jᵀ p\_j − 2 p\_iᵀ p\_j = d\_ij²

定义 Gram 矩阵 G = P · Pᵀ（其中 P 的第 i 行是 p\_i），则：

G\[i\]\[i\] + G\[j\]\[j\] − 2G\[i\]\[j\] = d\_ij²

约束 G ⪰ 0 即为一个 SDP 问题。

为了能同时恢复绝对坐标（而非仅恢复相对构型），我们构造增广矩阵：

Z ∈ R^{(n+2)×(n+2)}, Z ⪰ 0

其中：

\- 左上 n×n 块 = Gram 矩阵 G = P · Pᵀ

\- 右上 n×2 块 = P（即各节点的坐标！）

\- 右下 2×2 块 = I₂（二维单位矩阵）

通过将锚点的已知坐标直接固定到 Z 中，SDP 求解后即可从 Z 的右上块

读出所有节点（包括未知设备）的位置，无需再做额外的 Procrustes 对齐。

目标函数取为所有距离约束的平方残差之和的最小化：

min Σ\_{(i,j)∈E} (‖p\_i − p\_j‖² − d\_ij²)²

### 求解代码

```python
def problem2_wifi_localization():
    """问题二: 室内Wi-Fi定位"""
    print("\n" + "=" * 60)
    print("问题二: 室内Wi-Fi定位 (传感器定位SDP)")
    print("=" * 60)

    # --- 数据 ---
    anchors, true_positions, edges = generate_wifi_data(
        n_anchors=4, n_devices=8, room_w=20.0, room_h=15.0,
        noise_level=0.3, comm_range=12.0, seed=42
    )
    n_anchors = len(anchors)
    n_devices = len(true_positions)
    n = n_anchors + n_devices

    print(f"\n办公区: 20m × 15m")
    print(f"锚点数: {n_anchors}, 设备数: {n_devices}")
    print(f"距离测量数: {len(edges)}")
    print(f"锚点坐标:")
    for i, a in enumerate(anchors):
        print(f"  路由器{i+1}: ({a[0]:.1f}, {a[1]:.1f})")

    # --- SDP建模 ---
    m = n + 2
    Z = cp.Variable((m, m), symmetric=True)

    constraints = [Z >> 0]

    # 右下角 2×2 = 单位矩阵
    constraints.append(Z[n, n] == 1)
    constraints.append(Z[n + 1, n + 1] == 1)
    constraints.append(Z[n, n + 1] == 0)

    # 锚点位置已知
    for i in range(n_anchors):
        constraints.append(Z[i, n] == anchors[i, 0])
        constraints.append(Z[i, n + 1] == anchors[i, 1])

    # 距离约束

    obj_terms = [ ]

    for (i, j, d_meas) in edges:
        est_dist_sq = Z[i, i] + Z[j, j] - 2 * Z[i, j]
        obj_terms.append(cp.square(est_dist_sq - d_meas ** 2))

    objective = cp.Minimize(cp.sum(obj_terms))

    # --- 求解 ---
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS)

    print(f"\n求解状态: {prob.status}")
    print(f"最优值: {prob.value:.4f}")

    # --- 读取位置 ---
    Z_opt = Z.value
    est_all = Z_opt[:n, n:n + 2]
    est_devices = est_all[n_anchors:]

    errors = np.linalg.norm(est_devices - true_positions, axis=1)

    print(f"\n定位结果:")
    for i in range(n_devices):
        print(f"  设备{i+1}: 真实=({true_positions[i,0]:.1f}, {true_positions[i,1]:.1f}), "
              f"估计=({est_devices[i,0]:.2f}, {est_devices[i,1]:.2f}), "
              f"误差={errors[i]:.2f}m")
    print(f"  平均误差: {np.mean(errors):.2f}m")

    return anchors, true_positions, est_devices, edges, errors
```
