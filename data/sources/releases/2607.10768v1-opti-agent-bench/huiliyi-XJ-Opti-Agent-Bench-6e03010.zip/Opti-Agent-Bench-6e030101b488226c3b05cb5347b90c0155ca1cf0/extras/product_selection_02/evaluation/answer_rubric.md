# 评估 Rubric（10 项）

| No. | 维度 | 检查点 | 通过标准 | 失败标准 | 严重度 |
|:---:|------|--------|----------|----------|:------:|
| 1 | Problem Type | 识别替代效应的组合性 | 明确等效需求受上架集合影响 | 仍按独立 SKU 处理 | Critical |
| 2 | Problem Type | 识别贝叶斯学习主线 | 仍保持 Gamma-Poisson / TS 主线 | 放弃动态学习 | Major |
| 3 | Objective | 季度累计利润目标清楚 | 利润目标与替代效应一致 | 目标函数混乱 | Major |
| 4 | Constraints | 100 选 30 约束完整 | 运营约束无误 | 基本约束缺失 | Critical |
| 5 | Modeling | 等效需求公式处理合理 | 能实现或近似实现 λ_eff 逻辑 | 替代矩阵逻辑严重错误 | Critical |
| 6 | Modeling | 替代矩阵维度与覆盖合理 | 至少正确处理矩阵规模与索引 | 维度错配致大量 SKU 失真 | Critical |
| 7 | Learning | TS / 动态决策真实存在 | 不只是静态排序 | 纯贪心或假 TS | Critical |
| 8 | Code Quality | 代码可运行 | 有端到端可执行实现 | 无代码或 Hello World | Critical |
| 9 | Result Quality | 利润结果与方案质量可信 | 输出与问题规模自洽 | 数值无依据或失真严重 | Major |
| 10 | Evaluation Quality | 能识别评估博弈风险 | 有抗博弈意识 | 完全无安全性思考 | Minor |
