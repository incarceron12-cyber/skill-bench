# 问题六：信贷风控动态授信

原始标题：信贷风控动态授信

【业务背景】
某消费金融公司为信用贷产品管理大量客户。每月初，风控系统会根据客户画像
和近期行为信号，给出额度管理建议。公司希望在利息与手续费收入、坏账风险、
客户留存和审慎经营之间取得长期平衡。

客户信用评分分为 5 档：

  等级0 "优质" (Score ≥ 750): 违约率低于 1%。
  等级1 "良好" (700-749): 违约率约 1-3%。
  等级2 "一般" (650-699): 违约率约 3-8%。
  等级3 "风险" (600-649): 违约率约 8-15%。
  等级4 "高危" (< 600): 违约率高于 15%。

额度使用率分为 3 档：

  等级0 "低使用" (<30%): 客户财务较宽裕，但也可能流失。
  等级1 "中使用" (30-70%): 使用较健康。
  等级2 "高使用" (>70%): 可能存在资金压力或过度依赖信贷。

近期还款行为分为 3 档：

  等级0 "全额准时"
  等级1 "最低额还款"
  等级2 "逾期违约"

不同信用评分等级对应的基础违约率如下：

  信用等级    优质      良好      一般      风险      高危
  违约率      0.005     0.020     0.050     0.120     0.250

不同额度使用率带来的基础利息收入如下，单位为相对经营分值：

  使用率      低使用    中使用    高使用
  利息收入      3.0       8.0      12.0

风控系统每月可以选择以下额度管理措施：

  管理措施      信用评分影响参数    使用率影响参数    客户流失概率    操作成本扣分
  提升额度          +0.3                +0.5              0.02            0.5
  维持现状           0.0                 0.0              0.05            0.0
  降低额度          -0.2                +0.3              0.15            0.3
  冻结账户          -1.0                -2.0              0.60            2.0
  推送分期          +0.1                -0.3              0.03            1.0

信用评分影响参数为正，表示客户关系和还款压力改善后更可能进入更好的信用
分档；为负则表示更可能恶化。使用率影响参数用于描述下月使用率分档的倾向，
并不是额度百分比的直接变化。

当月经营分值由收入、手续费、坏账损失、客户流失成本和操作成本共同构成：

  · 基础利息收入由当前使用率决定。
  · 如果选择提升额度，收入潜力按 1.2 倍计算。
  · 如果选择推送分期，且客户当前为中使用或高使用，额外增加 3.0 分手续费。
  · 最低额还款客户的违约率按基础违约率的 1.5 倍计算，最高不超过 0.50。
  · 逾期违约客户的违约率按基础违约率的 2.5 倍计算，最高不超过 0.80。
  · 坏账损失按 调整后违约率 × 当前使用率对应利息收入 × 3 计算。
  · 客户流失成本按 客户流失概率 × 15.0 计算。
  · 最终还要扣除管理措施对应的操作成本扣分。

如果选择冻结账户，当月不再获得正常收入；经营分值按

  - 坏账损失 × 0.5 - 操作成本扣分

计算，表示冻结账户可以部分止损，但仍存在回收和关系破裂成本。

下月信用评分受额度管理措施和还款行为共同影响。全额准时还款会使信用评分
影响参数额外增加 0.3；逾期违约会使其额外减少 0.5。随后，60% 的权重按
调整后的目标信用分档变化，40% 的权重保留在当前信用分档。

下月使用率分档按以下方式变化：50% 的权重落在管理措施影响后的目标分档，
30% 的权重保留在当前分档，另外两个相邻分档各有 10% 的权重；若超出边界，
则截断在 [0, 2] 区间内。

下月还款行为也有惯性，但会受信用等级和管理措施影响：

  · 如果冻结账户，70% 的权重进入"逾期违约"，30% 的权重进入"最低额还款"。
  · 如果推送分期，"全额准时"、"最低额还款"、"逾期违约"的权重分别为
    0.50、0.35、0.15。
  · 其他措施下，当前还款行为先保留 0.50 的惯性权重。
    - 优质或良好客户额外给"全额准时"0.30、"最低额还款"0.10、
      "逾期违约"0.10。
    - 风险或高危客户额外给"全额准时"0.05、"最低额还款"0.15、
      "逾期违约"0.30。
    - 一般客户额外给"全额准时"0.15、"最低额还款"0.15、
      "逾期违约"0.20。

公司希望制定一套长期月度额度管理规则，使未来多月的经营分值尽可能高。
需要注意，优质低使用客户并不一定适合盲目提额，因为可能只增加资本占用；
高使用客户也不一定适合立即降额或冻结，因为过度收缩额度可能加重还款压力
并诱发更高违约风险。

---

## 评分 Rubric

**PF Validity Score**: TD.1=0.5, TD.2=0.5, TD.3=1.0, TD.4=0.5, Overall=0.625

### Problem Analysis

这是月度信用额度管理问题。决策是提额、维持、降额、冻结或推送分期；状态应包含信用评分、使用率和还款行为。目标是长期经营分值，综合收入、手续费、坏账、流失和操作成本。

主要陷阱是不能简单“优质提额、高危冻结”。提额可能增加收入潜力但也影响风险暴露；降额可能导致流失或还款压力恶化；冻结能止损但会造成关系破裂和回收损失。

### Evaluation Rubric

| No. | Dimension | Checkpoint | Pass Criteria | Fail Criteria | Severity |
|:---:|-----------|------------|---------------|---------------|:--------:|
| 1 | Problem Type Identification | 识别为长期动态风控决策 | 说明本月额度措施会影响下月信用、使用率和还款行为 | 当成单月信用评分分类或静态授信规则 | Critical |
| 2 | Problem Type Identification | 正确识别决策变量 | 每月选择提额、维持、降额、冻结或推送分期 | 把评分、使用率、还款行为当成决策 | Critical |
| 3 | Objective Function Understanding | 正确组合经营分值 | 纳入利息、分期手续费、坏账损失、流失成本和操作成本 | 只最大化利息收入，或只最小化违约率 | Critical |
| 4 | Objective Function Understanding | 正确处理违约率调整 | 根据还款行为对基础违约率做 1.5/2.5 倍调整并设置上限 | 所有客户只用基础违约率，忽略逾期加权 | Major |
| 5 | Constraint Formulation | 正确处理冻结特殊收益 | 冻结时不获得正常收入，按部分止损公式计算 | 把冻结当成零风险零成本，或仍保留正常收入 | Major |
| 6 | Dynamic / Uncertainty Handling | 正确处理信用评分演化 | 管理措施与还款行为共同影响信用分档，并保留 40% 惯性 | 信用分只由当前评分决定，或确定性跳档 | Major |
| 7 | Dynamic / Uncertainty Handling | 正确处理使用率与还款行为演化 | 使用率按 50/30/相邻权重更新；还款行为按措施和信用等级更新 | 忽略使用率分母效应或还款行为惯性 | Major |
| 8 | Solution Approach | 方法适配风险收益动态权衡 | 可用动态规划、策略优化或仿真学习，并说明长期收益-风险权衡 | 给固定规则“好客户提额、坏客户冻结”且无长期验证 | Major |

### Expected Failure Modes

- 优质客户一律提额、高危客户一律冻结。
- 忽略客户流失成本和操作成本。
- 忽略还款行为对违约率和信用演化的影响。
- 把冻结账户当成完全消除坏账风险。

---

# 参考答案

# 问题六解答：信贷风控动态授信

> 来源：`mdp_problems_part2.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def policy_iteration(S, A, P, R, gamma=0.99, max_iter=200):
    pi = np.zeros(S, dtype=int)
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        R_pi = np.array([R[s, pi[s]] for s in range(S)])
        P_pi = np.array([P[s, pi[s], :] for s in range(S)])
        V_new = np.linalg.solve(np.eye(S) - gamma * P_pi, R_pi)
        history.append(np.max(np.abs(V_new - V)))
        V = V_new
        Q = R + gamma * (P @ V)
        pi_new = np.argmax(Q, axis=1)
        if np.array_equal(pi_new, pi):
            break
        pi = pi_new
    return V, pi, history

def q_learning(S, A, P, R, gamma=0.99, alpha=0.05, epsilon=0.15,
               n_episodes=30000, max_steps=300, seed=42):
    rng = np.random.RandomState(seed)
    Q = np.zeros((S, A))
    rewards_history = []
    # 衰减学习率和探索率
    for ep in range(n_episodes):
        s = rng.randint(S)
        total_reward = 0
        lr = alpha / (1 + ep * 0.0001)
        eps = max(0.01, epsilon * (1 - ep / n_episodes))
        for step in range(max_steps):
            if rng.rand() < eps:
                a = rng.randint(A)
            else:
                a = np.argmax(Q[s])
            s_next = rng.choice(S, p=P[s, a])
            r = R[s, a]
            total_reward += (gamma ** step) * r
            Q[s, a] += lr * (r + gamma * np.max(Q[s_next]) - Q[s, a])
            s = s_next
        rewards_history.append(total_reward)
    V = np.max(Q, axis=1)
    pi = np.argmax(Q, axis=1)
    return V, pi, rewards_history
```

## 题目专属实现

```python
def generate_credit_data(seed=42):
    """
    生成信贷风控动态授信的 MDP 数据。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    credit_levels = ["优质(≥750)", "良好(700-749)", "一般(650-699)", "风险(600-649)", "高危(<600)"]
    usage_levels = ["低使用(<30%)", "中使用(30-70%)", "高使用(>70%)"]
    repay_behaviors = ["全额准时", "最低额还款", "逾期违约"]

    n_credit = len(credit_levels)
    n_usage = len(usage_levels)
    n_repay = len(repay_behaviors)
    S = n_credit * n_usage * n_repay  # 45

    action_names = ["提升额度", "维持现状", "降低额度", "冻结账户", "推送分期"]
    A = len(action_names)

    def encode(c, u, r):
        return c * n_usage * n_repay + u * n_repay + r

    def decode(s):
        c = s // (n_usage * n_repay)
        rem = s % (n_usage * n_repay)
        u = rem // n_repay
        r = rem % n_repay
        return c, u, r

    # --- 违约率 (按信用等级) ---
    default_rate = [0.005, 0.02, 0.05, 0.12, 0.25]

    # --- 利息收入 (按使用率) ---
    interest_income = [3.0, 8.0, 12.0]  # 低/中/高使用

    # --- 各动作参数 ---
    # 对信用评分的影响方向 (正=改善, 负=恶化)
    credit_shift = {
        0: 0.3,    # 提额: 轻微改善 (客户满意)
        1: 0.0,    # 维持: 不变
        2: -0.2,   # 降额: 轻微恶化 (客户不满)
        3: -1.0,   # 冻结: 大幅恶化 (关系破裂)
        4: 0.1,    # 分期: 轻微改善 (帮助客户管理)
    }

    # 对使用率的影响
    usage_shift = {
        0: 0.5,    # 提额: 可用额度增加，使用率相对下降但绝对使用可能上升
        1: 0.0,
        2: 0.3,    # 降额: 额度减少，使用率被动上升
        3: -2.0,   # 冻结: 无法使用
        4: -0.3,   # 分期: 引导还款，使用率下降
    }

    # 流失概率
    churn_prob = {0: 0.02, 1: 0.05, 2: 0.15, 3: 0.60, 4: 0.03}

    # 操作成本
    action_cost = [0.5, 0.0, 0.3, 2.0, 1.0]

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        c, u, r = decode(s)
        for a in range(A):
            # --- 奖励 ---
            income = interest_income[u]
            # 提额增加收入潜力
            if a == 0:
                income *= 1.2
            # 分期额外手续费
            fee = 3.0 if a == 4 and u >= 1 else 0
            # 坏账损失
            dr = default_rate[c]
            if r == 2:  # 已逾期客户违约率更高
                dr = min(dr * 2.5, 0.8)
            if r == 1:
                dr = min(dr * 1.5, 0.5)
            bad_debt = dr * interest_income[u] * 3  # 违约时损失约3个月利息的本金
            # 流失成本
            churn_cost = churn_prob[a] * 15.0  # 流失一个客户的长期价值损失

            R[s, a] = income + fee - bad_debt - churn_cost - action_cost[a]

            # 冻结状态的特殊处理: 收入为0
            if a == 3:
                R[s, a] = -bad_debt * 0.5 - action_cost[a]  # 止损但仍有部分回收

            # --- 转移概率 ---
            # 信用评分变化
            c_probs = np.zeros(n_credit)
            shift = credit_shift[a]
            # 还款行为也影响信用
            if r == 0:
                shift += 0.3  # 全额还款改善信用
            elif r == 2:
                shift -= 0.5  # 逾期恶化信用

            target_c = c - shift  # 注意: c越小越好(0=优质)
            c_low = max(0, min(n_credit - 1, int(np.floor(target_c))))
            c_high = max(0, min(n_credit - 1, c_low + 1))
            frac = target_c - np.floor(target_c)
            frac = max(0, min(1, frac))
            c_probs[c_low] += (1 - frac) * 0.6
            c_probs[c_high] += frac * 0.6
            c_probs[c] += 0.4  # 惯性
            c_probs = np.maximum(c_probs, 0)
            c_probs /= c_probs.sum()

            # 使用率变化
            u_probs = np.zeros(n_usage)
            u_shift = usage_shift[a]
            target_u = u + u_shift * 0.3
            u_target_int = max(0, min(n_usage - 1, int(round(target_u))))
            u_probs[u_target_int] = 0.5
            u_probs[u] += 0.3
            # 邻近等级
            for du in [-1, 1]:
                uu = max(0, min(n_usage - 1, u + du))
                u_probs[uu] += 0.1
            u_probs = np.maximum(u_probs, 0)
            u_probs /= u_probs.sum()

            # 还款行为变化
            r_probs = np.zeros(n_repay)
            if a == 3:  # 冻结: 还款行为不再有意义
                r_probs[2] = 0.7  # 大概率进入违约回收
                r_probs[1] = 0.3
            elif a == 4:  # 分期: 改善还款
                r_probs[0] = 0.5
                r_probs[1] = 0.35
                r_probs[2] = 0.15
            else:
                # 惯性 + 信用等级影响
                r_probs[r] = 0.5
                if c <= 1:  # 优质/良好客户倾向良好还款
                    r_probs[0] += 0.3
                    r_probs[1] += 0.1
                    r_probs[2] += 0.1
                elif c >= 3:  # 风险/高危客户倾向恶化
                    r_probs[0] += 0.05
                    r_probs[1] += 0.15
                    r_probs[2] += 0.30
                else:
                    r_probs[0] += 0.15
                    r_probs[1] += 0.15
                    r_probs[2] += 0.20
            r_probs = np.maximum(r_probs, 0)
            r_probs /= r_probs.sum()

            # 联合转移
            for c_next in range(n_credit):
                for u_next in range(n_usage):
                    for r_next in range(n_repay):
                        s_next = encode(c_next, u_next, r_next)
                        P[s, a, s_next] += c_probs[c_next] * u_probs[u_next] * r_probs[r_next]

            P[s, a] /= P[s, a].sum()

    state_names = [f"{credit_levels[c]}|{usage_levels[u]}|{repay_behaviors[r]}"
                   for c in range(n_credit) for u in range(n_usage) for r in range(n_repay)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.96,
        'state_names': state_names, 'action_names': action_names,
        'n_credit': n_credit, 'n_usage': n_usage, 'n_repay': n_repay,
        'credit_levels': credit_levels, 'usage_levels': usage_levels,
        'repay_behaviors': repay_behaviors, 'decode': decode,
    }

def problem6_credit():
    """问题六: 信贷风控动态授信 (PI vs Q-Learning)"""
    print("\n" + "=" * 60)
    print("问题六: 信贷风控动态授信 (金融MDP)")
    print("=" * 60)

    mdp = generate_credit_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_credit']}信用 × {mdp['n_usage']}使用率 × {mdp['n_repay']}还款)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")

    # --- Policy Iteration ---
    V_pi, pi_pi, hist_pi = policy_iteration(S, A, P, R, gamma)
    print(f"\nPolicy Iteration: {len(hist_pi)} 轮收敛")

    # --- Q-Learning ---
    V_ql, pi_ql, ql_rewards = q_learning(S, A, P, R, gamma,
                                          alpha=0.06, epsilon=0.15,
                                          n_episodes=35000, max_steps=200, seed=42)
    policy_match = np.sum(pi_pi == pi_ql)
    print(f"Q-Learning: 35000 episodes")
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")

    # --- 输出策略 ---
    print(f"\n最优授信策略 (PI, 全额准时还款客户):")
    decode = mdp['decode']
    for c in range(mdp['n_credit']):
        print(f"  【{mdp['credit_levels'][c]}】")
        for u in range(mdp['n_usage']):
            s = c * mdp['n_usage'] * mdp['n_repay'] + u * mdp['n_repay'] + 0  # 全额准时
            act_pi = mdp['action_names'][pi_pi[s]]
            act_ql = mdp['action_names'][pi_ql[s]]
            match = "=" if pi_pi[s] == pi_ql[s] else "X"
            print(f"    {mdp['usage_levels'][u]:14s} → PI:{act_pi:6s}  QL:{act_ql:6s}  [{match}]")

    return mdp, V_pi, pi_pi, hist_pi, V_ql, pi_ql, ql_rewards
```
