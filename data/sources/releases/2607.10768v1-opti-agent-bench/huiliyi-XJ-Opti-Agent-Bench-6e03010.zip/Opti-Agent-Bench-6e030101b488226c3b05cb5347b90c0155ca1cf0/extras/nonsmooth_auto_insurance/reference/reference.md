## 问题三：车险理赔风险分层定价 — 分位数回归（金融/保险）

### 数学建模 — 为什么是非光滑优化？

分位数回归 (Quantile Regression):

min_β  Σ_{i=1}^n  ρ_τ(y_i − x_iᵀβ)

其中:
- (x_i, y_i): 第 i 个客户的特征向量和实际理赔金额
- β ∈ R^p: 回归系数
- τ ∈ (0,1): 目标分位数
- ρ_τ(u) = u·(τ − 𝟙{u<0}) 是 "check function" (pinball loss):
    ρ_τ(u) = τ·u     当 u ≥ 0
    ρ_τ(u) = (τ-1)·u 当 u < 0

**非光滑性分析：**
- check function ρ_τ(u) 在 u=0 处不可微: 左导数 = τ-1 < 0, 右导数 = τ > 0
- 当 y_i = x_iᵀβ 时（残差恰好为零），目标函数不可微
- 因此标准梯度下降不适用

### 求解方法

**方法 A — 次梯度法 (Subgradient Method):**

ρ_τ(u) 的次梯度:
  ∂ρ_τ(u)/∂u = τ       若 u > 0
              = τ-1     若 u < 0
              ∈ [τ-1, τ] 若 u = 0

β ← β - α_k · (1/n) Σ (-x_i · g_i), 其中 g_i 是 ρ_τ(residual_i) 的次梯度。步长 α_k = α₀ / √k (衰减步长保证收敛)

**方法 B — LP 重整化 (将分位数回归转化为线性规划):**

引入松弛变量 u_i⁺, u_i⁻ ≥ 0:
  min  τ Σu_i⁺ + (1-τ) Σu_i⁻
  s.t. y_i - x_iᵀβ = u_i⁺ - u_i⁻,  u_i⁺, u_i⁻ ≥ 0

这是标准线性规划, 可用 LP 求解器高效求解。

**方法 C — CVXPY 精确求解 (基准)。**

### 求解代码

```python
def check_loss(u, tau):
    """分位数回归的 check function (pinball loss)。"""
    return u * (tau - (u < 0).astype(float))


def solve_quantile_subgradient(X, y, tau, lr=0.01, max_iter=5000, seed=42):
    """次梯度法求解分位数回归。对特征进行内部标准化以改善收敛。"""
    rng = np.random.RandomState(seed)
    n, p = X.shape

    # 内部标准化 (截距列除外)
    X_scale = X.copy()
    col_std = np.ones(p)
    col_mean = np.zeros(p)
    for j in range(1, p):  # 跳过截距列
        col_mean[j] = X[:, j].mean()
        col_std[j] = X[:, j].std() + 1e-10
        X_scale[:, j] = (X[:, j] - col_mean[j]) / col_std[j]

    beta = np.zeros(p)
    history = []

    for k in range(1, max_iter + 1):
        residuals = y - X_scale @ beta
        # 次梯度
        g = np.where(residuals >= 0, -tau, 1 - tau)
        grad = -X_scale.T @ g / n
        step = lr / np.sqrt(k)
        beta = beta - step * grad

        obj = np.sum(check_loss(y - X_scale @ beta, tau)) / n
        history.append(obj)

    # 恢复到原始尺度
    beta_orig = beta.copy()
    for j in range(1, p):
        beta_orig[j] = beta[j] / col_std[j]
        beta_orig[0] -= beta[j] * col_mean[j] / col_std[j]

    return beta_orig, history


def solve_quantile_lp(X, y, tau):
    """LP 重整化求解分位数回归。"""
    n, p = X.shape
    beta = cp.Variable(p)
    u_pos = cp.Variable(n, nonneg=True)
    u_neg = cp.Variable(n, nonneg=True)

    objective = cp.Minimize((tau * cp.sum(u_pos) + (1 - tau) * cp.sum(u_neg)) / n)
    constraints = [y - X @ beta == u_pos - u_neg]

    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS)
    return beta.value, prob.value


def solve_quantile_cvxpy(X, y, tau):
    """CVXPY 直接求解分位数回归 (基准), 使用 LP 形式。"""
    n, p = X.shape
    beta = cp.Variable(p)
    u_pos = cp.Variable(n, nonneg=True)
    u_neg = cp.Variable(n, nonneg=True)
    objective = cp.Minimize((tau * cp.sum(u_pos) + (1 - tau) * cp.sum(u_neg)) / n)
    constraints = [y - X @ beta == u_pos - u_neg]
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.CLARABEL)
    return beta.value, prob.value
```

### 问题执行函数

```python
def problem3_insurance_quantile():
    """问题三: 车险理赔风险分层定价 (分位数回归)"""
    print("\n" + "=" * 60)
    print("问题三: 车险理赔风险分层定价 (分位数回归)")
    print("=" * 60)

    X, y, feature_names = generate_insurance_data()
    n, p = X.shape

    print(f"\n理赔案例数: {n}, 特征数: {p}")
    print(f"理赔金额统计: 均值={y.mean():.2f}万, 中位数={np.median(y):.2f}万, "
          f"最大={y.max():.2f}万")
    print(f"特征: {feature_names}")

    taus = [0.25, 0.50, 0.75, 0.90, 0.95]
    results = {}

    for tau in taus:
        print(f"\n--- τ = {tau} ---")

        # 次梯度法
        t0 = time.time()
        beta_sg, hist_sg = solve_quantile_subgradient(X, y, tau, lr=0.05, max_iter=3000)
        t_sg = time.time() - t0

        # LP
        t0 = time.time()
        beta_lp, obj_lp = solve_quantile_lp(X, y, tau)
        t_lp = time.time() - t0

        # CVXPY
        t0 = time.time()
        beta_cvx, obj_cvx = solve_quantile_cvxpy(X, y, tau)
        t_cvx = time.time() - t0

        print(f"  次梯度: obj={hist_sg[-1]:.4f}, {len(hist_sg)}轮/{t_sg:.3f}s")
        print(f"  LP改写: obj={obj_lp:.4f}, {t_lp:.3f}s")
        print(f"  CVXPY:  obj={obj_cvx:.4f}, {t_cvx:.3f}s")

        results[tau] = {
            'beta_sg': beta_sg, 'beta_lp': beta_lp, 'beta_cvx': beta_cvx,
            'hist_sg': hist_sg, 'obj_cvx': obj_cvx,
        }

    return X, y, feature_names, taus, results
```

---
