"""
六个非光滑优化业务问题 — 第一部分 (问题一~三)
========================================
问题一: 粮食品质近红外光谱建模 (LASSO / L1 正则化)        — 农业
问题二: 钢板轧制厚度轮廓修复 (Total Variation 去噪)       — 制造
问题三: 车险理赔风险分层定价 (分位数回归)                  — 金融/保险

每道题给出:
  ① 详细业务背景和数学建模
  ② 数据生成代码
  ③ 多种求解方法 (手写一阶算法 vs CVXPY 精确解) 的实现与对比

依赖: pip install numpy cvxpy matplotlib
"""
import numpy as np
import cvxpy as cp
import matplotlib.pyplot as plt
import time
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# ====================================================================
# 通用工具: 近端算子
# ====================================================================

def prox_l1(v, lam):
    """L1 范数的近端算子 (软阈值)。prox_{λ||·||₁}(v) = sign(v) max(|v|-λ, 0)"""
    return np.sign(v) * np.maximum(np.abs(v) - lam, 0)


# ====================================================================
# 问题一: 粮食品质近红外光谱建模 — LASSO / L1 正则化 (农业)
# ====================================================================
#
# 【业务背景】
# 某省级粮食质检中心负责对收储入库的小麦进行品质检测。其中，蛋白质含量
# 是衡量小麦面粉加工性能的核心指标（直接影响面筋强度和面包烘焙品质），
# 传统的凯氏定氮法虽然准确但耗时 2-3 小时且需要消耗化学试剂。
#
# 为了实现"快检快放"，质检中心引进了近红外（NIR）光谱仪。该仪器可以
# 在 30 秒内扫描一份小麦样品，获取 p = 256 个波长通道（范围 900-1700nm，
# 间隔约 3.1nm）上的吸光度值。过去两年积累了 n 份样品的光谱数据，
# 每份样品同时用凯氏定氮法测定了真实蛋白质含量作为标签。
#
# 质检中心希望建立一个**线性回归模型** y = Xw + b，用光谱数据 X 预测
# 蛋白质含量 y。然而：
#   1. 特征维度远大于样本量（p=256 >> n=80），普通最小二乘法严重过拟合。
#   2. 相邻波长通道高度共线性（相关系数 > 0.99），矩阵 XᵀX 严重病态。
#   3. 实际上只有少数特定吸收峰（如 1200nm 附近的 N-H 键二倍频、
#      1450nm 附近的 O-H 键伸缩振动）与蛋白质含量真正相关。
#
# 因此，需要 LASSO (Least Absolute Shrinkage and Selection Operator) 回归：
# 通过 L1 正则化项迫使大部分回归系数精确为零，自动筛选出关键波长。
#
# 【数学建模 — 为什么是非光滑优化？】
#
# LASSO 问题:
#   min_w  (1/2n) ‖Xw − y‖₂²  +  λ ‖w‖₁
#
# 其中:
#   - X ∈ R^{n×p}: 光谱数据矩阵, n=80 个样品, p=256 个波长通道
#   - y ∈ R^n: 蛋白质含量 (%), 范围约 9%-15%
#   - w ∈ R^p: 回归系数向量
#   - λ > 0: 正则化参数, 控制稀疏度
#   - ‖w‖₁ = Σ|w_j|: L1 范数, 非光滑项 (在 w_j=0 处不可微)
#
# 非光滑性分析:
#   - 目标函数 = 光滑项 f(w) + 非光滑项 g(w)
#   - f(w) = (1/2n)‖Xw-y‖₂² 是可微的, 梯度 ∇f(w) = (1/n)Xᵀ(Xw-y)
#   - g(w) = λ‖w‖₁ 在任何 w_j=0 处不可微 (左导数=-λ, 右导数=+λ)
#   - 因此标准梯度下降法不适用, 需要使用近端梯度类方法
#
# 【数据生成参数】
#
# generate_nir_data() 按如下方式构造贴近真实 NIR 光谱的模拟数据:
#
#   光谱矩阵 X:
#   - 波长网格: 256 个等距点, 覆盖 900-1700 nm
#   - 基线: 由 3 阶多项式生成平滑背景 (模拟仪器响应曲线)
#   - 吸收峰: 在 5 个关键波长处叠加高斯吸收峰 (半峰宽 15-30nm)
#     · 1020 nm (淀粉 C-H 键)
#     · 1200 nm (蛋白质 N-H 键二倍频) ← 与蛋白质相关
#     · 1350 nm (脂肪 C-H 键组合频)
#     · 1450 nm (水分 O-H 键) ← 与蛋白质弱相关
#     · 1580 nm (蛋白质 N-H 键一倍频) ← 与蛋白质相关
#   - 噪声: 每个通道叠加 N(0, σ²_noise) 的高斯噪声
#
#   真实系数 w_true:
#   - p=256 维中仅 12 个非零 (分布在 1200nm 和 1580nm 附近)
#   - 非零系数值在 [-1.5, 1.5] 之间随机
#   - 稀疏度 = 12/256 ≈ 4.7%
#
#   蛋白质含量 y:
#   - y = X @ w_true + 截距 + N(0, 0.3²)
#   - 截距 b=12.0 (小麦蛋白质含量的典型均值)
#
#   正则化参数 λ:
#   - λ_max = ‖Xᵀy‖_∞ / n (使所有系数为零的最小 λ)
#   - 推荐 λ = 0.1 × λ_max
#
# 【求解方法】
#
# 方法 A — ISTA (Iterative Shrinkage-Thresholding Algorithm, 近端梯度下降):
#   重复:
#     w ← prox_{(λ/L)‖·‖₁}( w − (1/L) ∇f(w) )
#   其中 L = ‖XᵀX‖₂/n 是 f 的 Lipschitz 常数, prox 为软阈值算子。
#   收敛速率: O(1/k)
#
# 方法 B — FISTA (Fast ISTA, 加速近端梯度):
#   在 ISTA 基础上加入 Nesterov 动量加速:
#     z ← w + ((t_k-1)/t_{k+1}) (w - w_prev)
#     w ← prox_{(λ/L)‖·‖₁}( z − (1/L) ∇f(z) )
#   收敛速率: O(1/k²), 比 ISTA 快一个量级。
#
# 方法 C — CVXPY 精确求解 (基准):
#   直接调用凸优化求解器求得精确最优解, 用于验证手写算法的正确性。
# ====================================================================

def generate_nir_data(n=80, p=256, n_nonzero=12, noise_std=0.3,
                      intercept=12.0, seed=42):
    """
    生成近红外光谱 LASSO 回归数据。

    返回
    ----
    X : (n, p) 光谱矩阵
    y : (n,)   蛋白质含量
    w_true : (p,) 真实稀疏系数
    wavelengths : (p,) 波长网格 (nm)
    lam : float 推荐的正则化参数 λ
    """
    rng = np.random.RandomState(seed)
    wavelengths = np.linspace(900, 1700, p)

    # 吸收峰参数: (中心波长, 半峰宽, 与蛋白质的相关强度)
    peaks = [
        (1020, 25, 0.3),    # 淀粉
        (1200, 20, 1.0),    # 蛋白质 N-H 二倍频
        (1350, 30, 0.2),    # 脂肪
        (1450, 20, 0.5),    # 水分
        (1580, 18, 0.9),    # 蛋白质 N-H 一倍频
    ]

    X = np.zeros((n, p))
    for i in range(n):
        # 基线
        baseline_coeff = rng.randn(4) * 0.1
        baseline = np.polyval(baseline_coeff, (wavelengths - 1300) / 400)
        spectrum = baseline + 0.5

        # 吸收峰
        for center, width, strength in peaks:
            amplitude = rng.uniform(0.2, 1.0) * strength
            spectrum += amplitude * np.exp(-0.5 * ((wavelengths - center) / width) ** 2)

        # 噪声
        spectrum += rng.randn(p) * 0.02
        X[i] = spectrum

    # 标准化
    X = (X - X.mean(axis=0)) / (X.std(axis=0) + 1e-10)

    # 真实稀疏系数: 集中在 1200nm 和 1580nm 附近
    w_true = np.zeros(p)
    peak_indices_1200 = np.where((wavelengths > 1180) & (wavelengths < 1230))[0]
    peak_indices_1580 = np.where((wavelengths > 1560) & (wavelengths < 1600))[0]
    active_indices = np.concatenate([
        rng.choice(peak_indices_1200, min(6, len(peak_indices_1200)), replace=False),
        rng.choice(peak_indices_1580, min(6, len(peak_indices_1580)), replace=False),
    ])
    active_indices = active_indices[:n_nonzero]
    w_true[active_indices] = rng.randn(len(active_indices)) * 0.8

    # 生成 y
    y = X @ w_true + intercept + rng.randn(n) * noise_std

    # 推荐 lambda
    lam_max = np.max(np.abs(X.T @ (y - y.mean()))) / n
    lam = 0.1 * lam_max

    return X, y, w_true, wavelengths, lam


def solve_lasso_ista(X, y, lam, max_iter=3000, tol=1e-6):
    """ISTA (近端梯度下降) 求解 LASSO。"""
    n, p = X.shape
    L = np.linalg.norm(X.T @ X / n, 2)  # Lipschitz 常数
    w = np.zeros(p)
    history = []

    for k in range(max_iter):
        grad = X.T @ (X @ w - y) / n
        w_new = prox_l1(w - grad / L, lam / L)
        obj = 0.5 / n * np.sum((X @ w_new - y) ** 2) + lam * np.sum(np.abs(w_new))
        history.append(obj)
        if np.max(np.abs(w_new - w)) < tol:
            break
        w = w_new

    return w, history


def solve_lasso_fista(X, y, lam, max_iter=3000, tol=1e-6):
    """FISTA (加速近端梯度) 求解 LASSO。"""
    n, p = X.shape
    L = np.linalg.norm(X.T @ X / n, 2)
    w = np.zeros(p)
    w_prev = w.copy()
    t = 1.0
    history = []

    for k in range(max_iter):
        t_new = (1 + np.sqrt(1 + 4 * t ** 2)) / 2
        z = w + ((t - 1) / t_new) * (w - w_prev)
        grad = X.T @ (X @ z - y) / n
        w_new = prox_l1(z - grad / L, lam / L)
        obj = 0.5 / n * np.sum((X @ w_new - y) ** 2) + lam * np.sum(np.abs(w_new))
        history.append(obj)
        if np.max(np.abs(w_new - w)) < tol:
            break
        w_prev = w
        w = w_new
        t = t_new

    return w, history


def solve_lasso_cvxpy(X, y, lam):
    """CVXPY 精确求解 LASSO (基准)。"""
    n, p = X.shape
    w = cp.Variable(p)
    objective = cp.Minimize(0.5 / n * cp.sum_squares(X @ w - y) + lam * cp.norm1(w))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return w.value, prob.value


def problem1_nir_lasso():
    """问题一: 粮食品质近红外光谱建模 (LASSO)"""
    print("=" * 60)
    print("问题一: 粮食品质近红外光谱建模 (LASSO)")
    print("=" * 60)

    X, y, w_true, wavelengths, lam = generate_nir_data()
    n, p = X.shape

    print(f"\n样品数 n={n}, 波长通道数 p={p}")
    print(f"真实非零系数数: {np.sum(w_true != 0)}")
    print(f"正则化参数 λ = {lam:.6f}")

    # --- 方法 A: ISTA ---
    t0 = time.time()
    w_ista, hist_ista = solve_lasso_ista(X, y, lam)
    t_ista = time.time() - t0
    nnz_ista = np.sum(np.abs(w_ista) > 1e-4)

    # --- 方法 B: FISTA ---
    t0 = time.time()
    w_fista, hist_fista = solve_lasso_fista(X, y, lam)
    t_fista = time.time() - t0
    nnz_fista = np.sum(np.abs(w_fista) > 1e-4)

    # --- 方法 C: CVXPY ---
    t0 = time.time()
    w_cvx, obj_cvx = solve_lasso_cvxpy(X, y, lam)
    t_cvx = time.time() - t0
    nnz_cvx = np.sum(np.abs(w_cvx) > 1e-4)

    print(f"\n{'方法':<10} {'目标值':<14} {'非零系数':<10} {'迭代/耗时':<15}")
    print("-" * 50)
    print(f"{'ISTA':<10} {hist_ista[-1]:<14.6f} {nnz_ista:<10} {len(hist_ista)}轮/{t_ista:.3f}s")
    print(f"{'FISTA':<10} {hist_fista[-1]:<14.6f} {nnz_fista:<10} {len(hist_fista)}轮/{t_fista:.3f}s")
    print(f"{'CVXPY':<10} {obj_cvx:<14.6f} {nnz_cvx:<10} {t_cvx:.3f}s")

    return X, y, w_true, wavelengths, lam, w_ista, w_fista, w_cvx, hist_ista, hist_fista


# ====================================================================
# 问题二: 钢板轧制厚度轮廓修复 — Total Variation 去噪 (制造)
# ====================================================================
#
# 【业务背景】
# 某钢铁厂的热轧生产线每天生产数百卷钢板，厚度均匀性是最核心的质量指标。
# 生产线末端安装了一台 X 射线测厚仪，沿钢板宽度方向（横截面）等距布置了
# n = 200 个测量点，每个测量点实时采集钢板厚度值（目标厚度 3.00 mm）。
#
# 然而，测厚仪信号受到多种干扰:
#   1. **高频电磁噪声**: 轧机电机和冷却水泵产生的电磁干扰，导致测量值
#      出现随机毛刺（约 ±0.05 mm 的高斯噪声）。
#   2. **真实厚度阶跃**: 钢板横截面存在若干处厚度突变（"凸度"和"楔形"），
#      这是轧辊磨损和弯曲导致的真实缺陷，需要保留在修复后的信号中。
#
# 质检工程师需要从带噪的测量信号中恢复出真实的厚度轮廓。要求:
#   - 滤除高频噪声毛刺（光滑化）
#   - 但保留厚度的阶跃突变位置和幅度（不能把阶跃也平滑掉）
#
# 传统的移动平均或高斯滤波会把阶跃也模糊掉。**Total Variation (TV) 去噪**
# 恰好适合这个需求: 它在光滑区域去噪的同时保留尖锐边缘。
#
# 【数学建模 — 为什么是非光滑优化？】
#
# 一维 TV 去噪 (Rudin-Osher-Fatemi 模型):
#   min_x  (1/2) ‖x − y‖₂²  +  λ · TV(x)
#
# 其中:
#   - y ∈ R^n: 带噪测量信号 (n=200 个测点)
#   - x ∈ R^n: 待恢复的真实厚度轮廓
#   - TV(x) = Σ_{i=1}^{n-1} |x_{i+1} − x_i|: 全变分 (Total Variation)
#   - λ > 0: 正则化参数 (λ越大越平滑, λ越小越贴近原始数据)
#
# 非光滑性分析:
#   - TV(x) = ‖Dx‖₁, 其中 D ∈ R^{(n-1)×n} 是一阶差分矩阵:
#       D = [[-1,1,0,...], [0,-1,1,...], ...]
#   - ‖Dx‖₁ = Σ|x_{i+1} - x_i| 在任何 x_{i+1} = x_i 处不可微
#   - 目标函数 = 光滑二次项 + 非光滑 L1 项（作用在差分域上）
#
# 【数据生成参数】
#
# generate_steel_thickness_data() 构造以下模拟数据:
#
#   真实厚度轮廓 x_true:
#   - 基线厚度 3.00 mm
#   - 在 4 个位置处加入厚度阶跃 (模拟凸度和楔形缺陷):
#     · 位置 40: +0.08 mm (钢板左侧偏厚)
#     · 位置 90: -0.05 mm (中部凹陷)
#     · 位置 130: +0.06 mm (右侧偏厚)
#     · 位置 170: -0.04 mm (右侧边缘)
#   - 阶跃之间为常数 (分段常数信号)
#
#   带噪信号 y:
#   - y = x_true + N(0, noise_std²), noise_std = 0.04 mm
#
#   正则化参数 λ:
#   - 推荐 λ = 0.08 (经验调参, 平衡去噪与边缘保留)
#
#   差分矩阵 D:
#   - D ∈ R^{199×200}, D[i,i]=-1, D[i,i+1]=1
#
# 【求解方法】
#
# 方法 A — ADMM (Alternating Direction Method of Multipliers):
#   将问题拆分为:
#     min_x  (1/2)‖x-y‖₂² + λ‖z‖₁  s.t. Dx = z
#   ADMM 迭代:
#     x ← (I + ρ DᵀD)⁻¹ (y + ρ Dᵀ(z - u))
#     z ← prox_{(λ/ρ)‖·‖₁}(Dx + u)
#     u ← u + Dx - z
#   其中 ρ > 0 是增广 Lagrange 乘子参数。
#   利用 D 的三对角结构, x 步可用 O(n) 的 Thomas 算法高效求解。
#
# 方法 B — CVXPY 精确求解 (基准)。
# ====================================================================

def generate_steel_thickness_data(n=200, noise_std=0.04, seed=42):
    """
    生成钢板厚度轮廓 TV 去噪数据。

    返回
    ----
    y : (n,) 带噪测量信号
    x_true : (n,) 真实厚度轮廓
    D : (n-1, n) 一阶差分矩阵
    lam : float 推荐的正则化参数
    positions : (n,) 横截面位置坐标 (mm)
    """
    rng = np.random.RandomState(seed)
    positions = np.linspace(0, 1500, n)  # 钢板宽度 1500mm

    # 分段常数的真实厚度轮廓
    x_true = np.ones(n) * 3.00
    x_true[40:90] += 0.08
    x_true[90:130] -= 0.05
    x_true[130:170] += 0.06
    x_true[170:] -= 0.04

    # 带噪信号
    y = x_true + rng.randn(n) * noise_std

    # 差分矩阵
    D = np.zeros((n - 1, n))
    for i in range(n - 1):
        D[i, i] = -1
        D[i, i + 1] = 1

    lam = 0.08

    return y, x_true, D, lam, positions


def solve_tv_admm(y, D, lam, rho=1.0, max_iter=1000, tol=1e-5):
    """ADMM 求解 1D TV 去噪。"""
    n = len(y)
    m = D.shape[0]

    # 预计算: (I + ρ DᵀD)⁻¹ — 利用矩阵较小直接求逆
    DtD = D.T @ D
    M_inv = np.linalg.inv(np.eye(n) + rho * DtD)

    x = y.copy()
    z = np.zeros(m)
    u = np.zeros(m)
    history = []

    for k in range(max_iter):
        # x 步
        x = M_inv @ (y + rho * D.T @ (z - u))
        # z 步
        Dx = D @ x
        z_new = prox_l1(Dx + u, lam / rho)
        # u 步
        u = u + Dx - z_new

        # 目标值
        obj = 0.5 * np.sum((x - y) ** 2) + lam * np.sum(np.abs(D @ x))
        history.append(obj)

        # 收敛检查
        if np.linalg.norm(z_new - z) < tol:
            break
        z = z_new

    return x, history


def solve_tv_cvxpy(y, D, lam):
    """CVXPY 精确求解 TV 去噪。"""
    n = len(y)
    x = cp.Variable(n)
    objective = cp.Minimize(0.5 * cp.sum_squares(x - y) + lam * cp.norm1(D @ x))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return x.value, prob.value


def problem2_steel_tv():
    """问题二: 钢板轧制厚度轮廓修复 (TV去噪)"""
    print("\n" + "=" * 60)
    print("问题二: 钢板轧制厚度轮廓修复 (TV去噪)")
    print("=" * 60)

    y, x_true, D, lam, positions = generate_steel_thickness_data()
    n = len(y)

    print(f"\n测量点数: {n}")
    print(f"噪声标准差: 0.04 mm")
    print(f"正则化参数 λ = {lam}")
    print(f"阶跃位置: 40, 90, 130, 170")

    # --- ADMM ---
    t0 = time.time()
    x_admm, hist_admm = solve_tv_admm(y, D, lam, rho=1.0)
    t_admm = time.time() - t0
    err_admm = np.linalg.norm(x_admm - x_true) / np.linalg.norm(x_true)

    # --- CVXPY ---
    t0 = time.time()
    x_cvx, obj_cvx = solve_tv_cvxpy(y, D, lam)
    t_cvx = time.time() - t0
    err_cvx = np.linalg.norm(x_cvx - x_true) / np.linalg.norm(x_true)

    err_noisy = np.linalg.norm(y - x_true) / np.linalg.norm(x_true)

    print(f"\n{'方法':<10} {'目标值':<14} {'相对误差':<12} {'耗时':<10}")
    print("-" * 46)
    print(f"{'原始噪声':<10} {'—':<14} {err_noisy:<12.6f} {'—':<10}")
    print(f"{'ADMM':<10} {hist_admm[-1]:<14.6f} {err_admm:<12.6f} {t_admm:.3f}s")
    print(f"{'CVXPY':<10} {obj_cvx:<14.6f} {err_cvx:<12.6f} {t_cvx:.3f}s")

    return y, x_true, x_admm, x_cvx, positions, hist_admm


# ====================================================================
# 问题三: 车险理赔风险分层定价 — 分位数回归 (金融/保险)
# ====================================================================
#
# 【业务背景】
# 某财产保险公司正在重新设计其车险产品的定价方案。传统定价基于条件均值
# 预测（OLS回归），即: "平均而言，这类客户预计赔付多少"。但保险业的核心
# 风险在于**尾部**——理赔金额的分布通常严重右偏（大多数理赔金额较小，
# 但少数严重事故可能赔付数十万）。
#
# 精算部门需要针对同一客户特征，同时估计理赔金额分布的多个**分位数**:
#   - 25% 分位数 (Q25): 乐观情景下的理赔下界
#   - 50% 分位数 (Q50): 中位数预测（比均值更稳健）
#   - 75% 分位数 (Q75): 中等不利情景
#   - 90% 分位数 (Q90): 极端不利情景 → 用于确定保费上限
#   - 95% 分位数 (Q95): 压力测试情景 → 用于确定再保险分出点
#
# 客户特征包括 p=6 个变量:
#   x₁: 车龄 (年)                — 老车出险率更高
#   x₂: 驾驶员年龄 (岁)          — 年轻和年老驾驶员风险更高
#   x₃: 年行驶里程 (万公里)       — 里程越长风险越大
#   x₄: 历史出险次数 (次)         — 出险记录是强预测因子
#   x₅: 车辆价值 (万元)           — 车价越高, 潜在赔付越大
#   x₆: 是否新能源车 (0/1)        — 新能源车维修成本更高
#
# 【数学建模 — 为什么是非光滑优化？】
#
# 分位数回归 (Quantile Regression):
#   min_β  Σ_{i=1}^n  ρ_τ(y_i − x_iᵀβ)
#
# 其中:
#   - (x_i, y_i): 第 i 个客户的特征向量和实际理赔金额
#   - β ∈ R^p: 回归系数
#   - τ ∈ (0,1): 目标分位数
#   - ρ_τ(u) = u·(τ − 𝟙{u<0}) 是 "check function" (pinball loss):
#       ρ_τ(u) = τ·u     当 u ≥ 0
#       ρ_τ(u) = (τ-1)·u 当 u < 0
#
# 非光滑性分析:
#   - check function ρ_τ(u) 在 u=0 处不可微:
#     左导数 = τ-1 < 0, 右导数 = τ > 0
#   - 当 y_i = x_iᵀβ 时（残差恰好为零），目标函数不可微
#   - 因此标准梯度下降不适用
#
# 【数据生成参数】
#
# generate_insurance_data() 构造如下模拟数据 (n=500 个历史理赔案例):
#
#   特征 X:
#   - x₁ ~ Uniform(1, 15) 车龄
#   - x₂ ~ Normal(38, 12²) 驾驶员年龄, 截断到 [18, 75]
#   - x₃ ~ Exponential(2.5) 年行驶里程 (万公里)
#   - x₄ ~ Poisson(1.2) 历史出险次数
#   - x₅ ~ LogNormal(2.8, 0.6²) 车辆价值 (万元)
#   - x₆ ~ Bernoulli(0.25) 是否新能源
#
#   理赔金额 y (万元):
#   - 条件分布: y|x ~ LogNormal(μ(x), σ(x)²)
#   - μ(x) = β₀ + β₁·x₁ + β₂·|x₂-35| + β₃·x₃ + β₄·x₄ + β₅·log(x₅) + β₆·x₆
#   - σ(x) = 0.5 + 0.1·x₄  (出险多的客户, 理赔金额方差也更大)
#   - 真实 β = [0.5, 0.04, 0.02, 0.15, 0.30, 0.20, 0.25]
#
# 【求解方法】
#
# 方法 A — 次梯度法 (Subgradient Method):
#   ρ_τ(u) 的次梯度:
#     ∂ρ_τ(u)/∂u = τ       若 u > 0
#                 = τ-1     若 u < 0
#                 ∈ [τ-1, τ] 若 u = 0
#   β ← β - α_k · (1/n) Σ (-x_i · g_i), 其中 g_i 是 ρ_τ(residual_i) 的次梯度
#   步长 α_k = α₀ / √k (衰减步长保证收敛)
#
# 方法 B — LP 重整化 (将分位数回归转化为线性规划):
#   引入松弛变量 u_i⁺, u_i⁻ ≥ 0:
#     min  τ Σu_i⁺ + (1-τ) Σu_i⁻
#     s.t. y_i - x_iᵀβ = u_i⁺ - u_i⁻,  u_i⁺, u_i⁻ ≥ 0
#   这是标准线性规划, 可用 LP 求解器高效求解。
#
# 方法 C — CVXPY 精确求解 (基准)。
# ====================================================================

def generate_insurance_data(n=500, seed=42):
    """
    生成车险理赔分位数回归数据。

    返回
    ----
    X : (n, p) 客户特征矩阵 (含截距列)
    y : (n,)   理赔金额 (万元)
    feature_names : list 特征名称
    """
    rng = np.random.RandomState(seed)

    # 特征
    x1 = rng.uniform(1, 15, n)                                    # 车龄
    x2 = np.clip(rng.normal(38, 12, n), 18, 75)                   # 驾驶员年龄
    x3 = rng.exponential(2.5, n)                                   # 年行驶里程
    x4 = rng.poisson(1.2, n).astype(float)                        # 历史出险
    x5 = np.exp(rng.normal(2.8, 0.6, n))                          # 车辆价值
    x6 = rng.binomial(1, 0.25, n).astype(float)                   # 新能源

    features = np.column_stack([x1, x2, x3, x4, x5, x6])
    feature_names = ["车龄", "驾龄", "年里程", "出险次数", "车价", "新能源"]

    # 理赔金额 (对数正态, 单位: 万元, 控制在合理范围)
    beta_true = np.array([0.02, 0.01, 0.05, 0.15, 0.08, 0.10])
    mu = 0.5 + features @ beta_true
    mu += 0.01 * np.abs(x2 - 35)  # 年龄偏离35的非线性效应
    mu = np.clip(mu, 0.1, 4.0)  # 控制 log 均值范围
    sigma = 0.3 + 0.05 * x4
    sigma = np.clip(sigma, 0.2, 1.0)
    y = np.exp(rng.normal(mu, sigma))
    y = np.clip(y, 0.1, 200)  # 截断极端值: 理赔 0.1-200 万元

    # 加截距列
    X = np.column_stack([np.ones(n), features])
    feature_names = ["截距"] + feature_names

    return X, y, feature_names


def check_loss(u, tau):
    """分位数回归的 check function (pinball loss)。"""
    return u * (tau - (u < 0).astype(float))


def solve_quantile_subgradient(X, y, tau, lr=0.01, max_iter=5000, seed=42):
    """次梯度法求解分位数回归。对特征进行内部标准化以改善收敛。"""
    rng = np.random.RandomState(seed)
    n, p = X.shape

    # 内部标准化 (截距列除外)
    X_scale = X.copy()
    col_std = np.ones(p)
    col_mean = np.zeros(p)
    for j in range(1, p):  # 跳过截距列
        col_mean[j] = X[:, j].mean()
        col_std[j] = X[:, j].std() + 1e-10
        X_scale[:, j] = (X[:, j] - col_mean[j]) / col_std[j]

    beta = np.zeros(p)
    history = []

    for k in range(1, max_iter + 1):
        residuals = y - X_scale @ beta
        # 次梯度
        g = np.where(residuals >= 0, -tau, 1 - tau)
        grad = -X_scale.T @ g / n
        step = lr / np.sqrt(k)
        beta = beta - step * grad

        obj = np.sum(check_loss(y - X_scale @ beta, tau)) / n
        history.append(obj)

    # 恢复到原始尺度
    beta_orig = beta.copy()
    for j in range(1, p):
        beta_orig[j] = beta[j] / col_std[j]
        beta_orig[0] -= beta[j] * col_mean[j] / col_std[j]

    return beta_orig, history


def solve_quantile_lp(X, y, tau):
    """LP 重整化求解分位数回归。"""
    n, p = X.shape
    beta = cp.Variable(p)
    u_pos = cp.Variable(n, nonneg=True)
    u_neg = cp.Variable(n, nonneg=True)

    objective = cp.Minimize((tau * cp.sum(u_pos) + (1 - tau) * cp.sum(u_neg)) / n)
    constraints = [y - X @ beta == u_pos - u_neg]

    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS)
    return beta.value, prob.value


def solve_quantile_cvxpy(X, y, tau):
    """CVXPY 直接求解分位数回归 (基准), 使用 LP 形式。"""
    n, p = X.shape
    beta = cp.Variable(p)
    u_pos = cp.Variable(n, nonneg=True)
    u_neg = cp.Variable(n, nonneg=True)
    objective = cp.Minimize((tau * cp.sum(u_pos) + (1 - tau) * cp.sum(u_neg)) / n)
    constraints = [y - X @ beta == u_pos - u_neg]
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.CLARABEL)
    return beta.value, prob.value


def problem3_insurance_quantile():
    """问题三: 车险理赔风险分层定价 (分位数回归)"""
    print("\n" + "=" * 60)
    print("问题三: 车险理赔风险分层定价 (分位数回归)")
    print("=" * 60)

    X, y, feature_names = generate_insurance_data()
    n, p = X.shape

    print(f"\n理赔案例数: {n}, 特征数: {p}")
    print(f"理赔金额统计: 均值={y.mean():.2f}万, 中位数={np.median(y):.2f}万, "
          f"最大={y.max():.2f}万")
    print(f"特征: {feature_names}")

    taus = [0.25, 0.50, 0.75, 0.90, 0.95]
    results = {}

    for tau in taus:
        print(f"\n--- τ = {tau} ---")

        # 次梯度法
        t0 = time.time()
        beta_sg, hist_sg = solve_quantile_subgradient(X, y, tau, lr=0.05, max_iter=3000)
        t_sg = time.time() - t0

        # LP
        t0 = time.time()
        beta_lp, obj_lp = solve_quantile_lp(X, y, tau)
        t_lp = time.time() - t0

        # CVXPY
        t0 = time.time()
        beta_cvx, obj_cvx = solve_quantile_cvxpy(X, y, tau)
        t_cvx = time.time() - t0

        print(f"  次梯度: obj={hist_sg[-1]:.4f}, {len(hist_sg)}轮/{t_sg:.3f}s")
        print(f"  LP改写: obj={obj_lp:.4f}, {t_lp:.3f}s")
        print(f"  CVXPY:  obj={obj_cvx:.4f}, {t_cvx:.3f}s")

        results[tau] = {
            'beta_sg': beta_sg, 'beta_lp': beta_lp, 'beta_cvx': beta_cvx,
            'hist_sg': hist_sg, 'obj_cvx': obj_cvx,
        }

    return X, y, feature_names, taus, results


# ====================================================================
# 可视化
# ====================================================================

def visualize_part1(result1, result2, result3):
    """绘制前三个问题的结果"""
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))

    # === 问题一: LASSO ===
    X, y, w_true, wl, lam, w_ista, w_fista, w_cvx, hist_ista, hist_fista = result1

    # 上: 系数对比
    ax = axes[0, 0]
    ax.stem(wl, w_true, linefmt='g-', markerfmt='go', basefmt='g-', label='True')
    ax.plot(wl, w_cvx, 'r.', markersize=3, alpha=0.7, label='CVXPY')
    ax.plot(wl, w_fista, 'bx', markersize=3, alpha=0.5, label='FISTA')
    ax.set_xlabel('Wavelength (nm)')
    ax.set_ylabel('Coefficient')
    ax.set_title('P1: LASSO Coefficients (NIR)', fontsize=10)
    ax.legend(fontsize=7)
    ax.grid(True, alpha=0.3)

    # 下: 收敛曲线
    ax = axes[1, 0]
    ax.semilogy(hist_ista, color='#FF6B6B', linewidth=1.5, label=f'ISTA ({len(hist_ista)} iters)')
    ax.semilogy(hist_fista, color='#4ECDC4', linewidth=1.5, label=f'FISTA ({len(hist_fista)} iters)')
    ax.axhline(y=hist_fista[-1], color='gray', linestyle='--', alpha=0.5, label='Optimal')
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Objective')
    ax.set_title('P1: ISTA vs FISTA Convergence', fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # === 问题二: TV 去噪 ===
    y_noisy, x_true, x_admm, x_cvx_tv, positions, hist_admm = result2

    # 上: 信号对比
    ax = axes[0, 1]
    ax.plot(positions, y_noisy, 'gray', linewidth=0.5, alpha=0.5, label='Noisy')
    ax.plot(positions, x_true, 'g-', linewidth=2, label='True')
    ax.plot(positions, x_admm, 'r--', linewidth=1.5, label='ADMM')
    ax.plot(positions, x_cvx_tv, 'b:', linewidth=1.5, label='CVXPY')
    ax.set_xlabel('Position (mm)')
    ax.set_ylabel('Thickness (mm)')
    ax.set_title('P2: Steel Thickness TV Denoising', fontsize=10)
    ax.legend(fontsize=7)
    ax.grid(True, alpha=0.3)

    # 下: ADMM 收敛
    ax = axes[1, 1]
    ax.semilogy(hist_admm, color='#FF6B6B', linewidth=1.5)
    ax.set_xlabel('ADMM Iteration')
    ax.set_ylabel('Objective')
    ax.set_title(f'P2: ADMM Convergence ({len(hist_admm)} iters)', fontsize=10)
    ax.grid(True, alpha=0.3)

    # === 问题三: 分位数回归 ===
    X_ins, y_ins, fnames, taus, qr_results = result3

    # 上: 各分位数的系数热力图
    ax = axes[0, 2]
    beta_matrix = np.array([qr_results[tau]['beta_cvx'] for tau in taus])
    im = ax.imshow(beta_matrix[:, 1:], cmap='RdBu_r', aspect='auto')  # 去掉截距
    ax.set_yticks(range(len(taus)))
    ax.set_yticklabels([f'τ={t}' for t in taus], fontsize=8)
    ax.set_xticks(range(len(fnames) - 1))
    ax.set_xticklabels(fnames[1:], fontsize=7, rotation=20)
    ax.set_title('P3: Quantile Regression Coefficients', fontsize=10)
    plt.colorbar(im, ax=ax, shrink=0.8)

    # 下: 次梯度收敛 (τ=0.5 和 τ=0.95)
    ax = axes[1, 2]
    for tau, color, ls in [(0.50, '#4ECDC4', '-'), (0.95, '#FF6B6B', '--')]:
        hist = qr_results[tau]['hist_sg']
        ax.plot(hist, color=color, linewidth=1.5, linestyle=ls, label=f'τ={tau}')
        ax.axhline(y=qr_results[tau]['obj_cvx'], color=color, linestyle=':', alpha=0.4)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Objective')
    ax.set_title('P3: Subgradient Convergence', fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    out_path = 'nonsmooth_part1_results.png'
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"\n可视化已保存: {out_path}")
    plt.close()


# ====================================================================
# 主函数
# ====================================================================

if __name__ == "__main__":
    print()
    print("###############################################################")
    print("#   六个非光滑优化业务问题 — 第一部分 (农业·制造·保险)           #")
    print("###############################################################")

    r1 = problem1_nir_lasso()
    r2 = problem2_steel_tv()
    r3 = problem3_insurance_quantile()

    visualize_part1(r1, r2, r3)

    print("\n" + "=" * 60)
    print("第一部分总结")
    print("=" * 60)
    print("""
问题             | 非光滑项                | 近端算子/改写策略             | 求解方法
----------------|------------------------|-----------------------------|-----------------------
粮食NIR光谱(LASSO)| λ‖w‖₁                  | 软阈值 sign(v)max(|v|-λ,0) | ISTA, FISTA, CVXPY
钢板厚度(TV去噪)  | λ‖Dx‖₁ (差分域L1)       | ADMM 变量分裂               | ADMM, CVXPY
车险定价(分位数)   | Σρ_τ(y_i-x_iᵀβ) (check)| 次梯度 / LP改写              | Subgradient, LP, CVXPY
""")
