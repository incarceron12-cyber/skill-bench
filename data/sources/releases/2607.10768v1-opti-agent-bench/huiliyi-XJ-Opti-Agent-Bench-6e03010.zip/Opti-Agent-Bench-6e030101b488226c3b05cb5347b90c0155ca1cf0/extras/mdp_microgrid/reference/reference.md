# 问题四解答：微电网储能调度

> 来源：`mdp_problems_part2.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history

def q_learning(S, A, P, R, gamma=0.99, alpha=0.05, epsilon=0.15,
               n_episodes=30000, max_steps=300, seed=42):
    rng = np.random.RandomState(seed)
    Q = np.zeros((S, A))
    rewards_history = []
    # 衰减学习率和探索率
    for ep in range(n_episodes):
        s = rng.randint(S)
        total_reward = 0
        lr = alpha / (1 + ep * 0.0001)
        eps = max(0.01, epsilon * (1 - ep / n_episodes))
        for step in range(max_steps):
            if rng.rand() < eps:
                a = rng.randint(A)
            else:
                a = np.argmax(Q[s])
            s_next = rng.choice(S, p=P[s, a])
            r = R[s, a]
            total_reward += (gamma ** step) * r
            Q[s, a] += lr * (r + gamma * np.max(Q[s_next]) - Q[s, a])
            s = s_next
        rewards_history.append(total_reward)
    V = np.max(Q, axis=1)
    pi = np.argmax(Q, axis=1)
    return V, pi, rewards_history
```

## 题目专属实现

```python
def generate_microgrid_data(seed=42):
    """
    生成微电网储能调度的 MDP 数据。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    battery_levels = ["空(0-20%)", "低(20-40%)", "中(40-60%)", "高(60-80%)", "满(80-100%)"]
    time_periods = ["谷时(23-7)", "平时(7-11)", "峰时(11-15)", "平时(15-23)"]
    weather_types = ["晴天", "多云", "阴雨"]

    n_bat = len(battery_levels)
    n_time = len(time_periods)
    n_weather = len(weather_types)
    S = n_bat * n_time * n_weather  # 60

    action_names = ["大网充电", "存储光伏", "放电自用", "放电售网", "不操作"]
    A = len(action_names)

    def encode(bat, t, w):
        return bat * n_time * n_weather + t * n_weather + w

    def decode(s):
        bat = s // (n_time * n_weather)
        rem = s % (n_time * n_weather)
        t = rem // n_weather
        w = rem % n_weather
        return bat, t, w

    # --- 电价 ---
    elec_price = [0.3, 0.6, 1.0, 0.6]  # 谷/平/峰/平

    # --- 光伏发电能力 (占电池容量的比例/时段) ---
    # 受天气和时段影响
    pv_output = np.array([
        # 晴天  多云  阴雨
        [0.05, 0.02, 0.01],   # 谷时 (夜间，几乎无光伏)
        [0.30, 0.18, 0.06],   # 平时(早) (上午)
        [0.45, 0.27, 0.09],   # 峰时 (中午，光伏最强)
        [0.20, 0.12, 0.04],   # 平时(晚) (下午至傍晚)
    ])

    # --- 园区负荷 (占电池容量比例/时段) ---
    load = [0.10, 0.25, 0.30, 0.25]

    # --- 电池损耗成本 (每次充放电操作的折旧) ---
    battery_degrad_cost = 1.5

    # --- 天气转移 ---
    weather_trans = np.array([
        [0.65, 0.25, 0.10],
        [0.25, 0.50, 0.25],
        [0.10, 0.30, 0.60],
    ])

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        bat, t, w = decode(s)
        price = elec_price[t]
        pv = pv_output[t, w]

        for a in range(A):
            reward = 0.0
            bat_change = 0

            if a == 0:  # 大网充电
                bat_change = 1
                reward = -price * 20 - battery_degrad_cost  # 购电费 + 折旧
            elif a == 1:  # 存储光伏
                # 光伏发电量转化为电池等级变化
                if pv >= 0.20:
                    bat_change = 1
                else:
                    bat_change = 0
                reward = -battery_degrad_cost * 0.5  # 轻微折旧
            elif a == 2:  # 放电自用 (替代从大网购电)
                bat_change = -1
                reward = price * 18 - battery_degrad_cost  # 节省的电费 - 折旧
            elif a == 3:  # 放电售网
                bat_change = -1
                reward = price * 15 - battery_degrad_cost  # 售电收入 - 折旧 (售电价低于购电价)
            elif a == 4:  # 不操作
                bat_change = 0
                reward = 0.0

            # 电量约束
            bat_new = max(0, min(n_bat - 1, bat + bat_change))

            # 特殊情况: 电量不足放电 或 电量已满充电
            if a in [2, 3] and bat == 0:  # 空电池不能放电
                bat_new = 0
                reward = -2.0  # 罚款 (无效操作)
            if a in [0, 1] and bat == n_bat - 1:  # 满电池不能充电
                bat_new = n_bat - 1
                reward = -1.0

            # 时段循环 + 天气转移
            t_next = (t + 1) % n_time

            for w_next in range(n_weather):
                pw = weather_trans[w, w_next]
                # 电池电量有随机性 (模拟负荷波动)
                for bat_delta in [-1, 0, 1]:
                    if bat_delta == 0:
                        p_delta = 0.6
                    elif bat_delta == -1:
                        p_delta = 0.25 if t in [1, 2, 3] else 0.1  # 白天负荷消耗更大
                    else:
                        p_delta = 0.15 if t in [1, 2] and w == 0 else 0.05  # 晴天光伏补充
                    bat_final = max(0, min(n_bat - 1, bat_new + bat_delta))
                    s_next = encode(bat_final, t_next, w_next)
                    P[s, a, s_next] += pw * p_delta

            R[s, a] = reward

            # 归一化
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

    state_names = [f"{battery_levels[b]}|{time_periods[t]}|{weather_types[w]}"
                   for b in range(n_bat) for t in range(n_time) for w in range(n_weather)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.99,
        'state_names': state_names, 'action_names': action_names,
        'n_bat': n_bat, 'n_time': n_time, 'n_weather': n_weather,
        'battery_levels': battery_levels, 'time_periods': time_periods,
        'weather_types': weather_types, 'decode': decode,
        'elec_price': elec_price,
    }

def problem4_microgrid():
    """问题四: 微电网储能调度 (Q-Learning vs VI)"""
    print("=" * 60)
    print("问题四: 微电网储能调度 (能源MDP)")
    print("=" * 60)

    mdp = generate_microgrid_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_bat']}电量 × {mdp['n_time']}时段 × {mdp['n_weather']}天气)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")

    # --- Value Iteration (基准) ---
    V_vi, pi_vi, hist_vi = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration: {len(hist_vi)} 轮收敛")

    # --- Q-Learning ---
    V_ql, pi_ql, ql_rewards = q_learning(S, A, P, R, gamma,
                                          alpha=0.08, epsilon=0.2,
                                          n_episodes=40000, max_steps=200, seed=42)
    policy_match = np.sum(pi_vi == pi_ql)
    print(f"Q-Learning: 40000 episodes 训练完成")
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")
    print(f"值函数平均偏差: {np.mean(np.abs(V_vi - V_ql)):.2f}")

    # --- 输出关键策略 ---
    print(f"\n最优调度策略 (VI, 晴天):")
    decode = mdp['decode']
    for t in range(mdp['n_time']):
        print(f"  【{mdp['time_periods'][t]}】电价={mdp['elec_price'][t]}元/kWh")
        for bat in range(mdp['n_bat']):
            s = bat * mdp['n_time'] * mdp['n_weather'] + t * mdp['n_weather'] + 0
            act = mdp['action_names'][pi_vi[s]]
            print(f"    {mdp['battery_levels'][bat]:12s} → {act:8s}")

    return mdp, V_vi, pi_vi, hist_vi, V_ql, pi_ql, ql_rewards
```
