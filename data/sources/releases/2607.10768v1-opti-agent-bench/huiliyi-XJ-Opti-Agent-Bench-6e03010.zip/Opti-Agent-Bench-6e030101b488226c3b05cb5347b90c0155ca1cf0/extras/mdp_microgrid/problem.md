# 问题四：微电网储能调度

原始标题：微电网储能调度

【业务背景】
某工业园区建设了一套分布式光伏-储能微电网系统，包括楼顶光伏板
（峰值功率 500kW）和一组锂电池储能系统（容量 1000kWh）。园区与市电
大网相连，可以购电，也可以将部分余电上网。能源管理员需要在每个运营
时段决定电池如何充放电，以降低长期电费、提高光伏消纳，并控制电池损耗。

电池电量按 5 档记录：

  等级0 "空" (0-20%)
  等级1 "低" (20-40%)
  等级2 "中" (40-60%)
  等级3 "高" (60-80%)
  等级4 "满" (80-100%)

一天按 4 个运营时段循环：

  时段0 "谷时(23-7)": 电价 0.3 元/kWh
  时段1 "平时(7-11)": 电价 0.6 元/kWh
  时段2 "峰时(11-15)": 电价 1.0 元/kWh
  时段3 "平时(15-23)": 电价 0.6 元/kWh

天气分为晴天、多云、阴雨。不同天气和时段下，光伏发电能力约占电池容量
的比例如下：

  时段              晴天    多云    阴雨
  谷时(23-7)        0.05    0.02    0.01
  平时(7-11)        0.30    0.18    0.06
  峰时(11-15)       0.45    0.27    0.09
  平时(15-23)       0.20    0.12    0.04

园区负荷也随时段变化，按电池容量比例估计如下：

  谷时(23-7)    平时(7-11)    峰时(11-15)    平时(15-23)
     0.10          0.25           0.30            0.25

天气在相邻时段之间有一定延续性，历史切换统计如下：

  当前天气    晴天    多云    阴雨
  晴天        0.65    0.25    0.10
  多云        0.25    0.50    0.25
  阴雨        0.10    0.30    0.60

能源管理员每个时段可以选择以下电池操作。表中的收益和成本为相对经营分值，
用于统一表示购电成本、售电收益、自用节省和电池寿命折旧。

  操作方式       电量直接变化       当期经营分值
  大网充电       +1 档              - 当前电价 × 20 - 1.5
  存储光伏       光伏比例≥0.20 时 +1 档，否则 0 档    -0.75
  放电自用       -1 档              当前电价 × 18 - 1.5
  放电售网       -1 档              当前电价 × 15 - 1.5
  不操作          0 档               0.0

如果电池为空却选择放电自用或放电售网，该操作无效，并产生 -2.0 分的运行
罚分。如果电池已满却继续大网充电或存储光伏，该操作无效，并产生 -1.0 分
的运行罚分。

完成本时段操作后，时间进入下一个运营时段；从时段3之后回到时段0。电池
最终电量还会受到负荷波动和光伏出力波动影响。以操作后的电量为基础，电量
额外变化的相对权重如下，最后按可行电量档位归一化：

  · 额外变化 0 档的权重为 0.60。
  · 白天和平时晚间（时段1、2、3）额外消耗 1 档的权重为 0.25，谷时为 0.10。
  · 晴天的白天时段（时段1、2）额外增加 1 档的权重为 0.15，其他情形为 0.05。

电量最终截断在 [0, 4] 区间内。

园区希望制定一套长期电池运营规则，使未来多个时段的净经营分值尽可能高。
需要注意，谷时电价低并不意味着一定要充满；如果次日上午是晴天，过满的
电池可能无法吸收光伏。峰时电价高也不意味着一定要售电，因为后续园区负荷
可能需要电池自用来减少购电。

---

## 评分 Rubric

**PF Validity Score**: TD.1=0.5, TD.2=0.5, TD.3=1.0, TD.4=0.5, Overall=0.625

### Problem Analysis

这是分时段电池充放电运营问题。决策是大网充电、存储光伏、放电自用、放电售网或不操作；状态应包含电量档位、时段和天气。目标是长期净经营分值，综合购电、售电、自用节省和电池折旧。

主要陷阱是不能简单套“谷时充电、峰时放电”。光伏出力、后续负荷、电池容量边界和随机电量变化会让局部套利规则失效。

### Evaluation Rubric

| No. | Dimension | Checkpoint | Pass Criteria | Fail Criteria | Severity |
|:---:|-----------|------------|---------------|---------------|:--------:|
| 1 | Problem Type Identification | 识别为多时段随机储能控制 | 说明当前充放电影响未来电量、时段和天气下的收益机会 | 当成单时段电价套利或确定性调度 | Critical |
| 2 | Problem Type Identification | 正确识别决策变量 | 每时段选择五类电池操作之一 | 把电价、天气或负荷当成可控变量 | Critical |
| 3 | Objective Function Understanding | 正确计算操作经营分值 | 区分大网充电、存储光伏、放电自用、放电售网和不操作的收益/成本公式 | 只按电价差计算，忽略折旧和无效操作罚分 | Critical |
| 4 | Constraint Formulation | 正确处理电量边界 | 电量档位截断在 0 到 4，并处理空电池放电、满电池充电罚分 | 允许电量越界或无效操作无惩罚 | Major |
| 5 | Data Usage | 正确使用光伏与负荷数据 | 使用天气-时段光伏表和时段负荷信息影响未来电量 | 忽略光伏出力，或只看电价 | Major |
| 6 | Dynamic / Uncertainty Handling | 正确处理天气切换 | 使用给定天气转移统计，不能固定天气或独立重采样 | 天气不进入未来状态或收益判断 | Major |
| 7 | Dynamic / Uncertainty Handling | 正确处理额外电量波动 | 使用负荷消耗和晴天光伏补充的额外权重，并归一化 | 电量只按操作变化，不考虑随机波动 | Major |
| 8 | Solution Approach | 方法适配周期性动态决策 | 可用动态规划、滚动策略优化或强化学习式仿真，并说明长期期望 | 只给固定规则“谷充峰放”且无状态依赖 | Major |

### Expected Failure Modes

- 谷时一律充满、峰时一律售电。
- 忽略光伏无法消纳的问题。
- 忽略空/满电池的无效操作罚分。
- 把天气和负荷都当成确定值。

---

# 参考答案

# 问题四解答：微电网储能调度

> 来源：`mdp_problems_part2.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history

def q_learning(S, A, P, R, gamma=0.99, alpha=0.05, epsilon=0.15,
               n_episodes=30000, max_steps=300, seed=42):
    rng = np.random.RandomState(seed)
    Q = np.zeros((S, A))
    rewards_history = []
    # 衰减学习率和探索率
    for ep in range(n_episodes):
        s = rng.randint(S)
        total_reward = 0
        lr = alpha / (1 + ep * 0.0001)
        eps = max(0.01, epsilon * (1 - ep / n_episodes))
        for step in range(max_steps):
            if rng.rand() < eps:
                a = rng.randint(A)
            else:
                a = np.argmax(Q[s])
            s_next = rng.choice(S, p=P[s, a])
            r = R[s, a]
            total_reward += (gamma ** step) * r
            Q[s, a] += lr * (r + gamma * np.max(Q[s_next]) - Q[s, a])
            s = s_next
        rewards_history.append(total_reward)
    V = np.max(Q, axis=1)
    pi = np.argmax(Q, axis=1)
    return V, pi, rewards_history
```

## 题目专属实现

```python
def generate_microgrid_data(seed=42):
    """
    生成微电网储能调度的 MDP 数据。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    battery_levels = ["空(0-20%)", "低(20-40%)", "中(40-60%)", "高(60-80%)", "满(80-100%)"]
    time_periods = ["谷时(23-7)", "平时(7-11)", "峰时(11-15)", "平时(15-23)"]
    weather_types = ["晴天", "多云", "阴雨"]

    n_bat = len(battery_levels)
    n_time = len(time_periods)
    n_weather = len(weather_types)
    S = n_bat * n_time * n_weather  # 60

    action_names = ["大网充电", "存储光伏", "放电自用", "放电售网", "不操作"]
    A = len(action_names)

    def encode(bat, t, w):
        return bat * n_time * n_weather + t * n_weather + w

    def decode(s):
        bat = s // (n_time * n_weather)
        rem = s % (n_time * n_weather)
        t = rem // n_weather
        w = rem % n_weather
        return bat, t, w

    # --- 电价 ---
    elec_price = [0.3, 0.6, 1.0, 0.6]  # 谷/平/峰/平

    # --- 光伏发电能力 (占电池容量的比例/时段) ---
    # 受天气和时段影响
    pv_output = np.array([
        # 晴天  多云  阴雨
        [0.05, 0.02, 0.01],   # 谷时 (夜间，几乎无光伏)
        [0.30, 0.18, 0.06],   # 平时(早) (上午)
        [0.45, 0.27, 0.09],   # 峰时 (中午，光伏最强)
        [0.20, 0.12, 0.04],   # 平时(晚) (下午至傍晚)
    ])

    # --- 园区负荷 (占电池容量比例/时段) ---
    load = [0.10, 0.25, 0.30, 0.25]

    # --- 电池损耗成本 (每次充放电操作的折旧) ---
    battery_degrad_cost = 1.5

    # --- 天气转移 ---
    weather_trans = np.array([
        [0.65, 0.25, 0.10],
        [0.25, 0.50, 0.25],
        [0.10, 0.30, 0.60],
    ])

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        bat, t, w = decode(s)
        price = elec_price[t]
        pv = pv_output[t, w]

        for a in range(A):
            reward = 0.0
            bat_change = 0

            if a == 0:  # 大网充电
                bat_change = 1
                reward = -price * 20 - battery_degrad_cost  # 购电费 + 折旧
            elif a == 1:  # 存储光伏
                # 光伏发电量转化为电池等级变化
                if pv >= 0.20:
                    bat_change = 1
                else:
                    bat_change = 0
                reward = -battery_degrad_cost * 0.5  # 轻微折旧
            elif a == 2:  # 放电自用 (替代从大网购电)
                bat_change = -1
                reward = price * 18 - battery_degrad_cost  # 节省的电费 - 折旧
            elif a == 3:  # 放电售网
                bat_change = -1
                reward = price * 15 - battery_degrad_cost  # 售电收入 - 折旧 (售电价低于购电价)
            elif a == 4:  # 不操作
                bat_change = 0
                reward = 0.0

            # 电量约束
            bat_new = max(0, min(n_bat - 1, bat + bat_change))

            # 特殊情况: 电量不足放电 或 电量已满充电
            if a in [2, 3] and bat == 0:  # 空电池不能放电
                bat_new = 0
                reward = -2.0  # 罚款 (无效操作)
            if a in [0, 1] and bat == n_bat - 1:  # 满电池不能充电
                bat_new = n_bat - 1
                reward = -1.0

            # 时段循环 + 天气转移
            t_next = (t + 1) % n_time

            for w_next in range(n_weather):
                pw = weather_trans[w, w_next]
                # 电池电量有随机性 (模拟负荷波动)
                for bat_delta in [-1, 0, 1]:
                    if bat_delta == 0:
                        p_delta = 0.6
                    elif bat_delta == -1:
                        p_delta = 0.25 if t in [1, 2, 3] else 0.1  # 白天负荷消耗更大
                    else:
                        p_delta = 0.15 if t in [1, 2] and w == 0 else 0.05  # 晴天光伏补充
                    bat_final = max(0, min(n_bat - 1, bat_new + bat_delta))
                    s_next = encode(bat_final, t_next, w_next)
                    P[s, a, s_next] += pw * p_delta

            R[s, a] = reward

            # 归一化
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

    state_names = [f"{battery_levels[b]}|{time_periods[t]}|{weather_types[w]}"
                   for b in range(n_bat) for t in range(n_time) for w in range(n_weather)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.99,
        'state_names': state_names, 'action_names': action_names,
        'n_bat': n_bat, 'n_time': n_time, 'n_weather': n_weather,
        'battery_levels': battery_levels, 'time_periods': time_periods,
        'weather_types': weather_types, 'decode': decode,
        'elec_price': elec_price,
    }

def problem4_microgrid():
    """问题四: 微电网储能调度 (Q-Learning vs VI)"""
    print("=" * 60)
    print("问题四: 微电网储能调度 (能源MDP)")
    print("=" * 60)

    mdp = generate_microgrid_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_bat']}电量 × {mdp['n_time']}时段 × {mdp['n_weather']}天气)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")

    # --- Value Iteration (基准) ---
    V_vi, pi_vi, hist_vi = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration: {len(hist_vi)} 轮收敛")

    # --- Q-Learning ---
    V_ql, pi_ql, ql_rewards = q_learning(S, A, P, R, gamma,
                                          alpha=0.08, epsilon=0.2,
                                          n_episodes=40000, max_steps=200, seed=42)
    policy_match = np.sum(pi_vi == pi_ql)
    print(f"Q-Learning: 40000 episodes 训练完成")
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")
    print(f"值函数平均偏差: {np.mean(np.abs(V_vi - V_ql)):.2f}")

    # --- 输出关键策略 ---
    print(f"\n最优调度策略 (VI, 晴天):")
    decode = mdp['decode']
    for t in range(mdp['n_time']):
        print(f"  【{mdp['time_periods'][t]}】电价={mdp['elec_price'][t]}元/kWh")
        for bat in range(mdp['n_bat']):
            s = bat * mdp['n_time'] * mdp['n_weather'] + t * mdp['n_weather'] + 0
            act = mdp['action_names'][pi_vi[s]]
            print(f"    {mdp['battery_levels'][bat]:12s} → {act:8s}")

    return mdp, V_vi, pi_vi, hist_vi, V_ql, pi_ql, ql_rewards
```
