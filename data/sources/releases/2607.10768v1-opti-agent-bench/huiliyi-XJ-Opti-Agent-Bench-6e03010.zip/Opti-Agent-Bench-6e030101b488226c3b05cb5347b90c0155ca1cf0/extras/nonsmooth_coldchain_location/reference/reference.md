### 参考解答（来自 nonsmooth_part2_解答.md）

#### 数学建模 — 为什么是非光滑优化？

加权 Chebyshev 中心 / 极小极大选址 (Minimax Facility Location):

min_x  max_{i=1,...,n}  c_i · ‖x − a_i‖₂

其中:
- x ∈ R²: 配送中心待选坐标 (经度, 纬度)
- a_i ∈ R²: 第 i 家门店坐标
- c_i > 0: 第 i 家门店的紧迫度权重
- ‖·‖₂: 欧氏距离

非光滑性分析:
- max 函数本身是非光滑的: 当两个或多个门店同时取到最大值时，目标函数在该点不可微 (像 max(f₁, f₂) 在 f₁=f₂ 处有折角)
- ‖x-a_i‖₂ 在 x=a_i 处也不可微 (但实际选址不会落在门店上)
- 即使每个 c_i‖x-a_i‖ 是光滑的, max 的外层仍然非光滑

等价的 SOCP 改写 (光滑化的常用手段):

引入辅助变量 t ≥ 0:

min  t
s.t. c_i · ‖x − a_i‖₂ ≤ t,  ∀i=1,...,n

这是二阶锥规划 (SOCP), 可被 CVXPY 高效求解。

#### 求解方法

**方法 A — 次梯度法 (Subgradient Method):**

f(x) = max_i c_i‖x-a_i‖ 的次梯度:
- 取 i* = argmax_i c_i‖x-a_i‖
- g = c_{i*} · (x - a_{i*}) / ‖x - a_{i*}‖  (次梯度方向)
- 更新: x ← x - α_k · g, 步长 α_k = α₀/√k

**方法 B — SOCP 改写 + CVXPY (精确解)。**

#### 求解代码

```python
import numpy as np
import cvxpy as cp
import time


def solve_minimax_subgradient(stores, weights, lr=2.0, max_iter=3000, seed=42):
    """次梯度法求解极小极大选址。"""
    rng = np.random.RandomState(seed)
    n = len(stores)
    x = stores.mean(axis=0)  # 初始点: 重心
    history = []
    best_x = x.copy()
    best_val = np.inf

    for k in range(1, max_iter + 1):
        dists = np.array([weights[i] * np.linalg.norm(x - stores[i]) for i in range(n)])
        val = np.max(dists)
        history.append(val)

        if val < best_val:
            best_val = val
            best_x = x.copy()

        # 次梯度: 取最大者
        i_star = np.argmax(dists)
        diff = x - stores[i_star]
        norm = np.linalg.norm(diff)
        if norm > 1e-10:
            g = weights[i_star] * diff / norm
        else:
            g = rng.randn(2) * 0.01
        step = lr / np.sqrt(k)
        x = x - step * g

    return best_x, best_val, history


def solve_minimax_socp(stores, weights):
    """SOCP 改写 + CVXPY 求解极小极大选址。"""
    n = len(stores)
    x = cp.Variable(2)
    t = cp.Variable()
    constraints = []
    for i in range(n):
        constraints.append(weights[i] * cp.norm(x - stores[i]) <= t)
    prob = cp.Problem(cp.Minimize(t), constraints)
    prob.solve(solver=cp.SCS)
    return x.value, t.value
```

#### 问题执行函数

```python
def problem5_coldchain():
    """问题五: 冷链配送中心选址 (极小极大)"""
    print("\n" + "=" * 60)
    print("问题五: 冷链配送中心选址 (极小极大)")
    print("=" * 60)

    stores, weights = generate_coldchain_data()
    n = len(stores)

    print(f"\n门店数: {n}")
    print(f"区域范围: [0,100]×[0,100] km")
    print(f"权重范围: [{weights.min():.2f}, {weights.max():.2f}]")

    # --- 次梯度法 ---
    t0 = time.time()
    x_sg, val_sg, hist_sg = solve_minimax_subgradient(stores, weights, lr=3.0, max_iter=5000)
    t_sg = time.time() - t0

    # --- SOCP ---
    t0 = time.time()
    x_socp, val_socp = solve_minimax_socp(stores, weights)
    t_socp = time.time() - t0

    print(f"\n{'方法':<10} {'最大加权距离':<14} {'选址坐标':<20} {'耗时':<8}")
    print("-" * 52)
    print(f"{'次梯度':<10} {val_sg:<14.4f} ({x_sg[0]:.2f}, {x_sg[1]:.2f}){'':<8} {t_sg:.3f}s")
    print(f"{'SOCP':<10} {val_socp:<14.4f} ({x_socp[0]:.2f}, {x_socp[1]:.2f}){'':<8} {t_socp:.3f}s")

    return stores, weights, x_sg, val_sg, hist_sg, x_socp, val_socp
```
