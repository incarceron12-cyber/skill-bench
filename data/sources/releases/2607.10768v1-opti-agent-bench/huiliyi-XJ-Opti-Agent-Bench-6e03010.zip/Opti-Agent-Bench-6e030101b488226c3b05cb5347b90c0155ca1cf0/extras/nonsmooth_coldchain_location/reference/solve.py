"""
六个非光滑优化业务问题 — 第二部分 (问题四~六)
========================================
问题四: 电网负荷模式分解 (鲁棒PCA / 核范数+L1)      — 能源
问题五: 冷链配送中心选址 (极小极大 / Chebyshev中心)  — 物流
问题六: 放疗剂量鲁棒规划 (Huber 回归)               — 医疗

依赖: pip install numpy cvxpy matplotlib
"""
import numpy as np
import cvxpy as cp
import matplotlib.pyplot as plt
import time
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['Arial Unicode MS', 'SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


# ====================================================================
# 通用工具
# ====================================================================

def prox_l1(v, lam):
    """L1 范数的近端算子 (软阈值)。"""
    return np.sign(v) * np.maximum(np.abs(v) - lam, 0)


def prox_nuclear(M, lam):
    """核范数的近端算子 (奇异值软阈值)。"""
    U, s, Vt = np.linalg.svd(M, full_matrices=False)
    s_shrunk = np.maximum(s - lam, 0)
    return U @ np.diag(s_shrunk) @ Vt


# ====================================================================
# 问题四: 电网负荷模式分解 — 鲁棒PCA (能源)
# ====================================================================
#
# 【业务背景】
# 某省级电网调度中心每天记录全省 m=30 个地级市变电站的日负荷曲线。
# 每条曲线包含 24 个小时的平均负荷值 (MW)。积累了 d=60 天（约两个月）
# 的数据后，形成一个 负荷矩阵 M ∈ R^{30×60}。
#
# 调度员发现:
#   1. **大部分日负荷曲线呈现强规律性**: 各城市的负荷模式高度相似
#      （白天高、夜间低的"鸭子曲线"），且不同城市之间因产业结构相似
#      而存在高度相关性。这意味着矩阵 M 具有**低秩**结构（可以用
#      少数几个"典型负荷模式"的线性组合近似）。
#   2. **少数异常值破坏了规律**: 某些城市在某些天由于极端天气（酷暑/
#      寒潮导致空调负荷骤增）、突发设备故障、或大型活动（演唱会、
#      赛事）等原因，负荷出现大幅偏离。这些异常在矩阵中表现为**稀疏
#      的大幅偏差**。
#
# 调度中心希望将负荷矩阵分解为:
#   M = L + S
#   - L: 低秩矩阵 (正常的规律性负荷模式)
#   - S: 稀疏矩阵 (异常负荷偏差)
#
# 分解出 L 后可以用于短期负荷预测的基线建模；分解出 S 后可以自动识别
# 异常事件（告警），用于事后复盘和预案编制。
#
# 【数学建模 — 为什么是非光滑优化？】
#
# 鲁棒 PCA (Robust Principal Component Analysis):
#   min_{L,S}  ‖L‖_* + λ ‖S‖₁
#   s.t.       L + S = M
#
# 其中:
#   - ‖L‖_* = Σ σ_i(L): 核范数 (所有奇异值之和), 促进 L 低秩
#   - ‖S‖₁ = Σ|S_{ij}|: 元素级 L1 范数, 促进 S 稀疏
#   - λ > 0: 权衡参数, 理论推荐值 λ = 1/√max(m,d)
#
# 非光滑性分析:
#   - 核范数 ‖L‖_* 在奇异值为零处不可微 (类似 L1 范数在零处不可微,
#     但作用在奇异值上)
#   - ‖S‖₁ 在任何 S_{ij}=0 处不可微
#   - 两个非光滑项的联合优化, 标准梯度法完全无法使用
#
# 【数据生成参数】
#
# generate_power_load_data() 构造模拟数据:
#
#   低秩部分 L_true:
#   - 秩 r = 3 (三种典型负荷模式)
#   - L_true = U @ V.T, U ∈ R^{30×3}, V ∈ R^{60×3}
#   - 各列基向量通过正弦函数模拟日间/夜间/季节性模式
#   - 基线均值约 500-2000 MW
#
#   稀疏部分 S_true:
#   - 异常比例: 约 5% 的元素非零
#   - 非零值: ±(200~800) MW 的大幅偏差
#   - 模拟极端天气和突发事件
#
#   观测矩阵: M = L_true + S_true
#
#   推荐 λ = 1/√max(30, 60) ≈ 0.129
#
# 【求解方法】
#
# 方法 A — 不精确增广 Lagrange 乘子法 (Inexact ALM):
#   增广 Lagrange 函数:
#     L_μ = ‖L‖_* + λ‖S‖₁ + <Y, M-L-S> + (μ/2)‖M-L-S‖_F²
#   初始化: Y = M/max(‖M‖₂, ‖M‖_∞/λ), μ₀ = 1.25/‖M‖₂
#   迭代:
#     L ← prox_{(1/μ)‖·‖_*}(M - S + Y/μ)    [奇异值软阈值]
#     S ← prox_{(λ/μ)‖·‖₁}(M - L + Y/μ)     [元素级软阈值]
#     Y ← Y + μ(M - L - S)                    [对偶更新]
#     μ ← min(ρ·μ, μ̄)                         [自适应增大惩罚, ρ=1.5]
#
# 方法 B — CVXPY 精确求解 (基准)。
# ====================================================================

def generate_power_load_data(m=30, d=60, rank=3, sparse_frac=0.05, seed=42):
    """
    生成电网负荷矩阵分解数据。

    返回
    ----
    M : (m, d) 观测负荷矩阵
    L_true : (m, d) 真实低秩部分
    S_true : (m, d) 真实稀疏异常部分
    lam : float 推荐的 λ
    """
    rng = np.random.RandomState(seed)

    # 低秩部分: 3 种典型模式
    U = np.zeros((m, rank))
    V = np.zeros((d, rank))
    for r in range(rank):
        U[:, r] = np.sin(np.linspace(0, (r + 1) * np.pi, m)) * (200 + r * 100)
        V[:, r] = np.cos(np.linspace(0, (r + 0.5) * np.pi, d)) * (1.0 + 0.3 * r)
    L_true = U @ V.T + 800  # 基线 800 MW

    # 稀疏部分
    S_true = np.zeros((m, d))
    n_sparse = int(m * d * sparse_frac)
    sparse_idx = rng.choice(m * d, n_sparse, replace=False)
    sparse_vals = rng.choice([-1, 1], n_sparse) * rng.uniform(200, 800, n_sparse)
    S_true.ravel()[sparse_idx] = sparse_vals

    M = L_true + S_true
    lam = 1.0 / np.sqrt(max(m, d))

    return M, L_true, S_true, lam


def solve_rpca_admm(M, lam, max_iter=1000, tol=1e-7):
    """
    不精确增广 Lagrange 乘子法 (Inexact ALM) 求解鲁棒 PCA。
    参考: Lin, Chen & Ma (2010) — The Augmented Lagrange Multiplier Method
          for Exact Recovery of Corrupted Low-Rank Matrices.
    """
    m, d = M.shape
    norm_M = np.linalg.norm(M, 'fro')
    norm_two = np.linalg.norm(M, 2)          # 谱范数
    norm_inf = np.max(np.abs(M)) / lam
    dual_norm = max(norm_two, norm_inf)

    # 初始化: Y / dual_norm, mu 自适应
    Y = M / dual_norm
    mu = 1.25 / norm_two
    mu_bar = mu * 1e7
    rho_update = 1.5            # mu 每轮增长因子

    L = np.zeros_like(M)
    S = np.zeros_like(M)
    history = []

    for k in range(max_iter):
        # L 步: 奇异值软阈值
        L = prox_nuclear(M - S + Y / mu, 1.0 / mu)
        # S 步: 元素级软阈值
        S = prox_l1(M - L + Y / mu, lam / mu)
        # 对偶更新
        residual = M - L - S
        Y = Y + mu * residual
        # 自适应增大 mu
        mu = min(rho_update * mu, mu_bar)

        obj = np.sum(np.linalg.svd(L, compute_uv=False)) + lam * np.sum(np.abs(S))
        history.append(obj)

        if np.linalg.norm(residual, 'fro') / (norm_M + 1e-10) < tol:
            break

    return L, S, history


def solve_rpca_cvxpy(M, lam):
    """CVXPY 精确求解鲁棒 PCA。"""
    m, d = M.shape
    L = cp.Variable((m, d))
    S = cp.Variable((m, d))
    objective = cp.Minimize(cp.normNuc(L) + lam * cp.norm1(S))
    constraints = [L + S == M]
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS, max_iters=5000)
    return L.value, S.value, prob.value


def problem4_power_rpca():
    """问题四: 电网负荷模式分解 (鲁棒PCA)"""
    print("=" * 60)
    print("问题四: 电网负荷模式分解 (鲁棒PCA)")
    print("=" * 60)

    M, L_true, S_true, lam = generate_power_load_data()
    m, d = M.shape

    print(f"\n负荷矩阵: {m}城市 × {d}天")
    print(f"真实低秩部分: rank={np.linalg.matrix_rank(L_true, tol=1e-3)}")
    print(f"真实稀疏部分: {np.sum(S_true != 0)} 个非零元素 ({np.sum(S_true != 0)/(m*d):.1%})")
    print(f"λ = {lam:.4f}")

    # --- ADMM ---
    t0 = time.time()
    L_admm, S_admm, hist_admm = solve_rpca_admm(M, lam)
    t_admm = time.time() - t0
    rank_admm = np.linalg.matrix_rank(L_admm, tol=10)
    nnz_admm = np.sum(np.abs(S_admm) > 10)

    # --- CVXPY ---
    t0 = time.time()
    L_cvx, S_cvx, obj_cvx = solve_rpca_cvxpy(M, lam)
    t_cvx = time.time() - t0
    rank_cvx = np.linalg.matrix_rank(L_cvx, tol=10)
    nnz_cvx = np.sum(np.abs(S_cvx) > 10)

    err_L_admm = np.linalg.norm(L_admm - L_true, 'fro') / np.linalg.norm(L_true, 'fro')
    err_L_cvx = np.linalg.norm(L_cvx - L_true, 'fro') / np.linalg.norm(L_true, 'fro')

    print(f"\n{'方法':<8} {'目标值':<14} {'L秩':<6} {'S非零':<8} {'L误差':<10} {'耗时':<8}")
    print("-" * 54)
    print(f"{'ADMM':<8} {hist_admm[-1]:<14.2f} {rank_admm:<6} {nnz_admm:<8} {err_L_admm:<10.4f} {t_admm:.3f}s")
    print(f"{'CVXPY':<8} {obj_cvx:<14.2f} {rank_cvx:<6} {nnz_cvx:<8} {err_L_cvx:<10.4f} {t_cvx:.3f}s")

    return M, L_true, S_true, L_admm, S_admm, L_cvx, S_cvx, hist_admm


# ====================================================================
# 问题五: 冷链配送中心选址 — 极小极大 (物流)
# ====================================================================
#
# 【业务背景】
# 某生鲜电商在华东地区运营着 n=20 家线下门店/前置仓，分布在不同城市和
# 区域。公司计划新建一座冷链配送中心，为所有门店供货。冷链运输对时效
# 要求极高（生鲜保质期短），因此选址的核心目标不是最小化**平均**配送距离，
# 而是最小化**最远那家门店的配送距离**——即确保最不利的门店也能在可接受
# 时间内收到货物。
#
# 此外，不同门店的"紧迫度"不同（日均订单量越大、覆盖人口越多的门店
# 越重要），因此距离还要乘以权重系数。
#
# 【数学建模 — 为什么是非光滑优化？】
#
# 加权 Chebyshev 中心 / 极小极大选址 (Minimax Facility Location):
#   min_x  max_{i=1,...,n}  c_i · ‖x − a_i‖₂
#
# 其中:
#   - x ∈ R²: 配送中心待选坐标 (经度, 纬度)
#   - a_i ∈ R²: 第 i 家门店坐标
#   - c_i > 0: 第 i 家门店的紧迫度权重
#   - ‖·‖₂: 欧氏距离
#
# 非光滑性分析:
#   - max 函数本身是非光滑的: 当两个或多个门店同时取到最大值时，
#     目标函数在该点不可微 (像 max(f₁, f₂) 在 f₁=f₂ 处有折角)
#   - ‖x-a_i‖₂ 在 x=a_i 处也不可微 (但实际选址不会落在门店上)
#   - 即使每个 c_i‖x-a_i‖ 是光滑的, max 的外层仍然非光滑
#
# 等价的 SOCP 改写 (光滑化的常用手段):
#   引入辅助变量 t ≥ 0:
#     min  t
#     s.t. c_i · ‖x − a_i‖₂ ≤ t,  ∀i=1,...,n
#   这是二阶锥规划 (SOCP), 可被 CVXPY 高效求解。
#
# 【数据生成参数】
#
# generate_coldchain_data() 构造如下数据:
#
#   门店坐标 a_i (经纬度, 以 km 为单位):
#   - 在 [0, 100km] × [0, 100km] 的区域内随机散布 n=20 家门店
#   - 有 3 个聚类中心 (模拟城市群), 门店围绕聚类中心分布
#
#   权重 c_i:
#   - c_i ∝ 日均订单量, 从 Uniform(0.5, 2.0) 采样
#   - 靠近聚类中心的大店权重更高
#
# 【求解方法】
#
# 方法 A — 次梯度法 (Subgradient Method):
#   f(x) = max_i c_i‖x-a_i‖ 的次梯度:
#     取 i* = argmax_i c_i‖x-a_i‖
#     g = c_{i*} · (x - a_{i*}) / ‖x - a_{i*}‖  (次梯度方向)
#   更新: x ← x - α_k · g, 步长 α_k = α₀/√k
#
# 方法 B — SOCP 改写 + CVXPY (精确解)。
# ====================================================================

def generate_coldchain_data(n=20, seed=42):
    """
    生成冷链配送中心极小极大选址数据。

    返回
    ----
    stores : (n, 2) 门店坐标 (km)
    weights : (n,) 门店权重
    """
    rng = np.random.RandomState(seed)

    # 3 个聚类中心
    centers = np.array([[25, 30], [70, 60], [50, 85]])
    stores = []
    for i in range(n):
        c = centers[rng.randint(3)]
        stores.append(c + rng.randn(2) * 12)
    stores = np.array(stores)
    stores = np.clip(stores, 0, 100)

    # 权重 (靠近中心的门店更大)
    weights = rng.uniform(0.5, 2.0, n)

    return stores, weights


def solve_minimax_subgradient(stores, weights, lr=2.0, max_iter=3000, seed=42):
    """次梯度法求解极小极大选址。"""
    rng = np.random.RandomState(seed)
    n = len(stores)
    x = stores.mean(axis=0)  # 初始点: 重心
    history = []
    best_x = x.copy()
    best_val = np.inf

    for k in range(1, max_iter + 1):
        dists = np.array([weights[i] * np.linalg.norm(x - stores[i]) for i in range(n)])
        val = np.max(dists)
        history.append(val)

        if val < best_val:
            best_val = val
            best_x = x.copy()

        # 次梯度: 取最大者
        i_star = np.argmax(dists)
        diff = x - stores[i_star]
        norm = np.linalg.norm(diff)
        if norm > 1e-10:
            g = weights[i_star] * diff / norm
        else:
            g = rng.randn(2) * 0.01
        step = lr / np.sqrt(k)
        x = x - step * g

    return best_x, best_val, history


def solve_minimax_socp(stores, weights):
    """SOCP 改写 + CVXPY 求解极小极大选址。"""
    n = len(stores)
    x = cp.Variable(2)
    t = cp.Variable()
    constraints = []
    for i in range(n):
        constraints.append(weights[i] * cp.norm(x - stores[i]) <= t)
    prob = cp.Problem(cp.Minimize(t), constraints)
    prob.solve(solver=cp.SCS)
    return x.value, t.value


def problem5_coldchain():
    """问题五: 冷链配送中心选址 (极小极大)"""
    print("\n" + "=" * 60)
    print("问题五: 冷链配送中心选址 (极小极大)")
    print("=" * 60)

    stores, weights = generate_coldchain_data()
    n = len(stores)

    print(f"\n门店数: {n}")
    print(f"区域范围: [0,100]×[0,100] km")
    print(f"权重范围: [{weights.min():.2f}, {weights.max():.2f}]")

    # --- 次梯度法 ---
    t0 = time.time()
    x_sg, val_sg, hist_sg = solve_minimax_subgradient(stores, weights, lr=3.0, max_iter=5000)
    t_sg = time.time() - t0

    # --- SOCP ---
    t0 = time.time()
    x_socp, val_socp = solve_minimax_socp(stores, weights)
    t_socp = time.time() - t0

    print(f"\n{'方法':<10} {'最大加权距离':<14} {'选址坐标':<20} {'耗时':<8}")
    print("-" * 52)
    print(f"{'次梯度':<10} {val_sg:<14.4f} ({x_sg[0]:.2f}, {x_sg[1]:.2f}){'':<8} {t_sg:.3f}s")
    print(f"{'SOCP':<10} {val_socp:<14.4f} ({x_socp[0]:.2f}, {x_socp[1]:.2f}){'':<8} {t_socp:.3f}s")

    return stores, weights, x_sg, val_sg, hist_sg, x_socp, val_socp


# ====================================================================
# 问题六: 放疗剂量鲁棒规划 — Huber 回归 (医疗)
# ====================================================================
#
# 【业务背景】
# 某肿瘤医院的放疗科为头颈部肿瘤患者制定调强放射治疗 (IMRT) 计划。
# 放疗计划的核心是确定 p 个射束 (beam) 的强度权重 w，使得各组织
# 接收到的剂量尽可能接近处方值。
#
# 具体而言，患者的解剖结构被 CT 图像离散化为 n 个体素 (voxel)，
# 每个体素 i 接收到的剂量为:
#   dose_i = Σ_j  A_{ij} · w_j
# 其中 A 是"剂量影响矩阵"（由 Monte Carlo 模拟计算得到），w_j 是第 j
# 个射束的强度。
#
# 处方要求:
#   - 靶区 (肿瘤) 的每个体素: 剂量 ≈ 60 Gy (处方剂量)
#   - 危及器官 (脊髓、腮腺等): 剂量应尽量低
#
# 传统方法使用最小二乘 (L2) 损失来拟合处方剂量:
#   min ‖Aw - d‖₂²
# 但实际中，处方值 d 的某些体素会因为器官运动、摆位误差或图像分割
# 不精确等原因包含**离群值**（个别体素的处方值严重偏离合理范围）。
# L2 损失会对离群值产生过大的梯度响应，导致整个计划被少数异常体素
# "带偏"，影响全局剂量分布。
#
# **Huber 损失**（也称"光滑化的绝对值损失"）提供了更鲁棒的替代:
# 它在残差较小时表现为二次损失（对小误差敏感），在残差较大时切换为
# 线性损失（对离群值不过度惩罚），从而在拟合精度和鲁棒性之间取得平衡。
#
# 【数学建模 — 为什么是非光滑优化？】
#
# Huber 回归 (Huber Regression):
#   min_w  (1/n) Σ_{i=1}^n  H_δ(d_i − (Aw)_i)  +  (μ/2) ‖w‖₂²
#
# 其中 Huber 损失函数:
#   H_δ(u) = (1/2) u²           当 |u| ≤ δ
#           = δ(|u| - δ/2)      当 |u| > δ
#
# 非光滑性分析:
#   - H_δ(u) 在 u = ±δ 处的**一阶导数是连续的**:
#     H_δ'(u) = u     当 |u| ≤ δ
#             = δ·sign(u) 当 |u| > δ
#     所以 Huber 损失本身是可微的（只是二阶不可微）。
#   - 但从非光滑优化的视角, Huber 损失可以看作 (1/2)‖·‖₂² 和 δ‖·‖₁ 的
#     Moreau 包络的混合, 其近端算子有显式解。
#   - 更重要的是, 当 δ→0 时 Huber 退化为 L1 损失 (完全非光滑),
#     δ→∞ 时退化为 L2 损失 (完全光滑)。因此 Huber 回归恰好处于
#     光滑与非光滑优化的交界处, 是理解非光滑概念的绝佳案例。
#   - 与 L1 回归 (min ‖Aw-d‖₁) 做对比, 可以看到非光滑度的影响。
#
# 补充: 射束强度非负约束 w ≥ 0 (物理限制, 不能有负强度)。
#
# 【数据生成参数】
#
# generate_radiotherapy_data() 构造如下模拟数据:
#
#   剂量影响矩阵 A ∈ R^{n×p}:
#   - n = 150 个体素, p = 40 个射束
#   - A_{ij} 表示第 j 个射束对第 i 个体素的剂量贡献 (非负)
#   - 按指数衰减模型生成: A_{ij} ∝ exp(-α·dist(beam_j, voxel_i))
#
#   处方剂量 d ∈ R^n:
#   - 靶区体素 (前60个): d_i = 60 Gy
#   - 危及器官 (后90个): d_i = 10 Gy (希望尽量低)
#   - 叠加 5% 的离群值: 随机选取部分体素, 将 d_i 设为极端值
#     (模拟分割误差导致的错误处方)
#
#   Huber 参数 δ:
#   - 推荐 δ = 5.0 Gy (残差超过 5Gy 时切换为线性损失)
#
#   正则化参数 μ:
#   - μ = 0.01 (防止射束强度过大)
#
# 【求解方法】
#
# 方法 A — 近端梯度下降 (Proximal Gradient for Huber + L2 + 非负约束):
#   Huber 损失的梯度:
#     ∇_w H_loss = -(1/n) Aᵀ · clip(d-Aw, -δ, δ)  (当 |residual| ≤ δ)
#                  -(1/n) Aᵀ · δ·sign(d-Aw)          (当 |residual| > δ)
#   组合: g = ∇_w Huber_loss + μ·w
#   投影: w ← max(w - step·g, 0)  (非负约束的投影)
#
# 方法 B — L2 回归 (普通最小二乘, 对比基线):
#   min ‖Aw-d‖₂² + μ‖w‖₂², w≥0
#   展示 L2 回归对离群值的敏感性。
#
# 方法 C — CVXPY 精确求解 (Huber + 非负约束, 基准)。
# ====================================================================

def generate_radiotherapy_data(n=150, p=40, outlier_frac=0.05, seed=42):
    """
    生成放疗剂量规划 Huber 回归数据。

    返回
    ----
    A : (n, p) 剂量影响矩阵
    d : (n,)   处方剂量 (含离群值)
    d_clean : (n,) 干净的处方剂量 (无离群值)
    delta : float Huber 参数
    mu : float 正则化参数
    """
    rng = np.random.RandomState(seed)

    n_target = 60   # 靶区体素数
    n_oar = n - n_target  # 危及器官体素数

    # 几何布局: 射束围绕靶区, 靶区在中心, 器官在外围
    # 靶区体素: 集中在 (5, 5) 附近
    target_center = np.array([5.0, 5.0])
    voxel_pos = np.zeros((n, 2))
    voxel_pos[:n_target] = target_center + rng.randn(n_target, 2) * 1.0
    # 危及器官: 在 (5,5) 外围, 距中心 3-6 个单位
    angles = rng.uniform(0, 2 * np.pi, n_oar)
    radii = rng.uniform(3, 6, n_oar)
    voxel_pos[n_target:, 0] = target_center[0] + radii * np.cos(angles)
    voxel_pos[n_target:, 1] = target_center[1] + radii * np.sin(angles)

    # 射束: 从多个角度照射靶区
    beam_pos = np.zeros((p, 2))
    beam_angles = np.linspace(0, 2 * np.pi, p, endpoint=False)
    beam_radii = rng.uniform(1.5, 3.5, p)
    beam_pos[:, 0] = target_center[0] + beam_radii * np.cos(beam_angles)
    beam_pos[:, 1] = target_center[1] + beam_radii * np.sin(beam_angles)

    # 剂量影响矩阵: 指数衰减
    A = np.zeros((n, p))
    for j in range(p):
        dists = np.linalg.norm(voxel_pos - beam_pos[j], axis=1)
        A[:, j] = np.exp(-0.5 * dists) * rng.uniform(1.0, 3.0)
    A = np.maximum(A, 0)

    # 干净的处方剂量
    d_clean = np.zeros(n)
    d_clean[:n_target] = 60.0    # 靶区
    d_clean[n_target:] = 10.0    # 危及器官

    # 加入离群值
    d = d_clean.copy()
    n_outliers = int(n * outlier_frac)
    outlier_idx = rng.choice(n, n_outliers, replace=False)
    d[outlier_idx] = rng.choice([0, 120, 150], n_outliers)  # 极端错误值

    delta = 5.0
    mu = 0.01

    return A, d, d_clean, delta, mu


def huber_loss(u, delta):
    """Huber 损失函数 (向量化)。"""
    abs_u = np.abs(u)
    return np.where(abs_u <= delta, 0.5 * u ** 2, delta * (abs_u - 0.5 * delta))


def huber_grad(u, delta):
    """Huber 损失对 u 的梯度 (向量化)。"""
    return np.clip(u, -delta, delta)


def solve_huber_proxgrad(A, d, delta, mu, max_iter=2000, tol=1e-6):
    """近端梯度下降求解 Huber 回归 (含非负约束)。"""
    n, p = A.shape
    L = np.linalg.norm(A.T @ A / n, 2) + mu  # Lipschitz 常数
    w = np.ones(p) * 0.1
    history = []

    for k in range(max_iter):
        residuals = d - A @ w
        # Huber 损失关于 w 的梯度
        grad_huber = -A.T @ huber_grad(residuals, delta) / n
        grad_reg = mu * w
        grad = grad_huber + grad_reg

        w_new = np.maximum(w - grad / L, 0)  # 投影到非负

        obj = np.sum(huber_loss(d - A @ w_new, delta)) / n + 0.5 * mu * np.sum(w_new ** 2)
        history.append(obj)

        if np.max(np.abs(w_new - w)) < tol:
            break
        w = w_new

    return w, history


def solve_l2_regression(A, d, mu):
    """普通 L2 回归 (对比基线), 带非负约束。"""
    n, p = A.shape
    w = cp.Variable(p, nonneg=True)
    objective = cp.Minimize(cp.sum_squares(A @ w - d) / n + 0.5 * mu * cp.sum_squares(w))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return w.value, prob.value


def solve_huber_cvxpy(A, d, delta, mu):
    """CVXPY 精确求解 Huber 回归 (基准)。"""
    n, p = A.shape
    w = cp.Variable(p, nonneg=True)
    residuals = d - A @ w
    loss = cp.sum(cp.huber(residuals, delta)) / n + 0.5 * mu * cp.sum_squares(w)
    prob = cp.Problem(cp.Minimize(loss))
    prob.solve(solver=cp.SCS)
    return w.value, prob.value


def problem6_radiotherapy():
    """问题六: 放疗剂量鲁棒规划 (Huber回归)"""
    print("\n" + "=" * 60)
    print("问题六: 放疗剂量鲁棒规划 (Huber回归)")
    print("=" * 60)

    A, d, d_clean, delta, mu = generate_radiotherapy_data()
    n, p = A.shape
    n_outliers = np.sum(d != d_clean)

    print(f"\n体素数: {n}, 射束数: {p}")
    print(f"离群体素数: {n_outliers} ({n_outliers/n:.0%})")
    print(f"Huber δ = {delta}, 正则化 μ = {mu}")

    # --- 近端梯度 (Huber) ---
    t0 = time.time()
    w_huber, hist_huber = solve_huber_proxgrad(A, d, delta, mu)
    t_huber = time.time() - t0

    # --- L2 回归 (对比) ---
    t0 = time.time()
    w_l2, obj_l2 = solve_l2_regression(A, d, mu)
    t_l2 = time.time() - t0

    # --- CVXPY Huber (基准) ---
    t0 = time.time()
    w_cvx, obj_cvx = solve_huber_cvxpy(A, d, delta, mu)
    t_cvx = time.time() - t0

    # 评估: 用干净的处方剂量计算拟合误差
    dose_huber = A @ w_huber
    dose_l2 = A @ w_l2
    dose_cvx = A @ w_cvx

    # 靶区剂量偏差 (应接近 60 Gy)
    target_err_huber = np.mean(np.abs(dose_huber[:60] - 60))
    target_err_l2 = np.mean(np.abs(dose_l2[:60] - 60))
    target_err_cvx = np.mean(np.abs(dose_cvx[:60] - 60))

    # 危及器官超标量
    oar_excess_huber = np.mean(np.maximum(dose_huber[60:] - 15, 0))
    oar_excess_l2 = np.mean(np.maximum(dose_l2[60:] - 15, 0))
    oar_excess_cvx = np.mean(np.maximum(dose_cvx[60:] - 15, 0))

    print(f"\n{'方法':<12} {'靶区偏差(Gy)':<14} {'器官超标(Gy)':<14} {'耗时':<8}")
    print("-" * 48)
    print(f"{'Huber(近端)':<12} {target_err_huber:<14.2f} {oar_excess_huber:<14.2f} {t_huber:.3f}s")
    print(f"{'L2(最小二乘)':<12} {target_err_l2:<14.2f} {oar_excess_l2:<14.2f} {t_l2:.3f}s")
    print(f"{'Huber(CVXPY)':<12} {target_err_cvx:<14.2f} {oar_excess_cvx:<14.2f} {t_cvx:.3f}s")

    return A, d, d_clean, delta, w_huber, w_l2, w_cvx, hist_huber


# ====================================================================
# 可视化
# ====================================================================

def visualize_part2(result4, result5, result6):
    """绘制后三个问题的结果"""
    fig, axes = plt.subplots(2, 3, figsize=(18, 10))

    # === 问题四: 鲁棒PCA ===
    M, L_true, S_true, L_admm, S_admm, L_cvx, S_cvx, hist_admm = result4

    # 上: 稀疏矩阵热力图
    ax = axes[0, 0]
    vmax = max(np.abs(S_true).max(), np.abs(S_admm).max()) * 0.8
    im = ax.imshow(np.abs(S_admm), cmap='hot', aspect='auto', vmin=0, vmax=vmax)
    ax.set_xlabel('Day')
    ax.set_ylabel('City')
    ax.set_title('P4: Detected Anomalies |S| (ADMM)', fontsize=10)
    plt.colorbar(im, ax=ax, shrink=0.8)

    # 下: ADMM 收敛
    ax = axes[1, 0]
    ax.semilogy(hist_admm, color='#FF6B6B', linewidth=1.5)
    ax.set_xlabel('ADMM Iteration')
    ax.set_ylabel('Objective')
    ax.set_title(f'P4: ADMM Convergence ({len(hist_admm)} iters)', fontsize=10)
    ax.grid(True, alpha=0.3)

    # === 问题五: 极小极大选址 ===
    stores, weights, x_sg, val_sg, hist_sg, x_socp, val_socp = result5

    # 上: 门店与选址
    ax = axes[0, 1]
    scatter = ax.scatter(stores[:, 0], stores[:, 1], c=weights, cmap='YlOrRd',
                          s=weights * 80, edgecolors='black', zorder=3)
    ax.scatter(*x_sg, marker='*', s=300, c='blue', edgecolors='black', zorder=5,
               label=f'Subgrad ({val_sg:.1f})')
    ax.scatter(*x_socp, marker='D', s=200, c='red', edgecolors='black', zorder=5,
               label=f'SOCP ({val_socp:.1f})')
    # 画最大加权距离的圆
    for x_opt, color, ls in [(x_socp, 'red', '--')]:
        dists = np.array([weights[i] * np.linalg.norm(x_opt - stores[i]) for i in range(len(stores))])
        i_max = np.argmax(dists)
        r = np.linalg.norm(x_opt - stores[i_max])
        circle = plt.Circle(x_opt, r, fill=False, color=color, linestyle=ls, linewidth=1.5)
        ax.add_patch(circle)
    ax.set_xlabel('X (km)')
    ax.set_ylabel('Y (km)')
    ax.set_title('P5: Cold Chain Facility Location', fontsize=10)
    ax.legend(fontsize=8)
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    plt.colorbar(scatter, ax=ax, shrink=0.8, label='Weight')

    # 下: 次梯度收敛
    ax = axes[1, 1]
    ax.plot(hist_sg, color='#4ECDC4', linewidth=1, alpha=0.6)
    # 移动平均
    window = 50
    if len(hist_sg) > window:
        smoothed = np.convolve(hist_sg, np.ones(window)/window, mode='valid')
        ax.plot(range(window-1, len(hist_sg)), smoothed, color='#FF6B6B', linewidth=2,
                label='Smoothed')
    ax.axhline(y=val_socp, color='gray', linestyle='--', alpha=0.7, label=f'SOCP opt={val_socp:.2f}')
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Max Weighted Distance')
    ax.set_title('P5: Subgradient Convergence', fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)

    # === 问题六: Huber 放疗 ===
    A, d, d_clean, delta, w_huber, w_l2, w_cvx_h, hist_huber = result6

    # 上: 剂量分布对比
    ax = axes[0, 2]
    dose_huber = A @ w_huber
    dose_l2 = A @ w_l2
    voxel_idx = np.arange(len(d))
    ax.scatter(voxel_idx, d, c='gray', s=8, alpha=0.3, label='Prescription (w/ outliers)')
    ax.plot(voxel_idx, dose_huber, 'b-', linewidth=1.5, alpha=0.8, label='Huber dose')
    ax.plot(voxel_idx, dose_l2, 'r--', linewidth=1.5, alpha=0.6, label='L2 dose')
    ax.axhline(y=60, color='green', linestyle=':', alpha=0.5, label='Target 60Gy')
    ax.axvline(x=60, color='gray', linestyle='--', alpha=0.3)
    ax.annotate('Target\nRegion', (30, 65), fontsize=8, ha='center')
    ax.annotate('Organs\nat Risk', (105, 65), fontsize=8, ha='center')
    ax.set_xlabel('Voxel Index')
    ax.set_ylabel('Dose (Gy)')
    ax.set_title('P6: Radiotherapy Dose (Huber vs L2)', fontsize=10)
    ax.legend(fontsize=7, loc='upper right')
    ax.grid(True, alpha=0.3)

    # 下: Huber 收敛
    ax = axes[1, 2]
    ax.semilogy(hist_huber, color='#4ECDC4', linewidth=1.5)
    ax.set_xlabel('Iteration')
    ax.set_ylabel('Objective')
    ax.set_title(f'P6: Proximal Gradient ({len(hist_huber)} iters)', fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    out_path = 'nonsmooth_part2_results.png'
    plt.savefig(out_path, dpi=150, bbox_inches='tight')
    print(f"\n可视化已保存: {out_path}")
    plt.close()


# ====================================================================
# 主函数
# ====================================================================

if __name__ == "__main__":
    print()
    print("###############################################################")
    print("#   六个非光滑优化业务问题 — 第二部分 (能源·物流·医疗)           #")
    print("###############################################################")

    r4 = problem4_power_rpca()
    r5 = problem5_coldchain()
    r6 = problem6_radiotherapy()

    visualize_part2(r4, r5, r6)

    print("\n" + "=" * 60)
    print("第二部分总结")
    print("=" * 60)
    print("""
问题              | 非光滑项                  | 处理策略                        | 求解方法
-----------------|--------------------------|---------------------------------|---------------------
电网负荷分解(RPCA) | ‖L‖_* + λ‖S‖₁           | 奇异值软阈值 + 元素级软阈值       | ADMM, CVXPY
冷链选址(Minimax)  | max_i c_i‖x-a_i‖        | 次梯度 / SOCP改写                | Subgradient, SOCP
放疗剂量(Huber)    | Σ H_δ(d_i-(Aw)_i) + 非负 | Huber梯度 + 非负投影             | ProxGrad, L2对比, CVXPY
""")
