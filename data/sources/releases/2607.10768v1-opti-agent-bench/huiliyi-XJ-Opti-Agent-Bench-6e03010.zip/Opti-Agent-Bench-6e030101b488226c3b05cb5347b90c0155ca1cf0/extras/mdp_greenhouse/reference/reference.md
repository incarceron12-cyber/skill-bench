# 问题一解答：智能温室气候调控

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    """
    值迭代算法。

    参数
    ----
    S : int  状态数
    A : int  动作数
    P : np.ndarray, shape (S, A, S)  转移概率 P[s,a,s']
    R : np.ndarray, shape (S, A)     即时奖励 R[s,a]
    gamma : float  折扣因子
    tol : float    收敛阈值
    max_iter : int 最大迭代次数

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略 (每个状态的最优动作索引)
    history : list               每轮迭代的 max|V_new - V_old|
    """
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)            # shape (S, A)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history
```

## 题目专属实现

```python
def generate_greenhouse_data(seed=42):
    """
    生成智能温室气候调控的 MDP 数据。

    返回
    ----
    mdp : dict
        包含 S, A, P, R, gamma, state_names, action_names, state_info 等信息。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间定义 ---
    temp_levels = ["严寒(<12°C)", "偏冷(12-18°C)", "适宜(18-26°C)", "偏热(26-32°C)", "酷热(>32°C)"]
    growth_stages = ["苗期", "开花期", "结果期", "成熟期"]
    weather_types = ["晴天", "多云", "阴雨"]

    n_temp = len(temp_levels)
    n_growth = len(growth_stages)
    n_weather = len(weather_types)
    S = n_temp * n_growth * n_weather  # 60

    # 动作空间
    action_names = ["强加热", "弱加热", "不干预", "弱降温", "强降温"]
    A = len(action_names)

    # --- 辅助函数: 状态编码/解码 ---
    def encode(t, g, w):
        return t * n_growth * n_weather + g * n_weather + w

    def decode(s):
        t = s // (n_growth * n_weather)
        rem = s % (n_growth * n_weather)
        g = rem // n_weather
        w = rem % n_weather
        return t, g, w

    # --- 天气转移矩阵 (天气之间的马尔可夫链) ---
    # 晴天倾向持续，但可能变多云；阴雨不太持久
    weather_transition = np.array([
        [0.60, 0.30, 0.10],   # 晴 → 晴/多云/阴雨
        [0.25, 0.50, 0.25],   # 多云 → ...
        [0.15, 0.35, 0.50],   # 阴雨 → ...
    ])

    # --- 温度转移: 取决于 (当前温度, 动作, 天气) ---
    # 动作对温度的影响: 强加热+2, 弱加热+1, 不干预0, 弱降温-1, 强降温-2
    action_temp_shift = [2, 1, 0, -1, -2]
    # 天气对温度的随机扰动分布 (以温度等级为单位)
    # 晴天: 倾向升温; 阴雨: 倾向降温
    weather_temp_bias = [0.5, 0.0, -0.5]  # 晴/多云/阴雨

    # --- 每个生长阶段的最佳温度等级和推进概率 ---
    # 最佳温度 (0-4 对应严寒到酷热)
    optimal_temp = [2, 2, 2, 2]    # 四个阶段都偏好"适宜"
    # 在最佳温度下的阶段推进概率 (苗期→开花期较快，成熟期不再推进)
    advance_prob_optimal = [0.20, 0.15, 0.12, 0.0]
    # 偏离最佳温度1级: 推进概率减半; 偏离2级: 推进概率为1/4

    # --- 各动作的能耗成本 ---
    energy_cost = [8.0, 3.0, 0.0, 3.0, 8.0]

    # --- 温度-阶段适宜度奖励 ---
    # 每个阶段在不同温度等级下的生长质量评分
    growth_quality = np.array([
        # 严寒  偏冷  适宜  偏热  酷热    ← 温度等级
        [-5.0, 3.0, 10.0, 4.0, -3.0],   # 苗期
        [-8.0, 2.0, 12.0, 3.0, -6.0],   # 开花期 (对温度最敏感)
        [-4.0, 4.0,  9.0, 5.0, -2.0],   # 结果期
        [-3.0, 5.0,  8.0, 6.0, -1.0],   # 成熟期 (相对耐受)
    ])

    # 阶段推进奖励
    advance_reward = [15.0, 20.0, 25.0, 0.0]

    # --- 构建转移概率和奖励矩阵 ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        t, g, w = decode(s)
        for a in range(A):
            # 即时奖励
            R[s, a] = growth_quality[g, t] - energy_cost[a]

            # 温度转移
            base_shift = action_temp_shift[a] + weather_temp_bias[w]
            # 离散化: 以概率分配到相邻温度等级
            for w_next in range(n_weather):
                pw = weather_transition[w, w_next]

                # 温度变化 (带随机性)
                # 基于动作+天气，温度倾向移动 base_shift 级
                # 实际以概率分布在 [-1, 0, +1] 相对于 base_shift
                for dt in [-1, 0, 1]:
                    if dt == 0:
                        p_dt = 0.5
                    else:
                        p_dt = 0.25
                    target_t_raw = t + action_temp_shift[a] + dt
                    # 天气扰动
                    if w_next == 0:  # 晴天: 额外概率升温
                        target_t_raw += (1 if rng.rand() < 0.3 else 0)
                    elif w_next == 2:  # 阴雨: 额外概率降温
                        target_t_raw -= (1 if rng.rand() < 0.3 else 0)
                    target_t = max(0, min(n_temp - 1, int(round(target_t_raw))))

                    # 生长阶段推进
                    temp_dist = abs(t - optimal_temp[g])
                    adv_p = advance_prob_optimal[g] / (2 ** temp_dist)
                    adv_p = min(adv_p, 0.5)

                    g_next = min(g + 1, n_growth - 1)
                    # 两种情况: 推进 / 不推进
                    if g < n_growth - 1:
                        s_advance = encode(target_t, g_next, w_next)
                        s_stay = encode(target_t, g, w_next)
                        P[s, a, s_advance] += pw * p_dt * adv_p
                        P[s, a, s_stay] += pw * p_dt * (1 - adv_p)
                    else:
                        s_stay = encode(target_t, g, w_next)
                        P[s, a, s_stay] += pw * p_dt

            # 归一化 (确保概率和为1)
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

            # 阶段推进的期望奖励附加到 R (近似)
            if g < n_growth - 1:
                temp_dist = abs(t - optimal_temp[g])
                adv_p = advance_prob_optimal[g] / (2 ** temp_dist)
                R[s, a] += adv_p * advance_reward[g]

    state_names = []
    for s in range(S):
        t, g, w = decode(s)
        state_names.append(f"{temp_levels[t]}|{growth_stages[g]}|{weather_types[w]}")

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.97,
        'state_names': state_names, 'action_names': action_names,
        'n_temp': n_temp, 'n_growth': n_growth, 'n_weather': n_weather,
        'temp_levels': temp_levels, 'growth_stages': growth_stages,
        'weather_types': weather_types, 'decode': decode,
        'growth_quality': growth_quality, 'energy_cost': energy_cost,
    }

def problem1_greenhouse():
    """问题一: 智能温室气候调控 (Value Iteration)"""
    print("=" * 60)
    print("问题一: 智能温室气候调控 (农业MDP)")
    print("=" * 60)

    mdp = generate_greenhouse_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_temp']}温度 × {mdp['n_growth']}阶段 × {mdp['n_weather']}天气)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Value Iteration ---
    V, pi, hist = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration 收敛于 {len(hist)} 轮, 最终误差: {hist[-1]:.2e}")

    # --- 输出关键状态的最优策略 ---
    print(f"\n最优策略示例 (晴天条件下):")
    decode = mdp['decode']
    for g in range(mdp['n_growth']):
        print(f"  【{mdp['growth_stages'][g]}】")
        for t in range(mdp['n_temp']):
            s = t * mdp['n_growth'] * mdp['n_weather'] + g * mdp['n_weather'] + 0  # 晴天
            act = mdp['action_names'][pi[s]]
            print(f"    {mdp['temp_levels'][t]:15s} → {act:6s}  (V={V[s]:.1f})")

    return mdp, V, pi, hist
```
