# 问题一：智能温室气候调控

原始标题：智能温室气候调控

【业务背景】
一家现代农业企业运营着一座种植番茄的智能玻璃温室（面积 2000 m²）。
温室配备了天然气加热系统、湿帘-风机降温系统和自动遮阳帘，但电力和
天然气费用高昂——高峰期单日能耗费用可达数千元。

番茄的生长质量对温度极为敏感，农学研究将温室温度划分为以下 5 个等级，
每个等级对番茄的影响截然不同：

  等级0 "严寒" (< 12°C):
      植株新陈代谢几乎停滞，持续 6 小时以上将造成不可逆冻害，
      叶片出现水渍状坏死斑。根系吸收能力降至正常的 20% 以下。

  等级1 "偏冷" (12-18°C):
      光合速率约为最佳状态的 50-70%，果实膨大缓慢但不会造成
      器质性损伤。夜间适度偏冷有助于糖分积累（昼夜温差效应）。

  等级2 "适宜" (18-26°C):
      番茄生长的黄金区间。光合作用效率最高，花粉活力充沛，
      坐果率可达 95% 以上。这是四个生长阶段共同偏好的最佳等级。

  等级3 "偏热" (26-32°C):
      白天短时偏热尚可接受（蒸腾作用加速但未达伤害阈值），
      但持续偏热会导致花粉管伸长受阻、坐果率降至 60%，
      果实着色不均匀，商品性下降。

  等级4 "酷热" (> 32°C):
      花粉活力急剧丧失，坐果率不足 30%。叶片气孔关闭，
      光合停止，严重时出现日灼（果皮白化、干缩）。
      持续酷热超过 4 小时将触发紧急降温预警。

番茄在 4 个生长阶段（苗期 → 开花期 → 结果期 → 成熟期）对温度的
敏感度各不相同。下表给出每个阶段在不同温度等级下的"生长质量评分"
（单位: 分/2小时，综合考量光合效率、坐果率、果实品质等因素）：

  生长质量评分矩阵 Q_growth[阶段][温度]:

              严寒    偏冷    适宜    偏热    酷热
  苗期        -5.0    3.0    10.0    4.0    -3.0
  开花期      -8.0    2.0    12.0    3.0    -6.0
  结果期      -4.0    4.0     9.0    5.0    -2.0
  成熟期      -3.0    5.0     8.0    6.0    -1.0

  解读: 开花期在严寒和酷热下惩罚最大（-8, -6），适宜时奖励最高（12）；
        成熟期最为耐受，即使偏热也能维持 6 分。

温室管理员每隔 2 小时做一次调控决策。可选动作及其**对温度等级的确定性
偏移量**（以等级为单位）和**能耗成本**（元/次）如下：

  调控措施及成本:
  动作     温度偏移    能耗成本
  强加热    +2 级      8.0 元
  弱加热    +1 级      3.0 元
  不干预     0 级      0.0 元
  弱降温    -1 级      3.0 元
  强降温    -2 级      8.0 元

  例: 当前温度"偏冷"(等级1)，执行"强加热"(+2)，确定性部分将温度
      推向等级3"偏热"，但实际落点还会受到天气随机扰动的影响。

根据历史记录，天气在相邻时段之间有一定延续性。晴天倾向
自我持续，阴雨天也有一定惯性。天气状态概率:

  下列矩阵的第 [i][j] 个原始表示从 i 天气转移到 j 天气的概率:

              晴天    多云    阴雨
  晴天        0.60    0.30    0.10
  多云        0.25    0.50    0.25
  阴雨        0.15    0.35    0.50

天气还会对温室温度产生**额外的随机扰动**——晴天时太阳辐射使温室升温
（偏移 +0.5 级趋势），阴雨天降温（偏移 -0.5 级趋势），多云无偏。
具体地，温度在确定性偏移后，还会以概率分布 {-1级: 0.25, 0级: 0.50,
+1级: 0.25} 进一步随机波动，且晴天/阴雨时有额外 30% 概率再叠加
±1级扰动。最终温度截断在 [0, 4] 区间内。

生长阶段以一定概率向前推进。在最佳温度（等级2"适宜"）下推进概率最大，
偏离最佳温度 k 级后推进概率减半 k 次。具体参数:

  阶段推进参数:
  当前阶段     最佳温度下推进概率    偏离k级推进概率        阶段推进带来的经营价值
  苗期→开花期       0.20           0.20 / 2^k           15.0 分
  开花期→结果期     0.15           0.15 / 2^k           20.0 分
  结果期→成熟期     0.12           0.12 / 2^k           25.0 分
  成熟期(终态)       —              不再推进              —

  例: 开花期、温度等级为"偏冷"(距离适宜1级), 推进概率 = 0.15/2 = 0.075。

---

## 评分 Rubric

**PF Validity Score**: TD.1=0.5, TD.2=0.5, TD.3=1.0, TD.4=0.5, Overall=0.625

### Problem Analysis

这是一个离散时间、离散状态的温室滚动控制问题。决策是每 2 小时选择加热、降温或不干预；系统状态应至少包含温度等级、生长阶段和天气。目标是在作物生长质量、能耗成本和阶段推进价值之间做长期权衡。

主要陷阱是不能只做“低温加热、高温降温”的静态规则。天气有持续性，温度有随机扰动，强加热或强降温可能过度修正；生长阶段推进概率还依赖温度与最佳温度的距离。

### Evaluation Rubric

| No. | Dimension | Checkpoint | Pass Criteria | Fail Criteria | Severity |
|:---:|-----------|------------|---------------|---------------|:--------:|
| 1 | Problem Type Identification | 识别为动态随机控制问题 | 明确这是多周期温室控制，当前决策影响未来温度、天气组合和作物阶段 | 当成单期打分、静态分类或简单规则表 | Critical |
| 2 | Problem Type Identification | 正确识别决策变量 | 决策为每个决策时点/业务状态下选择强加热、弱加热、不干预、弱降温或强降温 | 把温度、天气或生长阶段误当成可直接选择的决策 | Critical |
| 3 | Objective Function Understanding | 正确组合经营目标 | 同时纳入生长质量评分、能耗成本和阶段推进经营价值，并以长期累计表现为目标 | 只最大化即时温度适宜度，或忽略能耗/推进价值 | Critical |
| 4 | Constraint Formulation | 保留温度边界和动作偏移 | 明确温度等级受动作偏移和扰动影响，并截断在 0 到 4 | 允许温度越界或忽略强/弱动作差异 | Major |
| 5 | Dynamic / Uncertainty Handling | 正确处理天气持续性 | 使用给定天气切换概率，而不是把天气视为独立同分布或确定不变 | 忽略天气演化，或只用当前天气做静态判断 | Major |
| 6 | Dynamic / Uncertainty Handling | 正确处理温度随机扰动 | 纳入基础 {-1,0,+1} 扰动及晴天/阴雨额外扰动 | 只用动作确定性偏移决定下期温度 | Major |
| 7 | Constraint Formulation | 正确处理生长阶段推进 | 阶段推进概率随距离最佳温度的级差按 2^k 衰减，成熟期不再推进 | 阶段固定不变，或推进概率与温度无关 | Major |
| 8 | Solution Approach | 方法匹配动态随机结构 | 可用动态规划、值迭代、策略迭代或等价有限状态控制方法，并说明状态枚举和期望计算 | 用线性回归、贪心规则或连续优化替代且无合理化 | Major |

### Expected Failure Modes

- 只根据当前温度选动作，忽略天气和阶段。
- 把天气扰动当成确定性偏移。
- 忽略能耗成本，导致总是强加热或强降温。
- 把成熟期继续向后推进。

---

# 参考答案

# 问题一解答：智能温室气候调控

> 来源：`mdp_problems_part1.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    """
    值迭代算法。

    参数
    ----
    S : int  状态数
    A : int  动作数
    P : np.ndarray, shape (S, A, S)  转移概率 P[s,a,s']
    R : np.ndarray, shape (S, A)     即时奖励 R[s,a]
    gamma : float  折扣因子
    tol : float    收敛阈值
    max_iter : int 最大迭代次数

    返回
    ----
    V : np.ndarray, shape (S,)   最优值函数
    pi : np.ndarray, shape (S,)  最优策略 (每个状态的最优动作索引)
    history : list               每轮迭代的 max|V_new - V_old|
    """
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)            # shape (S, A)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history
```

## 题目专属实现

```python
def generate_greenhouse_data(seed=42):
    """
    生成智能温室气候调控的 MDP 数据。

    返回
    ----
    mdp : dict
        包含 S, A, P, R, gamma, state_names, action_names, state_info 等信息。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间定义 ---
    temp_levels = ["严寒(<12°C)", "偏冷(12-18°C)", "适宜(18-26°C)", "偏热(26-32°C)", "酷热(>32°C)"]
    growth_stages = ["苗期", "开花期", "结果期", "成熟期"]
    weather_types = ["晴天", "多云", "阴雨"]

    n_temp = len(temp_levels)
    n_growth = len(growth_stages)
    n_weather = len(weather_types)
    S = n_temp * n_growth * n_weather  # 60

    # 动作空间
    action_names = ["强加热", "弱加热", "不干预", "弱降温", "强降温"]
    A = len(action_names)

    # --- 辅助函数: 状态编码/解码 ---
    def encode(t, g, w):
        return t * n_growth * n_weather + g * n_weather + w

    def decode(s):
        t = s // (n_growth * n_weather)
        rem = s % (n_growth * n_weather)
        g = rem // n_weather
        w = rem % n_weather
        return t, g, w

    # --- 天气转移矩阵 (天气之间的马尔可夫链) ---
    # 晴天倾向持续，但可能变多云；阴雨不太持久
    weather_transition = np.array([
        [0.60, 0.30, 0.10],   # 晴 → 晴/多云/阴雨
        [0.25, 0.50, 0.25],   # 多云 → ...
        [0.15, 0.35, 0.50],   # 阴雨 → ...
    ])

    # --- 温度转移: 取决于 (当前温度, 动作, 天气) ---
    # 动作对温度的影响: 强加热+2, 弱加热+1, 不干预0, 弱降温-1, 强降温-2
    action_temp_shift = [2, 1, 0, -1, -2]
    # 天气对温度的随机扰动分布 (以温度等级为单位)
    # 晴天: 倾向升温; 阴雨: 倾向降温
    weather_temp_bias = [0.5, 0.0, -0.5]  # 晴/多云/阴雨

    # --- 每个生长阶段的最佳温度等级和推进概率 ---
    # 最佳温度 (0-4 对应严寒到酷热)
    optimal_temp = [2, 2, 2, 2]    # 四个阶段都偏好"适宜"
    # 在最佳温度下的阶段推进概率 (苗期→开花期较快，成熟期不再推进)
    advance_prob_optimal = [0.20, 0.15, 0.12, 0.0]
    # 偏离最佳温度1级: 推进概率减半; 偏离2级: 推进概率为1/4

    # --- 各动作的能耗成本 ---
    energy_cost = [8.0, 3.0, 0.0, 3.0, 8.0]

    # --- 温度-阶段适宜度奖励 ---
    # 每个阶段在不同温度等级下的生长质量评分
    growth_quality = np.array([
        # 严寒  偏冷  适宜  偏热  酷热    ← 温度等级
        [-5.0, 3.0, 10.0, 4.0, -3.0],   # 苗期
        [-8.0, 2.0, 12.0, 3.0, -6.0],   # 开花期 (对温度最敏感)
        [-4.0, 4.0,  9.0, 5.0, -2.0],   # 结果期
        [-3.0, 5.0,  8.0, 6.0, -1.0],   # 成熟期 (相对耐受)
    ])

    # 阶段推进奖励
    advance_reward = [15.0, 20.0, 25.0, 0.0]

    # --- 构建转移概率和奖励矩阵 ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        t, g, w = decode(s)
        for a in range(A):
            # 即时奖励
            R[s, a] = growth_quality[g, t] - energy_cost[a]

            # 温度转移
            base_shift = action_temp_shift[a] + weather_temp_bias[w]
            # 离散化: 以概率分配到相邻温度等级
            for w_next in range(n_weather):
                pw = weather_transition[w, w_next]

                # 温度变化 (带随机性)
                # 基于动作+天气，温度倾向移动 base_shift 级
                # 实际以概率分布在 [-1, 0, +1] 相对于 base_shift
                for dt in [-1, 0, 1]:
                    if dt == 0:
                        p_dt = 0.5
                    else:
                        p_dt = 0.25
                    target_t_raw = t + action_temp_shift[a] + dt
                    # 天气扰动
                    if w_next == 0:  # 晴天: 额外概率升温
                        target_t_raw += (1 if rng.rand() < 0.3 else 0)
                    elif w_next == 2:  # 阴雨: 额外概率降温
                        target_t_raw -= (1 if rng.rand() < 0.3 else 0)
                    target_t = max(0, min(n_temp - 1, int(round(target_t_raw))))

                    # 生长阶段推进
                    temp_dist = abs(t - optimal_temp[g])
                    adv_p = advance_prob_optimal[g] / (2 ** temp_dist)
                    adv_p = min(adv_p, 0.5)

                    g_next = min(g + 1, n_growth - 1)
                    # 两种情况: 推进 / 不推进
                    if g < n_growth - 1:
                        s_advance = encode(target_t, g_next, w_next)
                        s_stay = encode(target_t, g, w_next)
                        P[s, a, s_advance] += pw * p_dt * adv_p
                        P[s, a, s_stay] += pw * p_dt * (1 - adv_p)
                    else:
                        s_stay = encode(target_t, g, w_next)
                        P[s, a, s_stay] += pw * p_dt

            # 归一化 (确保概率和为1)
            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

            # 阶段推进的期望奖励附加到 R (近似)
            if g < n_growth - 1:
                temp_dist = abs(t - optimal_temp[g])
                adv_p = advance_prob_optimal[g] / (2 ** temp_dist)
                R[s, a] += adv_p * advance_reward[g]

    state_names = []
    for s in range(S):
        t, g, w = decode(s)
        state_names.append(f"{temp_levels[t]}|{growth_stages[g]}|{weather_types[w]}")

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.97,
        'state_names': state_names, 'action_names': action_names,
        'n_temp': n_temp, 'n_growth': n_growth, 'n_weather': n_weather,
        'temp_levels': temp_levels, 'growth_stages': growth_stages,
        'weather_types': weather_types, 'decode': decode,
        'growth_quality': growth_quality, 'energy_cost': energy_cost,
    }

def problem1_greenhouse():
    """问题一: 智能温室气候调控 (Value Iteration)"""
    print("=" * 60)
    print("问题一: 智能温室气候调控 (农业MDP)")
    print("=" * 60)

    mdp = generate_greenhouse_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_temp']}温度 × {mdp['n_growth']}阶段 × {mdp['n_weather']}天气)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")
    print(f"折扣因子: γ = {gamma}")

    # --- Value Iteration ---
    V, pi, hist = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration 收敛于 {len(hist)} 轮, 最终误差: {hist[-1]:.2e}")

    # --- 输出关键状态的最优策略 ---
    print(f"\n最优策略示例 (晴天条件下):")
    decode = mdp['decode']
    for g in range(mdp['n_growth']):
        print(f"  【{mdp['growth_stages'][g]}】")
        for t in range(mdp['n_temp']):
            s = t * mdp['n_growth'] * mdp['n_weather'] + g * mdp['n_weather'] + 0  # 晴天
            act = mdp['action_names'][pi[s]]
            print(f"    {mdp['temp_levels'][t]:15s} → {act:6s}  (V={V[s]:.1f})")

    return mdp, V, pi, hist
```
