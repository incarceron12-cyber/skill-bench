# sdp2 问题二 手术室医疗设备定位

## 3. 分析与解法

### 【数学建模 — 为什么是 SDP？】

设节点 i（基站或设备）的位置为 p\_i ∈ R²。距离约束:

‖p\_i − p\_j‖² = d\_ij²

定义增广矩阵 Z ∈ R^{(n+2)×(n+2)}, Z ⪰ 0，其中：

- 左上 n×n 块 = Gram 矩阵 G = P·Pᵀ
- 右上 n×2 块 = P（位置坐标）
- 右下 2×2 块 = I₂

基站坐标已知作为硬约束，距离测量的平方残差作为目标函数最小化。

SDP 求解后直接从 Z 的右上块读取所有设备坐标。

### 求解函数

```python
def problem2_operating_room_localization():
    """问题二: 手术室医疗设备定位"""
    print("\n" + "=" * 60)
    print("问题二: 手术室医疗设备定位 (传感器定位SDP)")
    print("=" * 60)

    # --- 数据 ---
    anchors, true_positions, edges, device_names = generate_operating_room_data(
        n_anchors=5, n_devices=6, room_w=8.0, room_h=6.0,
        noise_anchor=0.10, noise_device=0.20,
        nlos_prob=0.15, nlos_bias=0.5, comm_range=5.0, seed=42
    )
    n_anchors = len(anchors)
    n_devices = len(true_positions)
    n = n_anchors + n_devices

    print(f"\n手术室尺寸: 8m × 6m")
    print(f"UWB基站数: {n_anchors}, 移动设备数: {n_devices}")
    print(f"测距数据量: {len(edges)}")
    print(f"设备列表: {device_names}")
    print(f"基站坐标:")
    for i, a in enumerate(anchors):
        print(f"  基站{i+1}: ({a[0]:.2f}, {a[1]:.2f})")

    # --- SDP建模 ---
    m = n + 2
    Z = cp.Variable((m, m), symmetric=True)

    constraints = [Z >> 0]

    # 右下角 2×2 = 单位矩阵
    constraints.append(Z[n, n] == 1)
    constraints.append(Z[n + 1, n + 1] == 1)
    constraints.append(Z[n, n + 1] == 0)

    # 基站位置已知
    for i in range(n_anchors):
        constraints.append(Z[i, n] == anchors[i, 0])
        constraints.append(Z[i, n + 1] == anchors[i, 1])

    # 距离约束

    obj_terms = [ ]

    for (i, j, d_meas) in edges:
        est_dist_sq = Z[i, i] + Z[j, j] - 2 * Z[i, j]
        obj_terms.append(cp.square(est_dist_sq - d_meas ** 2))

    objective = cp.Minimize(cp.sum(obj_terms))

    # --- 求解 ---
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS)

    print(f"\n求解状态: {prob.status}")
    print(f"最优值: {prob.value:.4f}")

    # --- 读取位置 ---
    Z_opt = Z.value
    est_all = Z_opt[:n, n:n + 2]
    est_devices = est_all[n_anchors:]

    errors = np.linalg.norm(est_devices - true_positions, axis=1)

    print(f"\n定位结果:")
    for i in range(n_devices):
        print(f"  {device_names[i]}: 真实=({true_positions[i,0]:.2f}, {true_positions[i,1]:.2f}), "
              f"估计=({est_devices[i,0]:.2f}, {est_devices[i,1]:.2f}), "
              f"误差={errors[i]:.3f}m")
    print(f"  平均误差: {np.mean(errors):.3f}m")
    meets_requirement = np.all(errors < 0.5)
    print(f"  是否满足 <0.5m 精度要求: {'是' if meets_requirement else '否'}")

    return anchors, true_positions, est_devices, edges, errors, device_names
```
