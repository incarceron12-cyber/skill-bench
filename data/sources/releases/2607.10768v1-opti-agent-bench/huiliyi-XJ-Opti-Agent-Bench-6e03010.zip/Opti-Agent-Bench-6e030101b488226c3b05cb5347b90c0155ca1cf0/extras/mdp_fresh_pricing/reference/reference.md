# 问题五解答：生鲜动态定价与库存管理

> 来源：`mdp_problems_part2.py`

## 解答内容说明

本文件将该题对应的求解代码单独整理为 `markdown`，包含本题所依赖的通用求解器，以及题目专属的数据构造与求解函数。

## 通用求解器

```python
import numpy as np

def value_iteration(S, A, P, R, gamma=0.99, tol=1e-6, max_iter=5000):
    V = np.zeros(S)
    history = []
    for it in range(max_iter):
        Q = R + gamma * (P @ V)
        V_new = np.max(Q, axis=1)
        diff = np.max(np.abs(V_new - V))
        history.append(diff)
        V = V_new
        if diff < tol:
            break
    pi = np.argmax(R + gamma * (P @ V), axis=1)
    return V, pi, history

def q_learning(S, A, P, R, gamma=0.99, alpha=0.05, epsilon=0.15,
               n_episodes=30000, max_steps=300, seed=42):
    rng = np.random.RandomState(seed)
    Q = np.zeros((S, A))
    rewards_history = []
    # 衰减学习率和探索率
    for ep in range(n_episodes):
        s = rng.randint(S)
        total_reward = 0
        lr = alpha / (1 + ep * 0.0001)
        eps = max(0.01, epsilon * (1 - ep / n_episodes))
        for step in range(max_steps):
            if rng.rand() < eps:
                a = rng.randint(A)
            else:
                a = np.argmax(Q[s])
            s_next = rng.choice(S, p=P[s, a])
            r = R[s, a]
            total_reward += (gamma ** step) * r
            Q[s, a] += lr * (r + gamma * np.max(Q[s_next]) - Q[s, a])
            s = s_next
        rewards_history.append(total_reward)
    V = np.max(Q, axis=1)
    pi = np.argmax(Q, axis=1)
    return V, pi, rewards_history
```

## 题目专属实现

```python
def generate_fresh_food_data(seed=42):
    """
    生成生鲜动态定价与库存管理的 MDP 数据。
    """
    rng = np.random.RandomState(seed)

    # --- 状态空间 ---
    inv_levels = ["缺货", "低库存", "中库存", "高库存", "过剩"]
    demand_periods = ["淡季(工作日)", "旺季(周末)", "爆发(节假日)"]
    freshness_levels = ["新鲜(Day1)", "次新(Day2)", "临期(Day3)"]

    n_inv = len(inv_levels)
    n_demand = len(demand_periods)
    n_fresh = len(freshness_levels)
    S = n_inv * n_demand * n_fresh  # 45

    # 联合动作: (定价, 补货)
    action_names = [
        "原价·不补货", "原价·小批补货", "原价·大批补货",
        "折扣·不补货", "折扣·小批补货", "清仓·不补货"
    ]
    A = len(action_names)

    # 动作参数
    price_mult = [1.0, 1.0, 1.0, 0.8, 0.8, 0.5]    # 定价倍率
    restock = [0, 1, 2, 0, 1, 0]                      # 补货量 (以库存等级为单位)
    demand_boost = [1.0, 1.0, 1.0, 1.4, 1.4, 2.0]    # 折扣对需求的刺激

    def encode(inv, dem, fr):
        return inv * n_demand * n_fresh + dem * n_fresh + fr

    def decode(s):
        inv = s // (n_demand * n_fresh)
        rem = s % (n_demand * n_fresh)
        dem = rem // n_fresh
        fr = rem % n_fresh
        return inv, dem, fr

    # --- 基础需求 (以库存等级为单位) ---
    base_demand = [1.0, 1.8, 3.0]  # 淡/旺/爆发

    # --- 需求周期转移 ---
    demand_trans = np.array([
        [0.65, 0.30, 0.05],   # 淡季 → ...
        [0.50, 0.35, 0.15],   # 旺季 → ...
        [0.60, 0.25, 0.15],   # 爆发 → ...
    ])

    # --- 经济参数 ---
    unit_revenue = 15.0      # 原价单位收入
    unit_cost = 8.0           # 进货单位成本
    holding_cost = 1.5        # 库存持有成本/天/级
    waste_penalty = 12.0      # 报废损失/单位
    stockout_penalty = 5.0    # 缺货惩罚 (失去顾客)

    # --- 构建 P 和 R ---
    P = np.zeros((S, A, S))
    R = np.zeros((S, A))

    for s in range(S):
        inv, dem, fr = decode(s)
        for a in range(A):
            # --- 奖励计算 ---
            # 可售量 = 当前库存
            demand = base_demand[dem] * demand_boost[a]
            sales = min(inv, demand)  # 实际销量
            revenue = sales * unit_revenue * price_mult[a]
            restock_cost = restock[a] * unit_cost
            holding = max(0, inv - sales) * holding_cost

            # 临期报废
            waste = 0
            if fr == 2:  # 临期
                unsold = max(0, inv - sales)
                waste = unsold * waste_penalty * 0.5  # 部分报废

            # 缺货惩罚
            stockout = max(0, demand - inv) * stockout_penalty if inv == 0 else 0

            R[s, a] = revenue - restock_cost - holding - waste - stockout

            # --- 状态转移 ---
            # 库存变化: 当前 - 销售 + 补货
            inv_after = inv - int(round(sales)) + restock[a]

            # 新鲜度: 每天降一级 (补货的是新鲜的，混合后取加权)
            if restock[a] > 0:
                fr_next_base = 0  # 补货后有新鲜品
            else:
                fr_next_base = min(fr + 1, n_fresh - 1)  # 老化

            for dem_next in range(n_demand):
                pd = demand_trans[dem, dem_next]

                # 库存随机性 (需求波动)
                for inv_delta in [-1, 0, 1]:
                    if inv_delta == 0:
                        p_inv = 0.5
                    elif inv_delta == -1:
                        p_inv = 0.30 if dem >= 1 else 0.15  # 旺季需求更大
                    else:
                        p_inv = 0.20 if restock[a] > 0 else 0.05
                    inv_next = max(0, min(n_inv - 1, inv_after + inv_delta))

                    # 新鲜度: 有补货时混合新鲜度
                    for fr_delta in [0, 1]:
                        if fr_delta == 0:
                            p_fr = 0.7
                        else:
                            p_fr = 0.3
                        fr_next = max(0, min(n_fresh - 1, fr_next_base + fr_delta))

                        s_next = encode(inv_next, dem_next, fr_next)
                        P[s, a, s_next] += pd * p_inv * p_fr

            row_sum = P[s, a].sum()
            if row_sum > 0:
                P[s, a] /= row_sum

    state_names = [f"{inv_levels[i]}|{demand_periods[d]}|{freshness_levels[f]}"
                   for i in range(n_inv) for d in range(n_demand) for f in range(n_fresh)]

    return {
        'S': S, 'A': A, 'P': P, 'R': R, 'gamma': 0.98,
        'state_names': state_names, 'action_names': action_names,
        'n_inv': n_inv, 'n_demand': n_demand, 'n_fresh': n_fresh,
        'inv_levels': inv_levels, 'demand_periods': demand_periods,
        'freshness_levels': freshness_levels, 'decode': decode,
    }

def problem5_fresh_food():
    """问题五: 生鲜动态定价与库存 (VI vs Q-Learning)"""
    print("\n" + "=" * 60)
    print("问题五: 生鲜动态定价与库存管理 (零售MDP)")
    print("=" * 60)

    mdp = generate_fresh_food_data(seed=42)
    S, A, P, R = mdp['S'], mdp['A'], mdp['P'], mdp['R']
    gamma = mdp['gamma']

    print(f"\n状态空间: {S} 个状态 ({mdp['n_inv']}库存 × {mdp['n_demand']}需求期 × {mdp['n_fresh']}新鲜度)")
    print(f"动作空间: {A} 个动作 {mdp['action_names']}")

    # --- Value Iteration ---
    V_vi, pi_vi, hist_vi = value_iteration(S, A, P, R, gamma)
    print(f"\nValue Iteration: {len(hist_vi)} 轮收敛")

    # --- Q-Learning ---
    V_ql, pi_ql, ql_rewards = q_learning(S, A, P, R, gamma,
                                          alpha=0.06, epsilon=0.15,
                                          n_episodes=35000, max_steps=200, seed=42)
    policy_match = np.sum(pi_vi == pi_ql)
    print(f"Q-Learning: 35000 episodes")
    print(f"策略一致率: {policy_match}/{S} ({policy_match/S:.0%})")

    # --- 输出策略 ---
    print(f"\n最优定价-补货策略 (VI, 新鲜商品):")
    decode = mdp['decode']
    for dem in range(mdp['n_demand']):
        print(f"  【{mdp['demand_periods'][dem]}】")
        for inv in range(mdp['n_inv']):
            s = inv * mdp['n_demand'] * mdp['n_fresh'] + dem * mdp['n_fresh'] + 0  # 新鲜
            act = mdp['action_names'][pi_vi[s]]
            print(f"    {mdp['inv_levels'][inv]:8s} → {act:14s}  (V={V_vi[s]:.1f})")

    return mdp, V_vi, pi_vi, hist_vi, V_ql, pi_ql, ql_rewards
```
