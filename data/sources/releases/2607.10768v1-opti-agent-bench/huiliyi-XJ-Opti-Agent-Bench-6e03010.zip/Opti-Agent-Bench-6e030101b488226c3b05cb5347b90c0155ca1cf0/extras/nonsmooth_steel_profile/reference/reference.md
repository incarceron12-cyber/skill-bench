## 问题二：钢板轧制厚度轮廓修复 — Total Variation 去噪（制造）

### 数学建模 — 为什么是非光滑优化？

一维 TV 去噪 (Rudin-Osher-Fatemi 模型):

min_x  (1/2) ‖x − y‖₂²  +  λ · TV(x)

其中:
- y ∈ R^n: 带噪测量信号 (n=200 个测点)
- x ∈ R^n: 待恢复的真实厚度轮廓
- TV(x) = Σ_{i=1}^{n-1} |x_{i+1} − x_i|: 全变分 (Total Variation)
- λ > 0: 正则化参数 (λ越大越平滑, λ越小越贴近原始数据)

**非光滑性分析：**
- TV(x) = ‖Dx‖₁, 其中 D ∈ R^{(n-1)×n} 是一阶差分矩阵:
    D = [[-1,1,0,...], [0,-1,1,...], ...]
- ‖Dx‖₁ = Σ|x_{i+1} - x_i| 在任何 x_{i+1} = x_i 处不可微
- 目标函数 = 光滑二次项 + 非光滑 L1 项（作用在差分域上）

### 求解方法

**方法 A — ADMM (Alternating Direction Method of Multipliers):**

将问题拆分为:
  min_x  (1/2)‖x-y‖₂² + λ‖z‖₁  s.t. Dx = z

ADMM 迭代:
  x ← (I + ρ DᵀD)⁻¹ (y + ρ Dᵀ(z - u))
  z ← prox_{(λ/ρ)‖·‖₁}(Dx + u)
  u ← u + Dx - z

其中 ρ > 0 是增广 Lagrange 乘子参数。利用 D 的三对角结构, x 步可用 O(n) 的 Thomas 算法高效求解。

**方法 B — CVXPY 精确求解 (基准)。**

### 求解代码

```python
def solve_tv_admm(y, D, lam, rho=1.0, max_iter=1000, tol=1e-5):
    """ADMM 求解 1D TV 去噪。"""
    n = len(y)
    m = D.shape[0]

    # 预计算: (I + ρ DᵀD)⁻¹ — 利用矩阵较小直接求逆
    DtD = D.T @ D
    M_inv = np.linalg.inv(np.eye(n) + rho * DtD)

    x = y.copy()
    z = np.zeros(m)
    u = np.zeros(m)
    history = []

    for k in range(max_iter):
        # x 步
        x = M_inv @ (y + rho * D.T @ (z - u))
        # z 步
        Dx = D @ x
        z_new = prox_l1(Dx + u, lam / rho)
        # u 步
        u = u + Dx - z_new

        # 目标值
        obj = 0.5 * np.sum((x - y) ** 2) + lam * np.sum(np.abs(D @ x))
        history.append(obj)

        # 收敛检查
        if np.linalg.norm(z_new - z) < tol:
            break
        z = z_new

    return x, history


def solve_tv_cvxpy(y, D, lam):
    """CVXPY 精确求解 TV 去噪。"""
    n = len(y)
    x = cp.Variable(n)
    objective = cp.Minimize(0.5 * cp.sum_squares(x - y) + lam * cp.norm1(D @ x))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return x.value, prob.value
```

### 问题执行函数

```python
def problem2_steel_tv():
    """问题二: 钢板轧制厚度轮廓修复 (TV去噪)"""
    print("\n" + "=" * 60)
    print("问题二: 钢板轧制厚度轮廓修复 (TV去噪)")
    print("=" * 60)

    y, x_true, D, lam, positions = generate_steel_thickness_data()
    n = len(y)

    print(f"\n测量点数: {n}")
    print(f"噪声标准差: 0.04 mm")
    print(f"正则化参数 λ = {lam}")
    print(f"阶跃位置: 40, 90, 130, 170")

    # --- ADMM ---
    t0 = time.time()
    x_admm, hist_admm = solve_tv_admm(y, D, lam, rho=1.0)
    t_admm = time.time() - t0
    err_admm = np.linalg.norm(x_admm - x_true) / np.linalg.norm(x_true)

    # --- CVXPY ---
    t0 = time.time()
    x_cvx, obj_cvx = solve_tv_cvxpy(y, D, lam)
    t_cvx = time.time() - t0
    err_cvx = np.linalg.norm(x_cvx - x_true) / np.linalg.norm(x_true)

    err_noisy = np.linalg.norm(y - x_true) / np.linalg.norm(x_true)

    print(f"\n{'方法':<10} {'目标值':<14} {'相对误差':<12} {'耗时':<10}")
    print("-" * 46)
    print(f"{'原始噪声':<10} {'—':<14} {err_noisy:<12.6f} {'—':<10}")
    print(f"{'ADMM':<10} {hist_admm[-1]:<14.6f} {err_admm:<12.6f} {t_admm:.3f}s")
    print(f"{'CVXPY':<10} {obj_cvx:<14.6f} {err_cvx:<12.6f} {t_cvx:.3f}s")

    return y, x_true, x_admm, x_cvx, positions, hist_admm
```

---
