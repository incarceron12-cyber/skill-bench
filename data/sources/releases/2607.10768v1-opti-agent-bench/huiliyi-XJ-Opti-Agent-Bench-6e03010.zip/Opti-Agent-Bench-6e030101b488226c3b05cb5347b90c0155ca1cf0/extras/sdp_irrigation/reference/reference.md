# sdp2 问题一 精准灌溉分区调度

## 3. 分析与解法

### 【数学建模 — 为什么是 SDP？】

这是经典的 Max-Cut（最大割）问题：

- 每块地块是图中的一个节点，分配标签 x\_i ∈ {+1, -1}（早班或晚班）。
- 相邻地块之间沟渠的水交换效率为边权重 W\[i\]\[j\]。
- 若 x\_i ≠ x\_j（分在不同批次），边 (i,j) 被"切割"，贡献 W\[i\]\[j\]。

目标函数:

max Σ\_{i<j} W\[i\]\[j\] · (1 - x\_i · x\_j) / 2

引入矩阵变量 X = x · xᵀ，约束 X\[i\]\[i\] = 1, X ⪰ 0。

去掉 rank(X) = 1 约束得到 SDP 松弛，再用 Goemans-Williamson
随机化舍入恢复可行解。

### 求解函数

```python
def problem1_irrigation_partition():
    """问题一: 精准灌溉分区调度"""
    print("=" * 60)
    print("问题一: 精准灌溉分区调度 (Max-Cut SDP松弛)")
    print("=" * 60)

    # --- 数据 ---
    fields, W, zones, positions = generate_irrigation_data(n=14, seed=42)
    n = len(fields)

    print(f"\n地块数量: {n}")
    print(f"灌溉组分布: {zones}")
    n_edges = np.sum(W > 0) // 2
    print(f"沟渠连接数: {n_edges}")
    print(f"总水交换效率: {np.sum(W) / 2:.0f} 立方米/小时")

    # --- SDP建模 ---
    X = cp.Variable((n, n), symmetric=True)

    constraints = [X >> 0]
    for i in range(n):
        constraints.append(X[i, i] == 1)

    objective = cp.Maximize(0.25 * (np.sum(W) - cp.trace(W @ X)))

    # --- 求解 ---
    prob = cp.Problem(objective, constraints)
    prob.solve(solver=cp.SCS)

    print(f"\n求解状态: {prob.status}")
    print(f"SDP松弛最优值 (跨批次水交换效率上界): {prob.value:.2f}")

    # --- Goemans-Williamson 随机化舍入 ---
    X_opt = X.value
    eigvals, eigvecs = np.linalg.eigh(X_opt)
    eigvals = np.maximum(eigvals, 0)
    V = eigvecs @ np.diag(np.sqrt(eigvals))

    best_cut = -1
    best_assignment = None

    for trial in range(500):
        r = np.random.randn(n)
        assignment = np.sign(V @ r)
        assignment[assignment == 0] = 1

        cut_value = 0
        for i in range(n):
            for j in range(i + 1, n):
                if assignment[i] != assignment[j]:
                    cut_value += W[i, j]

        if cut_value > best_cut:
            best_cut = cut_value
            best_assignment = assignment.copy()

    morning = [fields[i] for i in range(n) if best_assignment[i] > 0]
    afternoon = [fields[i] for i in range(n) if best_assignment[i] < 0]

    print(f"\n最佳灌溉调度方案:")
    print(f"  早班 (6:00-12:00): {morning}")
    print(f"  晚班 (12:00-18:00): {afternoon}")
    print(f"  跨批次水交换效率: {best_cut:.0f} 立方米/小时")
    print(f"  近似比: {best_cut / prob.value:.2%}")

    return W, X_opt, best_assignment, fields, zones, positions, prob.value, best_cut
```
