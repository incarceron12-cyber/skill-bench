### 参考解答（来自 nonsmooth_part2_解答.md）

#### 数学建模 — 为什么是非光滑优化？

Huber 回归 (Huber Regression):

min_w  (1/n) Σ_{i=1}^n  H_δ(d_i − (Aw)_i)  +  (μ/2) ‖w‖₂²

其中 Huber 损失函数:

H_δ(u) = (1/2) u²           当 |u| ≤ δ
        = δ(|u| - δ/2)      当 |u| > δ

非光滑性分析:
- H_δ(u) 在 u = ±δ 处的**一阶导数是连续的**:
  - H_δ'(u) = u     当 |u| ≤ δ
  - H_δ'(u) = δ·sign(u) 当 |u| > δ
  - 所以 Huber 损失本身是可微的（只是二阶不可微）。
- 但从非光滑优化的视角, Huber 损失可以看作 (1/2)‖·‖₂² 和 δ‖·‖₁ 的 Moreau 包络的混合, 其近端算子有显式解。
- 更重要的是, 当 δ→0 时 Huber 退化为 L1 损失 (完全非光滑), δ→∞ 时退化为 L2 损失 (完全光滑)。因此 Huber 回归恰好处于光滑与非光滑优化的交界处, 是理解非光滑概念的绝佳案例。
- 与 L1 回归 (min ‖Aw-d‖₁) 做对比, 可以看到非光滑度的影响。

补充: 射束强度非负约束 w ≥ 0 (物理限制, 不能有负强度)。

#### 求解方法

**方法 A — 近端梯度下降 (Proximal Gradient for Huber + L2 + 非负约束):**

Huber 损失的梯度:
- ∇_w H_loss = -(1/n) Aᵀ · clip(d-Aw, -δ, δ)  (当 |residual| ≤ δ)
- ∇_w H_loss = -(1/n) Aᵀ · δ·sign(d-Aw)          (当 |residual| > δ)

组合: g = ∇_w Huber_loss + μ·w

投影: w ← max(w - step·g, 0)  (非负约束的投影)

**方法 B — L2 回归 (普通最小二乘, 对比基线):**

min ‖Aw-d‖₂² + μ‖w‖₂², w≥0

展示 L2 回归对离群值的敏感性。

**方法 C — CVXPY 精确求解 (Huber + 非负约束, 基准)。**

#### 求解代码

```python
import numpy as np
import cvxpy as cp
import time


def huber_loss(u, delta):
    """Huber 损失函数 (向量化)。"""
    abs_u = np.abs(u)
    return np.where(abs_u <= delta, 0.5 * u ** 2, delta * (abs_u - 0.5 * delta))


def huber_grad(u, delta):
    """Huber 损失对 u 的梯度 (向量化)。"""
    return np.clip(u, -delta, delta)


def solve_huber_proxgrad(A, d, delta, mu, max_iter=2000, tol=1e-6):
    """近端梯度下降求解 Huber 回归 (含非负约束)。"""
    n, p = A.shape
    L = np.linalg.norm(A.T @ A / n, 2) + mu  # Lipschitz 常数
    w = np.ones(p) * 0.1
    history = []

    for k in range(max_iter):
        residuals = d - A @ w
        # Huber 损失关于 w 的梯度
        grad_huber = -A.T @ huber_grad(residuals, delta) / n
        grad_reg = mu * w
        grad = grad_huber + grad_reg

        w_new = np.maximum(w - grad / L, 0)  # 投影到非负

        obj = np.sum(huber_loss(d - A @ w_new, delta)) / n + 0.5 * mu * np.sum(w_new ** 2)
        history.append(obj)

        if np.max(np.abs(w_new - w)) < tol:
            break
        w = w_new

    return w, history


def solve_l2_regression(A, d, mu):
    """普通 L2 回归 (对比基线), 带非负约束。"""
    n, p = A.shape
    w = cp.Variable(p, nonneg=True)
    objective = cp.Minimize(cp.sum_squares(A @ w - d) / n + 0.5 * mu * cp.sum_squares(w))
    prob = cp.Problem(objective)
    prob.solve(solver=cp.SCS)
    return w.value, prob.value


def solve_huber_cvxpy(A, d, delta, mu):
    """CVXPY 精确求解 Huber 回归 (基准)。"""
    n, p = A.shape
    w = cp.Variable(p, nonneg=True)
    residuals = d - A @ w
    loss = cp.sum(cp.huber(residuals, delta)) / n + 0.5 * mu * cp.sum_squares(w)
    prob = cp.Problem(cp.Minimize(loss))
    prob.solve(solver=cp.SCS)
    return w.value, prob.value
```

#### 问题执行函数

```python
def problem6_radiotherapy():
    """问题六: 放疗剂量鲁棒规划 (Huber回归)"""
    print("\n" + "=" * 60)
    print("问题六: 放疗剂量鲁棒规划 (Huber回归)")
    print("=" * 60)

    A, d, d_clean, delta, mu = generate_radiotherapy_data()
    n, p = A.shape
    n_outliers = np.sum(d != d_clean)

    print(f"\n体素数: {n}, 射束数: {p}")
    print(f"离群体素数: {n_outliers} ({n_outliers/n:.0%})")
    print(f"Huber δ = {delta}, 正则化 μ = {mu}")

    # --- 近端梯度 (Huber) ---
    t0 = time.time()
    w_huber, hist_huber = solve_huber_proxgrad(A, d, delta, mu)
    t_huber = time.time() - t0

    # --- L2 回归 (对比) ---
    t0 = time.time()
    w_l2, obj_l2 = solve_l2_regression(A, d, mu)
    t_l2 = time.time() - t0

    # --- CVXPY Huber (基准) ---
    t0 = time.time()
    w_cvx, obj_cvx = solve_huber_cvxpy(A, d, delta, mu)
    t_cvx = time.time() - t0

    # 评估: 用干净的处方剂量计算拟合误差
    dose_huber = A @ w_huber
    dose_l2 = A @ w_l2
    dose_cvx = A @ w_cvx

    # 靶区剂量偏差 (应接近 60 Gy)
    target_err_huber = np.mean(np.abs(dose_huber[:60] - 60))
    target_err_l2 = np.mean(np.abs(dose_l2[:60] - 60))
    target_err_cvx = np.mean(np.abs(dose_cvx[:60] - 60))

    # 危及器官超标量
    oar_excess_huber = np.mean(np.maximum(dose_huber[60:] - 15, 0))
    oar_excess_l2 = np.mean(np.maximum(dose_l2[60:] - 15, 0))
    oar_excess_cvx = np.mean(np.maximum(dose_cvx[60:] - 15, 0))

    print(f"\n{'方法':<12} {'靶区偏差(Gy)':<14} {'器官超标(Gy)':<14} {'耗时':<8}")
    print("-" * 48)
    print(f"{'Huber(近端)':<12} {target_err_huber:<14.2f} {oar_excess_huber:<14.2f} {t_huber:.3f}s")
    print(f"{'L2(最小二乘)':<12} {target_err_l2:<14.2f} {oar_excess_l2:<14.2f} {t_l2:.3f}s")
    print(f"{'Huber(CVXPY)':<12} {target_err_cvx:<14.2f} {oar_excess_cvx:<14.2f} {t_cvx:.3f}s")

    return A, d, d_clean, delta, w_huber, w_l2, w_cvx, hist_huber
```
