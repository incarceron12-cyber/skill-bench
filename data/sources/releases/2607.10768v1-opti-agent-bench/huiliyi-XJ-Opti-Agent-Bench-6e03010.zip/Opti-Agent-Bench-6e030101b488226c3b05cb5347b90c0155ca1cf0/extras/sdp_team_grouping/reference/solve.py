#!/usr/bin/env python3
from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path
from typing import Iterable, Sequence


ROOT = Path(__file__).resolve().parent.parent
DEFAULT_DATA = ROOT / "data" / "team_instance_large.json"


def load_instance(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def names(instance: dict) -> list[str]:
    return [employee["name"] for employee in instance["employees"]]


def departments(instance: dict) -> list[str]:
    return [employee["department"] for employee in instance["employees"]]


def seniority(instance: dict) -> list[str]:
    return [employee["seniority"] for employee in instance["employees"]]


def mentor_pairs(instance: dict) -> list[tuple[int, int]]:
    return [
        (int(pair["mentor_id"]), int(pair["mentee_id"]))
        for pair in instance["mentor_pairs"]
    ]


def objective(instance: dict, line_a: Iterable[int], line_b: Iterable[int]) -> int:
    w = instance["collaboration_matrix"]
    return int(sum(w[i][j] for i in line_a for j in line_b))


def check_feasible(instance: dict, line_a: Sequence[int]) -> tuple[bool, list[str]]:
    n = len(instance["employees"])
    constraints = instance["constraints"]
    deps = departments(instance)
    levels = seniority(instance)
    pairs = mentor_pairs(instance)
    a_set = set(line_a)
    b_set = set(range(n)) - a_set
    violations: list[str] = []

    if len(a_set) != len(line_a):
        violations.append("A line contains duplicate members")
    if not constraints["team_size_min"] <= len(a_set) <= constraints["team_size_max"]:
        violations.append(f"A line size is {len(a_set)}")
    if not constraints["team_size_min"] <= len(b_set) <= constraints["team_size_max"]:
        violations.append(f"B line size is {len(b_set)}")

    min_front = constraints["min_frontend_per_team"]
    min_senior = constraints["min_senior_per_team"]
    if sum(deps[i] == "前端" for i in a_set) < min_front:
        violations.append("A line lacks frontend coverage")
    if sum(deps[i] == "前端" for i in b_set) < min_front:
        violations.append("B line lacks frontend coverage")
    if sum(levels[i] == "高级" for i in a_set) < min_senior:
        violations.append("A line lacks senior engineers")
    if sum(levels[i] == "高级" for i in b_set) < min_senior:
        violations.append("B line lacks senior engineers")

    for mentor, mentee in pairs:
        if (mentor in a_set) != (mentee in a_set):
            violations.append(f"mentor pair split: {mentor}-{mentee}")

    return not violations, violations


def solve_exact(instance: dict) -> dict:
    n = len(instance["employees"])
    labels = names(instance)
    min_size = int(instance["constraints"]["team_size_min"])
    max_size = int(instance["constraints"]["team_size_max"])
    best_value = -1
    best_groups: list[tuple[list[int], list[int]]] = []
    feasible_count = 0

    for size in range(min_size, max_size + 1):
        for line_a_tuple in itertools.combinations(range(n), size):
            line_a = list(line_a_tuple)
            feasible, _ = check_feasible(instance, line_a)
            if not feasible:
                continue
            feasible_count += 1
            line_b = [i for i in range(n) if i not in set(line_a)]
            value = objective(instance, line_a, line_b)
            if value > best_value:
                best_value = value
                best_groups = [(line_a, line_b)]
            elif value == best_value:
                best_groups.append((line_a, line_b))

    if not best_groups:
        raise RuntimeError("no feasible partition found")

    line_a, line_b = best_groups[0]
    feasible, violations = check_feasible(instance, line_a)
    return {
        "solver": "exact_enumeration_reference",
        "status": "optimal",
        "objective": best_value,
        "feasible": feasible,
        "violations": violations,
        "feasible_solution_count": feasible_count,
        "optimal_solution_count_including_symmetric_labels": len(best_groups),
        "line_a": [labels[i] for i in line_a],
        "line_b": [labels[i] for i in line_b],
        "line_a_indices": line_a,
        "line_b_indices": line_b,
    }


def solve_milp(instance: dict, time_limit: int = 120) -> dict:
    try:
        import pulp
    except ImportError as exc:
        raise RuntimeError("PuLP is required for large-instance MILP reference") from exc

    n = len(instance["employees"])
    labels = names(instance)
    deps = departments(instance)
    levels = seniority(instance)
    pairs = mentor_pairs(instance)
    w = instance["collaboration_matrix"]
    constraints_data = instance["constraints"]

    model = pulp.LpProblem("large_team_max_cut", pulp.LpMaximize)
    x = pulp.LpVariable.dicts("x", range(n), lowBound=0, upBound=1, cat="Binary")
    edge_pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    y = pulp.LpVariable.dicts("y", edge_pairs, lowBound=0, upBound=1, cat="Binary")

    model += pulp.lpSum(w[i][j] * y[(i, j)] for i, j in edge_pairs)

    team_size = pulp.lpSum(x[i] for i in range(n))
    model += team_size >= int(constraints_data["team_size_min"]), "team_size_min"
    model += team_size <= int(constraints_data["team_size_max"]), "team_size_max"

    frontend = [i for i, dept in enumerate(deps) if dept == "前端"]
    senior = [i for i, level in enumerate(levels) if level == "高级"]
    min_front = int(constraints_data["min_frontend_per_team"])
    min_senior = int(constraints_data["min_senior_per_team"])

    model += pulp.lpSum(x[i] for i in frontend) >= min_front, "front_a_min"
    model += pulp.lpSum(1 - x[i] for i in frontend) >= min_front, "front_b_min"
    model += pulp.lpSum(x[i] for i in senior) >= min_senior, "senior_a_min"
    model += pulp.lpSum(1 - x[i] for i in senior) >= min_senior, "senior_b_min"

    for mentor, mentee in pairs:
        model += x[mentor] == x[mentee], f"mentor_{mentor}_{mentee}"

    for i, j in edge_pairs:
        model += y[(i, j)] >= x[i] - x[j], f"abs_lb_ij_{i}_{j}"
        model += y[(i, j)] >= x[j] - x[i], f"abs_lb_ji_{i}_{j}"
        model += y[(i, j)] <= x[i] + x[j], f"abs_ub_sum_{i}_{j}"
        model += y[(i, j)] <= 2 - x[i] - x[j], f"abs_ub_comp_{i}_{j}"

    solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=time_limit)
    model.solve(solver)
    status = pulp.LpStatus[model.status]
    if status not in {"Optimal", "Not Solved", "Integer Feasible"}:
        raise RuntimeError(f"MILP solver failed with status={status}")

    line_a = [i for i in range(n) if pulp.value(x[i]) >= 0.5]
    line_b = [i for i in range(n) if i not in set(line_a)]
    feasible, violations = check_feasible(instance, line_a)
    value = objective(instance, line_a, line_b) if feasible else None
    return {
        "solver": "milp_reference_pulp_cbc",
        "status": "optimal" if status == "Optimal" else status.lower().replace(" ", "_"),
        "objective": value,
        "feasible": feasible,
        "violations": violations,
        "line_a": [labels[i] for i in line_a],
        "line_b": [labels[i] for i in line_b],
        "line_a_indices": line_a,
        "line_b_indices": line_b,
        "milp_status": status,
        "variable_count": n + len(edge_pairs),
        "edge_variable_count": len(edge_pairs),
    }


def solve(instance: dict, method: str = "auto", time_limit: int = 120) -> dict:
    n = len(instance["employees"])
    if method == "exact":
        return solve_exact(instance)
    if method == "milp":
        return solve_milp(instance, time_limit=time_limit)
    if method != "auto":
        raise ValueError(f"unknown method={method}")
    if n <= 22:
        return solve_exact(instance)
    return solve_milp(instance, time_limit=time_limit)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=DEFAULT_DATA)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--method", choices=["auto", "exact", "milp"], default="auto")
    parser.add_argument("--time-limit", type=int, default=120)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    instance = load_instance(args.data)
    result = solve(instance, method=args.method, time_limit=args.time_limit)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
