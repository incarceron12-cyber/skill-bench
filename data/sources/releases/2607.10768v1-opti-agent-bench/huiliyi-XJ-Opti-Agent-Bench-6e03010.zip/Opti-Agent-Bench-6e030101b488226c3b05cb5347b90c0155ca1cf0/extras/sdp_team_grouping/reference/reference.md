# sdp1 问题一：项目团队分组 Reference

本题本质是带硬约束的 Max-Cut / 二元分组问题。虽然可以写成 SDP 松弛再随机舍入，但评测 reference 不应依赖随机舍入结果。当前目录保留两类数据：

- `data/team_instance.json`：原题 12 人小实例，用穷举精确求解。
- `data/team_instance_large.json`：28 人大实例，用 MILP 精确求解，专门用于区分硬编码或只适配小规模的答案。

## 数学模型

令

- \(x_i=1\)：工程师 \(i\) 在 A 线；
- \(x_i=0\)：工程师 \(i\) 在 B 线。

目标是最大化跨线协作总量：

\[
\max \sum_{0\le i<j<12} W_{ij}\, |x_i-x_j|
\]

约束为：

\[
5 \le \sum_i x_i \le 7
\]

每条线至少 1 名前端工程师：

\[
\sum_{i\in F}x_i \ge 1,\qquad \sum_{i\in F}(1-x_i)\ge 1
\]

每条线至少 2 名高级工程师：

\[
\sum_{i\in S}x_i \ge 2,\qquad \sum_{i\in S}(1-x_i)\ge 2
\]

每对师徒必须同线：

\[
x_a=x_b,\qquad (a,b)\in\{(2,9),(5,4),(6,10)\}
\]

## 精确 reference 代码

代码位于：

```bash
reference/solve.py
```

运行：

```bash
python3 reference/solve.py --data data/team_instance_large.json --output results/reference_solution.json
```

`solve.py` 的 `--method auto` 会按规模选择求解方式：

- 小实例 \(n\le 22\)：枚举所有候选 A 线集合，逐一检查约束并计算目标值。
- 大实例 \(n>22\)：使用 MILP 线性化 Max-Cut。令 \(y_{ij}=|x_i-x_j|\)，加入线性约束
  \[
  y_{ij}\ge x_i-x_j,\quad y_{ij}\ge x_j-x_i,\quad
  y_{ij}\le x_i+x_j,\quad y_{ij}\le 2-x_i-x_j
  \]
  并最大化 \(\sum_{i<j} W_{ij}y_{ij}\)。

因此 reference 输出的是精确优化模型的最优解，而不是 SDP 随机舍入近似。

## 原题 12 人小实例最优结果

全局最优跨线协作总量：

```text
189
```

一个最优分组为：

| 产品线 | 成员 | 人数 | 前端 | 高级 |
|---|---|---:|---:|---:|
| A 线 | Alice, Dave, Eve, Frank, Grace, Karen | 6 | 2 | 3 |
| B 线 | Bob, Carol, Hank, Ivy, Jack, Leo | 6 | 1 | 2 |

A/B 标签互换也是等价最优解，因此共有 2 个含标签对称的最优解。

## 约束核验

- 规模均衡：A 线 6 人，B 线 6 人，满足 5-7 人要求。
- 前端覆盖：A 线 Eve、Frank；B 线 Bob，满足每条线至少 1 名前端。
- 骨干均衡：A 线 Alice、Dave、Frank；B 线 Carol、Ivy，满足每条线至少 2 名高级。
- 师徒绑定：
  - Carol 与 Jack 同在 B 线；
  - Frank 与 Eve 同在 A 线；
  - Grace 与 Karen 同在 A 线。

## 与 SDP 的关系

SDP 松弛形式仍然是正确的建模思路：令 \(X=xx^\top\)，加入 \(X\succeq0\)、\(X_{ii}=1\)，师徒绑定可写为 \(X_{ab}=1\)。但去掉 rank-1 约束后得到的是松弛上界，随机舍入也不保证每次达到全局最优。由于本题规模很小，reference 采用 exact enumeration 更严谨，也更适合作为评测参考答案。

## 28 人大实例

默认大实例由 `scripts/generate_team_instance.py --large-n 28 --seed 20260507` 生成。约束为：

- 每条线 13-15 人；
- 每条线至少 3 名前端；
- 每条线至少 4 名高级；
- 8 对师徒必须同线。

MILP reference 在该实例上得到的最优目标值为：

```text
2550
```

该实例用于批量运行 `responses/` 中的代码。原来只硬编码 12 名员工和固定矩阵的方案会因为未覆盖新增成员、人数约束和技能约束不匹配而失败。
