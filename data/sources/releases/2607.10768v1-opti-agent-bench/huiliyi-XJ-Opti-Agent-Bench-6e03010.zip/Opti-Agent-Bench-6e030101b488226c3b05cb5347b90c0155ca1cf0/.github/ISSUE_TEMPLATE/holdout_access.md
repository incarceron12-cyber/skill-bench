---
name: Holdout / delayed reference access
about: Request access to restricted tasks or reference solvers
title: "[Access] "
labels: access-request
---

- Name / affiliation:
- Intended use (research / teaching / audit):
- Which artifact (`task_08_cinema_hidden`, cable solver, ...):
- Agree not to redistribute before public release? (yes/no):
