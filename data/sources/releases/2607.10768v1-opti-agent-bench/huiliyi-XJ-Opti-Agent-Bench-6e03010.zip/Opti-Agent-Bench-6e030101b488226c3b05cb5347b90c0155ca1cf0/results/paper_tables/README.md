# Paper tables (aggregated)

Source: private `测试题/**/evaluation/横向对比总表.md` and `跨题目模型能力矩阵.md`.
These are **human/rubric evaluation scores** from the draft experiments, not pipeline Gateway scores.

| File | Description |
|------|-------------|
| `per_task_model_scores.csv` | Long-form ME/CE/RE + Total per (task, model) |
| `total_score_matrix.csv` | Model × task Total scores |
| `capability_matrix_overall.csv` | Cross-task capability dimensions |
| `alternate_scale_totals.csv` | Older 100-point totals (选品2/3, cinema hidden) |

Rows in per_task_model_scores: **55**

## Task coverage

- `task_01_drone_delivery` (无人机医疗包裹配送): 5 model rows
- `task_02_two_stage_stochastic` (区域配送网络): 5 model rows
- `task_03_socp_pension` (企业年金投资): 5 model rows
- `task_robust_scheduling` (异构算力调度): 5 model rows
- `task_05_nonsmooth_datacenter` (数据中心节能): 5 model rows
- `task_06_future_info_grocery` (生鲜门店补货): 5 model rows
- `task_07_cinema_visible` (电影院可见): 5 model rows
- `task_08_cinema_hidden` (电影院不可见(holdout)): 0 model rows
- `task_09_multistage_stochastic` (多阶段运力): 5 model rows
- `task_10_quant_investment` (量化投资): 5 model rows
- `extras_product_selection_01` (选品1): 5 model rows
- `extras_product_selection_02` (选品2): 0 model rows
- `extras_product_selection_03` (选品3): 0 model rows
- `extras_sdp_team_grouping` (SDP团队分组): 5 model rows
