# ORAC (Optimization R&D Agent Checklist) — short map

## Problem Formulation Validity
- **TD.1** Business-language task description
- **TD.2** Anti-template design (template matching should fail)
- **TD.3** Constraint completeness / coupling

## Solution Validity
- **ME.1** Mathematical model correctness
- **ME.2** Model–code consistency (core novelty)
- **ME.3** Model parsimony
- **CE.1** Code feasibility & optimality gap (reference checks)
- **CE.2** Multi-scale robustness
- **CE.3** Code quality
- **CE.4** Algorithmic appropriateness
- **RE.1** Report completeness
- **RE.2** Explanation clarity
- **RE.3** Reproducibility

Official scoring in this repo currently automates **Gateway** checks.
CE.1 / CE.2 / ME.2 automation lands in later releases; see paper for full protocol.
