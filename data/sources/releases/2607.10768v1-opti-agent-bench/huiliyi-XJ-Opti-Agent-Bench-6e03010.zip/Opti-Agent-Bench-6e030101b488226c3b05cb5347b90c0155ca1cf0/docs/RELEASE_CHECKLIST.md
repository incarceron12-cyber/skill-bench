# Opti-Agent-Bench 公开发布清单

对应私有工作区：`~/HXJ/agent`  
公开仓库：`~/HXJ/Opti-Agent-Bench`（本仓库）

状态说明：
- **Open**：v1 可直接公开
- **Sanitize**：可公开，但先清洗（去掉内部笔记、API、绝对路径）
- **Delayed**：暂缓公开（污染 / 反模板答案泄露风险）
- **Private**：不进公开仓

---

## 1. 论文任务 ↔ 公开文件对照

| Task ID | 论文中的角色 | 私有来源 | 公开内容 | 暂缓 / 私有 | 就绪度 |
|---------|--------------|----------|----------|-------------|--------|
| `task_01_drone_delivery` | 正文代表题（状态空间 / MDP） | `测试题/mdp/问题1_*` + `opti-agent-bench/tasks/...` | `problem.md`, `metadata.json`, `reference/feasibility*`, `optimal_value*` | 完整 DP 参考解可 Delayed | Medium |
| `task_11_cable_cutting` | 正文代表题（反模板） | `agent_test/` + `tasks/task_11_*` | `problem.md`, `data/*.csv`, checker | **完整 `cable_optimizer*.py` Delayed** | Medium |
| `task_robust_scheduling` | 正文代表题（泛化性） | `测试题/鲁棒优化/` | `problem.md`, `data/`, checker, 多尺度实例 | 原始大量 `robustness/runs` Private | High |
| `task_02_two_stage_stochastic` | 附录 / 建模精度 | `测试题/两阶段随机优化/` | `problem.md`, metadata | Reference 待补 | Low |
| `task_03_socp_pension` | 附录 / 建模精度 | `测试题/二阶锥优化/` | `problem.md`, verifier | 可开 solver（学术标准题） | Medium |
| `task_04_robust_production` | 附录 | `tasks/task_04_*` | `problem.md`, verifier | — | Medium |
| `task_05_nonsmooth_datacenter` | 附录 | `测试题/非平滑优化/` | `problem.md` | Reference 待补 | Low |
| `task_06_future_info_grocery` | 附录（信息泄露陷阱） | `测试题/未来信息/` | `problem.md`, `data/` | 生成脚本 Delayed（防刷数据） | Medium |
| `task_07_cinema_visible` | 附录 | `测试题/电影院/` | `problem.md`（需先去学术术语） | Reference 待补 | Low |
| `task_08_cinema_hidden` | **Holdout** | `测试题/电影院/问题2_不可见` | 仅 README 占位 | **题面+答案全部 Private** | Holdout |
| `task_09_multistage_stochastic` | 附录 | `测试题/多阶段随机优化/` | `problem.md`, 参考求解可 Delayed | — | Medium |
| `task_10_quant_investment` | 附录（质量偏弱） | `测试题/量化/` | 可选；建议改写后再开 | 现状 Delayed | Low |

**论文未承诺、暂不进 v1 主表：**
- `测试题/半正定规划/*` → Private / `extras/` 以后再说
- `测试题/选品问题/*` → Private / experimental
- `qoderwork_问题评估/`, `banchmark论文/`, `修改方向.md` → Private

---

## 2. 按资产类型：公开 vs 不公开

| 资产 | 决策 | 说明 |
|------|------|------|
| 业务题面 `problem.md` | Open（hidden 除外） | 与 arXiv 一致的最终版 |
| 输入数据 `data/` | Open | CSV/JSON；去掉内部路径注释 |
| `metadata.json` | Open | 难度、超时、类型 |
| `reference/feasibility_check.py` | Open | 别人能验解 |
| `reference/optimal_value.json` | Open | 便于算 gap |
| `reference/*solver*.py` / 完整参考解 | Delayed | 尤其电缆、反模板题 |
| `evaluation/rubric.md` | Open | ORAC 题目级 checklist |
| `pipeline/` 四阶段代码 | Open | 固定 pipeline，换 LLM |
| Gateway / 自动评分 | Open | 能开多少开多少 |
| 论文主表汇总结果 | Open | `results/paper_tables/` 仅聚合表 |
| 模型原始长回答 / 评审稿 | Private | 体积大、含半成品 |
| 全量 robustness run dump | Private | 可选另做 Zenodo 大包 |
| API key、内网评测地址 | Private | 永不入库 |
| 选品 / SDP 等扩展题 | Delayed | 与正文任务集对齐后再开 |

---

## 3. 发布前必做（DoD）

### 3.1 内容对齐
- [ ] 公开 `tasks/` 与 arXiv 正文/附录任务列表一致
- [ ] 每题 `problem.md` 是终版业务语言，不是旧草稿
- [ ] `task_08_cinema_hidden` 确认不进 open set
- [ ] 电缆题确认：**数据可开、完整 solver 暂缓**

### 3.2 清洗
- [ ] 全文扫一遍：内网 IP、API key、个人绝对路径、未脱敏公司名
- [ ] 删除 `.deps/`、`__pycache__/`、`.idea/`、超大 `results/` dump
- [ ] LICENSE + CITATION + README 中的 arXiv 链接填实

### 3.3 可复现
- [ ] `pip install -r requirements.txt` 后能跑通至少 1 题 Stage 3
- [ ] Gateway 对样例输出给出 pass/fail
- [ ] 提供 `results/paper_tables/` 与论文表号对应说明

### 3.4 污染与引用
- [ ] README 写明 contamination 声明 + holdout 政策
- [ ] arXiv comment / 脚注加 GitHub URL
- [ ] 打 `v1.0.0` tag → Zenodo DOI → 回填 README

---

## 4. 建议的分阶段上架

| 阶段 | 内容 | 目标 |
|------|------|------|
| **v0.1 skeleton** | 本仓库现状：结构 + pipeline + 题面拷贝 + 清单 | 团队对齐公开边界 |
| **v0.9 review** | 补齐 checker、清洗题面、论文主表 | 内部 review / 合作者试用 |
| **v1.0 public** | 开 GitHub + Zenodo；solver 仍可部分 Delayed | 与 arXiv 同步 |
| **v1.1** | 补 Reference、leaderboard、可选 HF 镜像 | 社区使用 |

---

## 5. 从私有仓搬运备忘

```bash
PRIV=~/HXJ/agent
PUB=~/HXJ/Opti-Agent-Bench
TASK=task_robust_scheduling

cp "$PRIV/opti-agent-bench/tasks/$TASK/problem.md" "$PUB/tasks/$TASK/"
cp "$PRIV/opti-agent-bench/tasks/$TASK/metadata.json" "$PUB/tasks/$TASK/"
# 仅 checker / optimal_value，不要盲目 rsync 整个 reference/
```

**禁止**直接 `cp -r ~/HXJ/agent` 到公开仓。
