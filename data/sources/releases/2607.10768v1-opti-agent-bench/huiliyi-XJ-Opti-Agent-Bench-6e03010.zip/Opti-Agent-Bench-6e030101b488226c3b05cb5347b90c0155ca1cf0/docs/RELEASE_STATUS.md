# Release status (v0.9 → toward v1.0)

## Core suite (`tasks/`)

| Task | problem | data | reference | Notes |
|------|---------|------|--------|-------|
| task_01_drone_delivery | ✅ | — | DP + tests | Main |
| task_02_two_stage_stochastic | ✅ | — | solve + opt value | |
| task_03_socp_pension | ✅ | — | solve + verify | |
| task_04_robust_production | ✅ | — | solve + verify | |
| task_05_nonsmooth_datacenter | ✅ | instance.json | feasibility + MILP reference | Done |
| task_06_future_info_grocery | ✅ | asof/finalized | generators; hidden→reference | No runtest |
| task_07_cinema_visible | ✅ | — | generator + checker | |
| task_08_cinema_hidden | ❌ holdout | — | — | Request-only |
| task_09_multistage_stochastic | ✅ | — | solve | |
| task_10_quant_investment | ✅ | data.csv | generator + ref solver | |
| task_11_cable_cutting | ✅ | csv | belady + **feasibility_check** | Full optimizer delayed |
| task_robust_scheduling | ✅ | instance.json | solve + verify + gen | Main |

## Paper tables

See `results/paper_tables/` (`per_task_model_scores.csv`, `total_score_matrix.csv`, `capability_matrix_overall.csv`).

## Still before GitHub v1.0

- [x] Fill arXiv URL + authors in README / CITATION.cff — https://arxiv.org/abs/2607.10768
- [ ] Optional smoke: `python -m pipeline.run` on one task
- [ ] Tag `v1.0.0` + Zenodo after arXiv ID exists
