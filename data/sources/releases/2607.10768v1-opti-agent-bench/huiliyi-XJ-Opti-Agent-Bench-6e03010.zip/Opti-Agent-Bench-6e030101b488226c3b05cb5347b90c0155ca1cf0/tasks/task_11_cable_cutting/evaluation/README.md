# Evaluation for `task_11_cable_cutting`

- `rubric.md` — task-specific ORAC / failure-oriented checklist
- `auto_eval.py` — optional wrappers around feasibility + gap checks
