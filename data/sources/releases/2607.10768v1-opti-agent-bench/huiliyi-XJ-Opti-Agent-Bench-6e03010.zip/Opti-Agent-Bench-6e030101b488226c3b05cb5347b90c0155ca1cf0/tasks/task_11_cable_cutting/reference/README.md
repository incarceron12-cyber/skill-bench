# Reference policy — cable cutting (anti-template)

| Artifact | Status |
|----------|--------|
| `../data/*.csv` | Public |
| `belady.py` | Public lower-bound heuristic on pulls |
| `feasibility_check.py` | Public metric / partial feasibility checker |
| Full `cable_optimizer.py` | **Delayed / request-only** |

```bash
python feasibility_check.py --data-dir ../data --solution /path/to/solution.json
```

The checker recomputes pulls, substitutions, unfilled, scrap/tail, and basic deadline /
substitution-legality checks. Same-model-first *online* policy is not fully proven offline.
