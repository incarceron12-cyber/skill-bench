#!/usr/bin/env python3
"""Public metric / feasibility checker for cable cutting solutions.

Does **not** include the reference optimizer. Validates a solution.json against
orders/reels/substitution and independently recomputes metrics.

Usage:
  python feasibility_check.py --data-dir ../data --solution solution.json
"""

from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any


SCRAP_THRESH = 2.0
PULL_MINUTES = 30


def parse_ts(s: str) -> datetime:
    s = s.strip().replace("Z", "+00:00")
    for fmt in (
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    ):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    # fallback: fromisoformat
    return datetime.fromisoformat(s.replace("Z", ""))


def deadline_minutes(order_time: datetime) -> int:
    return 70 if order_time.hour < 12 else 50


def load_csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_inputs(data_dir: Path):
    orders_raw = load_csv_rows(data_dir / "orders.csv")
    reels_raw = load_csv_rows(data_dir / "reels.csv")
    subs_raw = load_csv_rows(data_dir / "substitution.csv")

    # normalize column names
    def col(row, *names):
        for n in names:
            if n in row:
                return row[n]
        # Chinese headers
        mapping = {
            "model": ("型号", "model", "cable_model"),
            "length": ("长度", "length"),
            "time": ("下单时间", "order_time", "time"),
            "reel_id": ("编号", "reel_id", "id"),
            "ori": ("ori", "原型号"),
            "sub": ("sub", "替代型号"),
        }
        raise KeyError(names)

    orders = []
    for idx, r in enumerate(orders_raw):
        model = r.get("型号") or r.get("model")
        length = float(r.get("长度") or r.get("length"))
        t = parse_ts(r.get("下单时间") or r.get("order_time"))
        oid = f"ORD_{idx+1:05d}"
        orders.append({"order_id": oid, "model": model, "length": length, "time": t})

    reels = {}
    for r in reels_raw:
        rid = r.get("编号") or r.get("reel_id")
        reels[rid] = {
            "reel_id": rid,
            "model": r.get("型号") or r.get("model"),
            "length": float(r.get("长度") or r.get("length")),
        }

    subs = defaultdict(set)
    for r in subs_raw:
        ori = r.get("ori") or r.get("原型号")
        sub = r.get("sub") or r.get("替代型号")
        if ori and sub:
            subs[ori].add(sub)

    return orders, reels, subs


def check_solution(data_dir: Path, solution: dict[str, Any]) -> dict:
    orders, reels0, subs = load_inputs(data_dir)
    remaining = {rid: info["length"] for rid, info in reels0.items()}
    models = {rid: info["model"] for rid, info in reels0.items()}

    assignments = solution.get("assignments", [])
    transport = solution.get("transportation_log", [])
    workshop_log = solution.get("workshop_state_log", [])
    metrics_reported = solution.get("metrics") or {}

    violations: list[str] = []

    # map assignments by order_id; also allow positional ORD_#####
    by_id = {a.get("order_id"): a for a in assignments}
    if len(assignments) != len(orders):
        violations.append(
            f"assignment count {len(assignments)} != orders {len(orders)}"
        )

    filled = 0
    unfilled = 0
    substitutions = 0
    used_length = defaultdict(float)

    for o in orders:
        a = by_id.get(o["order_id"])
        if a is None:
            # try alternate id styles
            a = next((x for x in assignments if x.get("order_id") == o["order_id"]), None)
        if a is None:
            violations.append(f"missing assignment for {o['order_id']}")
            unfilled += 1
            continue

        length = float(a.get("order_length", o["length"]))
        if abs(length - o["length"]) > 1e-6:
            violations.append(f"{o['order_id']}: order_length mismatch")

        if o["length"] == 0:
            if a.get("reel_id") not in (None, "null", ""):
                violations.append(f"{o['order_id']}: zero-length should have reel_id null")
            filled += 1
            continue

        # unfilled marker
        if a.get("unfilled") or a.get("reel_id") in (None, "null", "") and o["length"] > 0:
            # some solutions omit unfilled flag and leave null reel
            if a.get("reel_id") in (None, "null", ""):
                unfilled += 1
                continue

        rid = a.get("reel_id")
        if rid not in remaining:
            violations.append(f"{o['order_id']}: unknown reel_id {rid}")
            unfilled += 1
            continue

        used_model = a.get("used_reel_model") or models[rid]
        need_model = a.get("cable_model") or o["model"]
        if need_model != o["model"]:
            violations.append(f"{o['order_id']}: cable_model != order model")

        if used_model != models[rid]:
            violations.append(
                f"{o['order_id']}: used_reel_model {used_model} != reel {rid} model {models[rid]}"
            )

        if used_model != need_model:
            substitutions += 1
            if used_model not in subs.get(need_model, set()) and used_model != need_model:
                violations.append(
                    f"{o['order_id']}: illegal substitution {need_model}->{used_model}"
                )

        if remaining[rid] + 1e-9 < o["length"]:
            violations.append(
                f"{o['order_id']}: reel {rid} remaining {remaining[rid]} < need {o['length']}"
            )
        remaining[rid] -= o["length"]
        used_length[rid] += o["length"]
        filled += 1

        # deadline check if timestamps present
        at = a.get("assignment_time") or a.get("cut_time")
        if at:
            try:
                cut = parse_ts(str(at))
                ot = o["time"]
                # drop tz for naive compare
                if cut.tzinfo and not ot.tzinfo:
                    cut = cut.replace(tzinfo=None)
                limit = deadline_minutes(ot)
                delta_min = (cut - ot).total_seconds() / 60.0
                if delta_min - limit > 1e-6:
                    violations.append(
                        f"{o['order_id']}: cut after deadline ({delta_min:.1f}>{limit})"
                    )
            except Exception as e:
                violations.append(f"{o['order_id']}: bad assignment_time ({e})")

    # transport metrics
    pulls = 0
    to_w = to_s = 0
    for ev in transport:
        direction = ev.get("direction")
        if direction in ("to_workshop", "to_storage"):
            pulls += 1
            if direction == "to_workshop":
                to_w += 1
            else:
                to_s += 1
        else:
            violations.append(f"bad transport direction: {direction}")

    # workshop occupancy snapshots: never >4; if present validate size
    for snap in workshop_log:
        reels_here = snap.get("reel_ids") or snap.get("reels") or []
        if len(reels_here) > 4:
            violations.append(
                f"workshop_state >4 reels at {snap.get('timestamp')}: {len(reels_here)}"
            )

    scrap = sum(v for v in remaining.values() if v <= SCRAP_THRESH + 1e-12)
    tail = sum(v for v in remaining.values() if v > SCRAP_THRESH)

    recomputed = {
        "orders": len(orders),
        "pulls": pulls,
        "to_workshop": to_w,
        "to_storage": to_s,
        "substitution_times": substitutions,
        "unfilled": unfilled,
        "filled": filled,
        "scrap_meters(<=2)": round(scrap, 6),
        "tail_meters(>2)": round(tail, 6),
    }

    # compare reported metrics if present (top-level or nested)
    reported = metrics_reported
    if not reported and all(k in solution for k in ("pulls", "orders")):
        reported = solution
    for key in ("pulls", "substitution_times", "unfilled", "scrap_meters(<=2)", "tail_meters(>2)"):
        if key in reported:
            rv = float(reported[key])
            cv = float(recomputed[key])
            if abs(rv - cv) > 1e-3:
                violations.append(f"metrics mismatch {key}: reported {rv}, recomputed {cv}")

    # soft note: same-model-first policy cannot be fully verified offline without
    # reconstructing online state; we only check substitution legality.

    return {
        "feasible": len(violations) == 0,
        "n_violations": len(violations),
        "violations": violations[:80],
        "recomputed_metrics": recomputed,
        "notes": [
            "Same-model-first / online visibility policy is not fully proven by this checker.",
            "Workshop capacity dynamics beyond snapshot length<=4 need transportation timing audit.",
        ],
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, default=None)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()
    here = Path(__file__).resolve().parent
    data_dir = args.data_dir or (here.parent / "data")
    sol = json.loads(args.solution.read_text(encoding="utf-8"))
    report = check_solution(data_dir, sol)
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    print(text)
    raise SystemExit(0 if report["feasible"] else 1)


if __name__ == "__main__":
    main()
