"""Belady-style lower bound on workshop pulls (with optional substitution)."""
from __future__ import annotations

import argparse
from collections import defaultdict
from pathlib import Path

import pandas as pd


def run(data_dir: Path) -> None:
    od = pd.read_csv(data_dir / "orders.csv")
    # support Chinese or English headers
    cols = {c: c for c in od.columns}
    model_col = "型号" if "型号" in od.columns else "model"
    time_col = "下单时间" if "下单时间" in od.columns else "order_time"
    od = od.sort_values(time_col).reset_index(drop=True)
    orders = list(od[model_col])

    sm = {"A": ["B", "C"], "E": ["D"], "F": ["D"], "J": ["H", "I"]}
    # override from substitution.csv if present
    sub_path = data_dir / "substitution.csv"
    if sub_path.exists():
        sub = pd.read_csv(sub_path)
        ori_c = "ori" if "ori" in sub.columns else sub.columns[0]
        sub_c = "sub" if "sub" in sub.columns else sub.columns[1]
        sm = defaultdict(list)
        for _, r in sub.iterrows():
            sm[str(r[ori_c])].append(str(r[sub_c]))

    serves = defaultdict(set)
    models = sorted(set(orders) | set(sm.keys()) | {s for vs in sm.values() for s in vs})
    for m in models:
        serves[m].add(m)
    for ori, subs in sm.items():
        for s in subs:
            serves[s].add(ori)

    def belady(use_sub: bool) -> int:
        cache = []
        pulls = 0
        for i, om in enumerate(orders):
            cands = [om] + (list(sm.get(om, [])) if use_sub else [])
            if any(cm in cands for cm in cache):
                continue
            pulls += 1
            best_m = om
            if use_sub:
                best_cov = len(serves[om])
                for cm in cands:
                    if len(serves[cm]) > best_cov:
                        best_cov = len(serves[cm])
                        best_m = cm
            if len(cache) >= 3:
                max_next, evict_m = -1, cache[0]
                for cm in cache:
                    nxt = len(orders)
                    for j in range(i + 1, len(orders)):
                        if (orders[j] == cm) if not use_sub else (orders[j] in serves[cm]):
                            nxt = j
                            break
                    if nxt > max_next:
                        max_next, evict_m = nxt, cm
                cache.remove(evict_m)
            cache.append(best_m)
        return pulls

    p1 = belady(False)
    p2 = belady(True)
    print(f"same-model Belady inbound pulls: {p1}, two-way ~{p1*2-3}")
    print(f"with-sub Belady inbound pulls: {p2}, two-way ~{p2*2-3}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", type=Path, default=Path(__file__).resolve().parent.parent / "data")
    args = ap.parse_args()
    run(args.data_dir)
