# Reference — `task_06_future_info_grocery`

## Included

- `diagnose_generated_data.py`
- `generate_data.py`
- `historical_hidden_truth.csv`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
