import csv
import math
from pathlib import Path
from statistics import mean

BASE = Path(__file__).resolve().parent / "generated"
FINAL = BASE / "historical_finalized.csv"
ASOF = BASE / "historical_asof.csv"
OUT = Path(__file__).resolve().parent / "首版数据诊断报告.md"


def read_csv(path):
    with path.open("r", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def to_float(x):
    try:
        return float(x)
    except Exception:
        return None


def corr(xs, ys):
    if len(xs) != len(ys) or len(xs) < 2:
        return None
    mx, my = mean(xs), mean(ys)
    num = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    denx = math.sqrt(sum((x - mx) ** 2 for x in xs))
    deny = math.sqrt(sum((y - my) ** 2 for y in ys))
    if denx == 0 or deny == 0:
        return None
    return num / (denx * deny)


def summarize_numeric(rows, col):
    vals = [to_float(r[col]) for r in rows if to_float(r[col]) is not None]
    vals.sort()
    n = len(vals)
    return {
        "n": n,
        "min": vals[0],
        "p25": vals[int(0.25 * (n - 1))],
        "mean": sum(vals) / n,
        "p75": vals[int(0.75 * (n - 1))],
        "max": vals[-1],
    }


def fmt(x):
    return "N/A" if x is None else f"{x:.3f}"


def main():
    final_rows = read_csv(FINAL)
    asof_rows = read_csv(ASOF)
    total_sales = [to_float(r["sales_veg"]) + to_float(r["sales_fruit"]) + to_float(r["sales_meat"]) for r in final_rows]

    legal_cols = [
        "is_holiday",
        "community_event_flag",
        "neighbor_store_sales_index",
        "upstream_supply_score",
        "prev_day_total_sales",
        "category_demand_momentum_asof",
    ]
    risky_cols = [
        "category_demand_momentum_final",
        "intra_day_footfall_snapshot",
        "freshness_discount_rate",
        "return_adjusted_net_demand",
    ]

    legal_corr = []
    for c in legal_cols:
        vals = [to_float(r[c]) for r in asof_rows]
        legal_corr.append((c, corr(vals, total_sales)))

    risky_corr = []
    for c in risky_cols:
        vals = [to_float(r[c]) for r in final_rows]
        risky_corr.append((c, corr(vals, total_sales)))

    quality_groups = {}
    for r in final_rows:
        q = r["batch_quality_grade"]
        ts = to_float(r["sales_veg"]) + to_float(r["sales_fruit"]) + to_float(r["sales_meat"])
        quality_groups.setdefault(q, []).append(ts)

    weather_groups = {}
    for r in final_rows:
        weather_groups.setdefault(r["weather_forecast"], []).append(
            to_float(r["sales_veg"]) + to_float(r["sales_fruit"]) + to_float(r["sales_meat"])
        )

    report = []
    report.append("# 社区生鲜补货题——首版数据诊断报告")
    report.append("")
    report.append("## 1. 样本概况")
    report.append("")
    report.append(f"- as-of 样本数：{len(asof_rows)}")
    report.append(f"- finalized 样本数：{len(final_rows)}")
    report.append(f"- 总销量均值：{fmt(mean(total_sales))}")
    report.append("")

    report.append("## 2. 关键数值字段分布")
    report.append("")
    for c in [
        "prev_day_total_sales",
        "category_demand_momentum_asof",
        "category_demand_momentum_final",
        "intra_day_footfall_snapshot",
        "freshness_discount_rate",
        "return_adjusted_net_demand",
    ]:
        rows = asof_rows if c in {"prev_day_total_sales", "category_demand_momentum_asof"} else final_rows
        s = summarize_numeric(rows, c)
        report.append(f"- `{c}`: min={fmt(s['min'])}, p25={fmt(s['p25'])}, mean={fmt(s['mean'])}, p75={fmt(s['p75'])}, max={fmt(s['max'])}")
    report.append("")

    report.append("## 3. 合法字段与总销量的相关性")
    report.append("")
    for c, v in legal_corr:
        report.append(f"- `{c}` vs total_sales: {fmt(v)}")
    report.append("")

    report.append("## 4. 风险 / future information 字段与总销量的相关性")
    report.append("")
    for c, v in risky_corr:
        report.append(f"- `{c}` vs total_sales: {fmt(v)}")
    report.append("")

    report.append("## 5. batch_quality_grade 与总销量")
    report.append("")
    for q in sorted(quality_groups):
        report.append(f"- 品质 {q}: 平均总销量 = {fmt(mean(quality_groups[q]))}")
    report.append("")

    report.append("## 6. weather_forecast 与总销量")
    report.append("")
    for w in weather_groups:
        report.append(f"- 预报天气 {w}: 平均总销量 = {fmt(mean(weather_groups[w]))}")
    report.append("")

    report.append("## 7. 初步诊断结论")
    report.append("")
    report.append("1. 合法字段中，`prev_day_total_sales` 与 `category_demand_momentum_asof` 应体现中等相关；若过低，说明合法信号不足。")
    report.append("2. 风险字段中，`return_adjusted_net_demand`、`intra_day_footfall_snapshot`、`category_demand_momentum_final` 应明显强于合法字段；否则 future information 诱惑不够。")
    report.append("3. 若 `freshness_discount_rate` 与总销量关系过弱或方向不稳定，可后续加强其由库存压力触发的机制。")
    report.append("4. 若 `batch_quality_grade` 对销量影响过弱，可提高品质对效用与退货的联动强度。")
    report.append("5. 若 `weather_forecast` 的影响过弱或过强，都需要继续调参，使其成为“合法但非万能”的中等强度特征。")
    report.append("")

    OUT.write_text("\n".join(report), encoding="utf-8")
    print(f"诊断报告已生成: {OUT}")


if __name__ == "__main__":
    main()
