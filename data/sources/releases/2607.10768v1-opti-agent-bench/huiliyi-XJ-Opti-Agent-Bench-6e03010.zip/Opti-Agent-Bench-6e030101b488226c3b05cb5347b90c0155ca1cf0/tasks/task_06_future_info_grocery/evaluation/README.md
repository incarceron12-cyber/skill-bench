# Evaluation for `task_06_future_info_grocery`

- `rubric.md` — task-specific ORAC / failure-oriented checklist
- `auto_eval.py` — optional wrappers around feasibility + gap checks
