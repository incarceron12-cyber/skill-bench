from __future__ import annotations

import csv
import math
import random
from datetime import date, timedelta
from pathlib import Path

OUT_DIR = Path(__file__).resolve().parent / "generated"
START_DATE = date(2024, 1, 1)
N_DAYS = 365
SEED = 42
random.seed(SEED)

BASE_UTILS = {"veg": 3.0, "fruit": 2.4, "meat": 1.8}
PRICES = {"veg": 20, "fruit": 32, "meat": 55}
COSTS = {"veg": 8, "fruit": 12, "meat": 25}
SALVAGE = {"veg": 1, "fruit": 2, "meat": 3}
MAX_ORDER = {"veg": 60, "fruit": 50, "meat": 40}
CAPACITY = 120
LOSS_COST = 5


def clip(x, lo, hi):
    return max(lo, min(hi, x))


def holiday_flag(d: date) -> int:
    return int(d.weekday() >= 5 or (d.month, d.day) in {(1, 1), (5, 1), (10, 1)})


def lunar_phase_index(day_idx: int) -> float:
    return round((day_idx % 29) / 29.0, 3)


def sample_weather(prev_actual: str | None) -> str:
    choices = ["晴", "阴", "雨", "大雨"]
    if prev_actual == "大雨":
        weights = [0.15, 0.25, 0.35, 0.25]
    elif prev_actual == "雨":
        weights = [0.20, 0.30, 0.35, 0.15]
    else:
        weights = [0.35, 0.30, 0.25, 0.10]
    return random.choices(choices, weights=weights, k=1)[0]


def forecast_weather(actual: str) -> str:
    if random.random() < {"晴": 0.8, "阴": 0.7, "雨": 0.78, "大雨": 0.85}[actual]:
        return actual
    neighbors = {"晴": ["阴"], "阴": ["晴", "雨"], "雨": ["阴", "大雨"], "大雨": ["雨"]}
    return random.choice(neighbors[actual])


def event_flag(d: date, is_holiday: int) -> int:
    p = 0.08 + 0.12 * (d.weekday() >= 5) + 0.10 * is_holiday
    x = random.random()
    if x < p * 0.25:
        return 2
    if x < p:
        return 1
    return 0


def weather_mult(w: str) -> float:
    return {"晴": 1.08, "阴": 1.0, "雨": 0.88, "大雨": 0.75}[w]


def sample_quality(score: float) -> str:
    if score >= 85:
        probs = [0.82, 0.15, 0.03]
    elif score >= 70:
        probs = [0.42, 0.40, 0.18]
    else:
        probs = [0.12, 0.43, 0.45]
    return random.choices(["A", "B", "C"], probs, k=1)[0]


def quality_sales_multiplier(quality: str):
    return {"A": {"veg": 1.02, "fruit": 1.02, "meat": 1.03}, "B": {"veg": 0.96, "fruit": 0.95, "meat": 0.90}, "C": {"veg": 0.84, "fruit": 0.82, "meat": 0.72}}[quality]


def mnl_pick(inv, utils):
    available = [k for k, v in inv.items() if v > 0]
    denom = 2.0 + sum(utils[k] for k in available)
    probs = [utils[k] / denom for k in available] + [2.0 / denom]
    return random.choices(available + ["none"], weights=probs, k=1)[0]


def gen_orders(prev_total, holiday, event, forecast, neighbor):
    base = {
        "veg": 24 + 0.10 * prev_total,
        "fruit": 18 + 0.075 * prev_total,
        "meat": 12 + 0.05 * prev_total,
    }
    boost = 1 + 0.08 * holiday + 0.07 * event + 0.12 * (neighbor - 1.0)
    if forecast == "晴":
        boost += 0.04
    elif forecast == "大雨":
        boost -= 0.06
    orders = {k: int(round(clip(v * boost + random.gauss(0, 2.5), 8, MAX_ORDER[k]))) for k, v in base.items()}
    total = sum(orders.values())
    if total > CAPACITY:
        scale = CAPACITY / total
        orders = {k: max(0, int(orders[k] * scale)) for k in orders}
    return orders


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]):
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    asof_rows, final_rows, truth_rows = [], [], []
    prev_actual, prev_total, prev_sales2 = None, 130, 125
    supply_score = 78.0
    prev_demand_score = 0.38
    for i in range(N_DAYS):
        d = START_DATE + timedelta(days=i)
        is_h = holiday_flag(d)
        actual = sample_weather(prev_actual)
        forecast = forecast_weather(actual)
        event = event_flag(d, is_h)
        neighbor = round(clip(1 + random.gauss(0, 0.035) + 0.08 * (event == 2) + 0.04 * is_h, 0.85, 1.18), 3)
        supply_score = clip(supply_score * 0.60 + 0.40 * (75 + random.gauss(0, 10)), 50, 97)
        demand_weights = [0.20 + 0.03 * (actual in {"雨", "大雨"}), 0.52, 0.28 + 0.05 * is_h + 0.05 * (event > 0)]
        demand_state = random.choices(["L", "M", "H"], weights=demand_weights, k=1)[0]
        base_lambda = {"L": 90, "M": 130, "H": 180}[demand_state]
        lam = base_lambda * weather_mult(actual) * (1 + 0.10 * is_h) * (1 + 0.12 * (event == 1) + 0.28 * (event == 2)) * neighbor
        lam *= clip(1 + 0.0025 * (prev_total - 130), 0.88, 1.14) * math.exp(random.gauss(0, 0.08))
        lam = max(40, lam)
        n_customers = max(0, int(random.gauss(lam, lam ** 0.5)))
        quality = sample_quality(supply_score)
        q_mult = quality_sales_multiplier(quality)
        w_mult = {"晴": {"veg": 1.03, "fruit": 1.10, "meat": 1.0}, "阴": {"veg": 1, "fruit": 1, "meat": 1}, "雨": {"veg": 0.95, "fruit": 0.92, "meat": 1.02}, "大雨": {"veg": 0.9, "fruit": 0.85, "meat": 1.03}}[actual]
        e_mult = {0: {"veg": 1, "fruit": 1, "meat": 1}, 1: {"veg": 1.02, "fruit": 1.06, "meat": 1.04}, 2: {"veg": 1.04, "fruit": 1.12, "meat": 1.10}}[event]
        utils = {k: BASE_UTILS[k] * q_mult[k] * w_mult[k] * e_mult[k] * math.exp(random.gauss(0, 0.05)) for k in BASE_UTILS}
        orders = gen_orders(prev_total, is_h, event, forecast, neighbor)
        inv = orders.copy(); sales = {"veg": 0, "fruit": 0, "meat": 0}; lost = 0
        for _ in range(n_customers):
            choice = mnl_pick(inv, utils)
            if choice == "none":
                continue
            if inv[choice] > 0:
                inv[choice] -= 1; sales[choice] += 1
            else:
                lost += 1
        total_sales = sum(sales.values())
        footfall = max(0, int(round(0.52 * n_customers + random.gauss(0, 6))))
        leftover = {k: orders[k] - sales[k] for k in orders}
        leftover_ratio = sum(leftover.values()) / max(1, sum(orders.values()))
        discount_base = 0.00 if leftover_ratio < 0.18 else 0.05 if leftover_ratio < 0.32 else 0.14 if leftover_ratio < 0.48 else 0.24
        discount = round(clip(discount_base + {"A": 0.00, "B": 0.04, "C": 0.08}[quality] + random.gauss(0, 0.01), 0, 0.35), 3)
        ret_range = {"A": (0.05, 0.10), "B": (0.10, 0.20), "C": (0.20, 0.35)}[quality]
        ret_p = random.uniform(*ret_range)
        returns = sum(1 for _ in range(total_sales) if random.random() < ret_p)
        complaint_noise = max(0, int(round(random.gauss({"A": 1.5, "B": 3.5, "C": 7.0}[quality], 1.5))))
        quality_penalty = {"A": 0, "B": random.randint(0, 4), "C": random.randint(2, 8)}[quality]
        net_demand = max(0, total_sales - returns - complaint_noise - quality_penalty)
        mom_asof = round(clip(0.35 * prev_demand_score + 0.30 * (prev_total / 180) + 0.22 * neighbor + 0.08 * is_h + 0.10 * event + random.gauss(0, 0.03), 0.05, 0.95), 3)
        partial_sales = int(round(0.75 * total_sales + random.gauss(0, 4)))
        mom_final = round(clip(0.45 * mom_asof + 0.40 * (partial_sales / 180) + 0.10 * (footfall / 120) + random.gauss(0, 0.025), 0.05, 0.95), 3)
        profit = sum(PRICES[k] * sales[k] - COSTS[k] * orders[k] + SALVAGE[k] * leftover[k] for k in orders) - LOSS_COST * lost
        base = {"date": d.isoformat(), "weekday": d.isoweekday(), "is_holiday": is_h, "weather_forecast": forecast, "community_event_flag": event, "neighbor_store_sales_index": neighbor, "upstream_supply_score": round(supply_score, 2), "prev_day_total_sales": prev_total, "store_age_months": 18 + i // 30, "lunar_phase_index": lunar_phase_index(i)}
        asof_rows.append(base | {"category_demand_momentum_asof": mom_asof})
        final_rows.append(base | {"category_demand_momentum_final": mom_final, "intra_day_footfall_snapshot": footfall, "freshness_discount_rate": discount, "return_adjusted_net_demand": net_demand, "batch_quality_grade": quality, "sales_veg": sales["veg"], "sales_fruit": sales["fruit"], "sales_meat": sales["meat"]})
        truth_rows.append({"date": d.isoformat(), "actual_weather": actual, "demand_state": demand_state, "quality_state": quality, "lambda_t": round(lam, 2), "true_v_veg": round(utils["veg"], 3), "true_v_fruit": round(utils["fruit"], 3), "true_v_meat": round(utils["meat"], 3), "order_veg": orders["veg"], "order_fruit": orders["fruit"], "order_meat": orders["meat"], "sales_veg": sales["veg"], "sales_fruit": sales["fruit"], "sales_meat": sales["meat"], "lost_customers": lost, "leftover_veg": leftover["veg"], "leftover_fruit": leftover["fruit"], "leftover_meat": leftover["meat"], "profit": round(profit, 2)})
        prev_actual, prev_sales2, prev_total, prev_demand_score = actual, prev_total, total_sales, mom_asof
    write_csv(OUT_DIR / "historical_asof.csv", asof_rows, list(asof_rows[0].keys()))
    write_csv(OUT_DIR / "historical_finalized.csv", final_rows, list(final_rows[0].keys()))
    write_csv(OUT_DIR / "historical_hidden_truth.csv", truth_rows, list(truth_rows[0].keys()))
    print(f"已生成数据到: {OUT_DIR}")


if __name__ == "__main__":
    main()
