# Evaluation for `task_robust_scheduling`

- `rubric.md` — task-specific ORAC / failure-oriented checklist
- `auto_eval.py` — optional wrappers around feasibility + gap checks
