"""泛化性评测引擎
=============================
对鲁棒优化模型进行泛化性评测，支持两套问题：
  - production:  「新产品线投产规划」（Bertsimas-Sim 鲁棒优化）
  - scheduling:  「异构算力调度」（最坏情况鲁棒调度）

用法:
    python eval_generalization.py [--problem production|scheduling] [--timeout 60] [--output results/] [--quick]

参数:
    --problem  问题类型，production 或 scheduling，默认 production
    --timeout  每次求解的超时时间（秒），默认 60
    --output   结果输出目录，默认 results/
    --quick    快速模式，仅运行 2 个测试用例用于验证框架
"""

import sys
import os
import json
import time
import argparse
import traceback
from datetime import datetime
from multiprocessing import Process, Queue

# 确保项目根目录在 sys.path 中
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

# 延迟导入，根据 --problem 参数决定导入哪个模块
_generate_instance = None
_get_all_cases = None
_get_parameter_generalization_cases = None


def _load_problem_module(problem_type='production'):
    """根据问题类型加载对应的数据生成模块。"""
    global _generate_instance, _get_all_cases, _get_parameter_generalization_cases
    if problem_type == 'scheduling':
        from generate_instances_scheduling import (
            generate_instance, get_all_cases, get_parameter_generalization_cases
        )
    else:
        from generate_instances import (
            generate_instance, get_all_cases, get_parameter_generalization_cases
        )
    _generate_instance = generate_instance
    _get_all_cases = get_all_cases
    _get_parameter_generalization_cases = get_parameter_generalization_cases


# ============================================================
# 模型注册表
# ============================================================

# 按问题类型分别注册模型
MODELS_PRODUCTION = {
    'reference': {
        'name': 'Reference (PuLP)',
        'wrapper': 'wrappers.wrapper_reference',
        'source': 'extracted/model_reference.py',
        'description': '参考解法，Bertsimas-Sim 鲁棒对等式',
    },
}

MODELS_SCHEDULING = {
    'gemini': {
        'name': 'Gemini 2.5-Pro',
        'wrapper': 'wrappers.wrapper_gemini',
        'source': 'extracted/model_gemini.py',
        'description': 'Gemini 2.5 Pro, PuLP MILP (异构算力调度)',
    },
    'kimi': {
        'name': 'Kimi k2.5',
        'wrapper': 'wrappers.wrapper_kimi',
        'source': 'extracted/model_kimi.py',
        'description': 'Kimi k2.5, scipy SLSQP + 枚举 (异构算力调度)',
    },
    'qwen': {
        'name': 'Qwen 3.5-Plus',
        'wrapper': 'wrappers.wrapper_qwen',
        'source': 'extracted/model_qwen.py',
        'description': 'Qwen 3.5 Plus, PuLP MILP (异构算力调度)',
    },
}

# 向后兼容：默认使用 production 模型集
MODELS = {**MODELS_PRODUCTION, **MODELS_SCHEDULING}


def _get_models(problem_type='production'):
    """根据问题类型返回对应的模型注册表。"""
    if problem_type == 'scheduling':
        return MODELS_SCHEDULING
    elif problem_type == 'production':
        return MODELS_PRODUCTION
    else:
        return MODELS


# ============================================================
# 超时机制（基于 multiprocessing）
# ============================================================

def _run_solve_in_process(wrapper_module_name, instance, result_queue):
    """在子进程中执行求解，结果通过 Queue 返回。抑制求解器的 stdout/stderr 输出。"""
    try:
        # 抑制子进程中的 C 层级 stdout/stderr（如 HiGHS 日志）
        import os
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, 1)  # redirect stdout
        os.dup2(devnull, 2)  # redirect stderr
        os.close(devnull)

        import importlib
        mod = importlib.import_module(wrapper_module_name)
        result = mod.solve(instance)
        result_queue.put(result)
    except Exception as e:
        result_queue.put({
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': 0.0,
            'error': f'{type(e).__name__}: {str(e)}',
            'solver': wrapper_module_name,
        })


def solve_with_timeout(wrapper_module_name, instance, timeout=60):
    """
    带超时的求解调用。使用 multiprocessing 实现跨平台超时。

    参数:
        wrapper_module_name: wrapper 模块的完整导入路径
        instance: 问题实例字典
        timeout: 超时秒数

    返回:
        dict: 统一格式的求解结果
    """
    result_queue = Queue()
    proc = Process(
        target=_run_solve_in_process,
        args=(wrapper_module_name, instance, result_queue),
    )

    start_time = time.time()
    proc.start()
    proc.join(timeout=timeout)

    elapsed = time.time() - start_time

    if proc.is_alive():
        proc.terminate()
        proc.join(timeout=5)
        if proc.is_alive():
            proc.kill()
            proc.join(timeout=2)
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': f'超时: 求解时间超过 {timeout} 秒',
            'solver': wrapper_module_name,
        }

    if not result_queue.empty():
        return result_queue.get()
    else:
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': '子进程异常退出，未返回结果',
            'solver': wrapper_module_name,
        }


# ============================================================
# 失败原因分类
# ============================================================

def classify_failure(result, instance):
    """
    根据求解结果和错误信息分类失败原因。

    返回:
        str: 'success' / 'hardcoded' / 'solver_limit' / 'logic_error' / 'timeout' / 'problem_mismatch'
    """
    if result['feasible'] and result['objective'] is not None:
        return 'success'

    error = result.get('error', '') or ''

    # 超时
    if '超时' in error or 'timeout' in error.lower():
        return 'timeout'

    # 问题不匹配（模型求解的是不同问题）
    if '问题不匹配' in error:
        return 'problem_mismatch'

    # 硬编码导致的失败
    if '硬编码' in error or 'hardcoded' in error.lower():
        return 'hardcoded'

    # 求解器限制
    if any(kw in error for kw in ['Infeasible', 'Unbounded', 'solver',
                                   'ImportError', '未安装']):
        return 'solver_limit'

    # 其他归类为逻辑错误
    return 'logic_error'


# ============================================================
# 生成测试用例 ID
# ============================================================

def make_case_id(case_params):
    """从测试用例参数生成可读的 ID。"""
    parts = []
    n = case_params.get('N', 4)
    parts.append(f"N{n}")
    bs = case_params.get('budget_scale', 1.0)
    if bs != 1.0:
        parts.append(f"bs{bs}")
    ul = case_params.get('uncertainty_level', 'medium')
    if ul != 'medium':
        parts.append(f"unc_{ul}")
    cp = case_params.get('cost_perturbation', 0.0)
    if cp != 0.0:
        parts.append(f"cp{cp}")
    return '_'.join(parts) if len(parts) > 1 else parts[0]


# ============================================================
# 主评测流程
# ============================================================

def run_evaluation(timeout=60, output_dir='results/', quick=False, problem_type='production'):
    """
    运行完整的泛化性评测。

    参数:
        timeout: 每次求解的超时时间（秒）
        output_dir: 结果输出目录
        quick: 快速模式，仅运行少量测试用例
        problem_type: 问题类型，'production' 或 'scheduling'
    """
    # 加载对应的数据生成模块和模型集
    _load_problem_module(problem_type)
    active_models = _get_models(problem_type)
    # 准备输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 获取测试用例
    if quick:
        # 快速模式：仅用 2 个用例验证框架
        default_N = 6 if problem_type == 'scheduling' else 4
        cases = [
            {'N': default_N, 'seed': 42, 'budget_scale': 1.0,
             'uncertainty_level': 'medium', 'cost_perturbation': 0.0,
             'description': f'默认参数 (N={default_N})'},
            {'N': default_N, 'seed': 42, 'budget_scale': 0.5,
             'uncertainty_level': 'medium', 'cost_perturbation': 0.0,
             'description': '预算缩放=0.5'},
        ]
    else:
        cases = _get_all_cases()

    model_keys = list(active_models.keys())
    total_runs = len(cases) * len(model_keys)

    problem_label = '异构算力调度' if problem_type == 'scheduling' else '新产品线投产规划'
    print("=" * 70)
    print(f"鲁棒优化泛化性评测 — {problem_label}")
    print("=" * 70)
    print(f"  测试用例数: {len(cases)}")
    print(f"  评测模型数: {len(model_keys)}")
    print(f"  总运行次数: {total_runs}")
    print(f"  超时设置:   {timeout} 秒")
    print(f"  输出目录:   {output_dir}")
    print(f"  模式:       {'快速验证' if quick else '完整评测'}")
    print("=" * 70)

    # 结果收集
    all_results = []
    run_idx = 0

    # 统计信息
    stats = {model_key: {'success': 0, 'fail': 0, 'total': 0}
             for model_key in model_keys}

    for case_idx, case_params in enumerate(cases):
        # 生成实例
        gen_params = {k: v for k, v in case_params.items() if k != 'description'}
        instance = _generate_instance(**gen_params)
        case_id = make_case_id(case_params)
        case_desc = case_params.get('description', case_id)

        for model_key in model_keys:
            run_idx += 1
            model_info = active_models[model_key]
            wrapper_module = model_info['wrapper']

            # 进度显示
            print(f"  [{run_idx:3d}/{total_runs}] "
                  f"Model: {model_key:10s} | Case: {case_desc}", end="")
            sys.stdout.flush()

            # 执行求解（带超时）
            result = solve_with_timeout(wrapper_module, instance, timeout)

            # 分类失败原因
            failure_category = classify_failure(result, instance)

            # 构建完整结果记录
            record = {
                'run_id': run_idx,
                'model': model_key,
                'model_name': model_info['name'],
                'case_id': case_id,
                'case_description': case_desc,
                'case_params': {k: v for k, v in case_params.items()
                                if k != 'description'},
                'N': case_params['N'],
                'objective': result['objective'],
                'feasible': result['feasible'],
                'solve_time': round(result['solve_time'], 4),
                'error': result['error'],
                'solver': result.get('solver', ''),
                'failure_category': failure_category,
            }

            # solution 可能很大，仅在成功时保存前几个值
            if result['solution'] and result['feasible']:
                sol = result['solution']
                if len(sol) <= 10:
                    record['solution'] = sol
                else:
                    # 大规模实例只保存前 10 个
                    keys = list(sol.keys())[:10]
                    record['solution'] = {k: sol[k] for k in keys}
                    record['solution_truncated'] = True

            all_results.append(record)

            # 更新统计
            stats[model_key]['total'] += 1
            if failure_category == 'success':
                stats[model_key]['success'] += 1
                print(f"  -> OK  obj={result['objective']:.2f}  "
                      f"t={result['solve_time']:.2f}s")
            else:
                stats[model_key]['fail'] += 1
                short_err = (result['error'] or '')[:60]
                print(f"  -> FAIL [{failure_category}] {short_err}")

    # ============================================================
    # 保存结果
    # ============================================================

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # 1. 完整结果 JSON
    results_file = os.path.join(output_dir, f'eval_results_{timestamp}.json')
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump({
            'metadata': {
                'timestamp': timestamp,
                'timeout': timeout,
                'num_cases': len(cases),
                'num_models': len(model_keys),
                'total_runs': total_runs,
                'quick_mode': quick,
            },
            'results': all_results,
        }, f, ensure_ascii=False, indent=2)

    # 2. 最新结果的符号链接（覆盖写入固定文件名）
    latest_file = os.path.join(output_dir, 'eval_results_latest.json')
    with open(latest_file, 'w', encoding='utf-8') as f:
        json.dump({
            'metadata': {
                'timestamp': timestamp,
                'timeout': timeout,
                'num_cases': len(cases),
                'num_models': len(model_keys),
                'total_runs': total_runs,
                'quick_mode': quick,
            },
            'results': all_results,
        }, f, ensure_ascii=False, indent=2)

    # ============================================================
    # 打印摘要
    # ============================================================

    print("\n" + "=" * 70)
    print("评测摘要")
    print("=" * 70)
    print(f"\n{'模型':<15s} {'成功':>6s} {'失败':>6s} {'总计':>6s} {'成功率':>8s}")
    print("-" * 45)
    for model_key in model_keys:
        s = stats[model_key]
        rate = f"{s['success']/s['total']*100:.1f}%" if s['total'] > 0 else 'N/A'
        print(f"{model_key:<15s} {s['success']:>6d} {s['fail']:>6d} "
              f"{s['total']:>6d} {rate:>8s}")

    # 按失败类别统计
    print(f"\n{'失败类别统计':}")
    category_counts = {}
    for r in all_results:
        cat = r['failure_category']
        category_counts[cat] = category_counts.get(cat, 0) + 1
    for cat, count in sorted(category_counts.items()):
        print(f"  {cat:<20s}: {count:>4d}")

    print(f"\n结果已保存到: {results_file}")
    print(f"最新结果副本: {latest_file}")

    return all_results


# ============================================================
# 入口
# ============================================================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='鲁棒优化泛化性评测引擎'
    )
    parser.add_argument('--timeout', type=int, default=60,
                        help='每次求解的超时时间（秒），默认 60')
    parser.add_argument('--output', type=str, default='results/',
                        help='结果输出目录，默认 results/')
    parser.add_argument('--quick', action='store_true',
                        help='快速模式，仅运行 2 个测试用例验证框架')
    parser.add_argument('--problem', type=str, default='production',
                        choices=['production', 'scheduling'],
                        help='问题类型: production(新产品线投产) 或 scheduling(异构算力调度)')

    args = parser.parse_args()

    run_evaluation(
        timeout=args.timeout,
        output_dir=args.output,
        quick=args.quick,
        problem_type=args.problem,
    )
