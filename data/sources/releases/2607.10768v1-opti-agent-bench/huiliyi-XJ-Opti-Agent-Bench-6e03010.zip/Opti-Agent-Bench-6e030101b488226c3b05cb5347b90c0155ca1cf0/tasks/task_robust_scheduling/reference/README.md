# Reference — `task_robust_scheduling`

## Included

- `eval_generalization.py`
- `generate_instances.py`
- `generate_instances_scheduling.py`
- `solve.py`
- `verify_optimality_proof.py`
- `verify_standard.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
