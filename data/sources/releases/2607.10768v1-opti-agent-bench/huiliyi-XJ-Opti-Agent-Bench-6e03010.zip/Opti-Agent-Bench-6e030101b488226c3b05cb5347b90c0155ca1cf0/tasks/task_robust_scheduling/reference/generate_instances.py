"""
异构算力调度鲁棒优化测试实例生成器
=============================
为「异构算力集群鲁棒调度」问题生成泛化性测试用例。

问题结构：
  - N 个任务，分配到 CPU/G1(A100)/G2(L4) 三类资源池
  - 每个任务有工作量需求 w_i、SLA 最低完成量 q_i、违约罚金 p_i、GPU 启动费 s_i
  - 异构吞吐率 muC/muG1/muG2，最坏情况折减因子 thetaC/thetaG1/thetaG2
  - 跨池网络约束 B, phi
  - 目标：最小化总成本（资源费 + 启动费 + 罚金），在最坏情况下满足容量/网络约束

参数字典结构（与三个模型代码兼容）：
  N             : int         任务数量
  w             : list[float] 各任务需求规模（工作量单位）
  q             : list[float] 各任务 SLA 最低完成量
  p             : list[float] 各任务违约罚金（元/单位工作量）
  s             : list[float] 各任务 GPU 启动费（元）
  muC           : list[float] 各任务 CPU 名义吞吐
  muG1          : list[float] 各任务 G1(A100) 名义吞吐
  muG2          : list[float] 各任务 G2(L4) 名义吞吐
  kC            : float       CPU 单位成本（元/核·小时）
  kG1           : float       G1 单位成本（元/卡·小时）
  kG2           : float       G2 单位成本（元/卡·小时）
  Ccpu          : float       CPU 池容量（核·小时）
  Cg1           : float       G1 池容量（卡·小时）
  Cg2           : float       G2 池容量（卡·小时）
  thetaC        : float       CPU 最坏折减因子
  thetaG1       : float       G1 最坏折减因子
  thetaG2       : float       G2 最坏折减因子
  B             : float       网络带宽预算（工作量单位/周期）
  phi           : float       最坏网络折减因子
"""

import random
import math

# ============================================================
# 原始问题数据（N=6, 来自问题描述文档的示例实例）
# ============================================================

ORIGINAL_N = 6

ORIGINAL_DATA = {
    "N": 6,
    "w":   [1200, 800, 600, 900, 700, 500],
    "q":   [1000, 700, 450, 750, 500, 350],
    "p":   [50,   80,  30,  60,  40,  90],
    "s":   [2000, 1500, 1000, 2500, 1200, 1800],
    "muC":  [40,  35, 30, 38, 32, 28],
    "muG1": [220, 180, 140, 200, 160, 120],
    "muG2": [140, 120, 100, 130, 110, 90],
    "kC":  2.0,
    "kG1": 30.0,
    "kG2": 18.0,
    "Ccpu": 120.0,
    "Cg1":  6.0,
    "Cg2":  8.0,
    "thetaC": 0.90,
    "thetaG1": 0.70,
    "thetaG2": 0.75,
    "B": 900.0,
    "phi": 0.65,
}


# ============================================================
# 数据生成器
# ============================================================

def generate_instance(N, seed=42, budget_scale=1.0, uncertainty_level='medium',
                      cost_perturbation=0.0):
    """
    生成一个合法的异构算力调度鲁棒优化问题实例。

    参数:
        N: 任务数量（>=1）
        seed: 随机种子（保证可复现）
        budget_scale: 预算/资源缩放因子（1.0=原始容量比例）。
                      影响 Ccpu/Cg1/Cg2/B，<1 表示资源紧张，>1 表示资源宽裕。
        uncertainty_level: 不确定性水平
                          'low'    — thetaG1/G2 接近 1（抖动小）
                          'medium' — 与原始问题一致的不确定性水平
                          'high'   — thetaG1/G2 更低（抖动大，更保守）
        cost_perturbation: 成本扰动幅度（0.0~0.5）。
                           对单位成本 kC/kG1/kG2 以及任务参数施加随机扰动。

    返回:
        dict: 包含问题所有参数的字典
    """
    assert N >= 1, "任务数量至少为 1"
    assert uncertainty_level in ('low', 'medium', 'high'), \
        "uncertainty_level 必须为 'low', 'medium', 'high'"
    assert 0.0 <= cost_perturbation <= 0.5, "cost_perturbation 范围 [0.0, 0.5]"

    rng = random.Random(seed)

    # --- 不确定性参数 ---
    theta_config = {
        'low':    {'thetaC': 0.95, 'thetaG1': 0.85, 'thetaG2': 0.90, 'phi': 0.80},
        'medium': {'thetaC': 0.90, 'thetaG1': 0.70, 'thetaG2': 0.75, 'phi': 0.65},
        'high':   {'thetaC': 0.80, 'thetaG1': 0.55, 'thetaG2': 0.60, 'phi': 0.50},
    }
    theta_params = theta_config[uncertainty_level]

    # --- 单位成本 ---
    kC = ORIGINAL_DATA['kC']
    kG1 = ORIGINAL_DATA['kG1']
    kG2 = ORIGINAL_DATA['kG2']
    if cost_perturbation > 0:
        kC *= (1 + rng.uniform(-cost_perturbation, cost_perturbation))
        kG1 *= (1 + rng.uniform(-cost_perturbation, cost_perturbation))
        kG2 *= (1 + rng.uniform(-cost_perturbation, cost_perturbation))
    kC = round(kC, 2)
    kG1 = round(kG1, 2)
    kG2 = round(kG2, 2)

    # --- 任务参数 ---
    w_list = []
    q_list = []
    p_list = []
    s_list = []
    muC_list = []
    muG1_list = []
    muG2_list = []

    # 基准参数范围（来源于原始问题的统计特征）
    W_RANGE = (300, 1500)           # 工作量范围
    Q_RATIO_RANGE = (0.60, 0.90)    # SLA/工作量比例
    P_RANGE = (20, 120)             # 违约罚金范围
    S_RANGE = (800, 3000)           # GPU 启动费范围
    MU_CPU_RANGE = (20, 50)         # CPU 吞吐范围
    MU_G1_RATIO_RANGE = (4.0, 7.0)  # G1/CPU 吞吐倍率
    MU_G2_RATIO_RANGE = (2.5, 4.5)  # G2/CPU 吞吐倍率

    for i in range(N):
        # 对于前6个任务且为默认参数，使用原始数据
        if (i < ORIGINAL_N and N == ORIGINAL_N and budget_scale == 1.0
                and uncertainty_level == 'medium' and cost_perturbation == 0.0):
            w_list.append(ORIGINAL_DATA['w'][i])
            q_list.append(ORIGINAL_DATA['q'][i])
            p_list.append(ORIGINAL_DATA['p'][i])
            s_list.append(ORIGINAL_DATA['s'][i])
            muC_list.append(ORIGINAL_DATA['muC'][i])
            muG1_list.append(ORIGINAL_DATA['muG1'][i])
            muG2_list.append(ORIGINAL_DATA['muG2'][i])
        elif i < ORIGINAL_N:
            # N=6 但其他参数变化：基于原始数据加扰动
            base_w = ORIGINAL_DATA['w'][i]
            base_q = ORIGINAL_DATA['q'][i]
            base_p = ORIGINAL_DATA['p'][i]
            base_s = ORIGINAL_DATA['s'][i]
            base_muC = ORIGINAL_DATA['muC'][i]
            base_muG1 = ORIGINAL_DATA['muG1'][i]
            base_muG2 = ORIGINAL_DATA['muG2'][i]

            if cost_perturbation > 0:
                base_w = round(base_w * (1 + rng.uniform(-cost_perturbation * 0.3,
                                                          cost_perturbation * 0.3)))
                base_p = round(base_p * (1 + rng.uniform(-cost_perturbation,
                                                          cost_perturbation)))
                base_s = round(base_s * (1 + rng.uniform(-cost_perturbation,
                                                          cost_perturbation)))

            # 保持 q/w 比例合理
            q_ratio = base_q / ORIGINAL_DATA['w'][i]
            base_q = round(base_w * q_ratio)
            base_q = max(1, min(base_q, base_w))

            w_list.append(base_w)
            q_list.append(base_q)
            p_list.append(max(1, base_p))
            s_list.append(max(100, base_s))
            muC_list.append(base_muC)
            muG1_list.append(base_muG1)
            muG2_list.append(base_muG2)
        else:
            # 随机生成新任务
            w_val = rng.randint(*W_RANGE)
            q_ratio = rng.uniform(*Q_RATIO_RANGE)
            q_val = round(w_val * q_ratio)
            q_val = max(1, min(q_val, w_val))

            p_val = rng.randint(*P_RANGE)
            s_val = rng.randint(*S_RANGE)

            muC_val = rng.randint(*MU_CPU_RANGE)
            g1_ratio = rng.uniform(*MU_G1_RATIO_RANGE)
            g2_ratio = rng.uniform(*MU_G2_RATIO_RANGE)
            muG1_val = round(muC_val * g1_ratio)
            muG2_val = round(muC_val * g2_ratio)

            if cost_perturbation > 0:
                p_val = round(p_val * (1 + rng.uniform(-cost_perturbation,
                                                        cost_perturbation)))
                s_val = round(s_val * (1 + rng.uniform(-cost_perturbation,
                                                        cost_perturbation)))

            w_list.append(w_val)
            q_list.append(q_val)
            p_list.append(max(1, p_val))
            s_list.append(max(100, s_val))
            muC_list.append(muC_val)
            muG1_list.append(muG1_val)
            muG2_list.append(muG2_val)

    # --- 资源容量 ---
    # 计算在最坏情况下仅用 CPU 满足所有 SLA 需要的 CPU 容量
    tC = theta_params['thetaC']
    cpu_needed_for_sla = sum(q_list[i] / (tC * muC_list[i]) for i in range(N))

    if (N == ORIGINAL_N and budget_scale == 1.0 and uncertainty_level == 'medium'
            and cost_perturbation == 0.0):
        Ccpu = ORIGINAL_DATA['Ccpu']
        Cg1 = ORIGINAL_DATA['Cg1']
        Cg2 = ORIGINAL_DATA['Cg2']
        B = ORIGINAL_DATA['B']
    else:
        # CPU 容量：给予足够空间满足 SLA（约 cpu_needed * 1.05~1.3 倍）
        cpu_margin = 1.05 if budget_scale >= 1.0 else 0.85
        Ccpu = round(cpu_needed_for_sla * cpu_margin * budget_scale, 1)
        # 保证至少能满足最小任务
        Ccpu = max(Ccpu, round(min(q_list) / (tC * max(muC_list)) * 2, 1))

        # GPU 容量：按任务数缩放
        base_g1 = 6.0 * (N / ORIGINAL_N)
        base_g2 = 8.0 * (N / ORIGINAL_N)
        Cg1 = round(base_g1 * budget_scale, 1)
        Cg2 = round(base_g2 * budget_scale, 1)

        # 网络带宽：按总工作量缩放
        total_w = sum(w_list)
        orig_total_w = sum(ORIGINAL_DATA['w'])
        B = round(ORIGINAL_DATA['B'] * (total_w / orig_total_w) * budget_scale, 1)

    # --- 构建实例字典 ---
    instance = {
        "N": N,
        "w": w_list,
        "q": q_list,
        "p": p_list,
        "s": s_list,
        "muC": muC_list,
        "muG1": muG1_list,
        "muG2": muG2_list,
        "kC": kC,
        "kG1": kG1,
        "kG2": kG2,
        "Ccpu": Ccpu,
        "Cg1": Cg1,
        "Cg2": Cg2,
        "thetaC": theta_params['thetaC'],
        "thetaG1": theta_params['thetaG1'],
        "thetaG2": theta_params['thetaG2'],
        "B": B,
        "phi": theta_params['phi'],
    }

    return instance


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例：在固定规模 N=6（原始规模）下，
    变化预算、不确定性、成本扰动等参数。

    返回:
        list[dict]: 每个元素是传给 generate_instance 的参数字典
    """
    cases = []

    budget_scales = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
    uncertainty_levels = ['low', 'medium', 'high']
    cost_perturbations = [0.0, 0.1, 0.3]

    # --- 单维度变化 ---
    # 预算变化
    for bs in budget_scales:
        cases.append({
            'N': 6, 'seed': 42, 'budget_scale': bs,
            'uncertainty_level': 'medium', 'cost_perturbation': 0.0,
            'description': f'预算缩放={bs}'
        })

    # 不确定性变化
    for ul in uncertainty_levels:
        if ul == 'medium':
            continue
        cases.append({
            'N': 6, 'seed': 42, 'budget_scale': 1.0,
            'uncertainty_level': ul, 'cost_perturbation': 0.0,
            'description': f'不确定性={ul}'
        })

    # 成本扰动
    for cp in cost_perturbations:
        if cp == 0.0:
            continue
        cases.append({
            'N': 6, 'seed': 42, 'budget_scale': 1.0,
            'uncertainty_level': 'medium', 'cost_perturbation': cp,
            'description': f'成本扰动={cp}'
        })

    # --- 组合变化 ---
    for bs in [0.5, 1.0, 2.0]:
        for ul in uncertainty_levels:
            for cp in [0.0, 0.2]:
                if bs == 1.0 and cp == 0.0:
                    continue
                if bs == 1.0 and ul == 'medium':
                    continue
                cases.append({
                    'N': 6, 'seed': 42, 'budget_scale': bs,
                    'uncertainty_level': ul, 'cost_perturbation': cp,
                    'description': f'预算={bs}, 不确定性={ul}, 扰动={cp}'
                })

    # 不同随机种子
    for s in [100, 200, 300]:
        cases.append({
            'N': 6, 'seed': s, 'budget_scale': 1.0,
            'uncertainty_level': 'medium', 'cost_perturbation': 0.1,
            'description': f'seed={s}, 扰动=0.1'
        })

    # 去重
    seen = set()
    unique_cases = []
    for c in cases:
        key = (c['N'], c['seed'], c['budget_scale'],
               c['uncertainty_level'], c['cost_perturbation'])
        if key not in seen:
            seen.add(key)
            unique_cases.append(c)

    return unique_cases


def get_scale_generalization_cases():
    """
    规模泛化测试用例：变化任务数量 N，其他使用默认参数。

    返回:
        list[dict]: 每个元素是传给 generate_instance 的参数字典
    """
    cases = []
    for n in [5, 10, 15, 20, 50, 100]:
        cases.append({
            'N': n, 'seed': 42, 'budget_scale': 1.0,
            'uncertainty_level': 'medium', 'cost_perturbation': 0.0,
            'description': f'规模 N={n}'
        })
    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 辅助：简单可行性检查
# ============================================================

def check_feasibility(instance):
    """
    检查实例是否基本可行：仅使用 CPU 能否满足所有 SLA。
    返回 (feasible, cpu_usage_ratio) 元组。
    """
    N = instance['N']
    tC = instance['thetaC']
    cpu_needed = sum(instance['q'][i] / (tC * instance['muC'][i]) for i in range(N))
    ratio = cpu_needed / instance['Ccpu']
    return ratio <= 1.0, ratio


# ============================================================
# 主程序：验证生成器
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("异构算力调度鲁棒优化测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 验证 N=6 默认参数复现原始问题 ------
    print("\n【1】N=6 默认参数 → 应复现原始问题数据")
    inst = generate_instance(N=6)

    match = True
    for key in ['N', 'w', 'q', 'p', 's', 'muC', 'muG1', 'muG2',
                'kC', 'kG1', 'kG2', 'Ccpu', 'Cg1', 'Cg2',
                'thetaC', 'thetaG1', 'thetaG2', 'B', 'phi']:
        if inst[key] != ORIGINAL_DATA[key]:
            print(f"  ✗ {key} 不匹配: {inst[key]} vs 原始 {ORIGINAL_DATA[key]}")
            match = False

    if match:
        print("  ✓ 所有参数与原始问题完全一致")

    # 可行性检查
    feasible, ratio = check_feasibility(inst)
    print(f"  CPU-only 可行性: {'✓' if feasible else '✗'} (CPU 占用率: {ratio:.2%})")

    # ------ 2. 代表性实例展示 ------
    print("\n" + "=" * 70)
    print("【2】代表性实例")
    print("=" * 70)

    demo_cases = [
        {'N': 6, 'seed': 42, 'budget_scale': 0.5,
         'uncertainty_level': 'medium', 'cost_perturbation': 0.0},
        {'N': 6, 'seed': 42, 'budget_scale': 1.0,
         'uncertainty_level': 'high', 'cost_perturbation': 0.0},
        {'N': 10, 'seed': 42, 'budget_scale': 1.0,
         'uncertainty_level': 'medium', 'cost_perturbation': 0.0},
        {'N': 20, 'seed': 123, 'budget_scale': 1.0,
         'uncertainty_level': 'medium', 'cost_perturbation': 0.2},
    ]

    for params in demo_cases:
        desc = ', '.join(f'{k}={v}' for k, v in params.items())
        inst = generate_instance(**params)
        feasible, ratio = check_feasibility(inst)
        print(f"\n  --- {desc} ---")
        print(f"  任务数: {inst['N']}, CPU容量: {inst['Ccpu']}, "
              f"G1容量: {inst['Cg1']}, G2容量: {inst['Cg2']}")
        print(f"  CPU-only 可行: {'✓' if feasible else '✗'} (占用率: {ratio:.2%})")
        print(f"  网络带宽: {inst['B']}, phi: {inst['phi']}")

    # ------ 3. 测试用例总数 ------
    print("\n" + "=" * 70)
    print("【3】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    # ------ 4. 批量可行性检查 ------
    print("\n" + "=" * 70)
    print("【4】批量可行性检查（所有用例）")
    print("=" * 70)

    n_feasible = 0
    n_total = len(all_cases)
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        inst = generate_instance(**params)
        feasible, ratio = check_feasibility(inst)
        if feasible:
            n_feasible += 1
        else:
            print(f"  ✗ CPU-only 不可行: {c['description']} (占用率: {ratio:.2%})")

    print(f"  CPU-only 可行实例: {n_feasible}/{n_total}")
    if n_feasible == n_total:
        print("  ✓ 所有测试用例的 SLA 仅用 CPU 即可满足（最基本可行性保证）")

    print("\n完成。")
