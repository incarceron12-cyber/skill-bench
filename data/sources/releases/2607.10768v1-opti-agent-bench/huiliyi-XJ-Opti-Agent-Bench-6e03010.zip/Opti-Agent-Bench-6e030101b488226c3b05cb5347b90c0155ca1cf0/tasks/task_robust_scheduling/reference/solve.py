# 提取自: problem/problem.md
# 类型: 异构算力调度参考解法

# robust_hetero_scheduling.py
from ortools.sat.python import cp_model

def solve_instance(data, scale=100, time_limit_s=10):
    """
    data fields:
      N
      w[i], q[i]            (work units)
      p[i], s[i]            (yuan per work-unit, yuan)
      muC[i], muG1[i], muG2[i] (work units per resource-hour)
      kC, kG1, kG2          (yuan per resource-hour)
      Ccpu, Cg1, Cg2        (resource-hours capacity)
      thetaC, thetaG1, thetaG2 (worst-case throughput factors)
      B, phi                (network budget, worst-case factor)
    """
    N = data["N"]
    w = data["w"]
    q = data["q"]
    p = data["p"]
    s = data["s"]
    muC = data["muC"]
    muG1 = data["muG1"]
    muG2 = data["muG2"]

    kC, kG1, kG2 = data["kC"], data["kG1"], data["kG2"]
    Ccpu, Cg1, Cg2 = data["Ccpu"], data["Cg1"], data["Cg2"]
    thetaC, thetaG1, thetaG2 = data["thetaC"], data["thetaG1"], data["thetaG2"]
    B, phi = data["B"], data["phi"]

    model = cp_model.CpModel()

    # scaled integer vars for work allocations
    uC = [model.NewIntVar(0, int(w[i]*scale), f"uC[{i}]") for i in range(N)]
    u1 = [model.NewIntVar(0, int(w[i]*scale), f"uG1[{i}]") for i in range(N)]
    u2 = [model.NewIntVar(0, int(w[i]*scale), f"uG2[{i}]") for i in range(N)]

    # completion and shortfall
    comp = [model.NewIntVar(0, int(w[i]*scale), f"comp[{i}]") for i in range(N)]
    short = [model.NewIntVar(0, int(w[i]*scale), f"short[{i}]") for i in range(N)]

    # GPU usage indicator (if any GPU work > 0)
    g = [model.NewBoolVar(f"gpu_used[{i}]") for i in range(N)]

    # main share max(uC,u1,u2) via auxiliary max var
    umax = [model.NewIntVar(0, int(w[i]*scale), f"umax[{i}]") for i in range(N)]
    # v_i = comp - umax
    v = [model.NewIntVar(0, int(w[i]*scale), f"v[{i}]") for i in range(N)]

    for i in range(N):
        model.Add(comp[i] == uC[i] + u1[i] + u2[i])
        model.Add(comp[i] <= int(w[i]*scale))

        # SLA shortfall: short >= q - comp, short >= 0
        model.Add(short[i] >= int(q[i]*scale) - comp[i])
        model.Add(short[i] >= 0)

        # umax = max(uC,u1,u2)
        model.Add(umax[i] >= uC[i])
        model.Add(umax[i] >= u1[i])
        model.Add(umax[i] >= u2[i])
        # upper bound: umax <= uC + M*(1-bC) etc. Implement max by selection booleans
        bC = model.NewBoolVar(f"bC[{i}]")
        b1 = model.NewBoolVar(f"b1[{i}]")
        b2 = model.NewBoolVar(f"b2[{i}]")
        model.Add(bC + b1 + b2 == 1)
        M = int(w[i]*scale)
        model.Add(umax[i] <= uC[i] + M*(1 - bC))
        model.Add(umax[i] <= u1[i] + M*(1 - b1))
        model.Add(umax[i] <= u2[i] + M*(1 - b2))

        model.Add(v[i] == comp[i] - umax[i])
        model.Add(v[i] >= 0)

        # GPU used indicator: if u1+u2 > 0 then g=1; if g=0 then u1=u2=0
        model.Add(u1[i] + u2[i] <= M * g[i])

    # Capacity constraints under worst-case (linear in u because we fixed worst-case theta)
    # resource_hours = sum(u / (theta*mu))
    # To keep integer linear, multiply by scale and by denominators:
    # We'll enforce: sum( u_scaled / (theta*mu) ) <= C
    # Use rational approximation by multiplying both sides with LCM-like factor.
    # For simplicity: use large constant DEN=10000 and precompute coeff = round(DEN/(theta*mu)).
    DEN = 10000

    def coeff(theta, mu):
        return int(round(DEN / (theta * mu)))


    cpu_lhs = [ ]


    g1_lhs = [ ]


    g2_lhs = [ ]

    for i in range(N):
        cpu_lhs.append(coeff(thetaC, muC[i]) * uC[i])
        g1_lhs.append(coeff(thetaG1, muG1[i]) * u1[i])
        g2_lhs.append(coeff(thetaG2, muG2[i]) * u2[i])

    # sum(coeff*u_scaled) <= C * DEN * scale
    model.Add(sum(cpu_lhs) <= int(Ccpu * DEN * scale))
    model.Add(sum(g1_lhs) <= int(Cg1 * DEN * scale))
    model.Add(sum(g2_lhs) <= int(Cg2 * DEN * scale))

    # Network constraint: sum v_i <= phi*B
    model.Add(sum(v) <= int(phi * B * scale))

    # Objective: resource cost + startup + penalty
    # resource cost: k * sum(u/(theta*mu))
    # approximate similarly: cost ~= k * (sum(coeff*u_scaled) / (DEN*scale))
    # We'll minimize scaled cost integer: multiply everything by (DEN*scale)

    obj_terms = [ ]


    # resource costs (scaled)
    obj_terms.append(int(kC) * sum(cpu_lhs))
    obj_terms.append(int(kG1) * sum(g1_lhs))
    obj_terms.append(int(kG2) * sum(g2_lhs))

    # startup costs: s_i * g_i, scaled by (DEN*scale)
    for i in range(N):
        obj_terms.append(int(s[i] * DEN * scale) * g[i])

    # penalty: p_i * shortfall, short in work units -> yuan; scale by (DEN*scale)
    for i in range(N):
        obj_terms.append(int(p[i] * DEN) * short[i])  # short already scaled by scale

    model.Minimize(sum(obj_terms))

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit_s
    solver.parameters.num_search_workers = 8

    status = solver.Solve(model)
    if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        return None

    # Recover solution
    sol = {
        "objective_scaled": solver.ObjectiveValue(),
        "uC": [solver.Value(uC[i]) / scale for i in range(N)],
        "uG1": [solver.Value(u1[i]) / scale for i in range(N)],
        "uG2": [solver.Value(u2[i]) / scale for i in range(N)],
        "completed": [solver.Value(comp[i]) / scale for i in range(N)],
        "shortfall": [solver.Value(short[i]) / scale for i in range(N)],
        "gpu_used": [solver.Value(g[i]) for i in range(N)],
        "v": [solver.Value(v[i]) / scale for i in range(N)],
    }

    # Compute human-readable approximate yuan cost (unscaled, from recovered values)
    # Use worst-case thetas
    cpu_hours = sum(sol["uC"][i] / (thetaC * muC[i]) for i in range(N))
    g1_hours = sum(sol["uG1"][i] / (thetaG1 * muG1[i]) for i in range(N))
    g2_hours = sum(sol["uG2"][i] / (thetaG2 * muG2[i]) for i in range(N))
    resource_cost = kC * cpu_hours + kG1 * g1_hours + kG2 * g2_hours
    startup_cost = sum(s[i] for i in range(N) if sol["gpu_used"][i] == 1)
    penalty_cost = sum(p[i] * sol["shortfall"][i] for i in range(N))
    sol["cpu_hours_wc"] = cpu_hours
    sol["g1_hours_wc"] = g1_hours
    sol["g2_hours_wc"] = g2_hours
    sol["cost_yuan_approx"] = resource_cost + startup_cost + penalty_cost
    sol["resource_cost_yuan_approx"] = resource_cost
    sol["startup_cost_yuan"] = startup_cost
    sol["penalty_cost_yuan"] = penalty_cost
    sol["network_used"] = sum(sol["v"])

    return sol

if __name__ == "__main__":
    # A small runnable example instance
    data = {
        "N": 6,
        "w":   [1200, 800, 600, 900, 700, 500],
        "q":   [1000, 700, 450, 750, 500, 350],
        "p":   [50,   80,  30,  60,  40,  90],   # yuan per unit shortfall
        "s":   [2000, 1500, 1000, 2500, 1200, 1800],  # GPU startup

        # nominal throughput (work units per resource-hour)
        "muC":  [40,  35, 30, 38, 32, 28],
        "muG1": [220, 180, 140, 200, 160, 120],
        "muG2": [140, 120, 100, 130, 110, 90],

        # unit costs
        "kC":  2.0,   # yuan per core-hour
        "kG1": 30.0,  # yuan per gpu-hour
        "kG2": 18.0,

        # capacities in this period
        "Ccpu": 120.0,  # core-hours
        "Cg1":  6.0,    # gpu-hours
        "Cg2":  8.0,

        # worst-case throughput factors
        "thetaC": 0.90,
        "thetaG1": 0.70,
        "thetaG2": 0.75,

        # network
        "B": 900.0,     # work units
        "phi": 0.65,
    }

    sol = solve_instance(data, scale=100, time_limit_s=10)
    if sol is None:
        print("No feasible solution.")
    else:
        print("Approx total cost (yuan):", round(sol["cost_yuan_approx"], 2))
        print("Resource cost (yuan):", round(sol["resource_cost_yuan_approx"], 2))
        print("Startup cost (yuan):", round(sol["startup_cost_yuan"], 2))
        print("Penalty cost (yuan):", round(sol["penalty_cost_yuan"], 2))
        print("Worst-case hours: CPU", round(sol["cpu_hours_wc"], 2),
              "G1", round(sol["g1_hours_wc"], 2),
              "G2", round(sol["g2_hours_wc"], 2))
        print("Network used:", sol["network_used"], " / budget:", data["phi"]*data["B"])
        for i in range(data["N"]):
            print(f"Task {i}: uC={sol['uC'][i]:.2f}, uG1={sol['uG1'][i]:.2f}, uG2={sol['uG2'][i]:.2f}, "
                  f"done={sol['completed'][i]:.2f}, short={sol['shortfall'][i]:.2f}, "
                  f"gpu={sol['gpu_used'][i]}, v={sol['v'][i]:.2f}")
