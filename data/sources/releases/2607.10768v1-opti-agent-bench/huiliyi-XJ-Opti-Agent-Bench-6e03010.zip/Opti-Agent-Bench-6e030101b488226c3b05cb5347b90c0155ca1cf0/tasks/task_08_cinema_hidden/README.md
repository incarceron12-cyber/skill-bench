# task_08_cinema_hidden — Restricted Holdout

Hidden-constraint cinema scheduling. **Not part of the open evaluation set.**

- `problem.md` and references are withheld to reduce contamination.
- Request access via GitHub issue (`holdout_access` template).
- Private source: `测试题/电影院/问题2_不可见/`
