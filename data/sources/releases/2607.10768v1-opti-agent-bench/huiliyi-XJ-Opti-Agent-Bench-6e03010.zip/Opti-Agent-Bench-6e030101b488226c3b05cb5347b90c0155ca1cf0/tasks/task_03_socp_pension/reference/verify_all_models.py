#!/usr/bin/env python3
"""
验证所有5个模型的投资组合配置数值结果
基准: 标准答案 收益率6.4472%, 波动率6.0000%
"""
import numpy as np

# 资产参数
returns = np.array([0.035, 0.055, 0.12, 0.08, 0.025])
volatilities = np.array([0.02, 0.05, 0.20, 0.15, 0.005])
asset_names = ['国债', '企业债', '股票指数基金', 'REITS', '货币基金']

# 相关系数矩阵
corr = np.array([
    [1.00, 0.60, -0.10, 0.05, 0.30],
    [0.60, 1.00,  0.20, 0.25, 0.15],
    [-0.10, 0.20, 1.00, 0.65, -0.05],
    [0.05, 0.25,  0.65, 1.00, 0.00],
    [0.30, 0.15, -0.05, 0.00, 1.00]
])

# 构建协方差矩阵
cov_matrix = np.outer(volatilities, volatilities) * corr

def evaluate_portfolio(name, weights, claimed_return=None, claimed_vol=None):
    w = np.array(weights)
    port_return = np.dot(w, returns)
    port_var = np.dot(w, np.dot(cov_matrix, w))
    port_vol = np.sqrt(port_var)
    rf = 0.025
    sharpe = (port_return - rf) / port_vol if port_vol > 0 else 0
    
    print(f"\n{'='*60}")
    print(f"模型: {name}")
    print(f"{'='*60}")
    print(f"配置: {dict(zip(asset_names, [f'{x:.4f}' for x in w]))}")
    print(f"权重之和: {sum(w):.6f}")
    print(f"计算收益率: {port_return:.6f} ({port_return*100:.4f}%)")
    print(f"计算波动率: {port_vol:.6f} ({port_vol*100:.4f}%)")
    print(f"夏普比率:   {sharpe:.4f}")
    
    if claimed_return is not None:
        print(f"模型声称收益率: {claimed_return:.6f}, 差值: {abs(port_return-claimed_return):.6f}")
    if claimed_vol is not None:
        print(f"模型声称波动率: {claimed_vol:.6f}, 差值: {abs(port_vol-claimed_vol):.6f}")
    
    # 约束检查
    print(f"\n--- 约束检查 ---")
    bounds = [(0.05, 0.50), (0.05, 0.40), (0.00, 0.30), (0.00, 0.20), (0.05, 0.40)]
    for i, (lb, ub) in enumerate(bounds):
        status = "✓" if lb <= w[i] <= ub else "✗"
        print(f"  {asset_names[i]}: {w[i]:.4f} ∈ [{lb:.2f}, {ub:.2f}] {status}")
    
    equity = w[2] + w[3]
    fixed_income = w[0] + w[1]
    print(f"  权益类合计: {equity:.4f} ≤ 0.40  {'✓' if equity<=0.40 else '✗'}")
    print(f"  固收类合计: {fixed_income:.4f} ≥ 0.30  {'✓' if fixed_income>=0.30 else '✗'}")
    print(f"  波动率: {port_vol:.6f} ≤ 0.06  {'✓' if port_vol<=0.06+1e-6 else '✗'}")
    print(f"  权重和=1: {sum(w):.6f}  {'✓' if abs(sum(w)-1)<0.001 else '✗'}")
    
    return port_return, port_vol, sharpe

print("标准答案验证:")
std_ret, std_vol, std_sharpe = evaluate_portfolio(
    "标准答案", [0.2871, 0.4000, 0.2535, 0.0094, 0.0500],
    claimed_return=0.064472, claimed_vol=0.060000)

print("\n\n" + "="*60)
print("5个模型结果验证")
print("="*60)

# Claude: w=[0.39, 0.19, 0.23, 0.09, 0.10]
evaluate_portfolio("Claude-Sonnet-4-6",
    [0.39, 0.19, 0.23, 0.09, 0.10],
    claimed_return=0.0614, claimed_vol=0.05937)

# Gemini: w=[0.20, 0.25, 0.25, 0.10, 0.20]
evaluate_portfolio("Gemini-2.5-Pro",
    [0.20, 0.25, 0.25, 0.10, 0.20],
    claimed_return=0.0638, claimed_vol=0.0595)

# Kimi: 需要运行代码确认，先用声称值验证
# Kimi代码中有cov_robust = cov_matrix * 1.1的问题

# DeepSeek: w=[0.11, 0.19, 0.11, 0.19, 0.40]
evaluate_portfolio("DeepSeek-v3.2",
    [0.11, 0.19, 0.11, 0.19, 0.40],
    claimed_return=0.0527, claimed_vol=0.049548)

# Qwen: w=[0.35, 0.25, 0.15, 0.05, 0.20]
evaluate_portfolio("Qwen-3.5-Plus",
    [0.35, 0.25, 0.15, 0.05, 0.20],
    claimed_return=0.0535, claimed_vol=0.0412)

print("\n\n" + "="*60)
print("对比总结")
print("="*60)
print(f"{'模型':<20} {'收益率':>8} {'波动率':>8} {'夏普':>6} {'vs标准收益差':>12}")
models = {
    "标准答案": [0.2871, 0.4000, 0.2535, 0.0094, 0.0500],
    "Claude": [0.39, 0.19, 0.23, 0.09, 0.10],
    "Gemini": [0.20, 0.25, 0.25, 0.10, 0.20],
    "DeepSeek": [0.11, 0.19, 0.11, 0.19, 0.40],
    "Qwen": [0.35, 0.25, 0.15, 0.05, 0.20],
}
for name, w in models.items():
    w = np.array(w)
    r = np.dot(w, returns)
    v = np.sqrt(np.dot(w, np.dot(cov_matrix, w)))
    s = (r - 0.025) / v
    diff = r - 0.064472
    print(f"{name:<20} {r*100:>7.4f}% {v*100:>7.4f}% {s:>6.4f} {diff*100:>+10.4f}%")

