"""
二阶锥优化 Problem 01: 企业年金投资组合配置
SOCP (Second-Order Cone Programming)

数学模型：
    max  μ^T w
    s.t. ||Σ^{1/2} w||_2 ≤ σ_max       (二阶锥约束)
         Σ w_j = 1                       (权重之和)
         l_j ≤ w_j ≤ u_j                (配置比例限制)
         w_股票 + w_REITS ≤ 0.40         (权益类上限)
         w_国债 + w_企业债 ≥ 0.30         (固收类下限)
"""

import numpy as np
from scipy.optimize import minimize

# ============================================================
# 数据定义
# ============================================================

assets = ['国债', '企业债', '股票指数', 'REITS', '货币基金']
n = len(assets)

# 年化预期收益率
mu = np.array([0.035, 0.055, 0.12, 0.08, 0.025])

# 年化波动率（标准差）
vol = np.array([0.02, 0.05, 0.20, 0.15, 0.005])

# 相关系数矩阵
corr = np.array([
    [1.00, 0.60, -0.10, 0.05, 0.30],
    [0.60, 1.00,  0.20, 0.25, 0.15],
    [-0.10, 0.20, 1.00, 0.65, -0.05],
    [0.05, 0.25,  0.65, 1.00, 0.00],
    [0.30, 0.15, -0.05, 0.00, 1.00],
])

# 协方差矩阵
Cov = np.diag(vol) @ corr @ np.diag(vol)
L = np.linalg.cholesky(Cov)  # Σ = L L^T

# 配置比例限制
lower = np.array([0.05, 0.05, 0.00, 0.00, 0.05])
upper = np.array([0.50, 0.40, 0.30, 0.20, 0.40])

sigma_max = 0.06  # 6%
total_budget = 2.0  # 亿元

print("=" * 60)
print("参数检查")
print("=" * 60)
for i, a in enumerate(assets):
    print(f"  {a}: 收益{mu[i]*100:.1f}%, 波动率{vol[i]*100:.1f}%, "
          f"范围[{lower[i]*100:.0f}%, {upper[i]*100:.0f}%]")
eig = np.linalg.eigvalsh(Cov)
print(f"  协方差矩阵正定: {'✓' if all(eig > 0) else '✗'}")

# ============================================================
# 求解 (SLSQP处理QCQP/SOCP)
# ============================================================

constraints = [
    {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},
    {'type': 'ineq', 'fun': lambda w: sigma_max**2 - w @ Cov @ w,
     'jac': lambda w: -2 * Cov @ w},
    {'type': 'ineq', 'fun': lambda w: 0.40 - w[2] - w[3]},
    {'type': 'ineq', 'fun': lambda w: w[0] + w[1] - 0.30},
]
bounds = list(zip(lower, upper))

best_result, best_return = None, -np.inf
np.random.seed(42)

for trial in range(200):
    if trial == 0:
        w0 = np.array([0.20, 0.20, 0.20, 0.15, 0.25])
    else:
        w0 = np.random.dirichlet(np.ones(n))
        w0 = np.clip(w0, lower, upper)
        w0 = w0 / w0.sum()

    res = minimize(lambda w: -mu @ w, w0, method='SLSQP',
                   jac=lambda w: -mu, bounds=bounds,
                   constraints=constraints,
                   options={'maxiter': 1000, 'ftol': 1e-12})

    if res.success and -res.fun > best_return:
        pv = np.sqrt(res.x @ Cov @ res.x)
        if pv <= sigma_max + 1e-8:
            best_return = -res.fun
            best_result = res

w = best_result.x
ret = mu @ w
risk = np.sqrt(w @ Cov @ w)

print("\n" + "=" * 60)
print(f"求解状态: Optimal")
print(f"最优年化收益率: {ret*100:.4f}%")
print(f"组合波动率: {risk*100:.4f}%")
print(f"年预期收益: {ret * total_budget * 10000:.2f} 万元")
print("=" * 60)

# ============================================================
# 详细结果
# ============================================================

print("\n【最优配置方案】")
print(f"{'资产':8s} {'比例':>8s} {'金额(万)':>10s} {'收益(万)':>10s}")
print("-" * 42)
for i, a in enumerate(assets):
    amt = w[i] * total_budget * 10000
    r = w[i] * mu[i] * total_budget * 10000
    print(f"{a:8s} {w[i]*100:>7.2f}% {amt:>9.0f} {r:>9.1f}")

eq = w[2] + w[3]
fi = w[0] + w[1]
print(f"\n【约束检查】")
print(f"  波动率: {risk*100:.4f}% ≤ {sigma_max*100}% "
      f"{'(紧约束)' if abs(risk-sigma_max)<1e-4 else '(松约束)'}")
print(f"  权益类: {eq*100:.2f}% ≤ 40% {'✓' if eq<=0.401 else '✗'}")
print(f"  固收类: {fi*100:.2f}% ≥ 30% {'✓' if fi>=0.299 else '✗'}")

sharpe = (ret - 0.025) / risk

# ============================================================
# 对比分析
# ============================================================

print("\n" + "=" * 60)
print("对比分析：有/无波动率约束")
print("=" * 60)

# 无风险约束
res_nr = minimize(lambda w: -mu @ w,
                  np.array([0.20, 0.20, 0.20, 0.15, 0.25]),
                  method='SLSQP', jac=lambda w: -mu, bounds=bounds,
                  constraints=[
                      {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},
                      {'type': 'ineq', 'fun': lambda w: 0.40 - w[2] - w[3]},
                      {'type': 'ineq', 'fun': lambda w: w[0] + w[1] - 0.30},
                  ],
                  options={'maxiter': 1000, 'ftol': 1e-12})

w_nr = res_nr.x
ret_nr = mu @ w_nr
risk_nr = np.sqrt(w_nr @ Cov @ w_nr)

print(f"\n无波动率约束: 收益{ret_nr*100:.4f}%, 波动率{risk_nr*100:.4f}%")
for i, a in enumerate(assets):
    print(f"  {a}: {w_nr[i]*100:.2f}%")

print(f"\n有波动率约束: 收益{ret*100:.4f}%, 波动率{risk*100:.4f}%")
for i, a in enumerate(assets):
    print(f"  {a}: {w[i]*100:.2f}%")

print(f"\n风险约束代价: 收益率降低 {(ret_nr-ret)*100:.4f}%")
print(f"  年少赚 {(ret_nr-ret)*total_budget*10000:.1f} 万元")

# 敏感性分析
print(f"\n敏感性：波动率上限 vs 最优收益率")
print(f"{'σ_max':>8s} {'收益率':>10s} {'收益(万)':>10s}")
print("-" * 32)
for s in [0.04, 0.05, 0.06, 0.07, 0.08, 0.10, 0.15]:
    cons_s = [
        {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},
        {'type': 'ineq', 'fun': lambda w, s=s: s**2 - w @ Cov @ w},
        {'type': 'ineq', 'fun': lambda w: 0.40 - w[2] - w[3]},
        {'type': 'ineq', 'fun': lambda w: w[0] + w[1] - 0.30},
    ]
    r2 = minimize(lambda w: -mu @ w, w, method='SLSQP',
                  jac=lambda w: -mu, bounds=bounds,
                  constraints=cons_s, options={'maxiter': 1000, 'ftol': 1e-12})
    if r2.success:
        rv = -r2.fun
        print(f"{s*100:>7.0f}% {rv*100:>9.4f}% {rv*total_budget*10000:>9.1f}")
    else:
        print(f"{s*100:>7.0f}%  不可行")

# SOCP结构验证
print("\n" + "=" * 60)
print("SOCP结构验证")
print("=" * 60)
print(f"  夏普比率: {sharpe:.4f}")
Lw = L.T @ w
print(f"  ||L^T w||_2 = {np.linalg.norm(Lw):.6f}")
print(f"  σ_max       = {sigma_max:.6f}")
print(f"  二阶锥约束: {'紧约束 ✓' if abs(np.linalg.norm(Lw)-sigma_max)<1e-4 else '松'}")

