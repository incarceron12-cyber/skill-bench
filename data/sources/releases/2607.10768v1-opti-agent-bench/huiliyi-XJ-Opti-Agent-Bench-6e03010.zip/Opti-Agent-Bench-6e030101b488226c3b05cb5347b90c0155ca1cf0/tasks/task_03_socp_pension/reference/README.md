# Reference — `task_03_socp_pension`

## Included

- `generate_instances.py`
- `problem_01_solve.py`
- `solve.py`
- `verify_all_models.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
