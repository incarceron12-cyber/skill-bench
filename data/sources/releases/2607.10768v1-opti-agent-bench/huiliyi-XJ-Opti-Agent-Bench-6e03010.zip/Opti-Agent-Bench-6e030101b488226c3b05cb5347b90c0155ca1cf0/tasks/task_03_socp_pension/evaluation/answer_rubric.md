# Metric-Aligned Answer Rubric：二阶锥优化 / 问题1_企业年金投资

## Problem Analysis

本题是一个**收益最大化型二阶锥优化（SOCP）/ 凸 QCQP**问题：

- 决策变量：五类资产配置权重 `w`。
- 目标函数：最大化线性预期收益 `mu^T w`。
- 核心风险约束：组合波动率 `sqrt(w^T Sigma w) <= 0.06`，等价于 `||L^T w||_2 <= 0.06`。
- 数据处理：必须由单资产波动率和相关系数矩阵构造协方差矩阵 `Sigma = diag(sigma) corr diag(sigma)`。
- 线性约束：权重和为 1，单资产上下界，权益类上限，固定收益类下限。
- 参考最优解：收益率约 `6.4472%`，波动率 `6.0000%`，配置约为国债 `28.71%`、企业债 `40.00%`、股票 `25.35%`、REITS `0.94%`、货币基金 `5.00%`。

关键陷阱：

- 不能把风险放进目标函数，偷换成经典均值-方差 QP、最小方差或最大夏普比。
- 不能直接使用相关系数矩阵当协方差矩阵。
- 不能用简单加权波动率代替协方差组合波动率。
- 不能为了提高收益把 6% 风控上限放宽到 6.09%。
- 不能只给保守可行解，必须尽量利用风险预算逼近收益最大化边界。
- 敏感性分析应真实重求不同波动率上限下的配置，而不是只写定性趋势。

## Global Scoring Rules

- 每个统一指标满分为 5 分。
- 每个子项可按 `0 / partial / full` 给分；若证据明显不足，给 0。
- `Scoring Method = Automatic` 表示优先使用代码运行、reference 复算、泛化评估结果或独立数值检查。
- `Scoring Method = LLM Judge` 表示由大模型根据回答文本进行语义评分。
- `Scoring Method = Hybrid` 表示先抽取代码或运行结果，再由大模型比较文本声明与实际实现。
- 本题有 `scripts/generate_instances.py`、`scripts/eval_generalization.py` 和 `results/eval_results_latest.json`，且题面要求波动率上限敏感性分析，因此 `CE.3` 正式评分并纳入总分。

## ME.1 模型正确性

评估回答是否正确识别 SOCP 结构、目标函数、风险约束和全部监管约束。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME1-R1 | 明确识别为 SOCP / 二阶锥优化 / 凸 QCQP，而不是普通 Markowitz QP | response text | LLM Judge | 0.80 |
| ME1-R2 | 正确区分线性收益目标与二阶锥风险约束，风险上限不进入目标函数 | response text / code | Hybrid | 0.85 |
| ME1-R3 | 目标方向正确：最大化 `mu^T w`，不偷换为最大夏普、最小方差或均衡配置 | response text / code | Hybrid | 0.85 |
| ME1-R4 | 从波动率和相关系数正确构造协方差矩阵 `Sigma` | response text / code | Hybrid | 0.85 |
| ME1-R5 | 正确表达波动率约束 `sqrt(w^T Sigma w) <= 0.06` 或等价二阶锥形式 | response text / code | Hybrid | 0.90 |
| ME1-R6 | 完整包含预算约束、单资产上下界、权益类上限、固定收益类下限 | response text / code | Hybrid | 0.75 |

ME.1 total: 5 points

## ME.2 模型简洁性

评估建模和求解路线是否聚焦于本题本身，避免无关扩展或评估脚本导向的做法。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME2-R1 | 使用最小必要变量：五维权重向量即可表达配置问题 | response text / code | LLM Judge | 0.75 |
| ME2-R2 | 求解方法与结构匹配：CVXPY/conic solver、SLSQP QCQP 或等价凸优化求解 | response text / code | Hybrid | 1.00 |
| ME2-R3 | 使用原题参数，不擅自放大协方差、放宽波动率上限或改变风险预算 | response text / code | Hybrid | 1.15 |
| ME2-R4 | 敏感性分析只改变题面要求的波动率上限等核心参数，不混入无关目标 | response text / code | LLM Judge | 0.90 |
| ME2-R5 | 报告聚焦配置、收益、风险、方法和敏感性，不用大量评估器设计或关键词堆砌稀释主线 | response text | LLM Judge | 1.20 |

ME.2 total: 5 points

## ME.3 模型-代码一致性

评估文字声明、代码实现和数值输出是否相互一致。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME3-R1 | 文本声称的问题类型和代码实际求解的模型一致 | response text + code | Hybrid | 0.85 |
| ME3-R2 | 文本中的目标、约束和代码中的目标、约束一致 | response text + code | Hybrid | 1.05 |
| ME3-R3 | 文本中的配置比例、收益率和波动率与代码运行结果一致 | response text + execution result | Hybrid | 1.25 |
| ME3-R4 | 文本中的敏感性分析与代码实际重求解结果一致 | response text + code | Hybrid | 0.95 |
| ME3-R5 | 没有出现“代码最优解”和“报告保守方案”并存但未解释的冲突 | response text + code | Hybrid | 0.90 |

ME.3 total: 5 points

## CE.1 代码可行性与正确性

评估代码是否可运行，并能复现可行且接近最优的配置。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE1-R1 | 提供可抽取、可执行的 Python 求解代码，而非只有说明或验证脚本 | code block / extracted code | Automatic + LLM fallback | 0.85 |
| CE1-R2 | 原始代码在当前环境中可运行到主要结果输出，无缺失依赖或不可写路径失败 | execution result | Automatic | 0.90 |
| CE1-R3 | 输出组合满足所有硬约束，尤其严格 `portfolio_volatility <= 0.06` | execution result / reference | Automatic | 1.15 |
| CE1-R4 | 收益率、波动率和权重接近 reference，风险预算基本绑定 | execution result / reference | Automatic | 1.20 |
| CE1-R5 | 代码实现真实优化求解，而不是只验证硬编码配置 | code / execution result | Hybrid | 0.90 |

CE.1 total: 5 points

## CE.2 代码质量与效率

评估代码结构、依赖、数值稳定性、效率和可维护性。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE2-R1 | 代码模块化清楚，数据、协方差、目标、约束、求解、报告输出分工明确 | code | LLM Judge | 0.95 |
| CE2-R2 | 对求解器失败、依赖缺失、无可行解和边界数值误差有合理处理 | code / execution result | Automatic + LLM Judge | 0.95 |
| CE2-R3 | 算法效率适合本题和泛化规模，不依赖过度多起点或超长搜索 | code / generalization result | Hybrid | 0.95 |
| CE2-R4 | 输入输出路径、运行入口和结果格式合理，便于复现和 wrapper 调用 | code / execution result | Automatic + LLM Judge | 0.90 |
| CE2-R5 | 包含独立复算、自检或约束检查，能暴露波动率、收益和比例约束错误 | code / execution result | Hybrid | 1.25 |

CE.2 total: 5 points

## CE.3 代码鲁棒性

评估代码在参数变化、风险上限变化和规模变化下的稳定性与解质量。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE3-R1 | 完成波动率上限敏感性分析，至少覆盖 `4% / 6% / 8%` 并真实重求解 | response text / code / execution | Automatic + LLM Judge | 1.00 |
| CE3-R2 | 参数泛化成功率高，能适应收益、相关性、约束松紧等变化 | results/eval_results_latest.json / code | Automatic | 1.10 |
| CE3-R3 | 规模泛化成功率高，资产数扩展时仍能在超时限制内求解 | results/eval_results_latest.json / code | Automatic | 0.95 |
| CE3-R4 | 多实例下解质量稳定，接近 reference，避免长期保守或风险预算闲置 | results/eval_results_latest.json / reference comparison | Automatic + LLM Judge | 1.25 |
| CE3-R5 | 对参数估计误差、协方差半正定性、求解器局限和业务落地风险有合理说明 | response text | LLM Judge | 0.70 |

CE.3 total: 5 points

## RE.1 报告完整性

评估回答是否完整覆盖资产配置、收益风险、方法论和敏感性分析。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE1-R1 | 给出五类资产配置比例和 2 亿元对应金额 | response text / output | LLM Judge + execution | 0.95 |
| RE1-R2 | 给出预期收益率、组合波动率、预期收益金额和约束检查 | response text / output | LLM Judge + execution | 1.05 |
| RE1-R3 | 给出数学模型：变量、目标、协方差、二阶锥/方差约束和线性约束 | response text | LLM Judge | 1.10 |
| RE1-R4 | 给出求解方法、求解器选择和复现步骤 | response text / code | LLM Judge | 0.85 |
| RE1-R5 | 给出波动率上限收紧/放宽下的敏感性分析 | response text / output | LLM Judge + execution | 1.05 |

RE.1 total: 5 points

## RE.2 解释清晰度

评估回答是否清楚解释配置逻辑、约束活跃性和业务含义。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE2-R1 | 清楚解释为何企业债倾向满配、货币基金倾向下限 | response text | LLM Judge | 1.00 |
| RE2-R2 | 清楚解释 REITS 与股票高相关导致 REITS 低配的原因 | response text | LLM Judge | 0.95 |
| RE2-R3 | 清楚解释国债和股票负相关的分散化作用 | response text | LLM Judge | 0.85 |
| RE2-R4 | 清楚说明波动率约束是否紧绑定及其风险收益含义 | response text / output | LLM Judge + execution | 1.10 |
| RE2-R5 | 文字组织清楚，不过度混入无关评估流程、模板字段或泛泛战略建议 | response text | LLM Judge | 1.10 |

RE.2 total: 5 points

## RE.3 结果可复现性

评估报告声称的结果是否可以由代码或 reference 独立复现。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE3-R1 | 提供明确运行入口、依赖说明或可直接运行代码 | response text / code | Automatic + LLM Judge | 0.85 |
| RE3-R2 | 主配置、收益率、波动率可由代码实际复现 | execution result / reference | Automatic | 1.30 |
| RE3-R3 | 敏感性分析可由代码实际复现，且基准点与主结果一致 | execution result / code | Automatic | 1.10 |
| RE3-R4 | 报告数值没有虚报、低报波动率或引用与代码不一致的保守方案 | response text + execution result | Hybrid | 1.00 |
| RE3-R5 | 结果文件写入、JSON/表格输出和金额换算不会阻断复现 | code / execution result | Automatic + LLM Judge | 0.75 |

RE.3 total: 5 points

## RE.4 局限承认

评估回答是否诚实说明模型、数据、代码和业务落地局限。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE4-R1 | 承认预期收益、波动率、相关系数估计误差会影响最优权重 | response text | LLM Judge | 1.00 |
| RE4-R2 | 承认历史相关性在危机中可能失效，正态波动率不足以覆盖尾部风险 | response text | LLM Judge | 0.95 |
| RE4-R3 | 承认交易成本、流动性、REITS 折价、企业债信用集中等现实风险 | response text | LLM Judge | 0.95 |
| RE4-R4 | 如实说明代码依赖、输出路径、求解器、容差利用或鲁棒化导致的偏差 | response text + code | Hybrid | 1.20 |
| RE4-R5 | 不夸大满分、生产可用性、严格合规性或“全局最优”结论 | response text | LLM Judge | 0.90 |

RE.4 total: 5 points

## Expected Failure Modes

- 把本题写成普通 Markowitz QP，而不识别“线性目标 + 二阶锥约束”结构。
- 最大化夏普比或最小化方差，偏离题面“在风险约束下最大化收益”的目标。
- 直接使用相关系数矩阵、简单加权波动率，或漏掉资产间联动。
- 数值方案收益看似高，但波动率超过 6%。
- 数值方案保守可行，但波动率远低于 6%，风险预算严重闲置。
- 使用 `/workspace/...` 等不可写路径导致代码主程序失败。
- 用 `cov * 1.1`、`sigma_max * 1.015` 等自行改题参数，却没有按原题重新评分。
- 只给硬编码配置或验证脚本，没有真正求解最优配置。
