"""
二阶锥优化测试实例生成器
=============================
为「企业年金投资组合配置」SOCP 问题生成泛化性测试用例。

问题结构：
  - N 种资产，每种有预期收益率、年化波动率
  - 资产间相关系数矩阵 → 协方差矩阵
  - 目标：max μ^T w  (最大化预期收益)
  - 约束：||Σ^{1/2} w||_2 ≤ σ_max (二阶锥约束)
          Σ w_j = 1 (预算约束)
          l_j ≤ w_j ≤ u_j (比例限制)
          权益类总比例 ≤ equity_cap
          固收类总比例 ≥ fixed_income_floor

参数字典结构（与 problem_01_solve.py / extracted models 兼容）：
  N_assets          : int             资产数量
  asset_names       : list[str]       资产名称列表
  asset_ids         : list[str]       资产ID列表（英文）
  mu                : list[float]     预期收益率向量
  sigma             : list[float]     各资产年化波动率(标准差)
  corr_matrix       : list[list]      相关系数矩阵
  cov_matrix        : list[list]      协方差矩阵
  total_investment   : float          投资总额（亿元）
  sigma_max         : float           风险容限（组合标准差上限）
  asset_classes     : dict            资产分类 {'equity': [...], 'fixed_income': [...], 'alternative': [...], 'cash': [...]}
  weight_bounds     : list[tuple]     各资产权重约束 [(lo, hi), ...]
  equity_cap        : float           权益类资产上限
  fixed_income_floor: float           固收类资产下限
"""

import numpy as np
import random
import math

# ============================================================
# 原始问题数据（N=5, problem_01 的精确数据）
# ============================================================

ORIGINAL_ASSET_NAMES = ['国债', '企业债', '股票指数', 'REITS', '货币基金']
ORIGINAL_ASSET_IDS = ['gov_bond', 'corp_bond', 'equity_index', 'reits', 'money_market']

ORIGINAL_MU = [0.035, 0.055, 0.12, 0.08, 0.025]
ORIGINAL_SIGMA = [0.02, 0.05, 0.20, 0.15, 0.005]

ORIGINAL_CORR = [
    [1.00, 0.60, -0.10, 0.05, 0.30],
    [0.60, 1.00,  0.20, 0.25, 0.15],
    [-0.10, 0.20, 1.00, 0.65, -0.05],
    [0.05, 0.25,  0.65, 1.00, 0.00],
    [0.30, 0.15, -0.05, 0.00, 1.00],
]

ORIGINAL_WEIGHT_BOUNDS = [
    (0.05, 0.50),  # 国债
    (0.05, 0.40),  # 企业债
    (0.00, 0.30),  # 股票指数
    (0.00, 0.20),  # REITS
    (0.05, 0.40),  # 货币基金
]

ORIGINAL_ASSET_CLASSES = {
    'equity': [2, 3],       # 股票指数, REITS
    'fixed_income': [0, 1], # 国债, 企业债
    'alternative': [],
    'cash': [4],            # 货币基金
}

ORIGINAL_EQUITY_CAP = 0.40
ORIGINAL_FIXED_INCOME_FLOOR = 0.30
ORIGINAL_SIGMA_MAX = 0.06
ORIGINAL_TOTAL_INVESTMENT = 2.0  # 亿元

# ============================================================
# 扩展资产模板（N>5 时使用）
# ============================================================

EXTRA_ASSET_TEMPLATES = [
    # (name, id, class, mu_range, sigma_range)
    ('地方政府债', 'local_gov_bond', 'fixed_income', (0.030, 0.045), (0.015, 0.030)),
    ('可转债', 'convertible_bond', 'fixed_income', (0.050, 0.080), (0.06, 0.12)),
    ('中小盘股票', 'small_cap', 'equity', (0.10, 0.18), (0.22, 0.35)),
    ('港股通基金', 'hk_stock', 'equity', (0.08, 0.15), (0.18, 0.28)),
    ('黄金ETF', 'gold_etf', 'alternative', (0.04, 0.08), (0.12, 0.20)),
    ('大宗商品', 'commodity', 'alternative', (0.05, 0.10), (0.15, 0.25)),
    ('同业存单', 'interbank_cd', 'cash', (0.022, 0.032), (0.003, 0.008)),
    ('短期理财', 'short_term_fin', 'cash', (0.025, 0.035), (0.005, 0.012)),
    ('信用债ABS', 'credit_abs', 'fixed_income', (0.045, 0.070), (0.04, 0.08)),
    ('公募REITS-B', 'reits_b', 'alternative', (0.06, 0.10), (0.10, 0.18)),
    ('指数增强基金', 'index_enhanced', 'equity', (0.09, 0.14), (0.16, 0.24)),
    ('债券指数基金', 'bond_index', 'fixed_income', (0.035, 0.050), (0.02, 0.04)),
    ('量化对冲', 'quant_hedge', 'alternative', (0.05, 0.09), (0.06, 0.12)),
    ('海外债券', 'foreign_bond', 'fixed_income', (0.030, 0.055), (0.03, 0.06)),
    ('新能源ETF', 'new_energy_etf', 'equity', (0.10, 0.20), (0.25, 0.40)),
]


# ============================================================
# 辅助函数
# ============================================================

def _ensure_psd(matrix, min_eigenvalue=1e-8):
    """确保矩阵正半定（特征值修正法）"""
    mat = np.array(matrix, dtype=float)
    # 强制对称
    mat = (mat + mat.T) / 2
    eigvals, eigvecs = np.linalg.eigh(mat)
    # 修正负特征值
    eigvals = np.maximum(eigvals, min_eigenvalue)
    result = eigvecs @ np.diag(eigvals) @ eigvecs.T
    # 再次强制对称（消除数值误差）
    result = (result + result.T) / 2
    return result


def _make_correlation_matrix(N, rng, level='medium'):
    """
    生成一个合法的 N×N 相关系数矩阵。

    方法：随机生成因子载荷矩阵，从中推导相关系数矩阵。
    """
    # 因子数量
    k = max(2, min(N // 2, 5))

    # 相关性强度
    factor_strength = {'low': 0.15, 'medium': 0.35, 'high': 0.55}
    strength = factor_strength.get(level, 0.35)

    # 生成因子载荷
    B = np.array([[rng.gauss(0, strength) for _ in range(k)] for _ in range(N)])

    # 协方差 = B B^T + diag
    cov_raw = B @ B.T
    # 提取相关系数
    d = np.sqrt(np.diag(cov_raw) + 1.0)  # +1 作为独特方差
    corr = np.eye(N)
    for i in range(N):
        for j in range(i + 1, N):
            r = cov_raw[i, j] / (d[i] * d[j])
            r = max(-0.9, min(0.9, r))  # 裁剪极端相关性
            corr[i, j] = r
            corr[j, i] = r

    # 确保正半定
    corr = _ensure_psd(corr, min_eigenvalue=0.01)
    # 归一化对角线为1
    d2 = np.sqrt(np.diag(corr))
    corr = corr / np.outer(d2, d2)
    np.fill_diagonal(corr, 1.0)

    return corr


def _adjust_constraint_tightness(bounds, equity_cap, fi_floor, level):
    """根据约束松紧度调整约束参数"""
    if level == 'loose':
        # 放宽约束：扩大各资产范围，放宽分类约束
        new_bounds = []
        for lo, hi in bounds:
            new_lo = max(0.0, lo - 0.02)
            new_hi = min(1.0, hi + 0.05)
            new_bounds.append((new_lo, new_hi))
        return new_bounds, min(0.50, equity_cap + 0.05), max(0.20, fi_floor - 0.05)
    elif level == 'tight':
        # 收紧约束：缩小范围，收紧分类约束
        new_bounds = []
        for lo, hi in bounds:
            new_lo = min(lo + 0.02, hi - 0.01)
            new_hi = max(hi - 0.03, lo + 0.01)
            new_bounds.append((new_lo, new_hi))
        return new_bounds, max(0.30, equity_cap - 0.05), min(0.40, fi_floor + 0.05)
    else:
        return list(bounds), equity_cap, fi_floor


# ============================================================
# 数据生成器
# ============================================================

def generate_instance(N_assets=5, seed=42, total_investment_scale=1.0,
                      sigma_max=0.06, return_volatility='medium',
                      correlation_level='medium', constraint_tightness='medium'):
    """
    生成一个合法的企业年金投资组合优化问题实例。

    参数:
        N_assets: 资产数量（原始5种）
        seed: 随机种子
        total_investment_scale: 投资总额缩放（1.0=原始2亿元）
        sigma_max: 风险容限（组合标准差上限，原始6%）
        return_volatility: 收益率估计的波动程度 ('low', 'medium', 'high')
        correlation_level: 资产间相关性水平 ('low', 'medium', 'high')
        constraint_tightness: 约束松紧度 ('loose', 'medium', 'tight')

    返回:
        dict: 包含问题所有参数的字典
    """
    assert N_assets >= 3, "至少需要3种资产"
    assert return_volatility in ('low', 'medium', 'high')
    assert correlation_level in ('low', 'medium', 'high')
    assert constraint_tightness in ('loose', 'medium', 'tight')

    rng = random.Random(seed)
    np_rng = np.random.RandomState(seed)

    # 判断是否为完全复现原始问题的条件
    is_original = (N_assets == 5 and total_investment_scale == 1.0
                   and sigma_max == ORIGINAL_SIGMA_MAX
                   and return_volatility == 'medium'
                   and correlation_level == 'medium'
                   and constraint_tightness == 'medium')

    # ---- 资产列表 ----
    if is_original:
        asset_names = list(ORIGINAL_ASSET_NAMES)
        asset_ids = list(ORIGINAL_ASSET_IDS)
        mu = list(ORIGINAL_MU)
        sigma = list(ORIGINAL_SIGMA)
        corr_matrix = [list(row) for row in ORIGINAL_CORR]
        weight_bounds = list(ORIGINAL_WEIGHT_BOUNDS)
        asset_classes = {k: list(v) for k, v in ORIGINAL_ASSET_CLASSES.items()}
        equity_cap = ORIGINAL_EQUITY_CAP
        fi_floor = ORIGINAL_FIXED_INCOME_FLOOR

    else:
        # 收益率波动调整因子
        rv_factor = {'low': 0.8, 'medium': 1.0, 'high': 1.3}[return_volatility]

        # -- 基础5种资产（始终包含） --
        base_n = min(N_assets, 5)
        asset_names = list(ORIGINAL_ASSET_NAMES[:base_n])
        asset_ids = list(ORIGINAL_ASSET_IDS[:base_n])
        mu = [m * rv_factor for m in ORIGINAL_MU[:base_n]]
        sigma = list(ORIGINAL_SIGMA[:base_n])
        weight_bounds = list(ORIGINAL_WEIGHT_BOUNDS[:base_n])

        # 资产分类（前5个固定分类）
        asset_classes = {'equity': [], 'fixed_income': [], 'alternative': [], 'cash': []}
        class_map_5 = ['fixed_income', 'fixed_income', 'equity', 'alternative', 'cash']
        for i in range(base_n):
            asset_classes[class_map_5[i]].append(i)

        # -- 扩展资产（N>5） --
        if N_assets > 5:
            # 从模板中选取（循环使用）
            extra_needed = N_assets - 5
            templates = list(EXTRA_ASSET_TEMPLATES)
            rng_copy = random.Random(seed + 1000)
            rng_copy.shuffle(templates)

            for idx in range(extra_needed):
                t = templates[idx % len(templates)]
                name, aid, aclass = t[0], t[1], t[2]
                mu_lo, mu_hi = t[3]
                sig_lo, sig_hi = t[4]

                # 如果 id 已存在则加后缀
                real_id = aid if aid not in asset_ids else f"{aid}_{idx}"
                real_name = name if name not in asset_names else f"{name}{idx}"

                asset_names.append(real_name)
                asset_ids.append(real_id)

                # 随机生成收益率和波动率
                m = rng.uniform(mu_lo, mu_hi) * rv_factor
                s = rng.uniform(sig_lo, sig_hi)
                mu.append(round(m, 5))
                sigma.append(round(s, 5))

                # 权重约束
                if aclass == 'equity':
                    weight_bounds.append((0.00, rng.uniform(0.10, 0.25)))
                elif aclass == 'fixed_income':
                    weight_bounds.append((rng.uniform(0.0, 0.03), rng.uniform(0.20, 0.40)))
                elif aclass == 'cash':
                    weight_bounds.append((rng.uniform(0.0, 0.03), rng.uniform(0.20, 0.35)))
                else:  # alternative
                    weight_bounds.append((0.00, rng.uniform(0.08, 0.18)))

                i_global = 5 + idx
                asset_classes[aclass].append(i_global)

        # -- 相关系数矩阵 --
        N = N_assets
        if N == 5 and correlation_level == 'medium':
            # 用原始相关系数矩阵（但收益率可能已变化）
            corr_matrix = [list(row) for row in ORIGINAL_CORR]
        elif N <= 5:
            # 从原始矩阵中取子矩阵
            orig = np.array(ORIGINAL_CORR)
            sub = orig[:N, :N]
            corr_matrix = sub.tolist()
        else:
            # 生成新的相关系数矩阵
            # 前5×5块保持原始相关性（如果 correlation_level=medium）
            full_corr = _make_correlation_matrix(N, rng, correlation_level)
            if correlation_level == 'medium':
                # 尽量保留前5×5块的原始相关性
                orig = np.array(ORIGINAL_CORR)
                for i in range(5):
                    for j in range(5):
                        full_corr[i, j] = orig[i, j]
                # 重新确保正半定
                full_corr = _ensure_psd(full_corr, min_eigenvalue=0.01)
                d2 = np.sqrt(np.diag(full_corr))
                full_corr = full_corr / np.outer(d2, d2)
                np.fill_diagonal(full_corr, 1.0)
            corr_matrix = full_corr.tolist()

        # -- 约束调整 --
        equity_cap = ORIGINAL_EQUITY_CAP
        fi_floor = ORIGINAL_FIXED_INCOME_FLOOR
        weight_bounds, equity_cap, fi_floor = _adjust_constraint_tightness(
            weight_bounds, equity_cap, fi_floor, constraint_tightness)

    # ---- 构建协方差矩阵 ----
    N = N_assets
    sigma_arr = np.array(sigma)
    corr_arr = np.array(corr_matrix)
    cov_matrix = np.diag(sigma_arr) @ corr_arr @ np.diag(sigma_arr)

    # 确保正半定
    cov_matrix = _ensure_psd(cov_matrix, min_eigenvalue=1e-10)

    # ---- 投资总额 ----
    total_investment = ORIGINAL_TOTAL_INVESTMENT * total_investment_scale

    # ---- 确保可行性 ----
    # 检查 sigma_max 是否太小：如果纯最低风险组合的波动率都超过 sigma_max，则放宽
    # 最低风险点 ≈ 全配最低波动率资产
    min_vol_idx = int(np.argmin(sigma_arr))
    # 粗略检查：等权最低配置的波动率
    w_safe = np.array([b[0] for b in weight_bounds])
    remaining = 1.0 - sum(w_safe)
    if remaining > 0:
        w_safe[min_vol_idx] += remaining
    elif remaining < 0:
        # 下限之和超过1，需要调整——这是约束不可行
        pass
    safe_vol = np.sqrt(w_safe @ cov_matrix @ w_safe) if sum(w_safe) > 0 else 0
    # 如果最安全的配置都超过 sigma_max，给出警告但不自动修改
    # （让用户知道这是一个紧约束甚至不可行的场景）

    # ---- 组装返回字典 ----
    # 权重约束规范化
    bounds_list = [(round(lo, 4), round(hi, 4)) for lo, hi in weight_bounds]

    instance = {
        'N_assets': N,
        'asset_names': asset_names,
        'asset_ids': asset_ids,
        'mu': [round(m, 6) for m in mu],
        'sigma': [round(s, 6) for s in sigma],
        'corr_matrix': [[round(c, 6) for c in row] for row in corr_arr.tolist()],
        'cov_matrix': [[round(c, 10) for c in row] for row in cov_matrix.tolist()],
        'total_investment': total_investment,
        'sigma_max': sigma_max,
        'asset_classes': asset_classes,
        'weight_bounds': bounds_list,
        'equity_cap': equity_cap,
        'fixed_income_floor': fi_floor,
    }

    return instance


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例：在固定规模 N=5（原始规模）下，
    变化风险容限、投资总额、收益率波动、相关性、约束松紧等参数。

    返回:
        list[dict]: 每个元素包含传给 generate_instance 的参数和 description
    """
    cases = []

    # --- 1. 基准（原始问题） ---
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
        'sigma_max': 0.06, 'return_volatility': 'medium',
        'correlation_level': 'medium', 'constraint_tightness': 'medium',
        'description': '基准：原始问题'
    })

    # --- 2. 风险容限变化 ---
    for sm in [0.02, 0.04, 0.10, 0.15]:
        cases.append({
            'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
            'sigma_max': sm, 'return_volatility': 'medium',
            'correlation_level': 'medium', 'constraint_tightness': 'medium',
            'description': f'风险容限 σ_max={sm}'
        })

    # --- 3. 投资总额变化 ---
    for scale in [0.5, 2.0, 5.0]:
        cases.append({
            'N_assets': 5, 'seed': 42, 'total_investment_scale': scale,
            'sigma_max': 0.06, 'return_volatility': 'medium',
            'correlation_level': 'medium', 'constraint_tightness': 'medium',
            'description': f'投资总额缩放={scale}'
        })

    # --- 4. 收益率波动 ---
    for rv in ['low', 'high']:
        cases.append({
            'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
            'sigma_max': 0.06, 'return_volatility': rv,
            'correlation_level': 'medium', 'constraint_tightness': 'medium',
            'description': f'收益率波动={rv}'
        })

    # --- 5. 相关性水平 ---
    for cl in ['low', 'high']:
        cases.append({
            'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
            'sigma_max': 0.06, 'return_volatility': 'medium',
            'correlation_level': cl, 'constraint_tightness': 'medium',
            'description': f'相关性水平={cl}'
        })

    # --- 6. 约束松紧 ---
    for ct in ['loose', 'tight']:
        cases.append({
            'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
            'sigma_max': 0.06, 'return_volatility': 'medium',
            'correlation_level': 'medium', 'constraint_tightness': ct,
            'description': f'约束松紧={ct}'
        })

    # --- 7. 关键组合场景 ---
    # 低风险 + 紧约束
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
        'sigma_max': 0.04, 'return_volatility': 'low',
        'correlation_level': 'medium', 'constraint_tightness': 'tight',
        'description': '组合：低风险+紧约束'
    })

    # 高风险 + 松约束
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
        'sigma_max': 0.15, 'return_volatility': 'high',
        'correlation_level': 'medium', 'constraint_tightness': 'loose',
        'description': '组合：高风险+松约束'
    })

    # 高相关 + 紧风险
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
        'sigma_max': 0.04, 'return_volatility': 'medium',
        'correlation_level': 'high', 'constraint_tightness': 'medium',
        'description': '组合：高相关+紧风险'
    })

    # 低相关 + 宽风险
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 1.0,
        'sigma_max': 0.10, 'return_volatility': 'medium',
        'correlation_level': 'low', 'constraint_tightness': 'medium',
        'description': '组合：低相关+宽风险'
    })

    # 大额 + 高风险
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 5.0,
        'sigma_max': 0.10, 'return_volatility': 'high',
        'correlation_level': 'medium', 'constraint_tightness': 'medium',
        'description': '组合：大额+高风险'
    })

    # 小额 + 低波动
    cases.append({
        'N_assets': 5, 'seed': 42, 'total_investment_scale': 0.5,
        'sigma_max': 0.04, 'return_volatility': 'low',
        'correlation_level': 'low', 'constraint_tightness': 'medium',
        'description': '组合：小额+低波动'
    })

    # 不同种子
    for s in [123, 456, 789]:
        cases.append({
            'N_assets': 5, 'seed': s, 'total_investment_scale': 1.0,
            'sigma_max': 0.06, 'return_volatility': 'medium',
            'correlation_level': 'medium', 'constraint_tightness': 'medium',
            'description': f'不同种子 seed={s}'
        })

    return cases


def get_scale_generalization_cases():
    """
    规模泛化测试用例：变化资产数量 N，其他使用默认或适当参数。

    返回:
        list[dict]: 每个元素包含传给 generate_instance 的参数和 description
    """
    cases = []
    for n in [3, 5, 8, 10, 15, 20]:
        cases.append({
            'N_assets': n, 'seed': 42, 'total_investment_scale': 1.0,
            'sigma_max': 0.06, 'return_volatility': 'medium',
            'correlation_level': 'medium', 'constraint_tightness': 'medium',
            'description': f'规模 N={n}'
        })
    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 辅助：快速求解验证可行性
# ============================================================

def solve_instance(instance, n_starts=50):
    """
    用 scipy SLSQP 快速求解一个实例，返回 (status, return_rate, volatility, weights)。
    """
    from scipy.optimize import minimize as sp_minimize

    N = instance['N_assets']
    mu_arr = np.array(instance['mu'])
    cov_arr = np.array(instance['cov_matrix'])
    sm = instance['sigma_max']
    bounds = instance['weight_bounds']
    eq_indices = instance['asset_classes']['equity'] + instance['asset_classes'].get('alternative', [])
    fi_indices = instance['asset_classes']['fixed_income']
    eq_cap = instance['equity_cap']
    fi_floor = instance['fixed_income_floor']

    constraints = [
        {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},
        {'type': 'ineq', 'fun': lambda w: sm ** 2 - w @ cov_arr @ w,
         'jac': lambda w: -2 * cov_arr @ w},
    ]
    if eq_indices:
        constraints.append(
            {'type': 'ineq', 'fun': lambda w, idx=eq_indices: eq_cap - sum(w[i] for i in idx)})
    if fi_indices:
        constraints.append(
            {'type': 'ineq', 'fun': lambda w, idx=fi_indices: sum(w[i] for i in idx) - fi_floor})

    lower = np.array([b[0] for b in bounds])
    upper = np.array([b[1] for b in bounds])
    sp_bounds = list(zip(lower, upper))

    best_result, best_return = None, -np.inf
    np_rng = np.random.RandomState(42)

    for trial in range(n_starts):
        if trial == 0:
            w0 = np.full(N, 1.0 / N)
            w0 = np.clip(w0, lower, upper)
            w0 = w0 / w0.sum()
        else:
            w0 = np_rng.dirichlet(np.ones(N))
            w0 = np.clip(w0, lower, upper)
            s = w0.sum()
            if s > 0:
                w0 = w0 / s

        try:
            res = sp_minimize(lambda w: -mu_arr @ w, w0, method='SLSQP',
                              jac=lambda w: -mu_arr, bounds=sp_bounds,
                              constraints=constraints,
                              options={'maxiter': 1000, 'ftol': 1e-12})
            if res.success and -res.fun > best_return:
                pv = np.sqrt(res.x @ cov_arr @ res.x)
                if pv <= sm + 1e-6:
                    best_return = -res.fun
                    best_result = res
        except Exception:
            continue

    if best_result is None:
        return 'Infeasible', None, None, None

    w = best_result.x
    ret = float(mu_arr @ w)
    risk = float(np.sqrt(w @ cov_arr @ w))
    return 'Optimal', ret, risk, w


# ============================================================
# 主程序：验证生成器
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("二阶锥优化测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 验证 N=5 默认参数复现原始问题 ------
    print("\n【1】N=5 默认参数 → 应复现原始问题数据")
    inst = generate_instance(N_assets=5)
    print(f"  资产: {inst['asset_names']}")
    print(f"  资产ID: {inst['asset_ids']}")
    print(f"  σ_max: {inst['sigma_max']}")
    print(f"  总投资: {inst['total_investment']} 亿元")

    # 逐项对比
    match = True
    for i in range(5):
        if abs(inst['mu'][i] - ORIGINAL_MU[i]) > 1e-8:
            print(f"  ✗ 收益率不匹配: {inst['asset_names'][i]} "
                  f"→ {inst['mu'][i]} vs 原始 {ORIGINAL_MU[i]}")
            match = False
        if abs(inst['sigma'][i] - ORIGINAL_SIGMA[i]) > 1e-8:
            print(f"  ✗ 波动率不匹配: {inst['asset_names'][i]} "
                  f"→ {inst['sigma'][i]} vs 原始 {ORIGINAL_SIGMA[i]}")
            match = False
        if inst['weight_bounds'][i] != ORIGINAL_WEIGHT_BOUNDS[i]:
            print(f"  ✗ 权重约束不匹配: {inst['asset_names'][i]}")
            match = False
    for i in range(5):
        for j in range(5):
            if abs(inst['corr_matrix'][i][j] - ORIGINAL_CORR[i][j]) > 1e-6:
                print(f"  ✗ 相关系数不匹配: [{i}][{j}]")
                match = False
                break

    # 检查协方差矩阵正定
    cov_arr = np.array(inst['cov_matrix'])
    eigvals = np.linalg.eigvalsh(cov_arr)
    print(f"  协方差矩阵最小特征值: {eigvals.min():.2e}")
    print(f"  协方差矩阵正定: {'✓' if all(eigvals > 0) else '✗'}")

    if match:
        print("  ✓ 所有参数与原始问题完全一致")

    # 求解验证
    print("\n  正在用 scipy 快速求解验证...")
    status, ret, risk, w = solve_instance(inst, n_starts=100)
    if status == 'Optimal':
        print(f"  求解状态: {status}")
        print(f"  最优年化收益率: {ret * 100:.4f}%")
        print(f"  组合波动率: {risk * 100:.4f}%")
        if abs(ret - 0.064472) < 0.005:
            print(f"  ✓ 收益率与标准答案(6.4472%)接近")
        else:
            print(f"  ⚠ 收益率与标准答案(6.4472%)有差异")
        if abs(risk - 0.06) < 0.002:
            print(f"  ✓ 波动率约束有效(≈6%)")
    else:
        print(f"  ✗ 求解失败: {status}")

    # ------ 2. 扩展实例验证（N=10） ------
    print("\n" + "=" * 70)
    print("【2】扩展实例验证（N=10）")
    print("=" * 70)

    inst10 = generate_instance(N_assets=10, seed=42)
    print(f"  资产数: {inst10['N_assets']}")
    print(f"  资产: {inst10['asset_names']}")

    cov10 = np.array(inst10['cov_matrix'])
    eigvals10 = np.linalg.eigvalsh(cov10)
    print(f"  协方差矩阵最小特征值: {eigvals10.min():.2e}")
    print(f"  协方差矩阵正半定: {'✓' if all(eigvals10 >= 0) else '✗'}")

    # Cholesky 分解验证
    try:
        L10 = np.linalg.cholesky(cov10)
        print(f"  Cholesky分解: ✓")
    except np.linalg.LinAlgError:
        print(f"  Cholesky分解: ✗ (矩阵非正定)")

    # 求解
    status10, ret10, risk10, w10 = solve_instance(inst10, n_starts=100)
    if status10 == 'Optimal':
        print(f"  求解: {status10}, 收益率={ret10 * 100:.4f}%, 波动率={risk10 * 100:.4f}%")
    else:
        print(f"  求解: {status10}")

    # ------ 3. 测试用例总数 ------
    print("\n" + "=" * 70)
    print("【3】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i + 1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i + 1:2d}] {c['description']}")

    # ------ 4. 批量可行性检查 ------
    print("\n" + "=" * 70)
    print("【4】批量可行性检查（所有用例）")
    print("=" * 70)

    n_feasible = 0
    n_total = len(all_cases)
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        inst_c = generate_instance(**params)

        # 检查协方差矩阵正半定
        cov_c = np.array(inst_c['cov_matrix'])
        eig_c = np.linalg.eigvalsh(cov_c)
        psd_ok = all(eig_c >= -1e-10)

        status_c, ret_c, risk_c, _ = solve_instance(inst_c, n_starts=30)
        if status_c == 'Optimal' and psd_ok:
            n_feasible += 1
            print(f"  ✓ {c['description']:40s} → 收益={ret_c * 100:.4f}%, "
                  f"波动率={risk_c * 100:.4f}%, PSD=✓")
        else:
            tag = '不可行' if status_c != 'Optimal' else 'PSD✗'
            print(f"  ✗ {c['description']:40s} → {tag}")

    print(f"\n  可行实例: {n_feasible}/{n_total}")
    if n_feasible == n_total:
        print("  ✓ 所有测试用例均可行且协方差矩阵正半定")

    print("\n完成。")
