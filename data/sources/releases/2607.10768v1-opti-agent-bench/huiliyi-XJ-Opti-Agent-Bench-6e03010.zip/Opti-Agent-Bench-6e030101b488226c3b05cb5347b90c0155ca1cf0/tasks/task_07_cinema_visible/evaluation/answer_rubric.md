# Metric-Aligned Answer Rubric：电影院 / 问题1_可见

## Problem Analysis

本题是一个**基于离散选择的影院排片优化 / MNL Bandit**问题，包含两个层次：

- 静态层：若 MNL 吸引力参数 `v_k` 已知，需要在单厅、单片、间隔/清场、黄金档必选等约束下选择合法开场集合 `S`，最大化单日期望收入。
- 动态层：若 `v_k` 未知，需要利用每日聚合销量和“不购票”人数在线估计吸引力参数，并在探索与利用之间权衡，以降低累计 regret。

关键陷阱：

- 不能只做静态排片，动态部分必须有真实学习机制。
- 静态目标必须是 MNL 期望收入，而不是简单票价和、排序或场次数最大化。
- 排片必须同时处理合法开场范围、场次间隔/清场、黄金档必选。
- 动态学习不能泄露真实 `v_k`，也不能通过固定最优排期、参数均匀化或评估脚本适配来规避探索-利用。
- 代码层需要能运行并能在参数/规模变化时保持可行性和合理质量。

## Global Scoring Rules

- 每个统一指标满分为 5 分。
- 每个子项可按 `0 / partial / full` 给分；若证据明显不足，给 0。
- `Scoring Method = Automatic` 表示优先使用代码运行、checker、泛化评估结果或独立复算。
- `Scoring Method = LLM Judge` 表示由大模型根据回答文本进行语义评分。
- `Scoring Method = Hybrid` 表示先抽取代码或运行结果，再由大模型比较文本声明与实际实现。
- 若题目要求代码而回答没有可执行代码，`CE.1`、`CE.2`、`CE.3`、`RE.3` 应低分或失败。
- 本题已提供 `scripts/generate_instances.py`、`scripts/eval_generalization.py` 和 `results/eval_results_latest.json`，因此 `CE.3` 应正式评分。

## ME.1 模型正确性

评估回答是否正确理解静态 MNL 排片优化和动态在线学习问题。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME1-R1 | 明确区分静态已知参数优化和动态未知参数学习两个子问题 | response text | LLM Judge | 0.60 |
| ME1-R2 | 识别为 MNL 选择模型 + 组合排片优化，包含“不购票”选项和聚合销量观测 | response text | LLM Judge | 0.85 |
| ME1-R3 | 正确写出或实现静态期望收入：`R(S,v)=lambda * sum_{k in S} r_k v_k / (1 + sum_{i in S} v_i)` | response text / code | Hybrid | 0.95 |
| ME1-R4 | 正确处理合法开场范围、场次间隔/清场约束和黄金档必选约束 | response text / code | Hybrid | 0.95 |
| ME1-R5 | 动态部分基于每日聚合销量和不购票人数更新参数估计，而不是直接使用真实 `v_k` | response text / code | Hybrid | 0.90 |
| ME1-R6 | 明确包含探索-利用权衡，并用 regret 或 reference 静态最优作为评价参照 | response text | LLM Judge | 0.75 |

ME.1 total: 5 points

## ME.2 模型简洁性

评估建模和算法是否聚焦、必要、不过度复杂。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME2-R1 | 清楚分离静态 optimizer、动态 learner、数据生成/观测和评估逻辑 | response text / code | LLM Judge | 1.00 |
| ME2-R2 | 静态求解方法与规模匹配，例如枚举、回溯、DP、整数规划，并说明复杂度边界 | response text / code | LLM Judge | 1.00 |
| ME2-R3 | 动态策略简单但真实，不通过 reference access、固定最优排期或参数均匀化规避学习 | response text / code | Hybrid | 1.25 |
| ME2-R4 | 对时间索引、间隔 convention、黄金档集合和可行时段范围的定义一致 | response text / code | Hybrid | 1.00 |
| ME2-R5 | 说明紧凑，避免把大量评估脚本、测试协议或管理建议混入核心求解方案 | response text | LLM Judge | 0.75 |

ME.2 total: 5 points

## ME.3 模型-代码一致性

评估报告声明的方法和实际代码是否一致。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME3-R1 | 代码实际实现的 MNL 收入公式与文本声明一致 | response text + code | Hybrid | 1.00 |
| ME3-R2 | 代码实际检查的排片可行性约束与题面和文本声明一致 | response text + code | Hybrid | 1.00 |
| ME3-R3 | 静态求解代码与文本声称的枚举/回溯/DP/IP 等方法一致 | response text + code | Hybrid | 0.90 |
| ME3-R4 | 动态学习代码与文本声称的 UCB/Thompson/MLE/贝叶斯等学习机制一致 | response text + code | Hybrid | 1.25 |
| ME3-R5 | 报告中的结果、regret、最优排期或泛化表现与代码运行/已有 results 一致 | response text + execution result | Hybrid | 0.85 |

ME.3 total: 5 points

## CE.1 代码可行性与正确性

评估代码是否可运行，并能求出合法、目标正确的静态/动态方案。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE1-R1 | 提供可抽取、可执行的求解代码，而不是只有 JSON、伪代码或评估说明 | code block / extracted code | Automatic + LLM fallback | 1.00 |
| CE1-R2 | 静态求解代码能运行并输出可解析排期 | execution result / wrapper | Automatic | 0.85 |
| CE1-R3 | 输出排期满足黄金档、合法范围和间隔/清场约束 | execution result / checker | Automatic | 1.05 |
| CE1-R4 | MNL 期望收入可独立复算，静态目标值质量接近参考解或最优解 | execution result / reference gap | Automatic | 1.10 |
| CE1-R5 | 动态流程能运行并产生参数更新、每日排期、收入或 regret 记录 | execution result / response code | Automatic + LLM fallback | 1.00 |

CE.1 total: 5 points

## CE.2 代码质量与效率

评估代码结构、可维护性、效率和可复用性。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE2-R1 | 代码模块化清晰，静态优化、动态学习、MNL 计算、可行性检查分工明确 | code | LLM Judge + basic stats | 1.00 |
| CE2-R2 | 索引体系、时段边界、黄金档和间隔 convention 一致且不易出错 | code | Automatic + LLM Judge | 1.10 |
| CE2-R3 | 算法复杂度适合默认规模，并有剪枝、DP、回溯或求解器思路应对规模增长 | code / generalization result | Hybrid | 1.10 |
| CE2-R4 | 输入输出协议合理，支持参数化或 JSON/CLI，便于 wrapper 和泛化测试调用 | code / wrapper | Automatic + LLM Judge | 0.90 |
| CE2-R5 | 随机性、依赖、异常和超时处理合理，代码能复现主要结果 | code / execution result | Automatic + LLM Judge | 0.90 |

CE.2 total: 5 points

## CE.3 代码鲁棒性

评估代码在参数变化和规模变化下的可运行性、可行性和解质量。本题使用已有 `results/eval_results_latest.json` 和泛化评估报告作为主要证据。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE3-R1 | 参数泛化成功率高，能适应 `L`、黄金档比例、票价缩放、到达强度、吸引力分散度变化 | results/eval_results_latest.json | Automatic | 1.20 |
| CE3-R2 | 规模泛化能力强，较大 `K` 下仍能在超时限制内求解 | results/eval_results_latest.json | Automatic | 1.10 |
| CE3-R3 | 多实例下排期可行性稳定，极少出现逻辑错误或不可行输出 | results/eval_results_latest.json | Automatic | 1.00 |
| CE3-R4 | 多实例下目标值质量稳定，gap 较小或能解释建模差异 | results/eval_results_latest.json / evaluation report | Automatic + LLM Judge | 1.00 |
| CE3-R5 | 对失败、超时、边界案例有清晰暴露和合理解释 | evaluation report / response text | LLM Judge | 0.70 |

CE.3 total: 5 points

## RE.1 报告完整性

评估回答是否完整覆盖问题理解、建模、算法、结果和评估。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE1-R1 | 清楚重述静态和动态两个任务、输入参数、观测信息和目标 | response text | LLM Judge | 0.80 |
| RE1-R2 | 给出完整静态 MNL 排片数学模型：变量、目标、约束 | response text | LLM Judge | 1.00 |
| RE1-R3 | 给出完整动态学习流程：观测、估计更新、探索利用、regret 评估 | response text | LLM Judge | 1.20 |
| RE1-R4 | 报告静态最优排期、收入、动态结果或 regret，并说明如何验证 | response text / output | LLM Judge + execution | 1.00 |
| RE1-R5 | 说明代码运行方式、输入输出格式和评估方式 | response text / code | LLM Judge | 1.00 |

RE.1 total: 5 points

## RE.2 解释清晰度

评估回答是否清楚解释模型、约束、学习和业务含义。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE2-R1 | 清楚解释 MNL 中场次选择概率、不购票选项和收入公式 | response text | LLM Judge | 1.10 |
| RE2-R2 | 清楚解释间隔/清场、黄金档、可行时段边界及索引 convention | response text | LLM Judge | 1.00 |
| RE2-R3 | 清楚解释聚合销量如何支持参数估计，以及为何存在探索-利用权衡 | response text | LLM Judge | 1.15 |
| RE2-R4 | 清楚解释 regret 的含义和静态 reference 最优的参照作用 | response text | LLM Judge | 0.90 |
| RE2-R5 | 文字组织清楚，不过度堆砌无关评估框架或自夸式总结 | response text | LLM Judge | 0.85 |

RE.2 total: 5 points

## RE.3 结果可复现性

评估报告声称的结果是否可以由代码、wrapper 或已有结果文件复现。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE3-R1 | 提供明确可运行入口、依赖说明和必要输入参数 | response text / extracted code | Automatic + LLM Judge | 0.90 |
| RE3-R2 | 静态排期和收入能由代码或 wrapper 实际复现 | execution result / wrapper | Automatic | 1.10 |
| RE3-R3 | 动态学习输出、收入或 regret 能由代码实际复现 | execution result / wrapper | Automatic | 1.10 |
| RE3-R4 | 泛化测试结果可由 `scripts/eval_generalization.py` 或已有 results 追溯 | results / scripts | Automatic | 1.00 |
| RE3-R5 | 报告没有虚报最优、零 regret、泛化成功率或代码能力 | response text + results | Hybrid | 0.90 |

RE.3 total: 5 points

## RE.4 局限承认

评估回答是否诚实说明建模、学习、代码和评估局限。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE4-R1 | 承认静态排片存在组合爆炸，枚举/暴力搜索有规模瓶颈 | response text / generalization result | LLM Judge | 1.00 |
| RE4-R2 | 承认动态估计的局限，如聚合数据识别难度、MLE/贝叶斯/UCB 近似误差 | response text | LLM Judge | 1.00 |
| RE4-R3 | 如实说明是否使用真实 `v_k`、reference access、固定最优排期或评估脚本适配 | response text + code | Hybrid | 1.15 |
| RE4-R4 | 承认间隔/清场 convention、索引体系或黄金档定义可能影响结果 | response text / code | LLM Judge | 0.85 |
| RE4-R5 | 不夸大动态学习效果、零 regret、满分或可扩展性 | response text | LLM Judge | 1.00 |

RE.4 total: 5 points

## Expected Failure Modes

- 只做静态最优排片，动态学习部分空转。
- 把 MNL 期望收入错写成简单票价和、排序分数或场次数最大化。
- 忽略“不购票”选项，导致 MNL 分母错误。
- 间隔/清场、黄金档或可行时段边界处理不一致。
- 动态部分直接使用真实 `v_k`，或固定使用静态最优排期，规避探索-利用。
- 用参数均匀化、reference 泄露、评估脚本适配等方式制造低 regret。
- 代码无法运行，或报告声称的方法与代码实际实现不一致。
- 规模变大时纯枚举超时，但报告没有承认复杂度瓶颈。
