"""
影院排片优化测试实例生成器
=============================
为「电影院_可见」影院排片优化问题（完全信息版）生成泛化性测试用例。

问题结构：
  - 单厅单影片，K 个等长时间段
  - 一场电影持续 L 个时间段，放映结束需 1 段清场
  - 不同场次开场时间至少间隔 L 段（清场由 wrapper 按模型差异适配）
  - 黄金档时间段 g 必须出现在每日排期中
  - 顾客选择服从 MNL 模型，吸引力参数 v_k > 0
  - 目标：静态最大化单日期望收入；动态 T 天在线学习最小化遗憾

参数字典结构（标准格式，由 wrapper 适配各模型）：
  K          : int           总时间段数
  L          : int           电影时长（占用时间段数，不含清场）
  g          : list[int]     黄金档时间段列表（0-based 索引）
  r          : list[float]   每个时段的票价（K 维，索引 0~K-1）
  v          : list[float]   MNL 吸引力参数（K 维，索引 0~K-1）
  lambda_t   : list[float]   每天的顾客到达率（T 维）
  lambda_min : float         到达率下界
  lambda_max : float         到达率上界
  T          : int           运营天数（用于动态学习评估）
"""

import random
import math


# ============================================================
# 原始问题基准数据（Kimi 默认参数，K=20, L=3, g=10）
# ============================================================

ORIGINAL_K = 20
ORIGINAL_L = 3
ORIGINAL_G = [10]  # 0-based

ORIGINAL_PRICES = [
    30, 30, 35, 35, 40, 40, 45, 45, 50, 50,
    55, 50, 50, 45, 45, 40, 40, 35, 35, 30
]

ORIGINAL_V = [
    0.1, 0.1, 0.15, 0.15, 0.2, 0.2, 0.25, 0.25, 0.3, 0.3,
    0.5, 0.3, 0.3, 0.25, 0.25, 0.2, 0.2, 0.15, 0.15, 0.1
]


# ============================================================
# 数据生成器
# ============================================================

def generate_instance(K=20, L=3, seed=42, golden_ratio=0.3, price_scale=1.0,
                      arrival_intensity='medium', v_spread='medium', T=100):
    """
    生成一个合法的影院排片优化问题实例。

    参数:
        K: 总时间段数
        L: 电影时长（占用的时间段数，不含清场）
        seed: 随机种子
        golden_ratio: 黄金档占比（影响 g 的数量）
        price_scale: 票价缩放因子
        arrival_intensity: 顾客到达强度 ('low', 'medium', 'high')
        v_spread: MNL 吸引力参数分散度 ('low', 'medium', 'high')
        T: 运营天数

    返回:
        dict: 标准实例字典
    """
    assert K >= 2 * L, f"K={K} 太小，至少需要 2*L={2*L} 才能排 1 场电影"
    assert L >= 1, "电影时长 L 至少为 1"
    assert arrival_intensity in ('low', 'medium', 'high')
    assert v_spread in ('low', 'medium', 'high')

    rng = random.Random(seed)

    # --- 黄金档时间段 ---
    # 黄金档集中在时段的 60%-80% 位置（模拟晚间黄金档）
    # 合法开场范围: [0, K-L-1]（0-based，最后一场需在 K-L-1 开场才能放完）
    max_start = K - L  # 最后合法开场位置（0-based 含）
    golden_center = int(K * 0.65)  # 黄金档中心位于 65% 位置
    golden_center = min(golden_center, max_start)

    n_golden = max(1, round(max_start * golden_ratio))
    # 限制黄金档数量不超过合法开场位数的一半
    n_golden = min(n_golden, max(1, max_start // 2))

    # 在 golden_center 附近选取黄金档
    candidates = list(range(0, max_start + 1))
    candidates.sort(key=lambda x: abs(x - golden_center))
    g = sorted(candidates[:n_golden])

    # 确保至少能排一场（黄金档中至少有一个合法开场时间）
    assert len(g) >= 1 and all(0 <= gi <= max_start for gi in g), \
        f"黄金档无效: g={g}, max_start={max_start}"

    # --- 票价 r ---
    # 票价呈倒 U 形：黄金档附近最高，两端较低
    r = []
    for k in range(K):
        dist_to_gold = min(abs(k - gc) for gc in g)
        # 基础票价 30-60，黄金档附近最高
        base = 30 + max(0, 30 - dist_to_gold * (30 / max(K // 2, 1)))
        base = max(15, base)  # 票价最低 15
        r.append(round(base * price_scale, 1))

    # --- MNL 吸引力参数 v ---
    spread_config = {
        'low':    (0.3, 0.1),    # 均值偏高、标准差小 → 选择概率接近均匀
        'medium': (0.25, 0.15),  # 中等分散度
        'high':   (0.2, 0.25),   # 均值偏低、标准差大 → 热门时段明显突出
    }
    v_mean, v_std = spread_config[v_spread]

    v = []
    for k in range(K):
        dist_to_gold = min(abs(k - gc) for gc in g)
        # 黄金档附近吸引力更高
        bonus = max(0, 0.3 - dist_to_gold * (0.3 / max(K // 2, 1)))
        val = rng.gauss(v_mean + bonus, v_std)
        val = max(0.01, val)  # 保证正值
        v.append(round(val, 4))

    # 确保黄金档 v 值较高
    for gi in g:
        if gi < len(v):
            v[gi] = max(v[gi], max(v) * 0.8)

    # --- 顾客到达率 lambda_t ---
    intensity_config = {
        'low':    (30, 80),
        'medium': (50, 150),
        'high':   (100, 300),
    }
    lambda_min, lambda_max = intensity_config[arrival_intensity]

    lambda_t = []
    for t in range(T):
        lam = rng.uniform(lambda_min, lambda_max)
        lambda_t.append(round(lam, 1))

    return {
        'K': K,
        'L': L,
        'g': g,
        'r': r,
        'v': v,
        'lambda_t': lambda_t,
        'lambda_min': lambda_min,
        'lambda_max': lambda_max,
        'T': T,
    }


# ============================================================
# 验证工具
# ============================================================

def compute_expected_revenue(schedule, r, v, lam=1.0):
    """MNL 模型期望收入（标准公式）"""
    if not schedule:
        return 0.0
    total_v = sum(v[k] for k in schedule if 0 <= k < len(v))
    denom = 1.0 + total_v
    rev = sum(r[k] * v[k] / denom for k in schedule
              if 0 <= k < len(r) and 0 <= k < len(v))
    return lam * rev


def find_optimal_schedule(K, L, g_list, r, v, max_slots=15):
    """
    搜索最优排期（间隔 >= L，0-based）。
    g_list 中的第一个黄金档必须包含。
    当合法开场位置较多时使用贪心算法避免指数爆炸。
    返回 (best_schedule, best_revenue)。
    """
    max_start = K - L
    g0 = g_list[0]  # 必选的黄金档

    # 合法开场位置
    valid_slots = [k for k in range(max_start + 1) if k != g0]

    # 当搜索空间太大时使用贪心
    if len(valid_slots) > max_slots:
        return _greedy_optimal(K, L, g0, valid_slots, r, v)

    best = {'schedule': [g0], 'revenue': compute_expected_revenue([g0], r, v)}

    def backtrack(start, current):
        rev = compute_expected_revenue(current, r, v)
        if rev > best['revenue']:
            best['revenue'] = rev
            best['schedule'] = current[:]

        for k in range(start, max_start + 1):
            ok = all(abs(k - s) >= L for s in current)
            if ok:
                current.append(k)
                backtrack(k + 1, current)
                current.pop()

    backtrack(0, [g0])
    return best['schedule'], best['revenue']


def _greedy_optimal(K, L, g0, valid_slots, r, v):
    """贪心构建排期：反复添加边际收益最大的场次。"""
    schedule = [g0]

    improved = True
    while improved:
        improved = False
        best_k, best_rev = None, compute_expected_revenue(schedule, r, v)
        for k in valid_slots:
            if k in schedule:
                continue
            if not all(abs(k - s) >= L for s in schedule):
                continue
            trial = sorted(schedule + [k])
            rev = compute_expected_revenue(trial, r, v)
            if rev > best_rev:
                best_rev = rev
                best_k = k
        if best_k is not None:
            schedule.append(best_k)
            improved = True

    return sorted(schedule), compute_expected_revenue(schedule, r, v)


def validate_instance(inst):
    """验证实例合法性，返回 (is_valid, messages)。"""
    msgs = []
    K, L, g = inst['K'], inst['L'], inst['g']
    r, v = inst['r'], inst['v']
    max_start = K - L

    # 基本维度检查
    if len(r) != K:
        msgs.append(f"r 维度 {len(r)} != K={K}")
    if len(v) != K:
        msgs.append(f"v 维度 {len(v)} != K={K}")
    if len(inst['lambda_t']) != inst['T']:
        msgs.append(f"lambda_t 维度 {len(inst['lambda_t'])} != T={inst['T']}")

    # 黄金档合法性
    for gi in g:
        if gi < 0 or gi > max_start:
            msgs.append(f"黄金档 g={gi} 超出合法范围 [0, {max_start}]")

    # v 正值约束
    if any(vi <= 0 for vi in v):
        msgs.append(f"存在非正 v 值")

    # 至少能排 1 场
    if max_start < 0:
        msgs.append(f"K={K}, L={L}: 无法排映任何场次")

    # 尝试求解
    if not msgs:
        sched, rev = find_optimal_schedule(K, L, g, r, v)
        if len(sched) < 1:
            msgs.append("最优排期为空")
        elif rev <= 0:
            msgs.append(f"最优收入 <= 0: {rev}")

    return len(msgs) == 0, msgs


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例（约 25-30 个）。
    在默认规模 K=20 下变化各维度参数及关键组合。
    """
    cases = []

    # === 单维度变化 ===

    # 1. 电影时长变化: L = 2, 3, 4, 5
    for l in [2, 3, 4, 5]:
        cases.append({
            'K': 20, 'L': l, 'seed': 42, 'golden_ratio': 0.3,
            'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
            'description': f'电影时长 L={l}'
        })

    # 2. 黄金档比例: 0.1, 0.3, 0.5
    for gr in [0.1, 0.3, 0.5]:
        if gr == 0.3:
            continue  # 已在 L=3 中包含
        cases.append({
            'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': gr,
            'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
            'description': f'黄金档比例={gr}'
        })

    # 3. 票价缩放: 0.5, 1.0, 2.0
    for ps in [0.5, 2.0]:
        cases.append({
            'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.3,
            'price_scale': ps, 'arrival_intensity': 'medium', 'v_spread': 'medium',
            'description': f'票价缩放={ps}'
        })

    # 4. 到达强度: low, medium, high
    for ai in ['low', 'high']:
        cases.append({
            'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.3,
            'price_scale': 1.0, 'arrival_intensity': ai, 'v_spread': 'medium',
            'description': f'到达强度={ai}'
        })

    # 5. 吸引力分散度: low, medium, high
    for vs in ['low', 'high']:
        cases.append({
            'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.3,
            'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': vs,
            'description': f'吸引力分散度={vs}'
        })

    # === 组合变化 ===

    # 6. 长电影 + 高票价
    cases.append({
        'K': 20, 'L': 5, 'seed': 42, 'golden_ratio': 0.3,
        'price_scale': 2.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '长电影+高票价 L=5,ps=2.0'
    })

    # 7. 短电影 + 高到达 + 高分散
    cases.append({
        'K': 20, 'L': 2, 'seed': 42, 'golden_ratio': 0.3,
        'price_scale': 1.0, 'arrival_intensity': 'high', 'v_spread': 'high',
        'description': '短电影+高到达+高分散 L=2'
    })

    # 8. 长电影 + 低到达 + 低分散
    cases.append({
        'K': 20, 'L': 5, 'seed': 42, 'golden_ratio': 0.3,
        'price_scale': 1.0, 'arrival_intensity': 'low', 'v_spread': 'low',
        'description': '长电影+低到达+低分散 L=5'
    })

    # 9. 多黄金档 + 高票价
    cases.append({
        'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.5,
        'price_scale': 2.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '多黄金档+高票价'
    })

    # 10. 少黄金档 + 低票价
    cases.append({
        'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.1,
        'price_scale': 0.5, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '少黄金档+低票价'
    })

    # 11-13. 不同种子（鲁棒性测试）
    for s in [123, 456, 789]:
        cases.append({
            'K': 20, 'L': 3, 'seed': s, 'golden_ratio': 0.3,
            'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
            'description': f'种子变化 seed={s}'
        })

    # 14. 高强度全组合
    cases.append({
        'K': 20, 'L': 2, 'seed': 42, 'golden_ratio': 0.5,
        'price_scale': 2.0, 'arrival_intensity': 'high', 'v_spread': 'high',
        'description': '极端组合: 短片+多黄金档+高票价+高到达+高分散'
    })

    # 15. 低强度全组合
    cases.append({
        'K': 20, 'L': 5, 'seed': 42, 'golden_ratio': 0.1,
        'price_scale': 0.5, 'arrival_intensity': 'low', 'v_spread': 'low',
        'description': '极端组合: 长片+少黄金档+低票价+低到达+低分散'
    })

    # 16-18. L 极端值
    cases.append({
        'K': 20, 'L': 1, 'seed': 42, 'golden_ratio': 0.3,
        'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '极短电影 L=1'
    })
    cases.append({
        'K': 20, 'L': 8, 'seed': 42, 'golden_ratio': 0.3,
        'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '极长电影 L=8'
    })
    cases.append({
        'K': 20, 'L': 9, 'seed': 42, 'golden_ratio': 0.1,
        'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
        'description': '接近上限 L=9 (K/2)'
    })

    # 去重
    seen = set()
    unique = []
    for c in cases:
        key = (c['K'], c['L'], c['seed'], c.get('golden_ratio'),
               c.get('price_scale'), c.get('arrival_intensity'), c.get('v_spread'))
        if key not in seen:
            seen.add(key)
            unique.append(c)

    return unique


def get_scale_generalization_cases():
    """
    规模泛化测试用例：变化时间段数 K，其他使用默认参数。
    """
    cases = []
    for k in [10, 20, 30, 40, 50]:
        cases.append({
            'K': k, 'L': 3, 'seed': 42, 'golden_ratio': 0.3,
            'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
            'description': f'规模 K={k}'
        })
    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 主程序：验证生成器
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("影院排片优化测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 默认参数实例 ------
    print("\n【1】默认参数实例（K=20, L=3）")
    inst = generate_instance()
    print(f"  K={inst['K']}, L={inst['L']}, T={inst['T']}")
    print(f"  黄金档 g={inst['g']}")
    print(f"  票价 r={inst['r']}")
    print(f"  吸引力 v={inst['v']}")
    print(f"  到达率范围: [{inst['lambda_min']}, {inst['lambda_max']}]")

    ok, msgs = validate_instance(inst)
    if ok:
        sched, rev = find_optimal_schedule(inst['K'], inst['L'], inst['g'],
                                           inst['r'], inst['v'])
        print(f"  ✓ 实例合法")
        print(f"  最优排期: {sched}")
        print(f"  最优收入: {rev:.4f}")
        print(f"  排期场次数: {len(sched)}")
    else:
        print(f"  ✗ 实例不合法: {msgs}")

    # ------ 2. 代表性实例展示 ------
    print("\n" + "=" * 70)
    print("【2】代表性实例")
    print("=" * 70)

    demo_params = [
        {'K': 20, 'L': 2, 'seed': 42},
        {'K': 20, 'L': 5, 'seed': 42},
        {'K': 30, 'L': 3, 'seed': 42},
        {'K': 50, 'L': 3, 'seed': 123},
        {'K': 20, 'L': 3, 'seed': 42, 'v_spread': 'high', 'price_scale': 2.0},
    ]

    for params in demo_params:
        desc = ', '.join(f'{k}={v}' for k, v in params.items())
        inst = generate_instance(**params)
        ok, msgs = validate_instance(inst)
        sched, rev = find_optimal_schedule(inst['K'], inst['L'], inst['g'],
                                           inst['r'], inst['v'])
        status = "✓" if ok else "✗"
        print(f"\n  --- {desc} ---")
        print(f"  {status} 黄金档={inst['g']}, 最优排期={sched}, "
              f"场次数={len(sched)}, 收入={rev:.4f}")
        if not ok:
            print(f"     问题: {msgs}")

    # ------ 3. 测试用例统计 ------
    print("\n" + "=" * 70)
    print("【3】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    # ------ 4. 批量合法性检查 ------
    print("\n" + "=" * 70)
    print("【4】批量合法性检查（所有用例）")
    print("=" * 70)

    n_valid = 0
    n_total = len(all_cases)
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        inst = generate_instance(**params)
        ok, msgs = validate_instance(inst)
        if ok:
            sched, rev = find_optimal_schedule(inst['K'], inst['L'], inst['g'],
                                               inst['r'], inst['v'])
            n_valid += 1
        else:
            print(f"  ✗ 不合法: {c['description']} → {msgs}")

    print(f"  合法实例: {n_valid}/{n_total}")
    if n_valid == n_total:
        print("  ✓ 所有测试用例均合法")
    print("\n完成。")
