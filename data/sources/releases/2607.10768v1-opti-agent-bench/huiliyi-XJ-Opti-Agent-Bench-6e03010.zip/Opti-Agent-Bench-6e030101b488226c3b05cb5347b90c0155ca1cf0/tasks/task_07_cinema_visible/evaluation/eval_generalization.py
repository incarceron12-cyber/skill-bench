"""影院排片优化泛化性评测引擎
=============================
对「电影院_可见」影院排片优化模型进行泛化性评测（静态优化）。

用法:
    python eval_generalization.py [--timeout 60] [--output results/] [--quick]

参数:
    --timeout  每次求解的超时时间（秒），默认 60
    --output   结果输出目录，默认 results/
    --quick    快速模式，仅运行 2 个测试用例用于验证框架
"""

import sys
import os
import json
import time
import argparse
import traceback
from datetime import datetime
from multiprocessing import Process, Queue

# 确保项目根目录在 sys.path 中
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
for path in (SCRIPT_DIR, PROJECT_ROOT):
    if path not in sys.path:
        sys.path.insert(0, path)

from generate_instances import generate_instance, get_all_cases, compute_expected_revenue


# ============================================================
# 模型注册表
# ============================================================

MODELS = {
    'claude': {
        'name': 'Claude',
        'wrapper': 'wrappers.wrapper_claude',
        'source': 'extracted/model_claude.py',
        'description': '枚举 + MNL 收入计算，间隔 >= L+1（含清场）',
    },
    'kimi': {
        'name': 'Kimi k2.5',
        'wrapper': 'wrappers.wrapper_kimi',
        'source': 'extracted/model_kimi.py',
        'description': '回溯 DFS 搜索(静态)，间隔 >= L',
    },
    'qwen3_max': {
        'name': 'Qwen3-max',
        'wrapper': 'wrappers.wrapper_qwen3_max',
        'source': 'extracted/model_qwen3_max.py',
        'description': '暴力枚举(combinations)，间隔 >= L',
    },
    'qwen35_plus': {
        'name': 'Qwen3.5-plus',
        'wrapper': 'wrappers.wrapper_qwen35_plus',
        'source': 'extracted/model_qwen35_plus.py',
        'description': '回溯 DFS 搜索(静态)，间隔 >= L',
    },
}


# ============================================================
# 超时机制（基于 multiprocessing）
# ============================================================

def _run_solve_in_process(wrapper_module_name, instance, result_queue):
    """在子进程中执行求解，结果通过 Queue 返回。"""
    try:
        # 抑制子进程中的 stdout/stderr
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, 1)
        os.dup2(devnull, 2)
        os.close(devnull)

        import importlib
        mod = importlib.import_module(wrapper_module_name)
        result = mod.solve(instance)
        result_queue.put(result)
    except Exception as e:
        result_queue.put({
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': 0.0,
            'error': f'{type(e).__name__}: {str(e)}',
            'solver': wrapper_module_name,
        })


def solve_with_timeout(wrapper_module_name, instance, timeout=60):
    """带超时的求解调用。"""
    result_queue = Queue()
    proc = Process(
        target=_run_solve_in_process,
        args=(wrapper_module_name, instance, result_queue),
    )

    start_time = time.time()
    proc.start()
    proc.join(timeout=timeout)
    elapsed = time.time() - start_time

    if proc.is_alive():
        proc.terminate()
        proc.join(timeout=5)
        if proc.is_alive():
            proc.kill()
            proc.join(timeout=2)
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': f'超时: 求解时间超过 {timeout} 秒',
            'solver': wrapper_module_name,
        }

    if not result_queue.empty():
        return result_queue.get()
    else:
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': '子进程异常退出，未返回结果',
            'solver': wrapper_module_name,
        }


# ============================================================
# 失败原因分类
# ============================================================

def classify_failure(result, instance):
    """分类失败原因。"""
    if result['feasible'] and result['objective'] is not None:
        return 'success'

    error = result.get('error', '') or ''

    if '超时' in error or 'timeout' in error.lower():
        return 'timeout'
    if 'MemoryError' in error:
        return 'memory_error'
    if 'combinations' in error.lower() or '枚举爆炸' in error:
        return 'combinatorial_explosion'
    if any(kw in error for kw in ['ImportError', 'ModuleNotFoundError']):
        return 'import_error'
    return 'logic_error'


# ============================================================
# 参考解 & 解质量评估
# ============================================================

def compute_reference_solution(instance):
    """计算参考最优解（使用 generate_instances 中的求解器）。"""
    from generate_instances import find_optimal_schedule
    K, L, g = instance['K'], instance['L'], instance['g']
    r, v = instance['r'], instance['v']
    sched, rev = find_optimal_schedule(K, L, g, r, v)
    return sched, rev


def evaluate_solution_quality(result, ref_schedule, ref_revenue, instance):
    """评估求解结果质量（与参考解对比）。"""
    if not result['feasible'] or result['objective'] is None:
        return {'quality': 'failed', 'gap': None, 'schedule_match': False}

    obj = result['objective']
    gap = (ref_revenue - obj) / ref_revenue if ref_revenue > 0 else 0.0

    sol = result.get('solution', [])
    schedule_match = (sorted(sol) == sorted(ref_schedule))

    return {
        'quality': 'optimal' if abs(gap) < 1e-6 else ('near_optimal' if gap < 0.05 else 'suboptimal'),
        'gap': round(gap, 6),
        'schedule_match': schedule_match,
    }


# ============================================================
# 生成测试用例 ID
# ============================================================

def make_case_id(case_params):
    """从测试用例参数生成可读的 ID。"""
    parts = []
    K = case_params.get('K', 20)
    parts.append(f"K{K}")
    L = case_params.get('L', 3)
    if L != 3:
        parts.append(f"L{L}")
    seed = case_params.get('seed', 42)
    if seed != 42:
        parts.append(f"s{seed}")
    gr = case_params.get('golden_ratio', 0.3)
    if gr != 0.3:
        parts.append(f"gr{gr}")
    ps = case_params.get('price_scale', 1.0)
    if ps != 1.0:
        parts.append(f"ps{ps}")
    ai = case_params.get('arrival_intensity', 'medium')
    if ai != 'medium':
        parts.append(f"ai_{ai}")
    vs = case_params.get('v_spread', 'medium')
    if vs != 'medium':
        parts.append(f"vs_{vs}")
    return '_'.join(parts) if len(parts) > 1 else parts[0]


# ============================================================
# 主评测流程
# ============================================================

def run_evaluation(timeout=60, output_dir='results/', quick=False):
    """运行完整的泛化性评测。"""
    if not os.path.isabs(output_dir):
        output_dir = os.path.join(PROJECT_ROOT, output_dir)
    os.makedirs(output_dir, exist_ok=True)

    # 获取测试用例
    if quick:
        cases = [
            {'K': 20, 'L': 3, 'seed': 42, 'golden_ratio': 0.3,
             'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
             'description': '默认参数 (K=20, L=3)'},
            {'K': 20, 'L': 2, 'seed': 42, 'golden_ratio': 0.3,
             'price_scale': 1.0, 'arrival_intensity': 'medium', 'v_spread': 'medium',
             'description': '短电影 L=2'},
        ]
    else:
        cases = get_all_cases()

    model_keys = list(MODELS.keys())
    total_runs = len(cases) * len(model_keys)

    print("=" * 70)
    print("影院排片优化泛化性评测")
    print("=" * 70)
    print(f"  测试用例数: {len(cases)}")
    print(f"  评测模型数: {len(model_keys)}")
    print(f"  总运行次数: {total_runs}")
    print(f"  超时设置:   {timeout} 秒")
    print(f"  输出目录:   {output_dir}")
    print(f"  模式:       {'快速验证' if quick else '完整评测'}")
    print("=" * 70)

    all_results = []
    run_idx = 0
    stats = {mk: {'success': 0, 'fail': 0, 'total': 0} for mk in model_keys}

    for case_idx, case_params in enumerate(cases):
        # 生成实例
        gen_params = {k: v for k, v in case_params.items() if k != 'description'}
        instance = generate_instance(**gen_params)
        case_id = make_case_id(case_params)
        case_desc = case_params.get('description', case_id)

        # 计算参考解
        ref_sched, ref_rev = compute_reference_solution(instance)

        print(f"\n--- 用例 [{case_idx+1}/{len(cases)}]: {case_desc} ---")
        print(f"    K={instance['K']}, L={instance['L']}, g={instance['g']}, "
              f"参考收入={ref_rev:.4f}, 参考排期={ref_sched}")

        for model_key in model_keys:
            run_idx += 1
            model_info = MODELS[model_key]
            wrapper_module = model_info['wrapper']

            print(f"  [{run_idx:3d}/{total_runs}] {model_key:14s}", end="")
            sys.stdout.flush()

            # 执行求解（带超时）
            result = solve_with_timeout(wrapper_module, instance, timeout)

            # 分类失败原因
            failure_category = classify_failure(result, instance)

            # 评估解质量
            quality = evaluate_solution_quality(result, ref_sched, ref_rev, instance)

            # 构建结果记录
            record = {
                'run_id': run_idx,
                'model': model_key,
                'model_name': model_info['name'],
                'case_id': case_id,
                'case_description': case_desc,
                'case_params': {k: v for k, v in case_params.items()
                                if k != 'description'},
                'K': instance['K'],
                'L': instance['L'],
                'g': instance['g'],
                'objective': result['objective'],
                'reference_revenue': ref_rev,
                'reference_schedule': ref_sched,
                'solution': result.get('solution'),
                'feasible': result['feasible'],
                'solve_time': round(result['solve_time'], 4),
                'error': result['error'],
                'solver': result.get('solver', ''),
                'failure_category': failure_category,
                'quality': quality,
            }
            all_results.append(record)

            # 更新统计 & 打印
            stats[model_key]['total'] += 1
            if failure_category == 'success':
                stats[model_key]['success'] += 1
                gap_str = f"gap={quality['gap']:.4f}" if quality['gap'] is not None else ''
                match_str = '✓' if quality['schedule_match'] else '≈'
                print(f"  -> OK  obj={result['objective']:.4f}  "
                      f"{gap_str}  {match_str}  t={result['solve_time']:.2f}s")
            else:
                stats[model_key]['fail'] += 1
                short_err = (result['error'] or '')[:60]
                print(f"  -> FAIL [{failure_category}] {short_err}")

    # ============================================================
    # 保存结果
    # ============================================================
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    results_file = os.path.join(output_dir, f'eval_results_{timestamp}.json')
    output_data = {
        'metadata': {
            'timestamp': timestamp,
            'timeout': timeout,
            'num_cases': len(cases),
            'num_models': len(model_keys),
            'total_runs': total_runs,
            'quick_mode': quick,
            'problem': '影院排片优化（完全信息版）',
        },
        'results': all_results,
    }
    with open(results_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    latest_file = os.path.join(output_dir, 'eval_results_latest.json')
    with open(latest_file, 'w', encoding='utf-8') as f:
        json.dump(output_data, f, ensure_ascii=False, indent=2)

    # ============================================================
    # 打印摘要
    # ============================================================
    print("\n" + "=" * 70)
    print("评测摘要")
    print("=" * 70)
    print(f"\n{'模型':<16s} {'成功':>6s} {'失败':>6s} {'总计':>6s} {'成功率':>8s}")
    print("-" * 48)
    for mk in model_keys:
        s = stats[mk]
        rate = f"{s['success']/s['total']*100:.1f}%" if s['total'] > 0 else 'N/A'
        print(f"{mk:<16s} {s['success']:>6d} {s['fail']:>6d} "
              f"{s['total']:>6d} {rate:>8s}")

    # 按失败类别统计
    print(f"\n失败类别统计:")
    category_counts = {}
    for r in all_results:
        cat = r['failure_category']
        category_counts[cat] = category_counts.get(cat, 0) + 1
    for cat, count in sorted(category_counts.items()):
        print(f"  {cat:<25s}: {count:>4d}")

    # 解质量统计
    print(f"\n解质量统计:")
    for mk in model_keys:
        model_results = [r for r in all_results if r['model'] == mk]
        n_opt = sum(1 for r in model_results if r['quality']['quality'] == 'optimal')
        n_near = sum(1 for r in model_results if r['quality']['quality'] == 'near_optimal')
        n_sub = sum(1 for r in model_results if r['quality']['quality'] == 'suboptimal')
        n_fail = sum(1 for r in model_results if r['quality']['quality'] == 'failed')
        gaps = [r['quality']['gap'] for r in model_results
                if r['quality']['gap'] is not None]
        avg_gap = sum(gaps) / len(gaps) if gaps else float('nan')
        print(f"  {mk:<14s}: 最优={n_opt} 近优={n_near} 次优={n_sub} "
              f"失败={n_fail}  平均gap={avg_gap:.4f}")

    print(f"\n结果已保存到: {results_file}")
    print(f"最新结果副本: {latest_file}")

    return all_results


# ============================================================
# 入口
# ============================================================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='影院排片优化泛化性评测引擎'
    )
    parser.add_argument('--timeout', type=int, default=60,
                        help='每次求解的超时时间（秒），默认 60')
    parser.add_argument('--output', type=str, default='results/',
                        help='结果输出目录，默认 results/')
    parser.add_argument('--quick', action='store_true',
                        help='快速模式，仅运行 2 个测试用例验证框架')

    args = parser.parse_args()

    run_evaluation(
        timeout=args.timeout,
        output_dir=args.output,
        quick=args.quick,
    )
