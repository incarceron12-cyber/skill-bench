#!/usr/bin/env python3
"""Robustness evaluator for generated cinema scheduling code.

This script is intentionally separate from eval_generalization.py.  It treats
each extracted model implementation as a black-box solver, runs it on hidden
static instances, then independently validates the returned schedule and
recomputes the objective.

Default static spec follows the existing local evaluation convention:
  - valid starts are 0..K-L
  - the required golden slot is one integer g
  - starts must be at least L apart

Use --spacing-plus-one to run the stricter cleaning-time variant where starts
must be at least L+1 apart and the last valid start is K-L-1.
"""

from __future__ import annotations

import argparse
import csv
import importlib
import json
import math
import os
import random
import statistics
import sys
import time
import traceback
from dataclasses import dataclass
from datetime import datetime
from multiprocessing import Process, Queue
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
BASE_DIR = SCRIPT_DIR.parent
RESULTS_DIR = BASE_DIR / "results"

for path in (BASE_DIR, SCRIPT_DIR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


MODELS = {
    "claude": {
        "name": "Claude",
        "wrapper": "wrappers.wrapper_claude",
        "source": "extracted/model_claude.py",
    },
    "kimi": {
        "name": "Kimi k2.5",
        "wrapper": "wrappers.wrapper_kimi",
        "source": "extracted/model_kimi.py",
    },
    "qwen3_max": {
        "name": "Qwen3-max",
        "wrapper": "wrappers.wrapper_qwen3_max",
        "source": "extracted/model_qwen3_max.py",
    },
    "qwen35_plus": {
        "name": "Qwen3.5-plus",
        "wrapper": "wrappers.wrapper_qwen35_plus",
        "source": "extracted/model_qwen35_plus.py",
    },
    "deepseek_v32": {
        "name": "Deepseek v3.2",
        "wrapper": None,
        "source": "responses/deepseek-v3.2.md",
    },
}


@dataclass(frozen=True)
class Spec:
    spacing_plus_one: bool = False

    def spacing(self, L: int) -> int:
        return L + 1 if self.spacing_plus_one else L

    def max_start(self, K: int, L: int) -> int:
        return K - L - 1 if self.spacing_plus_one else K - L

    @property
    def name(self) -> str:
        return "cleaning_time_L_plus_1" if self.spacing_plus_one else "local_spacing_L"


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def choose_g(max_start: int, position: str) -> int:
    if position == "first":
        return 0
    if position == "early":
        return max(0, round(max_start * 0.2))
    if position == "late":
        return min(max_start, round(max_start * 0.85))
    if position == "last":
        return max_start
    return min(max_start, round(max_start * 0.65))


def generate_instance(
    case_id: str,
    group: str,
    K: int,
    L: int,
    seed: int,
    spec: Spec,
    g_position: str = "center",
    price_profile: str = "bell",
    v_profile: str = "medium",
) -> dict[str, Any]:
    max_start = spec.max_start(K, L)
    if max_start < 0:
        raise ValueError(f"Invalid K/L for {case_id}: K={K}, L={L}")

    rng = random.Random(seed)
    g = choose_g(max_start, g_position)

    # Prices are defined for K slots to keep compatibility with model wrappers.
    r: list[float] = []
    for k in range(K):
        dist = abs(k - g)
        if price_profile == "uniform":
            base = 45.0
        elif price_profile == "spiky":
            base = 30.0
            if k in {g, max(0, g - spec.spacing(L)), min(max_start, g + spec.spacing(L))}:
                base = 85.0
        elif price_profile == "anti_corr":
            base = 25.0 + 45.0 * dist / max(K - 1, 1)
        elif price_profile == "decreasing":
            base = 70.0 - 40.0 * k / max(K - 1, 1)
        elif price_profile == "random":
            base = rng.uniform(20.0, 80.0)
        else:
            base = 30.0 + max(0.0, 35.0 - 35.0 * dist / max(K / 2.0, 1.0))
        noise = 0.0 if price_profile == "uniform" else rng.uniform(-2.0, 2.0)
        r.append(round(max(5.0, base + noise), 4))

    v: list[float] = []
    max_r, min_r = max(r), min(r)
    for k in range(K):
        dist = abs(k - g)
        if v_profile == "flat":
            val = 0.45 + rng.uniform(-0.01, 0.01)
        elif v_profile == "high_spread":
            val = rng.lognormvariate(-1.2, 0.9)
            val += max(0.0, 0.45 - 0.45 * dist / max(K / 2.0, 1.0))
        elif v_profile == "spiky":
            val = 0.04 + rng.random() * 0.04
            if k in {g, max(0, g - spec.spacing(L)), min(max_start, g + spec.spacing(L))}:
                val += 1.0 + rng.random() * 0.5
        elif v_profile == "anti_price":
            val = 0.08 + 0.9 * (max_r - r[k]) / max(max_r - min_r, 1e-9)
            val += rng.uniform(-0.03, 0.03)
        else:
            val = rng.lognormvariate(-1.4, 0.45)
            val += max(0.0, 0.35 - 0.35 * dist / max(K / 2.0, 1.0))
        v.append(round(max(0.01, val), 5))

    # Avoid giving value to starts outside the spec-valid range.
    for k in range(max_start + 1, K):
        v[k] = min(v[k], 0.02)

    return {
        "case_id": case_id,
        "group": group,
        "description": (
            f"{group}: K={K}, L={L}, g={g}, price={price_profile}, "
            f"v={v_profile}, seed={seed}"
        ),
        "K": K,
        "L": L,
        "g": [g],
        "g_value": g,
        "r": r,
        "v": v,
        "lambda_t": [1.0],
        "lambda_min": 1.0,
        "lambda_max": 1.0,
        "T": 1,
        "price_profile": price_profile,
        "v_profile": v_profile,
        "seed": seed,
        "spec": spec.name,
    }


def build_cases(spec: Spec, quick: bool = False) -> list[dict[str, Any]]:
    case_specs = [
        ("smoke_K20_L3", "smoke", 20, 3, 42, "center", "bell", "medium"),
        ("param_L1", "parameter", 20, 1, 42, "center", "bell", "medium"),
        ("param_L2", "parameter", 20, 2, 43, "center", "bell", "medium"),
        ("param_L5", "parameter", 20, 5, 44, "center", "bell", "medium"),
        ("param_L8", "parameter", 20, 8, 45, "center", "bell", "medium"),
        ("edge_g_first", "edge", 20, 3, 46, "first", "bell", "medium"),
        ("edge_g_last", "edge", 20, 3, 47, "last", "bell", "medium"),
        ("edge_flat_ties", "edge", 20, 3, 48, "center", "uniform", "flat"),
        ("adv_anti_corr", "adversarial", 20, 3, 49, "center", "anti_corr", "anti_price"),
        ("adv_price_spikes", "adversarial", 24, 3, 50, "center", "spiky", "medium"),
        ("adv_v_spikes", "adversarial", 24, 3, 51, "center", "bell", "spiky"),
        ("adv_random_prices", "adversarial", 24, 4, 52, "early", "random", "high_spread"),
        ("scale_K10", "scale", 10, 3, 53, "center", "bell", "medium"),
        ("scale_K30", "scale", 30, 3, 54, "center", "bell", "medium"),
        ("scale_K40", "scale", 40, 3, 55, "center", "bell", "medium"),
        ("scale_K50", "scale", 50, 3, 56, "center", "bell", "medium"),
        ("scale_K60_L5", "scale", 60, 5, 57, "center", "bell", "medium"),
    ]
    if not quick:
        case_specs.extend(
            [
                ("seed_101", "random_seed", 20, 3, 101, "center", "bell", "medium"),
                ("seed_202", "random_seed", 20, 3, 202, "center", "bell", "medium"),
                ("seed_303", "random_seed", 20, 3, 303, "center", "bell", "medium"),
                ("combo_short_spiky", "adversarial", 30, 2, 58, "late", "spiky", "spiky"),
                ("combo_long_anti", "adversarial", 30, 6, 59, "early", "anti_corr", "anti_price"),
                ("combo_decreasing_flat", "edge", 30, 4, 60, "center", "decreasing", "flat"),
                ("scale_K80", "scale", 80, 4, 61, "center", "bell", "medium"),
            ]
        )

    return [
        generate_instance(
            case_id=case_id,
            group=group,
            K=K,
            L=L,
            seed=seed,
            spec=spec,
            g_position=g_position,
            price_profile=price_profile,
            v_profile=v_profile,
        )
        for (
            case_id,
            group,
            K,
            L,
            seed,
            g_position,
            price_profile,
            v_profile,
        ) in case_specs
    ]


def expected_revenue(schedule: list[int], r: list[float], v: list[float], lam: float = 1.0) -> float:
    total_v = sum(v[k] for k in schedule)
    denom = 1.0 + total_v
    return lam * sum(r[k] * v[k] / denom for k in schedule)


def validate_schedule(schedule_raw: Any, instance: dict[str, Any], spec: Spec) -> tuple[bool, str, list[int] | None]:
    if schedule_raw is None:
        return False, "missing_solution", None
    if not isinstance(schedule_raw, (list, tuple)):
        return False, "solution_not_list", None

    schedule: list[int] = []
    for item in schedule_raw:
        if isinstance(item, bool) or not isinstance(item, int):
            return False, "non_integer_start", None
        schedule.append(int(item))

    if not schedule:
        return False, "empty_schedule", None
    if len(schedule) != len(set(schedule)):
        return False, "duplicate_starts", sorted(schedule)

    K, L = instance["K"], instance["L"]
    g = instance["g_value"]
    max_start = spec.max_start(K, L)
    H = spec.spacing(L)
    sorted_schedule = sorted(schedule)

    if g not in sorted_schedule:
        return False, "missing_golden_slot", sorted_schedule
    if any(k < 0 or k > max_start for k in sorted_schedule):
        return False, "start_out_of_range", sorted_schedule

    for a, b in zip(sorted_schedule, sorted_schedule[1:]):
        if b - a < H:
            return False, "spacing_violation", sorted_schedule

    return True, "valid", sorted_schedule


def weighted_interval_dp(slots: list[int], weights: dict[int, float], H: int) -> tuple[float, list[int]]:
    slots = sorted(slots)
    n = len(slots)
    if n == 0:
        return 0.0, []

    prev = []
    j = -1
    for i, slot in enumerate(slots):
        while j + 1 < i and slots[j + 1] <= slot - H:
            j += 1
        prev.append(j)

    dp = [0.0] * (n + 1)
    take = [False] * n
    for i in range(1, n + 1):
        slot = slots[i - 1]
        take_value = weights[slot] + dp[prev[i - 1] + 1]
        skip_value = dp[i - 1]
        if take_value > skip_value + 1e-12:
            dp[i] = take_value
            take[i - 1] = True
        else:
            dp[i] = skip_value

    chosen: list[int] = []
    i = n
    while i > 0:
        if take[i - 1]:
            slot = slots[i - 1]
            chosen.append(slot)
            i = prev[i - 1] + 1
        else:
            i -= 1

    return dp[n], sorted(chosen)


def reference_static(instance: dict[str, Any], spec: Spec, tol: float = 1e-10) -> tuple[list[int], float]:
    K, L = instance["K"], instance["L"]
    g = instance["g_value"]
    r, v = instance["r"], instance["v"]
    max_start = spec.max_start(K, L)
    H = spec.spacing(L)
    starts = list(range(max_start + 1))
    if g not in starts:
        raise ValueError(f"Golden slot {g} outside valid starts 0..{max_start}")

    q = expected_revenue([g], r, v)
    best_schedule = [g]
    best_obj = q

    for _ in range(100):
        weights = {k: r[k] * v[k] - q * v[k] for k in starts}
        left_slots = [k for k in starts if k <= g - H]
        right_slots = [k for k in starts if k >= g + H]
        left_value, left_schedule = weighted_interval_dp(left_slots, weights, H)
        right_value, right_schedule = weighted_interval_dp(right_slots, weights, H)
        schedule = sorted(left_schedule + [g] + right_schedule)
        phi = weights[g] + left_value + right_value - q
        obj = expected_revenue(schedule, r, v)
        best_schedule, best_obj = schedule, obj
        if abs(phi) <= tol:
            break
        q = obj

    return best_schedule, best_obj


def _run_wrapper(wrapper_module_name: str, instance: dict[str, Any], queue: Queue) -> None:
    try:
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, 1)
        os.dup2(devnull, 2)
        os.close(devnull)

        module = importlib.import_module(wrapper_module_name)
        result = module.solve(instance)
        queue.put({"ok": True, "result": result})
    except Exception as exc:  # pragma: no cover - defensive subprocess path
        queue.put(
            {
                "ok": False,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            }
        )


def solve_with_timeout(wrapper_module_name: str, instance: dict[str, Any], timeout: float) -> dict[str, Any]:
    queue: Queue = Queue()
    proc = Process(target=_run_wrapper, args=(wrapper_module_name, instance, queue))
    start = time.time()
    proc.start()
    proc.join(timeout=timeout)
    elapsed = time.time() - start

    if proc.is_alive():
        proc.terminate()
        proc.join(timeout=1)
        if proc.is_alive():
            proc.kill()
            proc.join(timeout=1)
        return {
            "status": "timeout",
            "elapsed": elapsed,
            "error": f"timeout after {timeout} seconds",
            "result": None,
        }

    if queue.empty():
        return {
            "status": "runtime_error",
            "elapsed": elapsed,
            "error": "subprocess exited without a result",
            "result": None,
        }

    payload = queue.get()
    if not payload.get("ok"):
        return {
            "status": "runtime_error",
            "elapsed": elapsed,
            "error": payload.get("error"),
            "traceback": payload.get("traceback"),
            "result": None,
        }

    return {"status": "completed", "elapsed": elapsed, "error": None, "result": payload["result"]}


def get_solution(result: Any) -> Any:
    if not isinstance(result, dict):
        return None
    for key in ("solution", "optimal_schedule", "schedule"):
        if key in result:
            return result[key]
    return None


def evaluate_model_case(
    model_key: str,
    model_info: dict[str, Any],
    instance: dict[str, Any],
    spec: Spec,
    timeout: float,
) -> dict[str, Any]:
    ref_schedule, ref_obj = reference_static(instance, spec)

    if model_info["wrapper"] is None:
        return {
            "model": model_key,
            "model_name": model_info["name"],
            "case_id": instance["case_id"],
            "group": instance["group"],
            "K": instance["K"],
            "L": instance["L"],
            "g": instance["g_value"],
            "status": "no_code",
            "valid": False,
            "failure_category": "no_code",
            "solution": None,
            "objective_recomputed": None,
            "objective_claimed": None,
            "objective_claimed_error": None,
            "reference_objective": ref_obj,
            "reference_schedule": ref_schedule,
            "gap": None,
            "gap_capped": None,
            "quality": "failed",
            "elapsed": 0.0,
            "error": "no runnable Python code was extracted",
        }

    run = solve_with_timeout(model_info["wrapper"], instance, timeout)
    result = run["result"]
    claimed_objective = result.get("objective") if isinstance(result, dict) else None
    solution_raw = get_solution(result)

    if run["status"] != "completed":
        return {
            "model": model_key,
            "model_name": model_info["name"],
            "case_id": instance["case_id"],
            "group": instance["group"],
            "K": instance["K"],
            "L": instance["L"],
            "g": instance["g_value"],
            "status": run["status"],
            "valid": False,
            "failure_category": run["status"],
            "solution": None,
            "objective_recomputed": None,
            "objective_claimed": claimed_objective,
            "objective_claimed_error": None,
            "reference_objective": ref_obj,
            "reference_schedule": ref_schedule,
            "gap": None,
            "gap_capped": None,
            "quality": "failed",
            "elapsed": round(run["elapsed"], 6),
            "error": run.get("error"),
        }

    valid, validation_reason, schedule = validate_schedule(solution_raw, instance, spec)
    if not valid:
        return {
            "model": model_key,
            "model_name": model_info["name"],
            "case_id": instance["case_id"],
            "group": instance["group"],
            "K": instance["K"],
            "L": instance["L"],
            "g": instance["g_value"],
            "status": "completed",
            "valid": False,
            "failure_category": validation_reason,
            "solution": schedule if schedule is not None else solution_raw,
            "objective_recomputed": None,
            "objective_claimed": claimed_objective,
            "objective_claimed_error": None,
            "reference_objective": ref_obj,
            "reference_schedule": ref_schedule,
            "gap": None,
            "gap_capped": None,
            "quality": "invalid",
            "elapsed": round(run["elapsed"], 6),
            "error": validation_reason,
        }

    assert schedule is not None
    recomputed_obj = expected_revenue(schedule, instance["r"], instance["v"])
    denom = max(abs(ref_obj), 1e-9)
    raw_gap = (ref_obj - recomputed_obj) / denom
    gap_capped = max(0.0, raw_gap)
    claimed_error = None
    if isinstance(claimed_objective, (int, float)):
        claimed_error = abs(float(claimed_objective) - recomputed_obj)

    if gap_capped <= 1e-8:
        quality = "optimal"
    elif gap_capped <= 0.05:
        quality = "near_optimal"
    else:
        quality = "suboptimal"

    return {
        "model": model_key,
        "model_name": model_info["name"],
        "case_id": instance["case_id"],
        "group": instance["group"],
        "K": instance["K"],
        "L": instance["L"],
        "g": instance["g_value"],
        "status": "completed",
        "valid": True,
        "failure_category": "success",
        "solution": schedule,
        "objective_recomputed": recomputed_obj,
        "objective_claimed": claimed_objective,
        "objective_claimed_error": claimed_error,
        "reference_objective": ref_obj,
        "reference_schedule": ref_schedule,
        "gap": raw_gap,
        "gap_capped": gap_capped,
        "quality": quality,
        "elapsed": round(run["elapsed"], 6),
        "error": None,
    }


def p95(values: list[float]) -> float | None:
    if not values:
        return None
    values = sorted(values)
    idx = min(len(values) - 1, math.ceil(0.95 * len(values)) - 1)
    return values[idx]


def summarize(records: list[dict[str, Any]], model_keys: list[str], total_cases: int) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for model in model_keys:
        rows = [r for r in records if r["model"] == model]
        valid_rows = [r for r in rows if r["valid"]]
        completed_rows = [r for r in rows if r["status"] == "completed"]
        gaps = [r["gap_capped"] for r in valid_rows if r["gap_capped"] is not None]
        elapsed = [r["elapsed"] for r in rows if r["elapsed"] is not None]
        max_k_solved = max((r["K"] for r in valid_rows), default=None)
        failures: dict[str, int] = {}
        for row in rows:
            cat = row["failure_category"]
            failures[cat] = failures.get(cat, 0) + 1

        summary[model] = {
            "model_name": rows[0]["model_name"] if rows else model,
            "total_cases": total_cases,
            "completed": len(completed_rows),
            "valid": len(valid_rows),
            "optimal": sum(1 for r in valid_rows if r["quality"] == "optimal"),
            "near_optimal": sum(1 for r in valid_rows if r["quality"] in {"optimal", "near_optimal"}),
            "suboptimal": sum(1 for r in valid_rows if r["quality"] == "suboptimal"),
            "timeouts": sum(1 for r in rows if r["failure_category"] == "timeout"),
            "invalid": sum(1 for r in rows if r["quality"] == "invalid"),
            "run_success_rate": len(completed_rows) / total_cases if total_cases else 0.0,
            "valid_rate": len(valid_rows) / total_cases if total_cases else 0.0,
            "near_optimal_rate": (
                sum(1 for r in valid_rows if r["quality"] in {"optimal", "near_optimal"}) / total_cases
                if total_cases
                else 0.0
            ),
            "timeout_rate": (
                sum(1 for r in rows if r["failure_category"] == "timeout") / total_cases
                if total_cases
                else 0.0
            ),
            "avg_gap": statistics.mean(gaps) if gaps else None,
            "worst_gap": max(gaps) if gaps else None,
            "runtime_p95": p95(elapsed),
            "max_k_solved": max_k_solved,
            "failure_counts": dict(sorted(failures.items())),
        }
    return summary


def write_csv(path: Path, records: list[dict[str, Any]]) -> None:
    fields = [
        "model",
        "case_id",
        "group",
        "K",
        "L",
        "g",
        "status",
        "valid",
        "failure_category",
        "quality",
        "gap_capped",
        "elapsed",
        "objective_recomputed",
        "reference_objective",
        "solution",
        "reference_schedule",
        "error",
    ]
    with path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for record in records:
            writer.writerow({field: record.get(field) for field in fields})


def fmt_rate(x: float) -> str:
    return f"{x * 100:.1f}%"


def fmt_num(x: float | None, digits: int = 4) -> str:
    return "N/A" if x is None else f"{x:.{digits}f}"


def write_report(
    path: Path,
    metadata: dict[str, Any],
    summary: dict[str, Any],
    records: list[dict[str, Any]],
) -> None:
    lines = [
        "# Code Robustness Report",
        "",
        "This is a supplemental static robustness evaluation. It measures whether generated code behaves like a reusable solver over hidden parameter instances. It is not a replacement for formulation/report scoring.",
        "",
        "## Setup",
        "",
        f"- Spec: `{metadata['spec']}`",
        f"- Cases: {metadata['num_cases']}",
        f"- Models: {metadata['num_models']}",
        f"- Per-case timeout: {metadata['timeout_seconds']} seconds",
        f"- Reference: exact fractional objective optimization via Dinkelbach + weighted interval DP",
        f"- Feasibility is independently checked; model-reported objective/feasible flags are not trusted.",
        "",
        "## Summary",
        "",
        "| Model | Valid | Near-opt | Timeout | Avg gap | Worst gap | Runtime p95 | Max K solved | Main failures |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---|",
    ]

    for model, row in summary.items():
        failures = ", ".join(f"{k}:{v}" for k, v in row["failure_counts"].items() if k != "success")
        if not failures:
            failures = "none"
        lines.append(
            "| {name} | {valid} | {near} | {timeout} | {avg_gap} | {worst_gap} | {p95} | {max_k} | {failures} |".format(
                name=row["model_name"],
                valid=fmt_rate(row["valid_rate"]),
                near=fmt_rate(row["near_optimal_rate"]),
                timeout=fmt_rate(row["timeout_rate"]),
                avg_gap=fmt_num(row["avg_gap"]),
                worst_gap=fmt_num(row["worst_gap"]),
                p95=fmt_num(row["runtime_p95"], 3),
                max_k=row["max_k_solved"] if row["max_k_solved"] is not None else "N/A",
                failures=failures,
            )
        )

    lines.extend(["", "## Failure Examples", ""])
    for model, row in summary.items():
        bad_rows = [
            r
            for r in records
            if r["model"] == model
            and (not r["valid"] or r["quality"] == "suboptimal" or r["failure_category"] != "success")
        ][:5]
        lines.append(f"### {row['model_name']}")
        if not bad_rows:
            lines.append("")
            lines.append("No major failures in this run.")
            lines.append("")
            continue
        lines.append("")
        for r in bad_rows:
            detail = r["failure_category"]
            if r["valid"] and r["gap_capped"] is not None:
                detail = f"{r['quality']}, gap={r['gap_capped']:.4f}"
            lines.append(
                f"- `{r['case_id']}` ({r['group']}, K={r['K']}, L={r['L']}): {detail}; "
                f"solution={r.get('solution')}"
            )
        lines.append("")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(timeout: float, quick: bool, spacing_plus_one: bool, output_dir: Path) -> dict[str, Any]:
    spec = Spec(spacing_plus_one=spacing_plus_one)
    cases = build_cases(spec, quick=quick)
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    model_keys = list(MODELS.keys())
    records: list[dict[str, Any]] = []
    total = len(cases) * len(model_keys)
    run_idx = 0

    print("=" * 72)
    print("Cinema code robustness evaluation")
    print("=" * 72)
    print(f"Spec:        {spec.name}")
    print(f"Cases:       {len(cases)}")
    print(f"Models:      {len(model_keys)}")
    print(f"Total runs:  {total}")
    print(f"Timeout:     {timeout}s")
    print(f"Output dir:  {output_dir}")
    print("=" * 72)

    for case in cases:
        ref_schedule, ref_obj = reference_static(case, spec)
        print(
            f"\n[{case['case_id']}] {case['group']} "
            f"K={case['K']} L={case['L']} g={case['g_value']} "
            f"reference={ref_obj:.4f} sched={ref_schedule}"
        )
        for model_key in model_keys:
            run_idx += 1
            model_info = MODELS[model_key]
            print(f"  [{run_idx:3d}/{total}] {model_key:<13s}", end="", flush=True)
            record = evaluate_model_case(model_key, model_info, case, spec, timeout)
            records.append(record)
            if record["valid"]:
                print(
                    f" OK {record['quality']:<12s} "
                    f"gap={record['gap_capped']:.4f} t={record['elapsed']:.2f}s"
                )
            else:
                print(f" FAIL {record['failure_category']} t={record['elapsed']:.2f}s")

    summary = summarize(records, model_keys, len(cases))
    metadata = {
        "timestamp": timestamp,
        "spec": spec.name,
        "spacing_plus_one": spacing_plus_one,
        "timeout_seconds": timeout,
        "quick": quick,
        "num_cases": len(cases),
        "num_models": len(model_keys),
        "total_runs": total,
        "case_ids": [case["case_id"] for case in cases],
    }
    output = {"metadata": metadata, "cases": cases, "summary": summary, "records": records}

    json_path = output_dir / f"robustness_results_{timestamp}.json"
    latest_path = output_dir / "robustness_results_latest.json"
    csv_path = output_dir / f"robustness_records_{timestamp}.csv"
    report_path = output_dir / "robustness_report.md"

    json_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    latest_path.write_text(json.dumps(output, ensure_ascii=False, indent=2), encoding="utf-8")
    write_csv(csv_path, records)
    write_report(report_path, metadata, summary, records)

    print("\n" + "=" * 72)
    print("Summary")
    print("=" * 72)
    for model_key, row in summary.items():
        print(
            f"{row['model_name']:<16s} valid={fmt_rate(row['valid_rate']):>6s} "
            f"near={fmt_rate(row['near_optimal_rate']):>6s} "
            f"timeout={fmt_rate(row['timeout_rate']):>6s} "
            f"avg_gap={fmt_num(row['avg_gap']):>8s} "
            f"p95={fmt_num(row['runtime_p95'], 3):>8s}"
        )
    print(f"\nJSON:   {json_path}")
    print(f"Latest: {latest_path}")
    print(f"CSV:    {csv_path}")
    print(f"Report: {report_path}")

    return output


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate static code robustness for cinema scheduling.")
    parser.add_argument("--timeout", type=float, default=8.0, help="Timeout per model-case run in seconds.")
    parser.add_argument("--quick", action="store_true", help="Run a shorter case set.")
    parser.add_argument(
        "--spacing-plus-one",
        action="store_true",
        help="Use starts spacing >= L+1 and max_start=K-L-1.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=RESULTS_DIR / "robustness",
        help="Output directory.",
    )
    args = parser.parse_args()

    run(
        timeout=args.timeout,
        quick=args.quick,
        spacing_plus_one=args.spacing_plus_one,
        output_dir=args.output,
    )


if __name__ == "__main__":
    main()
