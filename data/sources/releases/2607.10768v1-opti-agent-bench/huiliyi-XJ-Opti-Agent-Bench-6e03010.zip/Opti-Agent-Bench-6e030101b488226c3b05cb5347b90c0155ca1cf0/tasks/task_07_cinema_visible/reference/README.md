# Reference — `task_07_cinema_visible`

## Included

- `feasibility_check.py`
- `generate_instances.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
