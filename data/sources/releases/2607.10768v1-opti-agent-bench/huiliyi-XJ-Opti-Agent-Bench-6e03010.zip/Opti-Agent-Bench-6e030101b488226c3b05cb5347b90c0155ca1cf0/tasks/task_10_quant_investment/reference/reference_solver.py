#!/usr/bin/env python3
"""
Kimi-k2.5 模型代码提取
基于原始 Markdown 中的代码块
修改：数据路径、输出路径改为 stdout JSON
"""

import numpy as np
from scipy.optimize import minimize
import json
import time
from pathlib import Path

start_time = time.time()


def cvar_computation(losses, alpha):
    """
    Compute CVaR (Conditional Value at Risk) using Rockafellar-Uryasev representation.
    """
    n = len(losses)
    sorted_losses = np.sort(losses)
    
    # Index for VaR (alpha-quantile)
    k = int(np.ceil(alpha * n))
    k = max(1, min(k, n))
    
    # CVaR is the average of the worst alpha-fraction of losses
    cvar = np.mean(sorted_losses[-k:])
    
    return cvar


def robust_portfolio_objective(theta, returns, rho, alpha, varrho):
    """
    Compute the full distributionally robust portfolio objective.
    """
    n, d = returns.shape
    
    # Compute portfolio losses: L(θ, Z) = -θ^T Z
    losses = -returns @ theta
    
    # Expected loss under empirical distribution
    expected_loss = np.mean(losses)
    
    # CVaR component using Rockafellar-Uryasev representation
    cvar_value = cvar_computation(losses, alpha)
    
    # Wasserstein robust term
    grad_norm = np.linalg.norm(theta, ord=2)
    
    # Robust term: accounts for worst-case distribution within Wasserstein ball
    loss_std = np.std(losses)
    robust_term = rho * grad_norm * loss_std
    
    # Full objective: robust expected loss + CVaR penalty
    objective = expected_loss + robust_term + varrho * cvar_value
    
    return objective


def gradient_robust_objective(theta, returns, rho, alpha, varrho):
    """
    Compute gradient of the robust objective.
    """
    n, d = returns.shape
    
    # Compute losses
    losses = -returns @ theta
    
    # Gradient of expected loss: -E[Z]
    grad_expected = -np.mean(returns, axis=0)
    
    # Gradient of CVaR
    sorted_indices = np.argsort(losses)
    k = int(np.ceil(alpha * n))
    k = max(1, min(k, n))
    
    # Worst k losses
    worst_indices = sorted_indices[-k:]
    
    # Gradient of CVaR: -(1/k) * sum of returns for worst cases
    grad_cvar = -(1.0 / k) * np.sum(returns[worst_indices], axis=0)
    
    # Gradient of robust term
    grad_norm = np.linalg.norm(theta, ord=2)
    loss_std = np.std(losses)
    
    if grad_norm > 1e-10 and loss_std > 1e-10:
        # Gradient of ||θ||
        grad_norm_vec = theta / grad_norm
        
        # Gradient of std(-θ^T Z)
        mean_loss = np.mean(losses)
        grad_std = -(1.0 / (n * loss_std)) * (returns.T @ losses - mean_loss * np.sum(returns, axis=0))
        
        grad_robust = rho * (grad_norm_vec * loss_std + grad_norm * grad_std)
    else:
        grad_robust = np.zeros(d)
    
    # Total gradient
    gradient = grad_expected + grad_robust + varrho * grad_cvar
    
    return gradient


def project_to_simplex(v):
    """
    Project vector v onto the probability simplex using efficient algorithm.
    """
    n = len(v)
    u = np.sort(v)[::-1]  # Sort in descending order
    cssv = np.cumsum(u) - 1
    ind = np.arange(n) + 1
    rho = np.sum(u - cssv / ind > 0)
    
    if rho == 0:
        return np.zeros(n)
    
    theta = cssv[rho - 1] / rho
    return np.maximum(v - theta, 0)


def svrg_robust_portfolio(returns, rho, alpha, varrho,
                          step_size=0.01, max_iter=2000, batch_size=32,
                          verbose=False):
    """
    Stochastic Variance Reduced Gradient (SVRG) for robust portfolio optimization.
    """
    n, d = returns.shape
    
    # Initialize with equal weights
    theta = np.ones(d) / d
    theta_snapshot = theta.copy()
    
    # Compute full gradient at snapshot
    grad_snapshot = gradient_robust_objective(
        theta_snapshot, returns, rho, alpha, varrho
    )
    
    epoch_length = n  # One epoch = one pass through data
    
    for epoch in range(max_iter // epoch_length + 1):
        for t in range(epoch_length):
            iter_num = epoch * epoch_length + t
            if iter_num >= max_iter:
                break
            
            # Sample mini-batch
            indices = np.random.choice(n, size=min(batch_size, n), replace=False)
            batch_returns = returns[indices]
            
            # Compute stochastic gradients with variance reduction
            grad_current = gradient_robust_objective(
                theta, batch_returns, rho, alpha, varrho
            )
            
            grad_snapshot_batch = gradient_robust_objective(
                theta_snapshot, batch_returns, rho, alpha, varrho
            )
            
            # Variance reduced gradient
            grad_tilde = grad_current - grad_snapshot_batch + grad_snapshot
            
            # Gradient descent step
            theta = theta - step_size * grad_tilde
            
            # Project to simplex
            theta = project_to_simplex(theta)
            
            # Ensure numerical stability
            theta = np.maximum(theta, 0)
            theta = theta / (np.sum(theta) + 1e-10)
        
        # Update snapshot for next epoch
        theta_snapshot = theta.copy()
        grad_snapshot = gradient_robust_objective(
            theta_snapshot, returns, rho, alpha, varrho
        )
        
        if verbose and epoch % 10 == 0:
            obj = robust_portfolio_objective(theta, returns, rho, alpha, varrho)
            print(f"Epoch {epoch}: Objective = {obj:.6f}")
    
    return theta


def solve_robust_portfolio(returns, epsilon=0.1, rho=0.5, alpha=0.05, 
                           varrho=0.5, method='SLSQP'):
    """
    Main function to solve distributionally robust portfolio optimization.
    """
    n, d = returns.shape
    
    if method == 'SVRG':
        # Use stochastic variance reduced gradient
        weights = svrg_robust_portfolio(
            returns, rho, alpha, varrho,
            step_size=0.001, max_iter=5000, batch_size=min(32, n)
        )
    else:
        # Use scipy optimizer (deterministic)
        def objective(theta):
            return robust_portfolio_objective(theta, returns, rho, alpha, varrho)
        
        # Constraints: sum to 1, non-negative
        constraints = [{'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0}]
        bounds = [(0, 1) for _ in range(d)]
        
        # Initial guess: equal weights
        x0 = np.ones(d) / d
        
        # Optimize with multiple starting points for better solution
        best_result = None
        best_obj = float('inf')
        
        np.random.seed(42)
        for init in [np.ones(d) / d, np.random.dirichlet(np.ones(d)), 
                     np.eye(d)[np.random.randint(d)]]:
            result = minimize(objective, init, method=method, bounds=bounds,
                            constraints=constraints, 
                            options={'maxiter': 1000, 'ftol': 1e-9})
            if result.success and result.fun < best_obj:
                best_obj = result.fun
                best_result = result
        
        if best_result is not None:
            weights = best_result.x
        else:
            weights = x0
    
    # Normalize to ensure exact sum to 1
    weights = np.maximum(weights, 0)
    weights = weights / np.sum(weights)
    
    return weights


if __name__ == '__main__':
    # Load data
    data_path = Path(__file__).resolve().parents[1] / "problem" / "data.csv"
    data = np.loadtxt(data_path, delimiter=',')
    
    print(f"Data shape: {data.shape}")
    print(f"Number of samples (n): {data.shape[0]}")
    print(f"Number of assets (d): {data.shape[1]}")
    
    # Parameters
    epsilon = 0.1   # Smoothing parameter
    rho = 0.5       # Wasserstein radius
    alpha = 0.05    # CVaR confidence level (95% CVaR)
    varrho = 0.5    # CVaR weight
    
    print(f"\nParameters:")
    print(f"  epsilon = {epsilon}")
    print(f"  rho = {rho}")
    print(f"  alpha = {alpha}")
    print(f"  varrho = {varrho}")
    
    # Solve
    print("\nSolving robust portfolio optimization...")
    weights = solve_robust_portfolio(data, epsilon, rho, alpha, varrho)
    
    print(f"\nOptimal portfolio weights:")
    for i, w in enumerate(weights):
        print(f"  Asset {i+1}: {w:.6f}")
    
    print(f"\nSum of weights: {np.sum(weights):.6f}")
    print(f"Min weight: {np.min(weights):.6f}")
    print(f"Max weight: {np.max(weights):.6f}")
    
    # Evaluate portfolio
    losses = -data @ weights
    expected_loss = np.mean(losses)
    cvar = cvar_computation(losses, alpha)
    
    print(f"\nPortfolio metrics:")
    print(f"  Expected loss: {expected_loss:.6f}")
    print(f"  CVaR_{alpha}: {cvar:.6f}")
    print(f"  Robust objective: {expected_loss + varrho * cvar:.6f}")
    
    elapsed = time.time() - start_time
    n_eff = 1.0 / np.sum(weights**2)
    
    # Save results as JSON to stdout
    results = {
        "weights": [round(w, 6) for w in weights],
        "epsilon": epsilon,
        "rho": rho,
        "rho_risk": varrho,
        "alpha": alpha,
        "dual_objective": round(float(expected_loss + varrho * cvar), 6),
        "algorithm": "SVRG-based stochastic variance reduced gradient with SLSQP fallback",
        "dual_derivation_summary": "通过拉格朗日对偶和强对偶性推导对偶形式，使用SVRG方差缩减算法求解。",
        "n_eff": round(float(n_eff), 2),
        "run_time_seconds": round(elapsed, 2)
    }
    
    print("\n=== JSON OUTPUT ===")
    print(json.dumps(results, indent=2, ensure_ascii=False))
