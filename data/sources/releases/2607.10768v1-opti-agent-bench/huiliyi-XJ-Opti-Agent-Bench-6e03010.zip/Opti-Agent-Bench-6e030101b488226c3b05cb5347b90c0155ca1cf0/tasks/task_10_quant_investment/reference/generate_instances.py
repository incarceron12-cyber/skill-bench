"""
量化（分布鲁棒投资组合优化）测试实例生成器
=============================================
为 Wasserstein 分布鲁棒投资组合优化问题生成泛化性测试用例。

问题结构：
  - n 个历史资产回报样本, 每个样本是 d 维向量
  - 决策变量: θ ∈ R^d, θ_i ≥ 0, Σθ_i = 1
  - 目标: min_θ max_Q∈B_ρ(P_n) E_Q[L(θ, Z)]
  - 损失函数: L(θ, z) = -θ^Tz + ϱ · CVaR_α(-θ^Tz)
  - 平滑参数 ε 控制最坏情况评估的平滑程度
  - Wasserstein 半径 ρ 控制分布不确定性预算
  - 传输成本 c(x,y) = ||x - y||_2^2

生成的实例字典结构：
  data           : np.ndarray (n, d)   历史回报数据矩阵
  n_samples      : int                 样本数
  n_assets       : int                 资产数
  epsilon        : float               平滑参数
  rho            : float               Wasserstein 距离预算
  alpha          : float               CVaR 置信度 (tail probability)
  varrho         : float               CVaR 权重
  data_csv_path  : str                 保存的 CSV 文件路径（如有）
  description    : str                 实例描述

与模型代码兼容性：
  - Claude: pd.read_csv(path, header=None) 或 np.loadtxt
  - Kimi:   np.loadtxt(path, delimiter=',')
  - Qwen:   np.loadtxt(path, delimiter=',')
  - 所有模型均期望 (n, d) 形状的纯数值矩阵，无表头
"""

import numpy as np
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]

# ============================================================
# 原始问题数据特征（从 data.csv 分析得出）
# ============================================================
# data.csv: 100 行 × 10 列, 无表头
# 均值: 0.007 ~ 0.314 (递增趋势)
# 标准差: 0.195 ~ 0.456
# 相关系数: 均值 |r| ≈ 0.17, 范围 [-0.12, 0.38]
# 数值范围: [-0.85, 1.75]

ORIGINAL_N = 100
ORIGINAL_D = 10
ORIGINAL_EPSILON = 0.1   # Kimi/Qwen 使用的默认值
ORIGINAL_RHO = 0.05      # Qwen 使用的默认值
ORIGINAL_ALPHA = 0.05    # CVaR 尾部概率 (即 95% CVaR)
ORIGINAL_VARRHO = 0.5    # CVaR 权重


def _build_correlation_matrix(d, correlation='medium', rng=None):
    """
    构建 d×d 相关系数矩阵。
    
    correlation:
      - 'none':   单位矩阵（独立）
      - 'low':    |r| ≈ 0.05-0.15
      - 'medium': |r| ≈ 0.10-0.30 (原始数据水平)
      - 'high':   |r| ≈ 0.30-0.60
      - 'block':  分组高相关（模拟行业板块）
    """
    if rng is None:
        rng = np.random.default_rng(42)

    if correlation == 'none':
        return np.eye(d)

    if correlation == 'block':
        # 分 3~4 个块，块内高相关，块间低相关
        n_blocks = min(4, max(2, d // 3))
        block_sizes = [d // n_blocks] * n_blocks
        for i in range(d - sum(block_sizes)):
            block_sizes[i] += 1
        
        C = np.eye(d) * 0.3  # 底层低相关
        idx = 0
        for bs in block_sizes:
            block = np.full((bs, bs), 0.5 + rng.uniform(0.0, 0.2))
            np.fill_diagonal(block, 1.0)
            C[idx:idx+bs, idx:idx+bs] = block
            idx += bs
        # 对称化并确保正定
        C = (C + C.T) / 2
        np.fill_diagonal(C, 1.0)
        # 确保正定
        eigvals = np.linalg.eigvalsh(C)
        if eigvals.min() < 1e-6:
            C += (1e-6 - eigvals.min()) * np.eye(d)
            # 重新归一化为相关矩阵
            D = np.sqrt(np.diag(C))
            C = C / np.outer(D, D)
        return C

    # 随机相关矩阵 via Cholesky 方法
    corr_ranges = {
        'low':    (0.02, 0.12),
        'medium': (0.05, 0.25),
        'high':   (0.25, 0.55),
    }
    lo, hi = corr_ranges.get(correlation, (0.05, 0.25))
    
    # 生成随机正定矩阵
    # 使用 Vine 方法的简化版
    A = rng.uniform(-1, 1, (d, d))
    A = A @ A.T
    D = np.sqrt(np.diag(A))
    C = A / np.outer(D, D)
    
    # 缩放到目标相关系数范围
    target_mean = (lo + hi) / 2
    off_diag = C[np.triu_indices(d, 1)]
    current_mean = np.mean(np.abs(off_diag))
    if current_mean > 1e-8:
        scale = target_mean / current_mean
        C = np.eye(d) + scale * (C - np.eye(d))
        # 确保对角线为1
        D = np.sqrt(np.diag(C))
        C = C / np.outer(D, D)
        # 确保正定
        eigvals = np.linalg.eigvalsh(C)
        if eigvals.min() < 1e-6:
            C += (1e-6 - eigvals.min()) * np.eye(d)
            D = np.sqrt(np.diag(C))
            C = C / np.outer(D, D)
    
    return C


def generate_instance(n_samples=100, n_assets=5, seed=42,
                      epsilon=0.1, rho=0.1, alpha=0.05, varrho=0.5,
                      return_distribution='normal', correlation='medium',
                      mean_return_range=(0.0, 0.3),
                      volatility_range=(0.15, 0.50),
                      description=None):
    """
    生成分布鲁棒投资组合优化问题实例。

    参数:
        n_samples       : int     历史数据样本数
        n_assets        : int     资产数量
        seed            : int     随机种子
        epsilon         : float   平滑参数 (>0)
        rho             : float   Wasserstein 距离预算 (≥0)
        alpha           : float   CVaR 尾部概率 (0<α<1, 如 0.05 对应 95% CVaR)
        varrho          : float   CVaR 权重 (≥0)
        return_distribution : str 收益分布类型
            - 'normal':    多元正态
            - 't':         多元 t 分布 (df=5), 厚尾
            - 'skewed':    偏态 (对数正态变换)
            - 'mixture':   混合分布 (正常+危机)
            - 'uniform':   均匀分布
        correlation     : str     相关性结构
            - 'none', 'low', 'medium', 'high', 'block'
        mean_return_range : tuple 资产均值收益范围
        volatility_range  : tuple 资产波动率范围
        description     : str     实例描述

    返回:
        dict: 包含问题所有参数的字典
    """
    rng = np.random.default_rng(seed)

    # --- 生成资产参数 ---
    d = n_assets
    n = n_samples
    
    # 均值收益: 在给定范围内均匀分布
    mu = rng.uniform(mean_return_range[0], mean_return_range[1], d)
    # 按大小排序使其更自然
    mu.sort()
    
    # 波动率
    sigma = rng.uniform(volatility_range[0], volatility_range[1], d)
    
    # 相关系数矩阵
    corr_matrix = _build_correlation_matrix(d, correlation, rng)
    
    # 协方差矩阵
    cov_matrix = np.outer(sigma, sigma) * corr_matrix
    # 确保正定
    eigvals = np.linalg.eigvalsh(cov_matrix)
    if eigvals.min() < 1e-10:
        cov_matrix += (1e-10 - eigvals.min()) * np.eye(d)

    # --- 根据分布类型生成数据 ---
    if return_distribution == 'normal':
        data = rng.multivariate_normal(mu, cov_matrix, size=n)

    elif return_distribution == 't':
        # 多元 t 分布 (df=5): 厚尾
        df = 5
        normal_samples = rng.multivariate_normal(np.zeros(d), cov_matrix, size=n)
        chi2_samples = rng.chisquare(df, size=n)
        t_samples = normal_samples / np.sqrt(chi2_samples[:, None] / df)
        data = t_samples + mu

    elif return_distribution == 'skewed':
        # 偏态分布: 对数正态变换
        normal_samples = rng.multivariate_normal(np.zeros(d), cov_matrix, size=n)
        # 对数正态偏态 + 中心化
        skewed = np.exp(normal_samples * 0.5) - 1.0  # 轻度右偏
        data = skewed + mu

    elif return_distribution == 'mixture':
        # 混合分布: 80% 正常 + 20% 危机 (高波动率+负均值偏移)
        n_normal = int(0.8 * n)
        n_crisis = n - n_normal
        
        normal_data = rng.multivariate_normal(mu, cov_matrix, size=n_normal)
        
        crisis_mu = mu - 2 * sigma  # 危机期均值大幅下移
        crisis_cov = cov_matrix * 3.0  # 波动率放大
        crisis_data = rng.multivariate_normal(crisis_mu, crisis_cov, size=n_crisis)
        
        data = np.vstack([normal_data, crisis_data])
        # 随机打乱
        rng.shuffle(data)

    elif return_distribution == 'uniform':
        # 均匀分布 (每个资产独立)
        data = np.zeros((n, d))
        for j in range(d):
            lo = mu[j] - sigma[j] * np.sqrt(3)
            hi = mu[j] + sigma[j] * np.sqrt(3)
            data[:, j] = rng.uniform(lo, hi, n)

    else:
        raise ValueError(f"未知的分布类型: {return_distribution}")

    # --- 构建返回字典 ---
    if description is None:
        description = (
            f"n={n_samples}, d={n_assets}, ε={epsilon}, ρ={rho}, "
            f"α={alpha}, ϱ={varrho}, dist={return_distribution}, corr={correlation}"
        )

    return {
        'data': data,
        'n_samples': n,
        'n_assets': d,
        'epsilon': epsilon,
        'rho': rho,
        'alpha': alpha,
        'varrho': varrho,
        'return_distribution': return_distribution,
        'correlation': correlation,
        'description': description,
        # 生成参数（便于复现）
        'seed': seed,
        'mu': mu,
        'sigma': sigma,
    }


def save_instance_csv(instance, filepath):
    """将实例数据保存为 CSV 文件（与 data.csv 格式一致，无表头）。"""
    np.savetxt(filepath, instance['data'], delimiter=',', fmt='%.18e')
    return filepath


def load_original_data():
    """加载原始 data.csv 作为基准实例。"""
    data_path = BASE_DIR / "problem" / "data.csv"
    data = np.loadtxt(str(data_path), delimiter=',')
    return {
        'data': data,
        'n_samples': data.shape[0],
        'n_assets': data.shape[1],
        'epsilon': ORIGINAL_EPSILON,
        'rho': ORIGINAL_RHO,
        'alpha': ORIGINAL_ALPHA,
        'varrho': ORIGINAL_VARRHO,
        'return_distribution': 'original',
        'correlation': 'original',
        'description': '原始问题 (data.csv, n=100, d=10)',
        'seed': None,
        'mu': np.mean(data, axis=0),
        'sigma': np.std(data, axis=0),
    }


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例（约20个）：
    在固定规模 (n=100, d=10) 下变化 ε、ρ、α、varrho、分布类型、相关性。
    """
    cases = []
    base = dict(n_samples=100, n_assets=10, seed=42,
                return_distribution='normal', correlation='medium',
                mean_return_range=(0.0, 0.3), volatility_range=(0.15, 0.50))

    # --- 1. ε 变化 (平滑参数) ---
    for eps in [0.01, 0.05, 0.1, 0.5, 1.0, 2.0]:
        cases.append({**base, 'epsilon': eps, 'rho': 0.05, 'alpha': 0.05, 'varrho': 0.5,
                       'description': f'ε={eps}'})

    # --- 2. ρ 变化 (Wasserstein 半径) ---
    for rho in [0.01, 0.05, 0.1, 0.3, 0.5, 1.0]:
        if rho == 0.05:
            continue  # 已在 ε 变化中包含
        cases.append({**base, 'epsilon': 0.1, 'rho': rho, 'alpha': 0.05, 'varrho': 0.5,
                       'description': f'ρ={rho}'})

    # --- 3. α 变化 (CVaR 置信度) ---
    for alpha in [0.01, 0.05, 0.1, 0.2]:
        if alpha == 0.05:
            continue
        cases.append({**base, 'epsilon': 0.1, 'rho': 0.05, 'alpha': alpha, 'varrho': 0.5,
                       'description': f'α={alpha}'})

    # --- 4. varrho 变化 (CVaR 权重) ---
    for varrho in [0.0, 0.1, 0.5, 1.0, 2.0]:
        if varrho == 0.5:
            continue
        cases.append({**base, 'epsilon': 0.1, 'rho': 0.05, 'alpha': 0.05, 'varrho': varrho,
                       'description': f'ϱ={varrho}'})

    # --- 5. 分布类型变化 ---
    for dist in ['t', 'skewed', 'mixture', 'uniform']:
        cases.append({**base, 'epsilon': 0.1, 'rho': 0.05, 'alpha': 0.05, 'varrho': 0.5,
                       'return_distribution': dist,
                       'description': f'分布={dist}'})

    # --- 6. 相关性变化 ---
    for corr in ['none', 'low', 'high', 'block']:
        cases.append({**base, 'epsilon': 0.1, 'rho': 0.05, 'alpha': 0.05, 'varrho': 0.5,
                       'correlation': corr,
                       'description': f'相关性={corr}'})

    return cases


def get_scale_generalization_cases():
    """
    规模泛化测试用例（约6个）：
    变化 (n_samples, n_assets) 组合。
    """
    cases = []
    scale_combos = [
        (100, 5),    # 少资产
        (500, 5),    # 多样本少资产
        (1000, 5),   # 大样本少资产
        (100, 10),   # 原始规模
        (100, 20),   # 多资产
        (500, 10),   # 大样本原始资产数
    ]

    for n, d in scale_combos:
        cases.append({
            'n_samples': n, 'n_assets': d, 'seed': 42,
            'epsilon': 0.1, 'rho': 0.05, 'alpha': 0.05, 'varrho': 0.5,
            'return_distribution': 'normal', 'correlation': 'medium',
            'mean_return_range': (0.0, 0.3), 'volatility_range': (0.15, 0.50),
            'description': f'规模 (n={n}, d={d})',
        })

    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 验证工具
# ============================================================

def validate_instance(instance):
    """
    验证实例合法性。
    返回 (is_valid, messages)
    """
    messages = []
    data = instance['data']
    n, d = data.shape

    # 基本形状
    if n != instance['n_samples']:
        messages.append(f"✗ 样本数不匹配: data.shape[0]={n} vs n_samples={instance['n_samples']}")
    if d != instance['n_assets']:
        messages.append(f"✗ 资产数不匹配: data.shape[1]={d} vs n_assets={instance['n_assets']}")

    # 数值健康
    if np.any(np.isnan(data)):
        messages.append("✗ 数据包含 NaN")
    if np.any(np.isinf(data)):
        messages.append("✗ 数据包含 Inf")

    # 参数范围
    if instance['epsilon'] <= 0:
        messages.append(f"✗ epsilon 必须 > 0, 当前 = {instance['epsilon']}")
    if instance['rho'] < 0:
        messages.append(f"✗ rho 必须 ≥ 0, 当前 = {instance['rho']}")
    if not (0 < instance['alpha'] < 1):
        messages.append(f"✗ alpha 必须在 (0,1), 当前 = {instance['alpha']}")
    if instance['varrho'] < 0:
        messages.append(f"✗ varrho 必须 ≥ 0, 当前 = {instance['varrho']}")

    # 数据不应全为常数
    col_stds = np.std(data, axis=0)
    n_constant = np.sum(col_stds < 1e-10)
    if n_constant > 0:
        messages.append(f"⚠ {n_constant} 个资产方差接近 0")

    is_valid = all(not m.startswith("✗") for m in messages)
    if not messages:
        messages.append("✓ 实例合法")

    return is_valid, messages


def quick_solve_equal_weight(instance):
    """用等权重计算目标函数值，作为基准参考。"""
    data = instance['data']
    n, d = data.shape
    theta = np.ones(d) / d

    # 投资组合收益
    portfolio_returns = data @ theta
    losses = -portfolio_returns

    # 期望损失
    expected_loss = np.mean(losses)

    # CVaR
    alpha = instance['alpha']
    k = max(1, int(np.ceil(alpha * n)))
    sorted_losses = np.sort(losses)
    cvar = np.mean(sorted_losses[-k:])

    # 总目标 (近似)
    objective = expected_loss + instance['varrho'] * cvar

    return {
        'weights': theta,
        'expected_loss': expected_loss,
        'cvar': cvar,
        'objective': objective,
        'n_eff': d,  # 等权
    }


# ============================================================
# 主程序：验证生成器
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("量化（分布鲁棒投资组合优化）测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 加载原始数据 ------
    print("\n【1】原始问题数据")
    orig = load_original_data()
    print(f"  形状: {orig['data'].shape}")
    print(f"  均值范围: [{orig['mu'].min():.4f}, {orig['mu'].max():.4f}]")
    print(f"  波动率范围: [{orig['sigma'].min():.4f}, {orig['sigma'].max():.4f}]")
    baseline = quick_solve_equal_weight(orig)
    print(f"  等权基准目标值: {baseline['objective']:.6f}")

    # ------ 2. 默认参数生成 (n=100, d=10) ------
    print("\n【2】默认参数生成 (n=100, d=10, normal, medium)")
    inst = generate_instance(n_samples=100, n_assets=10, seed=42)
    valid, msgs = validate_instance(inst)
    for m in msgs:
        print(f"  {m}")
    base = quick_solve_equal_weight(inst)
    print(f"  等权基准目标值: {base['objective']:.6f}")
    print(f"  数据均值范围: [{inst['data'].mean(axis=0).min():.4f}, {inst['data'].mean(axis=0).max():.4f}]")

    # ------ 3. 各分布类型 ------
    print("\n【3】分布类型测试")
    for dist in ['normal', 't', 'skewed', 'mixture', 'uniform']:
        inst = generate_instance(n_samples=100, n_assets=10, seed=42,
                                  return_distribution=dist)
        valid, msgs = validate_instance(inst)
        base = quick_solve_equal_weight(inst)
        status = "✓" if valid else "✗"
        print(f"  {status} {dist:10s}: shape={inst['data'].shape}, "
              f"mean={inst['data'].mean():.4f}, std={inst['data'].std():.4f}, "
              f"obj={base['objective']:.4f}")

    # ------ 4. 各相关性结构 ------
    print("\n【4】相关性结构测试")
    for corr in ['none', 'low', 'medium', 'high', 'block']:
        inst = generate_instance(n_samples=100, n_assets=10, seed=42,
                                  correlation=corr)
        valid, _ = validate_instance(inst)
        C = np.corrcoef(inst['data'].T)
        off_diag = C[np.triu_indices(10, 1)]
        mean_abs_corr = np.mean(np.abs(off_diag))
        status = "✓" if valid else "✗"
        print(f"  {status} {corr:8s}: mean|r|={mean_abs_corr:.4f}")

    # ------ 5. 规模泛化 ------
    print("\n【5】规模泛化测试")
    for n, d in [(100, 5), (500, 5), (1000, 5), (100, 10), (100, 20), (500, 10)]:
        inst = generate_instance(n_samples=n, n_assets=d, seed=42)
        valid, _ = validate_instance(inst)
        base = quick_solve_equal_weight(inst)
        status = "✓" if valid else "✗"
        print(f"  {status} (n={n:4d}, d={d:2d}): shape={inst['data'].shape}, "
              f"obj={base['objective']:.4f}")

    # ------ 6. 测试用例统计 ------
    print("\n" + "=" * 70)
    print("【6】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    # ------ 7. 批量验证 ------
    print("\n" + "=" * 70)
    print("【7】批量验证（所有用例）")
    print("=" * 70)

    n_valid = 0
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        inst = generate_instance(**params)
        valid, msgs = validate_instance(inst)
        if valid:
            n_valid += 1
        else:
            print(f"  ✗ {c['description']}: {msgs}")

    print(f"  合法实例: {n_valid}/{len(all_cases)}")
    if n_valid == len(all_cases):
        print("  ✓ 所有测试用例均合法")

    # ------ 8. CSV 保存测试 ------
    print("\n【8】CSV 保存测试")
    test_inst = generate_instance(n_samples=50, n_assets=5, seed=123)
    test_path = str(BASE_DIR / "generated" / "test_instance.csv")
    os.makedirs(os.path.dirname(test_path), exist_ok=True)
    save_instance_csv(test_inst, test_path)
    # 读回验证
    loaded = np.loadtxt(test_path, delimiter=',')
    assert loaded.shape == (50, 5), f"形状不匹配: {loaded.shape}"
    assert np.allclose(loaded, test_inst['data']), "数据不一致"
    print(f"  ✓ CSV 保存/加载一致 ({test_path})")
    # 清理
    os.remove(test_path)
    os.rmdir(os.path.dirname(test_path))

    print("\n完成。")
