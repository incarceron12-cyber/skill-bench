# Reference — `task_10_quant_investment`

## Included

- `generate_instances.py`
- `reference_solver.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
