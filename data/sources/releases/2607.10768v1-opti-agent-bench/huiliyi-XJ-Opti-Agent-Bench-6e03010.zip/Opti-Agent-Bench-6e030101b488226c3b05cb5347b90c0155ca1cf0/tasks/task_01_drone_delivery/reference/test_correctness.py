"""
Comprehensive correctness audit for optimal_policy_dp.py
=========================================================
Tests cover:
 1. State transition correctness (step_common)
 2. Action legality edge cases
 3. TTL / timeout logic consistency between DP and simulation
 4. G() probability check
 5. Bellman consistency: V(s) == max_a Q(s,a)
 6. Simulation vs DP consistency (large episode count)
 7. Order timing consistency between DP and simulation
 8. Crash at b=0 consistency
 9. PICK/DROP/CHARGE time advancement
10. Edge case: no legal actions
"""

from __future__ import annotations
import sys, math, random, copy

# ---------------------------------------------------------------------------
# Import the module under test
# ---------------------------------------------------------------------------
sys.path.insert(0, "/Users/huiliyi/agent/测试题/mdp")
import optimal_policy_dp as mdp

passed = 0
failed = 0
findings = []

def check(condition: bool, name: str, detail: str = ""):
    global passed, failed
    if condition:
        passed += 1
        print(f"  [PASS] {name}")
    else:
        failed += 1
        msg = f"  [FAIL] {name}"
        if detail:
            msg += f" -- {detail}"
        print(msg)
        findings.append((name, detail))

# ---------------------------------------------------------------------------
# Helper: convert (i,j) grid coords to index
# ---------------------------------------------------------------------------
def idx(i, j):
    return mdp.ALL_POS.index((i, j))

# ===================================================================
print("=" * 72)
print("TEST 1: State transition correctness (step_common)")
print("=" * 72)

# 1a. Move RIGHT from (1,1) with b=50
t, pos, b = 0, idx(1, 1), 50
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "R")
check(nt == 1, "1a: time advances by 1")
check(np_ == idx(1, 2), "1a: position moves right (1,1)->(1,2)")
check(nb == 45, "1a: battery decreases by MOVE_B=5 (50->45)")
check(r == -5, "1a: reward is -MOVE_COST=-5")
check(done == False, "1a: not crashed")

# 1b. Move UP from (4,1) -- should be None, which means it's an illegal
# action. But step_common doesn't check legality; it would set pos=None.
# The action filter should prevent this.
# We test that MOVE_NEXT returns None for boundary.
check(mdp.MOVE_NEXT[(idx(4, 1), "U")] is None, "1b: UP from row 4 is None (boundary)")
check(mdp.MOVE_NEXT[(idx(1, 1), "D")] is None, "1b: DOWN from row 1 is None (boundary)")
check(mdp.MOVE_NEXT[(idx(1, 1), "L")] is None, "1b: LEFT from col 1 is None (boundary)")
check(mdp.MOVE_NEXT[(idx(1, 4), "R")] is None, "1b: RIGHT from col 4 is None (boundary)")

# 1c. WAIT with b=10
t, pos, b = 5, idx(2, 3), 10
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "W")
check(nt == 6, "1c: time advances by 1")
check(np_ == idx(2, 3), "1c: position unchanged on WAIT")
check(nb == 9, "1c: battery decreases by WAIT_B=1 (10->9)")
check(r == -1, "1c: reward is -WAIT_COST=-1")
check(done == False, "1c: not crashed")

# 1d. WAIT with b=1 -> b becomes 0 -> crash
t, pos, b = 5, idx(2, 3), 1
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "W")
check(nb == 0, "1d: battery goes to 0")
check(done == True, "1d: crash happens when b<=0")
check(r == -1 - 200, "1d: reward = -WAIT_COST - CRASH_COST = -201")

# 1e. CHARGE at base with b=45
t, pos, b = 3, idx(1, 1), 45
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "CHARGE")
check(nt == 4, "1e: time advances by 1")
check(np_ == idx(1, 1), "1e: position unchanged on CHARGE")
check(nb == 50, "1e: battery charges to min(50, 45+10)=50 (capped at MAX_B)")
check(r == 0, "1e: CHARGE reward is 0")
check(done == False, "1e: not crashed")

# 1f. CHARGE at base with b=42 (should go to 50, capped)
t, pos, b = 3, idx(1, 1), 42
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "CHARGE")
check(nb == 50, "1f: battery capped at MAX_B=50 (42+10=52 -> 50)")

# 1g. Move with exactly MOVE_B=5 battery -> b becomes 0 -> crash
t, pos, b = 10, idx(2, 2), 5
nt, np_, nb, r, done = mdp.step_common(t, pos, b, "U")
check(nb == 0, "1g: battery goes to 0 after move")
check(done == True, "1g: crash (b<=0)")
check(r == -5 - 200, "1g: reward = -MOVE_COST - CRASH_COST = -205")


# ===================================================================
print()
print("=" * 72)
print("TEST 2: Action legality edge cases")
print("=" * 72)

# 2a. Corner (1,1): can only go U, R (not D, L)
acts = mdp.no_order_actions(idx(1, 1), 50)
check("U" in acts, "2a: (1,1) b=50: U available")
check("R" in acts, "2a: (1,1) b=50: R available")
check("D" not in acts, "2a: (1,1) b=50: D not available (boundary)")
check("L" not in acts, "2a: (1,1) b=50: L not available (boundary)")
check("W" in acts, "2a: (1,1) b=50: W available")
# At base with b=50 (MAX_B), CHARGE should NOT be available
check("CHARGE" not in acts, "2a: (1,1) b=MAX_B=50: CHARGE not available (full)")

# 2b. Corner (4,4): can only go D, L
acts = mdp.no_order_actions(idx(4, 4), 50)
check("U" not in acts, "2b: (4,4) b=50: U not available")
check("D" in acts, "2b: (4,4) b=50: D available")
check("L" in acts, "2b: (4,4) b=50: L available")
check("R" not in acts, "2b: (4,4) b=50: R not available")
check("CHARGE" not in acts, "2b: (4,4) not at base: CHARGE not available")

# 2c. Battery exactly at MOVE_B threshold (b=5)
acts = mdp.no_order_actions(idx(2, 2), 5)
check("U" in acts, "2c: b=5 >= MOVE_B=5: move actions available")
check("W" in acts, "2c: b=5 >= WAIT_B=1: W available")

# 2d. Battery below MOVE_B but above WAIT_B (b=4)
acts = mdp.no_order_actions(idx(2, 2), 4)
check("U" not in acts, "2d: b=4 < MOVE_B=5: move actions NOT available")
check("W" in acts, "2d: b=4 >= WAIT_B=1: W available")

# 2e. Battery exactly at WAIT_B threshold (b=1)
acts = mdp.no_order_actions(idx(2, 2), 1)
check("U" not in acts, "2e: b=1 < MOVE_B=5: move actions NOT available")
check("W" in acts, "2e: b=1 >= WAIT_B=1: W available")

# 2f. Battery at 0 -> NO actions at all (b=0)
acts = mdp.no_order_actions(idx(2, 2), 0)
check(len(acts) == 0, "2f: b=0: no actions available", f"got {acts}")

# 2g. At base with b < MAX_B -> CHARGE should be available
acts = mdp.no_order_actions(idx(1, 1), 49)
check("CHARGE" in acts, "2g: (1,1) b=49 < MAX_B=50: CHARGE available")

# 2h. PICK: at pickup, not carrying
pickup_idx = idx(2, 3)
dropoff_idx = idx(3, 4)
acts = mdp.order_actions(pickup_idx, 30, pickup_idx, dropoff_idx, 0)
check("PICK" in acts, "2h: at pickup, not carrying -> PICK available")

# 2i. PICK: NOT at pickup
acts = mdp.order_actions(idx(1, 1), 30, pickup_idx, dropoff_idx, 0)
check("PICK" not in acts, "2i: not at pickup -> PICK not available")

# 2j. PICK: at pickup but carrying
acts = mdp.order_actions(pickup_idx, 30, pickup_idx, dropoff_idx, 1)
check("PICK" not in acts, "2j: carrying -> PICK not available")

# 2k. DROP: at dropoff, carrying
acts = mdp.order_actions(dropoff_idx, 30, None, dropoff_idx, 1)
check("DROP" in acts, "2k: at dropoff, carrying -> DROP available")

# 2l. DROP: not at dropoff
acts = mdp.order_actions(idx(1, 1), 30, None, dropoff_idx, 1)
check("DROP" not in acts, "2l: not at dropoff -> DROP not available")

# 2m. DROP: at dropoff but not carrying
acts = mdp.order_actions(dropoff_idx, 30, pickup_idx, dropoff_idx, 0)
check("DROP" not in acts, "2m: not carrying -> DROP not available")

# 2n. Edge position (1,2): D not available but L, R, U available
acts = mdp.no_order_actions(idx(1, 2), 50)
check("D" not in acts, "2n: (1,2) b=50: D not available (row 1 boundary)")
check("U" in acts, "2n: (1,2) b=50: U available")
check("L" in acts, "2n: (1,2) b=50: L available")
check("R" in acts, "2n: (1,2) b=50: R available")


# ===================================================================
print()
print("=" * 72)
print("TEST 3: TTL/timeout logic consistency")
print("=" * 72)

# 3a. In W(): when ttl=1 and action is PICK, ttl-1=0 -> timeout
# W should apply TIMEOUT_COST penalty and transition to G (no order)
pickup_p = idx(3, 3)
dropoff_p = idx(4, 4)
# Manually compute what W does for PICK when ttl=1
# val = 0 - TIMEOUT_COST + G(t+1, pos, b)  (if t+1 < T)
t_test = 10
pos_test = pickup_p
b_test = 30
expected_pick_val = 0 - mdp.TIMEOUT_COST + mdp.G(t_test + 1, pos_test, b_test)
actual_pick_val = mdp.q_waiting(t_test, pos_test, b_test, pickup_p, dropoff_p, 1, "PICK")
check(abs(expected_pick_val - actual_pick_val) < 1e-9,
      "3a: W() PICK with ttl=1 -> timeout penalty + G()",
      f"expected={expected_pick_val}, got={actual_pick_val}")

# 3b. In W(): when ttl=1 and action is a MOVE, ttl-1=0 -> timeout
# val = r + (-TIMEOUT_COST) + G(nt, np, nb)  (if not done and nt < T)
act_test = "U"
nt_, np_t, nb_t, r_t, done_t = mdp.step_common(t_test, pos_test, b_test, act_test)
if not done_t and nt_ < mdp.T:
    expected_move_val = r_t - mdp.TIMEOUT_COST + mdp.G(nt_, np_t, nb_t)
    actual_move_val = mdp.q_waiting(t_test, pos_test, b_test, pickup_p, dropoff_p, 1, act_test)
    check(abs(expected_move_val - actual_move_val) < 1e-9,
          "3b: W() MOVE with ttl=1 -> timeout penalty + G()",
          f"expected={expected_move_val}, got={actual_move_val}")

# 3c. Verify simulation handles ttl=1 PICK correctly
# We construct a scenario: drone at pickup, ttl=1, not carrying, does PICK
# After PICK: t+=1, ttl=0, carrying=1, but then ttl<=0 -> timeout
# In sim: after PICK with ttl=1: ttl becomes 0, carrying=1, then ttl<=0
# -> reward -= TIMEOUT_COST, state resets to no order
# This matches DP: ttl-1=0 -> penalty - TIMEOUT_COST + G(...)
# The key question: in the simulation, PICK with ttl=1:
#   t += 1; ttl -= 1 -> ttl=0; carrying = 1
#   if ttl <= 0: reward -= TIMEOUT_COST; reset to no order
# In the DP:
#   nt = t+1, ttl-1 = 0 <= 0: val = 0 - TIMEOUT_COST + G(nt, pos, b)
# These are consistent: both apply -20 penalty and go to no-order state.
check(True, "3c: PICK with ttl=1 consistent in DP and sim (verified by code inspection)")

# 3d. After timeout, 'no order' state restores correctly
# In sim: pickup=dropoff=None, ttl=0, carrying=0 -> next iteration generates order fresh
# In DP: transitions to G() which is the 'no order at start of period' value
check(True, "3d: After timeout, state resets to no-order (verified by code inspection)")

# 3e. In C(): when ttl=1 and action is a MOVE (not DROP), ttl-1=0 -> timeout
pos_carry = idx(2, 2)
dropoff_carry = idx(4, 4)
t_c = 10
b_c = 30
act_c = "R"
nt_c, np_c, nb_c, r_c, done_c = mdp.step_common(t_c, pos_carry, b_c, act_c)
if not done_c and nt_c < mdp.T:
    expected_c = r_c - mdp.TIMEOUT_COST + mdp.G(nt_c, np_c, nb_c)
    actual_c = mdp.q_carrying(t_c, pos_carry, b_c, dropoff_carry, 1, act_c)
    check(abs(expected_c - actual_c) < 1e-9,
          "3e: C() MOVE with ttl=1 -> timeout penalty + G()",
          f"expected={expected_c}, got={actual_c}")


# ===================================================================
print()
print("=" * 72)
print("TEST 4: G() probability check")
print("=" * 72)

# G(t, pos, b) = 0.8 * N(t, pos, b) + sum_{p in NON_BASE, d != p} ORDER_PAIR_PROB * W(...)
# The total probability should be:
#   0.8 + sum_{p in NON_BASE, d != p} ORDER_PAIR_PROB
# = 0.8 + 15 * 15 * (0.2 / 225)
# = 0.8 + 225 * 0.2 / 225
# = 0.8 + 0.2
# = 1.0

num_order_pairs = 0
for p in mdp.NON_BASE_IDX:
    for d in range(len(mdp.ALL_POS)):
        if d != p:
            num_order_pairs += 1

prob_sum = 0.8 + num_order_pairs * mdp.ORDER_PAIR_PROB
check(abs(prob_sum - 1.0) < 1e-12,
      "4a: Probabilities in G() sum to 1.0",
      f"0.8 + {num_order_pairs} * {mdp.ORDER_PAIR_PROB} = {prob_sum}")

# 4b. Verify number of order pairs: 15 pickup * 15 dropoff = 225
check(num_order_pairs == 225,
      "4b: Number of (pickup, dropoff) pairs is 225 (15 * 15)",
      f"got {num_order_pairs}")

# 4c. Verify ORDER_PAIR_PROB
check(abs(mdp.ORDER_PAIR_PROB - 0.2 / 225.0) < 1e-15,
      "4c: ORDER_PAIR_PROB = 0.2/225",
      f"got {mdp.ORDER_PAIR_PROB}")

# 4d. NON_BASE has 15 elements
check(len(mdp.NON_BASE_IDX) == 15,
      "4d: NON_BASE_IDX has 15 elements (all positions except base)",
      f"got {len(mdp.NON_BASE_IDX)}")

# 4e. Critically: the problem says dropoff is chosen from 15 sites
# EXCLUDING the pickup. That means for a given pickup p, there are 15
# possible dropoffs (16 total positions - 1 = 15, excluding p).
# In the code, d iterates over range(16) excluding d==p -> 15 values.
# This is correct.
for p_test in mdp.NON_BASE_IDX[:3]:
    count = sum(1 for d in range(len(mdp.ALL_POS)) if d != p_test)
    check(count == 15,
          f"4e: For pickup={p_test}, there are 15 valid dropoffs",
          f"got {count}")


# ===================================================================
print()
print("=" * 72)
print("TEST 5: Bellman consistency -- V(s) = max_a Q(s,a)")
print("=" * 72)

# 5a. No-order state: N(t, pos, b) should equal max over q_no_order
test_states_no_order = [
    (0, idx(1, 1), 50),
    (5, idx(2, 3), 20),
    (10, idx(3, 3), 10),
    (15, idx(4, 4), 30),
    (19, idx(1, 1), 5),
]
for t_s, pos_s, b_s in test_states_no_order:
    n_val = mdp.N(t_s, pos_s, b_s)
    acts = mdp.no_order_actions(pos_s, b_s)
    if acts:
        q_vals = {a: mdp.q_no_order(t_s, pos_s, b_s, a) for a in acts}
        max_q = max(q_vals.values())
        check(abs(n_val - max_q) < 1e-9,
              f"5a: N({t_s},{pos_s},{b_s}) == max_a Q = {max_q:.6f}",
              f"N={n_val:.6f}, max_q={max_q:.6f}, q_vals={q_vals}")

# 5b. Waiting state: W(t, pos, b, pickup, dropoff, ttl) == max_a q_waiting
test_states_waiting = [
    (5, idx(2, 2), 30, idx(3, 3), idx(4, 4), 5),
    (10, idx(3, 3), 20, idx(3, 3), idx(1, 1), 3),  # at pickup
    (0, idx(1, 1), 50, idx(2, 2), idx(4, 4), 8),
]
for t_s, pos_s, b_s, p_s, d_s, ttl_s in test_states_waiting:
    w_val = mdp.W(t_s, pos_s, b_s, p_s, d_s, ttl_s)
    acts = mdp.order_actions(pos_s, b_s, p_s, d_s, 0)
    if acts:
        q_vals = {a: mdp.q_waiting(t_s, pos_s, b_s, p_s, d_s, ttl_s, a) for a in acts}
        max_q = max(q_vals.values())
        check(abs(w_val - max_q) < 1e-9,
              f"5b: W({t_s},{pos_s},{b_s},{p_s},{d_s},{ttl_s}) == max_a Q = {max_q:.6f}",
              f"W={w_val:.6f}, max_q={max_q:.6f}")

# 5c. Carrying state: C(t, pos, b, dropoff, ttl) == max_a q_carrying
test_states_carrying = [
    (5, idx(2, 2), 30, idx(4, 4), 5),
    (10, idx(4, 4), 20, idx(4, 4), 3),  # at dropoff
    (0, idx(1, 1), 50, idx(3, 3), 8),
]
for t_s, pos_s, b_s, d_s, ttl_s in test_states_carrying:
    c_val = mdp.C(t_s, pos_s, b_s, d_s, ttl_s)
    acts = mdp.order_actions(pos_s, b_s, None, d_s, 1)
    if acts:
        q_vals = {a: mdp.q_carrying(t_s, pos_s, b_s, d_s, ttl_s, a) for a in acts}
        max_q = max(q_vals.values())
        check(abs(c_val - max_q) < 1e-9,
              f"5c: C({t_s},{pos_s},{b_s},{d_s},{ttl_s}) == max_a Q = {max_q:.6f}",
              f"C={c_val:.6f}, max_q={max_q:.6f}")


# ===================================================================
print()
print("=" * 72)
print("TEST 6: Simulation vs DP consistency")
print("=" * 72)

# First verify the DP value
dp_value = mdp.G(0, mdp.BASE_IDX, mdp.MAX_B)
check(abs(dp_value - 6.289852) < 0.001,
      f"6a: G(0, BASE, MAX_B) = {dp_value:.6f}, expected ~6.289852",
      f"got {dp_value:.6f}")

# Run simulation with large number of episodes
print("  Running simulation with 10000 episodes (this may take a moment)...")
sim_value = mdp.simulate_optimal(episodes=10000, seed=42)
print(f"  Simulation mean (10000 eps, seed=42): {sim_value:.4f}")
check(abs(sim_value - dp_value) < 3.0,
      f"6b: Simulation mean {sim_value:.4f} within 3.0 of DP value {dp_value:.4f}",
      f"difference = {abs(sim_value - dp_value):.4f}")

# Also run with multiple seeds and check average
print("  Running simulation across multiple seeds...")
multi_seed_results = []
for seed in range(10):
    val = mdp.simulate_optimal(episodes=2000, seed=seed * 1000)
    multi_seed_results.append(val)
grand_mean = sum(multi_seed_results) / len(multi_seed_results)
print(f"  Grand mean across 10 seeds (2000 eps each): {grand_mean:.4f}")
check(abs(grand_mean - dp_value) < 2.0,
      f"6c: Grand mean {grand_mean:.4f} within 2.0 of DP value {dp_value:.4f}",
      f"difference = {abs(grand_mean - dp_value):.4f}")


# ===================================================================
print()
print("=" * 72)
print("TEST 7: Order timing consistency (DP vs simulation)")
print("=" * 72)

# The key question: when a drone has no order, does the new order appear at
# the START of the current time step or at the start of the NEXT time step?
#
# In the DP:
#   G(t, pos, b) is called when we enter time step t with no order.
#   G immediately branches: with prob 0.8, no order -> N(t, pos, b);
#   with prob 0.2, an order appears -> W(t, pos, b, p, d, TTL).
#   In both N and W, the drone then takes an action at time t and
#   transitions to t+1.
#   So: the order appears at the START of time step t, and the action
#   at time t already accounts for the (possibly new) order.
#
# In the simulation:
#   At the top of each loop iteration for time step t, if no order,
#   the code draws whether an order appears. Then it picks an action.
#   So: the order appears at the START of time step t, same as DP.
#
# When we just delivered (DROP at time t): the sim sets pickup=dropoff=None,
# ttl=0, carrying=0, and t has already been incremented to t+1.
# Next loop iteration: at time t+1, it checks for a new order. This is
# correct -- the new order appears at the start of the NEXT time step.
#
# In the DP: DROP transitions to G(t+1, pos, b), which checks for a new
# order at time t+1. Also correct and consistent.

check(True, "7a: Order generation timing is consistent between DP and sim "
     "(both generate at START of time step, verified by code inspection)")

# 7b. Verify: after delivery, new order cannot appear in the SAME time step
# In DP: DROP at time t -> G(t+1, ...) -> order check is at t+1. Correct.
# In sim: DROP at time t -> t+=1, state reset, loop continues at t+1. Correct.
check(True, "7b: After delivery, new order appears at t+1 (not same step), "
     "consistent in DP and sim")

# 7c. After timeout, same logic applies
# In DP: timeout in W/C -> G(nt, ...) where nt = t+1. Order check at t+1.
# In sim: timeout -> state reset, loop continues with incremented t.
check(True, "7c: After timeout, new order at next time step, consistent")

# 7d. Verify simulation order generation probability distribution matches DP
# In sim: pickup from NON_BASE_IDX (15 elements, uniform)
# In DP: G sums over NON_BASE_IDX for pickup
check(len(mdp.NON_BASE_IDX) == 15,
      "7d: Pickup drawn from 15 non-base positions (consistent)")

# 7e. In sim: dropoff from all positions except pickup (15 choices)
# In DP: d in range(16), d != p -> 15 choices. Both are 15. Consistent.
# However, note: in the PROBLEM DESCRIPTION, it says "from the other 15 sites
# excluding pickup". There are 16 total positions, so excluding pickup gives 15.
# The DP iterates d in range(16) with d!=p. The sim does the same.
# But wait: the problem says "from the OTHER 15 sites" -- could this include base?
# Yes, the base CAN be a dropoff. The problem says pickup is from 15 non-base
# sites, but dropoff is from the other 15 sites (which could include base).
# Both DP and sim allow base as dropoff. Consistent with problem statement.
check(True, "7e: Dropoff can include base, consistent with problem statement "
     "and code")


# ===================================================================
print()
print("=" * 72)
print("TEST 8: Crash at b=0 consistency")
print("=" * 72)

# 8a. WAIT with b=1: b becomes 0, crash in step_common
t8, pos8, b8 = 5, idx(2, 2), 1
nt8, np8, nb8, r8, done8 = mdp.step_common(t8, pos8, b8, "W")
check(nb8 == 0 and done8 == True, "8a: step_common: WAIT b=1 -> crash")
check(r8 == -1 - 200, "8a: reward = -WAIT_COST - CRASH_COST = -201")

# 8b. In DP (N function): b=1, only action is W, should account for crash
n_val_crash = mdp.N(5, idx(2, 2), 1)
# The only legal action with b=1 is W (b < MOVE_B, so no moves)
acts_b1 = mdp.no_order_actions(idx(2, 2), 1)
check(acts_b1 == ["W"], "8b: b=1 at non-base: only W is legal", f"got {acts_b1}")
# q_no_order for W with b=1: step_common gives crash, r = -201, done=True
# So val = r = -201
expected_crash = -201.0
check(abs(n_val_crash - expected_crash) < 1e-9,
      f"8b: N(5, (2,2), 1) = {n_val_crash}, expected {expected_crash} (crash)",
      f"got {n_val_crash}")

# 8c. In simulation: b=1 -> WAIT -> b=0 -> loop exits (b > 0 check fails)
# In the sim loop: while t < T and b > 0
# After step_common with b=1 WAIT: b=0, so loop exits. Correct.
check(True, "8c: Sim loop exits when b<=0 after step_common (verified by inspection)")

# 8d. b=0 base case in DP: G/N/W/C all return 0.0
check(mdp.G(0, idx(1, 1), 0) == 0.0, "8d: G(0, base, 0) = 0.0")
check(mdp.N(0, idx(1, 1), 0) == 0.0, "8d: N(0, base, 0) = 0.0")
check(mdp.W(0, idx(1, 1), 0, idx(2, 2), idx(3, 3), 5) == 0.0, "8d: W(0, base, 0, ...) = 0.0")
check(mdp.C(0, idx(1, 1), 0, idx(3, 3), 5) == 0.0, "8d: C(0, base, 0, ...) = 0.0")


# ===================================================================
print()
print("=" * 72)
print("TEST 9: PICK/DROP/CHARGE time advancement")
print("=" * 72)

# 9a. CHARGE: step_common advances time by 1
t9, pos9, b9 = 5, idx(1, 1), 40
nt9, _, _, _, _ = mdp.step_common(t9, pos9, b9, "CHARGE")
check(nt9 == t9 + 1, "9a: CHARGE advances time by 1 (step_common)")

# 9b. PICK in W(): manually check nt = t + 1
# In W() line 94: nt, np, nb, r, done = t + 1, pos, b, 0, False
# In q_waiting line 139: nt, np, nb, r = t + 1, pos, b, 0
check(True, "9b: PICK in W()/q_waiting: t+1 (verified by code inspection lines 94, 139)")

# 9c. DROP in C(): manually check nt = t + 1
# In C() line 118: nt, np, nb, r, done = t + 1, pos, b, DELIVER_REWARD, False
# In q_carrying line 153: nt, np, nb, r = t + 1, pos, b, DELIVER_REWARD
check(True, "9c: DROP in C()/q_carrying: t+1 (verified by code inspection lines 118, 153)")

# 9d. PICK in simulate_optimal: t += 1 (line 192/325)
check(True, "9d: PICK in simulate_optimal: t += 1 (verified at line 192/325)")

# 9e. DROP in simulate_optimal: t += 1 (line 197/329)
check(True, "9e: DROP in simulate_optimal: t += 1 (verified at line 197/329)")

# 9f. Verify PICK does NOT consume battery
# In W(): PICK sets nb = b (no change). In sim: no battery change for PICK.
# Let's verify via q_waiting:
t9f = 5
pos9f = idx(3, 3)
b9f = 20
pickup9f = idx(3, 3)
dropoff9f = idx(4, 4)
ttl9f = 5
pick_q = mdp.q_waiting(t9f, pos9f, b9f, pickup9f, dropoff9f, ttl9f, "PICK")
# After PICK: t=6, pos=pos9f, b=20 (unchanged), ttl=4
# val = 0 + C(6, pos9f, 20, dropoff9f, 4)
expected_pick_q = mdp.C(t9f + 1, pos9f, b9f, dropoff9f, ttl9f - 1)
check(abs(pick_q - expected_pick_q) < 1e-9,
      "9f: PICK does not consume battery (b unchanged)",
      f"q_waiting PICK = {pick_q}, expected C(t+1,...) = {expected_pick_q}")

# 9g. Verify DROP does NOT consume battery
t9g = 5
pos9g = idx(4, 4)
b9g = 20
dropoff9g = idx(4, 4)
ttl9g = 3
drop_q = mdp.q_carrying(t9g, pos9g, b9g, dropoff9g, ttl9g, "DROP")
# After DROP: t=6, pos=pos9g, b=20, reward=50
# val = 50 + G(6, pos9g, 20)
expected_drop_q = mdp.DELIVER_REWARD + mdp.G(t9g + 1, pos9g, b9g)
check(abs(drop_q - expected_drop_q) < 1e-9,
      "9g: DROP does not consume battery, gives +50 reward",
      f"q_carrying DROP = {drop_q}, expected 50+G(t+1,...) = {expected_drop_q}")

# 9h. Verify CHARGE does NOT consume battery (only adds)
t9h = 5
pos9h = idx(1, 1)
b9h = 30
nt9h, np9h, nb9h, r9h, done9h = mdp.step_common(t9h, pos9h, b9h, "CHARGE")
check(nb9h == 40, "9h: CHARGE adds CHARGE_B=10 (30->40), does not subtract")
check(r9h == 0, "9h: CHARGE reward is 0")

# 9i. Verify all actions advance time by exactly 1 in DP
# For moves/wait/charge: step_common returns t+1
# For PICK/DROP: inline t+1
# Test: compare q functions at t=19 (last time step)
# At t=19: nt = 20 >= T, so terminal
t19_acts = mdp.no_order_actions(idx(2, 2), 30)
for a in t19_acts:
    nt_19, _, _, _, _ = mdp.step_common(19, idx(2, 2), 30, a)
    check(nt_19 == 20, f"9i: action '{a}' at t=19 advances to t=20 (terminal)")


# ===================================================================
print()
print("=" * 72)
print("TEST 10: Edge case -- no legal actions")
print("=" * 72)

# 10a. b=0: all functions return 0.0 immediately (base case), never call
# no_order_actions or order_actions with b=0.
check(mdp.N(0, idx(2, 2), 0) == 0.0,
      "10a: N returns 0 when b=0 (base case, no action enumeration)")

# 10b. Check: is there any state with b > 0 but empty actions?
# no_order_actions: if b >= 1 (WAIT_B), W is always available.
# So for b >= 1, there's always at least W.
# For b > 0 but b < WAIT_B: WAIT_B = 1, so b > 0 means b >= 1 means W is available.
# (b is integer, b > 0 => b >= 1 >= WAIT_B)
# But wait: the base case is b <= 0, not b < WAIT_B.
# If b = 0.5 (non-integer)? In this code, b is always integer (units of 2%).
# So b > 0 implies b >= 1, and WAIT_B = 1, so W is always available.

# However, let's also check: at base with b = MAX_B = 50:
# CHARGE requires b < MAX_B, so CHARGE not available. But W is still available.
acts_full_base = mdp.no_order_actions(idx(1, 1), 50)
check(len(acts_full_base) > 0,
      "10b: At base with b=MAX_B: still have actions (W, moves)",
      f"acts = {acts_full_base}")

# 10c. Check all positions with various battery levels: always have actions if b>=1
all_ok = True
for pos_idx in range(16):
    for b_val in range(1, 51):
        acts = mdp.no_order_actions(pos_idx, b_val)
        if len(acts) == 0:
            all_ok = False
            print(f"  WARNING: no_order_actions({pos_idx}, {b_val}) is empty!")
check(all_ok, "10c: For all (pos, b) with b>=1, at least one action exists")

# 10d. With order: order_actions includes all of no_order_actions plus possibly
# PICK/DROP. So if b >= 1, order_actions is never empty.
# But let's verify for a couple of cases.
acts_order = mdp.order_actions(idx(2, 2), 1, idx(3, 3), idx(4, 4), 0)
check(len(acts_order) > 0, "10d: order_actions with b=1 has at least W")

# 10e. max() on empty sequence would raise ValueError.
# This should never happen since b > 0 in the recursion implies b >= 1.
# But let's verify the DP base case catches b <= 0 before calling action functions.
# G, N, W, C all check 'if t >= T or b <= 0: return 0.0' at the top.
check(True, "10e: All DP functions have b<=0 base case before action enumeration")


# ===================================================================
print()
print("=" * 72)
print("ADDITIONAL CHECKS")
print("=" * 72)

# A1. Verify initial state value
dp_init = mdp.G(0, mdp.BASE_IDX, mdp.MAX_B)
check(abs(dp_init - 6.289852) < 0.001,
      f"A1: Initial state value G(0, base, 50) = {dp_init:.6f} matches expected 6.289852")

# A2. Terminal time: all values should be 0
check(mdp.G(20, idx(1, 1), 50) == 0.0, "A2: G(t=20, ...) = 0 (terminal)")
check(mdp.N(20, idx(1, 1), 50) == 0.0, "A2: N(t=20, ...) = 0 (terminal)")
check(mdp.W(20, idx(1, 1), 50, idx(2, 2), idx(3, 3), 5) == 0.0, "A2: W(t=20, ...) = 0")
check(mdp.C(20, idx(1, 1), 50, idx(3, 3), 5) == 0.0, "A2: C(t=20, ...) = 0")

# A3. At t=19 with an order: one step left, verify behavior
# If at pickup with order, ttl=1: PICK would timeout immediately
# The Q value for PICK = 0 - 20 + G(20, ...) = -20 + 0 = -20
pick_at_19 = mdp.q_waiting(19, idx(3, 3), 30, idx(3, 3), idx(4, 4), 1, "PICK")
check(abs(pick_at_19 - (-20.0)) < 1e-9,
      f"A3: PICK at t=19, ttl=1 -> timeout penalty -20 (got {pick_at_19})")

# A4. At t=19 at dropoff, carrying: DROP gives +50
drop_at_19 = mdp.q_carrying(19, idx(4, 4), 30, idx(4, 4), 3, "DROP")
check(abs(drop_at_19 - 50.0) < 1e-9,
      f"A4: DROP at t=19 -> reward +50 (got {drop_at_19})")

# A5. Verify W and q_waiting consistency for regular moves (not just edge cases)
t_a5 = 5
pos_a5 = idx(2, 2)
b_a5 = 25
pickup_a5 = idx(3, 3)
dropoff_a5 = idx(4, 4)
ttl_a5 = 6
w_val_a5 = mdp.W(t_a5, pos_a5, b_a5, pickup_a5, dropoff_a5, ttl_a5)
acts_a5 = mdp.order_actions(pos_a5, b_a5, pickup_a5, dropoff_a5, 0)
q_vals_a5 = {a: mdp.q_waiting(t_a5, pos_a5, b_a5, pickup_a5, dropoff_a5, ttl_a5, a) for a in acts_a5}
max_q_a5 = max(q_vals_a5.values())
check(abs(w_val_a5 - max_q_a5) < 1e-9,
      f"A5: W({t_a5},{pos_a5},{b_a5},{pickup_a5},{dropoff_a5},{ttl_a5}) = {w_val_a5:.6f} == max Q = {max_q_a5:.6f}")

# A6. Verify G decomposes correctly: G = 0.8*N + sum(PAIR_PROB * W)
t_a6 = 5
pos_a6 = idx(2, 2)
b_a6 = 25
g_val = mdp.G(t_a6, pos_a6, b_a6)
n_part = 0.8 * mdp.N(t_a6, pos_a6, b_a6)
w_part = 0.0
for p in mdp.NON_BASE_IDX:
    for d in range(len(mdp.ALL_POS)):
        if d != p:
            w_part += mdp.ORDER_PAIR_PROB * mdp.W(t_a6, pos_a6, b_a6, p, d, mdp.TTL)
recomputed = n_part + w_part
check(abs(g_val - recomputed) < 1e-9,
      f"A6: G decomposition: G={g_val:.6f}, 0.8*N+sum(W)={recomputed:.6f}")

# A7. CHARGE cannot be done when not at base
# This is enforced by no_order_actions: pos == BASE_IDX required
for pos_test in range(16):
    if pos_test != mdp.BASE_IDX:
        acts = mdp.no_order_actions(pos_test, 30)
        check("CHARGE" not in acts,
              f"A7: CHARGE not available at position {pos_test} (not base)")

# A8. Verify simulation TTL decrement for non-PICK/DROP actions with order
# In simulate_optimal, the else branch (line 200-206) does:
#   step_common, then ttl -= 1
# In W() (line 106): W(nt, np, nb, pickup, dropoff, ttl - 1)
# In C() (line 127): C(nt, np, nb, dropoff, ttl - 1)
# Both decrement ttl by 1. Consistent.
check(True, "A8: TTL decrement for moves in order states: sim and DP both decrement by 1")

# A9. Verify q_waiting and q_carrying handle crash (done=True) the same as W/C
# When step_common returns done=True, q functions return just r (which includes crash).
# W/C also return just r when done=True. Consistent.
t_a9 = 5
pos_a9 = idx(2, 2)
b_a9 = 5  # will crash on move
pickup_a9 = idx(3, 3)
dropoff_a9 = idx(4, 4)
ttl_a9 = 5
# Move up: b goes from 5 to 0, crash
q_w_crash = mdp.q_waiting(t_a9, pos_a9, b_a9, pickup_a9, dropoff_a9, ttl_a9, "U")
nt_a9, np_a9, nb_a9, r_a9, done_a9 = mdp.step_common(t_a9, pos_a9, b_a9, "U")
check(done_a9 == True, "A9: move with b=5 causes crash")
check(abs(q_w_crash - r_a9) < 1e-9,
      f"A9: q_waiting crash returns just r={r_a9} (got {q_w_crash})")

q_c_crash = mdp.q_carrying(t_a9, pos_a9, b_a9, dropoff_a9, ttl_a9, "U")
check(abs(q_c_crash - r_a9) < 1e-9,
      f"A9: q_carrying crash returns just r={r_a9} (got {q_c_crash})")


# ===================================================================
print()
print("=" * 72)
print("SUMMARY")
print("=" * 72)
print(f"  Total: {passed + failed}")
print(f"  Passed: {passed}")
print(f"  Failed: {failed}")
if findings:
    print()
    print("  FAILURES:")
    for name, detail in findings:
        print(f"    - {name}: {detail}")
else:
    print()
    print("  All tests passed. No correctness issues found.")
print("=" * 72)
