# Strict Metric-Aligned Answer Rubric：马尔科夫决策过程 / 问题1_无人机医疗包裹配送

## Problem Analysis

本题是有限时域随机 MDP。状态必须闭合覆盖位置、电量、是否携带、订单取货点、送达点、剩余时间和当前时间；动作包括移动、等待、取货、交货、充电；转移需要处理无订单时 20% 概率生成新订单、8 步订单时窗、电量耗尽终止和收益惩罚。核心陷阱是把近似启发式包装成精确 DP，或者订单状态只存一个点导致取货/交货逻辑错误。

本题评分强调以下反模板检查点：

- 状态表示必须同时存 pickup 和 delivery，不能只存一个 order_dest
- Bellman 递推要对随机订单生成做期望
- 取货、交货、充电耗时但不耗电，时间窗和电量终止要准确
- 精确 DP、MCTS 和启发式策略必须如实区分

## Strict Scoring Rules

- 每个统一指标满分 5 分，按 ME/CE/RE 维度独立打分。
- 代码和报告必须交叉核验；模型自称“最优”“完整”“可运行”不能直接采信。
- 若只写理论不交付可运行代码，`CE.1`、`RE.3` 必须明显扣分。
- 若代码可运行但绕开本题核心结构，只能获得有限代码分，不能用单例结果抵消建模缺陷。
- 若存在泛化脚本、测试用例或扰动数据，`CE.3` 计入总分；否则 `CE.3` 标记为 `NOT_IMPLEMENTED` 并排除。
- 所有语义判断由 LLM Judge 执行，所有可执行/可复算项优先使用 checker、测试脚本、旧运行报告或独立逻辑复核。

## ME.1 模型正确性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME1-R1 | 正确识别问题类型与核心不确定性/动态结构 | response text | LLM Judge | 1.00 |
| ME1-R2 | 定义关键决策变量、状态或策略变量，且口径与题面一致 | response text + code / checker | Hybrid | 1.00 |
| ME1-R3 | 目标函数完整覆盖收益、成本、风险或惩罚项 | response text + code / checker | Hybrid | 1.10 |
| ME1-R4 | 硬约束、耦合约束和时序/情景依赖关系处理正确 | response text + code / checker | Hybrid | 1.20 |
| ME1-R5 | 能抓住本题反模板陷阱，而不是套用普通模板 | response text | LLM Judge | 0.70 |

ME.1 total: 5 points

## ME.2 模型简洁性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME2-R1 | 建模主线简洁清楚，没有把辅助分析压过核心模型 | response text | LLM Judge | 1.20 |
| ME2-R2 | 方法复杂度与题目规模匹配，避免不必要的过度工程或纯拍脑袋 | response text + code / checker | Hybrid | 1.20 |
| ME2-R3 | 能区分精确解、近似解、启发式和评估器得分的不同含义 | response text | LLM Judge | 1.30 |
| ME2-R4 | 边界条件、反直觉结论和规模扩展限制说明恰当 | response text | LLM Judge | 1.30 |

ME.2 total: 5 points

## ME.3 模型-代码一致性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME3-R1 | 文字声称的问题类型和代码实际算法一致 | response text + code / checker | Hybrid | 1.00 |
| ME3-R2 | 公式/变量/约束与代码中的数据结构和计算逻辑一致 | response text + code / checker | Hybrid | 1.20 |
| ME3-R3 | 报告结果、代码输出和可复算指标一致 | response text + code / checker | Hybrid | 1.10 |
| ME3-R4 | 没有用关键词或包装性文本冒充未实现的核心算法 | response text + code / checker | Hybrid | 0.90 |
| ME3-R5 | 自评、局限说明与实际代码行为一致 | response text | LLM Judge | 0.80 |

ME.3 total: 5 points

## CE.1 代码可行性与正确性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE1-R1 | 提供可抽取、可运行的主求解代码或明确入口 | code / execution | Automatic | 0.90 |
| CE1-R2 | 核心算法实际实现了题目要求的方法，而非只给伪代码/评估器 | response text + code / checker | Hybrid | 1.30 |
| CE1-R3 | 输出满足题面硬约束且能被 checker 或报告重建 | code / execution | Automatic | 1.00 |
| CE1-R4 | 关键数值目标可复算，结果口径与 reference/题面一致 | code / execution | Automatic | 1.00 |
| CE1-R5 | 异常、路径、依赖、随机种子或输入输出协议基本稳定 | response text + code / checker | Automatic + LLM Judge | 0.80 |

CE.1 total: 5 points

## CE.2 代码质量与效率

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE2-R1 | 代码结构清晰，数据、模型、求解、输出边界分明 | response text | LLM Judge | 1.00 |
| CE2-R2 | 算法复杂度、内存和求解器选择适合当前规模 | response text + code / checker | Hybrid | 1.00 |
| CE2-R3 | 可参数化程度足够，不只是硬编码单个展示样例 | response text + code / checker | Hybrid | 1.00 |
| CE2-R4 | 数值稳定性、随机性和求解失败处理合理 | response text + code / checker | Hybrid | 1.00 |
| CE2-R5 | 与 pipeline/checker 的输出格式兼容 | response text + code / checker | Automatic + LLM Judge | 1.00 |

CE.2 total: 5 points

## CE.3 代码鲁棒性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE3-R1 | 存在多实例、扰动或参数泛化测试入口 | folder inspection / generated tests | Automatic | 0.80 |
| CE3-R2 | 模型代码能在多参数设置下保持可行性 | folder inspection / generated tests | Automatic | 1.20 |
| CE3-R3 | 目标值随规模/参数变化合理，不依赖单例调参 | folder inspection / generated tests | Hybrid | 1.00 |
| CE3-R4 | 失败类型、超时和不可行原因有记录或可诊断 | folder inspection / generated tests | Hybrid | 1.00 |
| CE3-R5 | 对规模扩展边界有诚实说明 | folder inspection / generated tests | LLM Judge | 1.00 |

CE.3 total: 5 points

## RE.1 报告完整性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE1-R1 | 完整重述业务目标、输入数据和关键约束 | response text | LLM Judge | 0.90 |
| RE1-R2 | 给出数学模型/状态转移/目标函数的核心表达 | response text | LLM Judge | 1.20 |
| RE1-R3 | 说明求解流程、依赖、入口和输出格式 | response text + code / checker | Hybrid | 1.00 |
| RE1-R4 | 报告最终方案、关键数值和约束检查结果 | response text + code / checker | Hybrid | 1.10 |
| RE1-R5 | 包含与题目陷阱相关的解释或诊断 | response text | LLM Judge | 0.80 |

RE.1 total: 5 points

## RE.2 解释清晰度

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE2-R1 | 业务含义与数学含义解释清楚 | response text | LLM Judge | 1.00 |
| RE2-R2 | 关键公式、算法步骤和结果口径便于复核 | response text | LLM Judge | 1.20 |
| RE2-R3 | 说明为什么该方法适合本题而不是普通模板 | response text | LLM Judge | 1.00 |
| RE2-R4 | 复杂度、近似性和工程边界表达清楚 | response text | LLM Judge | 1.00 |
| RE2-R5 | 行文聚焦，不用冗长外扩掩盖核心缺陷 | response text | LLM Judge | 0.80 |

RE.2 total: 5 points

## RE.3 结果可复现性

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE3-R1 | 提供可复现入口、依赖和数据路径 | response text + code / checker | Hybrid | 0.90 |
| RE3-R2 | 最终方案可由代码输出或从报告明确重建 | code / execution | Automatic | 1.00 |
| RE3-R3 | 目标值/收益/成本/得分可被独立复算 | code / execution | Automatic | 1.20 |
| RE3-R4 | 约束满足声明与 checker 或逻辑复核一致 | code / execution | Automatic | 1.10 |
| RE3-R5 | 没有混淆基准、旧版本数据或评估脚本口径 | response text + code / checker | Hybrid | 0.80 |

RE.3 total: 5 points

## RE.4 局限承认

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE4-R1 | 承认未实现、近似、启发式或不可复现部分 | response text | LLM Judge | 1.10 |
| RE4-R2 | 指出代码-文字不一致、数据口径或评估器漏洞 | response text + code / checker | Hybrid | 1.10 |
| RE4-R3 | 不夸大“最优”“生产可用”或“完全解决” | response text | LLM Judge | 1.00 |
| RE4-R4 | 说明泛化、鲁棒性、规模或边界风险 | response text | LLM Judge | 1.00 |
| RE4-R5 | 给出可操作的修正方向 | response text | LLM Judge | 0.80 |

RE.4 total: 5 points

## Expected Failure Modes

- 忽略或误处理：状态表示必须同时存 pickup 和 delivery，不能只存一个 order_dest
- 忽略或误处理：Bellman 递推要对随机订单生成做期望
- 忽略或误处理：取货、交货、充电耗时但不耗电，时间窗和电量终止要准确
- 忽略或误处理：精确 DP、MCTS 和启发式策略必须如实区分
- 文档声称完整解决，但代码只实现了简化、启发式或不可复现版本。
- 结果数字无法由代码、checker 或题面数据复算。
