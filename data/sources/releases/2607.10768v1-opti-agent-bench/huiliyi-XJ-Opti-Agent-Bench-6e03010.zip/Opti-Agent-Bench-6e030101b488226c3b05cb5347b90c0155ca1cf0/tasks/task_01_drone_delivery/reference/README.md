# Reference — `task_01_drone_delivery`

## Included

- `answer.md`
- `generate_instances.py`
- `optimal_policy_dp.py`
- `test_correctness.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
