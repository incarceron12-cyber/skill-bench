from __future__ import annotations

from functools import lru_cache
import random

T, TTL = 20, 8
ALL_POS = [(i, j) for i in range(1, 5) for j in range(1, 5)]
BASE = (1, 1)
BASE_IDX = ALL_POS.index(BASE)
NON_BASE = [p for p in ALL_POS if p != BASE]
NON_BASE_IDX = [ALL_POS.index(p) for p in NON_BASE]
ORDER_PROB = 0.2
ORDER_PAIR_PROB = ORDER_PROB / 225.0
MOVE_COST, WAIT_COST, CRASH_COST, TIMEOUT_COST, DELIVER_REWARD = 5, 1, 200, 20, 50
MOVE_B, WAIT_B, CHARGE_B, MAX_B = 5, 1, 10, 50  # 电量单位：2%

MOVE_NEXT = {}
for idx, (i, j) in enumerate(ALL_POS):
    MOVE_NEXT[(idx, "U")] = ALL_POS.index((i + 1, j)) if i < 4 else None
    MOVE_NEXT[(idx, "D")] = ALL_POS.index((i - 1, j)) if i > 1 else None
    MOVE_NEXT[(idx, "L")] = ALL_POS.index((i, j - 1)) if j > 1 else None
    MOVE_NEXT[(idx, "R")] = ALL_POS.index((i, j + 1)) if j < 4 else None


def no_order_actions(pos: int, b: int):
    acts = []
    for a in ("U", "D", "L", "R"):
        if b >= MOVE_B and MOVE_NEXT[(pos, a)] is not None:
            acts.append(a)
    if b >= WAIT_B:
        acts.append("W")
    if pos == BASE_IDX and b < MAX_B:
        acts.append("CHARGE")
    return acts


def order_actions(pos: int, b: int, pickup: int | None, dropoff: int | None, carrying: int):
    acts = no_order_actions(pos, b)
    if not carrying and pickup is not None and pos == pickup:
        acts.append("PICK")
    if carrying and dropoff is not None and pos == dropoff:
        acts.append("DROP")
    return acts


def step_common(t: int, pos: int, b: int, action: str):
    reward = 0
    if action in ("U", "D", "L", "R"):
        pos = MOVE_NEXT[(pos, action)]
        b -= MOVE_B
        reward -= MOVE_COST
    elif action == "W":
        b -= WAIT_B
        reward -= WAIT_COST
    elif action == "CHARGE":
        b = min(MAX_B, b + CHARGE_B)
    if b <= 0:
        return t + 1, pos, b, reward - CRASH_COST, True
    return t + 1, pos, b, reward, False


@lru_cache(None)
def G(t: int, pos: int, b: int) -> float:
    if t >= T or b <= 0:
        return 0.0
    total = 0.8 * N(t, pos, b)
    for p in NON_BASE_IDX:
        for d in range(len(ALL_POS)):
            if d != p:
                total += ORDER_PAIR_PROB * W(t, pos, b, p, d, TTL)
    return total


@lru_cache(None)
def N(t: int, pos: int, b: int) -> float:
    if t >= T or b <= 0:
        return 0.0
    best = -10**18
    for a in no_order_actions(pos, b):
        nt, np, nb, r, done = step_common(t, pos, b, a)
        val = r if done or nt >= T else r + G(nt, np, nb)
        if val > best:
            best = val
    return best


@lru_cache(None)
def W(t: int, pos: int, b: int, pickup: int, dropoff: int, ttl: int) -> float:
    if t >= T or b <= 0:
        return 0.0
    best = -10**18
    for a in order_actions(pos, b, pickup, dropoff, 0):
        if a == "PICK":
            nt, np, nb, r, done = t + 1, pos, b, 0, False
            if ttl - 1 <= 0:
                val = r - TIMEOUT_COST if nt >= T else r - TIMEOUT_COST + G(nt, np, nb)
            else:
                val = r if nt >= T else r + C(nt, np, nb, dropoff, ttl - 1)
        else:
            nt, np, nb, r, done = step_common(t, pos, b, a)
            if done or nt >= T:
                val = r
            elif ttl - 1 <= 0:
                val = r - TIMEOUT_COST + G(nt, np, nb)
            else:
                val = r + W(nt, np, nb, pickup, dropoff, ttl - 1)
        best = max(best, val)
    return best


@lru_cache(None)
def C(t: int, pos: int, b: int, dropoff: int, ttl: int) -> float:
    if t >= T or b <= 0:
        return 0.0
    best = -10**18
    for a in order_actions(pos, b, None, dropoff, 1):
        if a == "DROP":
            nt, np, nb, r, done = t + 1, pos, b, DELIVER_REWARD, False
            val = r if nt >= T else r + G(nt, np, nb)
        else:
            nt, np, nb, r, done = step_common(t, pos, b, a)
            if done or nt >= T:
                val = r
            elif ttl - 1 <= 0:
                val = r - TIMEOUT_COST + G(nt, np, nb)
            else:
                val = r + C(nt, np, nb, dropoff, ttl - 1)
        best = max(best, val)
    return best


def q_no_order(t: int, pos: int, b: int, action: str) -> float:
    nt, np, nb, r, done = step_common(t, pos, b, action)
    return r if done or nt >= T else r + G(nt, np, nb)


def q_waiting(t: int, pos: int, b: int, pickup: int, dropoff: int, ttl: int, action: str) -> float:
    if action == "PICK":
        nt, np, nb, r = t + 1, pos, b, 0
        if ttl - 1 <= 0:
            return r - TIMEOUT_COST if nt >= T else r - TIMEOUT_COST + G(nt, np, nb)
        return r if nt >= T else r + C(nt, np, nb, dropoff, ttl - 1)
    nt, np, nb, r, done = step_common(t, pos, b, action)
    if done or nt >= T:
        return r
    if ttl - 1 <= 0:
        return r - TIMEOUT_COST + G(nt, np, nb)
    return r + W(nt, np, nb, pickup, dropoff, ttl - 1)


def q_carrying(t: int, pos: int, b: int, dropoff: int, ttl: int, action: str) -> float:
    if action == "DROP":
        nt, np, nb, r = t + 1, pos, b, DELIVER_REWARD
        return r if nt >= T else r + G(nt, np, nb)
    nt, np, nb, r, done = step_common(t, pos, b, action)
    if done or nt >= T:
        return r
    if ttl - 1 <= 0:
        return r - TIMEOUT_COST + G(nt, np, nb)
    return r + C(nt, np, nb, dropoff, ttl - 1)


def optimal_action(t: int, pos: int, b: int, pickup: int | None = None, dropoff: int | None = None, ttl: int = 0, carrying: int = 0):
    if pickup is None and dropoff is None and ttl == 0 and carrying == 0:
        acts = no_order_actions(pos, b)
        return max(acts, key=lambda a: q_no_order(t, pos, b, a))
    if not carrying:
        acts = order_actions(pos, b, pickup, dropoff, 0)
        return max(acts, key=lambda a: q_waiting(t, pos, b, pickup, dropoff, ttl, a))
    acts = order_actions(pos, b, None, dropoff, 1)
    return max(acts, key=lambda a: q_carrying(t, pos, b, dropoff, ttl, a))


def simulate_optimal(episodes: int = 200, seed: int = 0) -> float:
    rng = random.Random(seed)
    total = 0.0
    for _ in range(episodes):
        t, pos, b, pickup, dropoff, ttl, carrying = 0, BASE_IDX, MAX_B, None, None, 0, 0
        reward_sum = 0.0
        while t < T and b > 0:
            if pickup is None and dropoff is None and ttl == 0 and carrying == 0 and rng.random() < ORDER_PROB:
                pickup = rng.choice(NON_BASE_IDX)
                candidates = [d for d in range(len(ALL_POS)) if d != pickup]
                dropoff = rng.choice(candidates)
                ttl = TTL
            a = optimal_action(t, pos, b, pickup, dropoff, ttl, carrying)
            if pickup is None and dropoff is None and ttl == 0 and carrying == 0:
                nt, pos, b, r, done = step_common(t, pos, b, a)
                reward_sum += r
                t = nt
            elif not carrying and a == "PICK":
                t += 1; ttl -= 1; carrying = 1
                if ttl <= 0:
                    reward_sum -= TIMEOUT_COST
                    pickup = dropoff = None; ttl = 0; carrying = 0
            elif carrying and a == "DROP":
                t += 1; reward_sum += DELIVER_REWARD
                pickup = dropoff = None; ttl = 0; carrying = 0
            else:
                nt, pos, b, r, done = step_common(t, pos, b, a)
                reward_sum += r; t = nt; ttl -= 1
                if b <= 0:
                    break
                if ttl <= 0:
                    reward_sum -= TIMEOUT_COST
                    pickup = dropoff = None; ttl = 0; carrying = 0
        total += reward_sum
    return total / episodes


if __name__ == "__main__":
    print("optimal initial value:", round(G(0, BASE_IDX, MAX_B), 6))
    print("optimal policy MC avg:", round(simulate_optimal(200, seed=0), 6))
