"""MDP（无人机医疗配送）泛化性评测引擎
==========================================
对 MDP 参考解法进行泛化性评测。

注意：所有模型回答均为评审分析报告，不含可运行的 MDP 求解代码。
因此本域仅评测参考解法自身在不同参数/规模下的泛化性表现。

用法:
    python eval_generalization.py [--timeout 120] [--output results/] [--quick]

参数:
    --timeout  每次求解的超时时间（秒），默认 120
    --output   结果输出目录，默认 results/
    --quick    快速模式，仅运行 3 个测试用例用于验证框架
"""

import sys
import os
import json
import time
import argparse
import traceback
from datetime import datetime
from multiprocessing import Process, Queue

# 确保项目根目录在 sys.path 中
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from generate_instances import (
    generate_instance, get_all_cases,
    get_parameter_generalization_cases, get_scale_generalization_cases,
)


# ============================================================
# 模型注册表
# ============================================================

MODELS = {
    'reference': {
        'name': '参考解法 (DP)',
        'wrapper': 'wrappers.wrapper_reference',
        'source': 'optimal_policy_dp.py',
        'description': '精确动态规划 + lru_cache，Bellman 方程求解',
    },
}

# 规模 -> 建议超时（秒）
GRID_TIMEOUT_HINTS = {
    3: 30,
    4: 120,
    5: 300,
    6: 600,
    7: 600,
    8: 600,
}


# ============================================================
# 超时机制（基于 multiprocessing）
# ============================================================

def _run_solve_in_process(wrapper_module_name, instance, result_queue):
    """在子进程中执行求解，结果通过 Queue 返回。"""
    try:
        import sys
        sys.setrecursionlimit(100000)
        import importlib
        mod = importlib.import_module(wrapper_module_name)
        result = mod.solve(instance)
        result_queue.put(result)
    except Exception as e:
        result_queue.put({
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': 0.0,
            'error': f'{type(e).__name__}: {str(e)}',
            'solver': 'DP',
        })


def solve_with_timeout(wrapper_module_name, instance, timeout=120):
    """
    带超时的求解调用。使用 multiprocessing 实现跨平台超时。
    """
    result_queue = Queue()
    proc = Process(
        target=_run_solve_in_process,
        args=(wrapper_module_name, instance, result_queue),
    )

    start_time = time.time()
    proc.start()
    proc.join(timeout=timeout)
    elapsed = time.time() - start_time

    if proc.is_alive():
        proc.terminate()
        proc.join(timeout=5)
        if proc.is_alive():
            proc.kill()
            proc.join(timeout=2)
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': f'超时: 求解时间超过 {timeout} 秒 (grid_size={instance.get("grid_size","?")})',
            'solver': 'DP',
        }

    if not result_queue.empty():
        return result_queue.get()
    else:
        return {
            'objective': None,
            'solution': None,
            'feasible': False,
            'solve_time': elapsed,
            'error': '子进程异常退出，未返回结果',
            'solver': 'DP',
        }


# ============================================================
# 失败原因分类
# ============================================================

def classify_failure(result, instance):
    """分类失败原因。"""
    if result['feasible'] and result['objective'] is not None:
        return 'success'

    error = result.get('error', '') or ''

    if '超时' in error or 'timeout' in error.lower():
        return 'timeout'
    if 'MemoryError' in error or '内存' in error:
        return 'memory'
    if 'RecursionError' in error:
        return 'recursion'
    return 'error'


# ============================================================
# Case ID 生成
# ============================================================

def make_case_id(case_params):
    """从测试用例参数生成可读的 ID。"""
    desc = case_params.get('description', '')
    if desc:
        # 简化中文描述为 ASCII-safe ID
        gs = case_params.get('grid_size', 4)
        parts = [f'g{gs}']
        for key in ['order_probability', 'ttl_range', 'battery_capacity',
                     'move_battery_pct', 'charge_battery_pct',
                     'reward_scale', 'deliver_reward', 'crash_cost']:
            if key in case_params:
                val = case_params[key]
                short_key = key[:6]
                parts.append(f'{short_key}={val}')
        return '_'.join(parts)
    return f'g{case_params.get("grid_size", 4)}'


# ============================================================
# 主评测流程
# ============================================================

def run_evaluation(timeout=120, output_dir='results/', quick=False):
    """
    运行完整的泛化性评测。

    参数:
        timeout: 每次求解的默认超时时间（秒）
        output_dir: 结果输出目录
        quick: 快速模式，仅运行少量测试用例
    """
    os.makedirs(output_dir, exist_ok=True)

    # 获取测试用例
    if quick:
        cases = [
            {'grid_size': 3, 'T': 15, 'seed': 42,
             'description': '小网格 3×3（快速验证）'},
            {'grid_size': 4, 'T': 20, 'seed': 42,
             'order_probability': 'medium', 'ttl_range': 'medium',
             'description': '原始参数 4×4'},
            {'grid_size': 4, 'T': 20, 'seed': 42,
             'order_probability': 'high', 'ttl_range': 'short',
             'description': '高频订单+短TTL'},
        ]
    else:
        cases = get_all_cases()

    model_keys = list(MODELS.keys())
    total_runs = len(cases) * len(model_keys)

    print("=" * 70)
    print("MDP（无人机医疗配送）泛化性评测")
    print("=" * 70)
    print(f"  测试用例数: {len(cases)}")
    print(f"  评测模型数: {len(model_keys)} (仅参考解法)")
    print(f"  总运行次数: {total_runs}")
    print(f"  默认超时:   {timeout} 秒")
    print(f"  输出目录:   {output_dir}")
    print(f"  模式:       {'快速验证' if quick else '完整评测'}")
    print("=" * 70)

    all_results = []
    run_idx = 0
    stats = {mk: {'success': 0, 'fail': 0, 'total': 0} for mk in model_keys}

    for case_idx, case_params in enumerate(cases):
        # 生成实例
        gen_params = {k: v for k, v in case_params.items() if k != 'description'}
        instance = generate_instance(**gen_params)
        case_id = make_case_id(case_params)
        case_desc = case_params.get('description', case_id)
        grid_size = instance['grid_size']

        # 根据 grid_size 调整超时
        effective_timeout = max(timeout, GRID_TIMEOUT_HINTS.get(grid_size, timeout))

        for model_key in model_keys:
            run_idx += 1
            model_info = MODELS[model_key]
            wrapper_module = model_info['wrapper']

            print(f"  [{run_idx:3d}/{total_runs}] "
                  f"Model: {model_key:10s} | Case: {case_desc} "
                  f"(timeout={effective_timeout}s)", end="")
            sys.stdout.flush()

            result = solve_with_timeout(wrapper_module, instance, effective_timeout)
            failure_category = classify_failure(result, instance)

            # 构建结果记录
            record = {
                'run_id': run_idx,
                'model': model_key,
                'model_name': model_info['name'],
                'case_id': case_id,
                'case_description': case_desc,
                'case_params': {k: v for k, v in case_params.items()
                                if k != 'description'},
                'grid_size': grid_size,
                'T': instance['T'],
                'TTL': instance['TTL'],
                'order_prob': instance['order_prob'],
                'objective': result['objective'],
                'feasible': result['feasible'],
                'solve_time': round(result['solve_time'], 4),
                'error': result['error'],
                'solver': result.get('solver', ''),
                'failure_category': failure_category,
                'effective_timeout': effective_timeout,
            }

            # 保存 solution 摘要
            if result.get('solution') and result['feasible']:
                sol = result['solution']
                record['total_dp_states'] = sol.get('total_dp_states', 0)
                record['cache_info'] = sol.get('cache_info', {})

            all_results.append(record)

            stats[model_key]['total'] += 1
            if failure_category == 'success':
                stats[model_key]['success'] += 1
                dp_states = ''
                if result.get('solution'):
                    dp_states = f"  states={result['solution'].get('total_dp_states', '?')}"
                print(f"  -> OK  obj={result['objective']:.4f}  "
                      f"t={result['solve_time']:.2f}s{dp_states}")
            else:
                stats[model_key]['fail'] += 1
                short_err = (result['error'] or '')[:60]
                print(f"  -> FAIL [{failure_category}] {short_err}")

    # ============================================================
    # 保存结果
    # ============================================================
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    results_file = os.path.join(output_dir, f'eval_results_{timestamp}.json')
    latest_file = os.path.join(output_dir, 'eval_results_latest.json')

    result_data = {
        'metadata': {
            'timestamp': timestamp,
            'domain': 'MDP（无人机医疗配送）',
            'timeout': timeout,
            'num_cases': len(cases),
            'num_models': len(model_keys),
            'total_runs': total_runs,
            'quick_mode': quick,
            'note': '所有大模型回答均为评审分析报告，不含可运行MDP求解代码。仅评测参考解法。',
        },
        'results': all_results,
    }

    for fpath in [results_file, latest_file]:
        with open(fpath, 'w', encoding='utf-8') as f:
            json.dump(result_data, f, ensure_ascii=False, indent=2)

    # ============================================================
    # 打印摘要
    # ============================================================
    print("\n" + "=" * 70)
    print("评测摘要")
    print("=" * 70)
    print(f"\n{'模型':<20s} {'成功':>6s} {'失败':>6s} {'总计':>6s} {'成功率':>8s}")
    print("-" * 50)
    for mk in model_keys:
        s = stats[mk]
        rate = f"{s['success']/s['total']*100:.1f}%" if s['total'] > 0 else 'N/A'
        print(f"{mk:<20s} {s['success']:>6d} {s['fail']:>6d} "
              f"{s['total']:>6d} {rate:>8s}")

    # 按失败类别统计
    category_counts = {}
    for r in all_results:
        cat = r['failure_category']
        category_counts[cat] = category_counts.get(cat, 0) + 1
    print(f"\n失败类别统计:")
    for cat, count in sorted(category_counts.items()):
        print(f"  {cat:<20s}: {count:>4d}")

    # 按 grid_size 统计
    print(f"\n按 grid_size 统计:")
    gs_stats = {}
    for r in all_results:
        gs = r['grid_size']
        if gs not in gs_stats:
            gs_stats[gs] = {'ok': 0, 'fail': 0, 'times': []}
        if r['failure_category'] == 'success':
            gs_stats[gs]['ok'] += 1
            gs_stats[gs]['times'].append(r['solve_time'])
        else:
            gs_stats[gs]['fail'] += 1
    for gs in sorted(gs_stats.keys()):
        s = gs_stats[gs]
        avg_t = sum(s['times'])/len(s['times']) if s['times'] else 0
        print(f"  grid={gs}: 成功={s['ok']} 失败={s['fail']} 平均时间={avg_t:.2f}s")

    print(f"\n结果已保存到: {results_file}")
    print(f"最新结果副本: {latest_file}")

    return all_results


# ============================================================
# 入口
# ============================================================

if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        description='MDP（无人机医疗配送）泛化性评测引擎'
    )
    parser.add_argument('--timeout', type=int, default=120,
                        help='每次求解的超时时间（秒），默认 120')
    parser.add_argument('--output', type=str, default='results/',
                        help='结果输出目录，默认 results/')
    parser.add_argument('--quick', action='store_true',
                        help='快速模式，仅运行 3 个测试用例验证框架')

    args = parser.parse_args()

    run_evaluation(
        timeout=args.timeout,
        output_dir=args.output,
        quick=args.quick,
    )
