"""
MDP（无人机医疗配送）测试实例生成器
=====================================
为「马尔可夫决策过程——无人机医疗包裹配送」问题生成泛化性测试用例。

问题结构：
  - grid_size × grid_size 网格，基地在 (1,1)
  - T 个离散时间段，每段选择一个动作
  - 订单以 order_probability 概率随机生成
  - 电量系统：飞行/等待/充电各有消耗/恢复
  - 目标：最大化期望总收益

参数字典结构（与 optimal_policy_dp.py 兼容）：
  grid_size         : int           网格边长
  T                 : int           总时间段数
  TTL               : int           订单时限（步数）
  order_prob        : float         订单生成概率
  base              : tuple(int,int) 基地坐标
  max_battery       : int           电量上限（内部单位）
  battery_unit      : float         每个内部电量单位对应的百分比
  move_battery      : int           飞行一格消耗电量（内部单位）
  wait_battery      : int           等待一步消耗电量（内部单位）
  charge_battery    : int           充电一次恢复电量（内部单位）
  move_cost         : float         飞行一格的收益损失
  wait_cost         : float         等待一步的收益损失
  crash_cost        : float         电量耗尽额外惩罚
  timeout_cost      : float         订单超时惩罚
  deliver_reward    : float         成功送达奖励
  seed              : int           随机种子
  description       : str           实例描述
"""

import random
import math


# ============================================================
# 原始问题参数（4×4 网格，optimal_policy_dp.py 的精确数据）
# ============================================================

ORIGINAL_PARAMS = {
    'grid_size': 4,
    'T': 20,
    'TTL': 8,
    'order_prob': 0.2,
    'base': (1, 1),
    'max_battery': 50,       # 内部单位，对应 100%
    'battery_unit': 2.0,     # 每单位 = 2%
    'move_battery': 5,       # 飞行一格消耗 5 单位 = 10%
    'wait_battery': 1,       # 等待一步消耗 1 单位 = 2%
    'charge_battery': 10,    # 充电恢复 10 单位 = 20%
    'move_cost': 5,          # 飞行一格收益 -5
    'wait_cost': 1,          # 等待一步收益 -1
    'crash_cost': 200,       # 电量耗尽额外 -200
    'timeout_cost': 20,      # 订单超时 -20
    'deliver_reward': 50,    # 成功送达 +50
}


# ============================================================
# 核心生成函数
# ============================================================

def generate_instance(grid_size=4, T=20, seed=42, battery_capacity=100,
                      order_probability='medium', ttl_range='medium',
                      reward_scale=1.0,
                      battery_unit=2.0,
                      move_battery_pct=10.0,
                      wait_battery_pct=2.0,
                      charge_battery_pct=20.0,
                      crash_cost=200,
                      timeout_cost=20,
                      deliver_reward=50,
                      move_cost=5,
                      wait_cost=1):
    """
    生成一个合法的无人机配送MDP问题实例。

    参数:
        grid_size:         网格边长（grid_size × grid_size）
        T:                 总时间段数
        seed:              随机种子
        battery_capacity:  电量上限百分比（如100表示100%）
        order_probability: 订单生成概率：
                           'low'    — 10%
                           'medium' — 20%（原始问题）
                           'high'   — 35%
                           或直接传入 float
        ttl_range:         订单时限范围：
                           'short'  — TTL=5
                           'medium' — TTL=8（原始问题）
                           'long'   — TTL=12
                           或直接传入 int
        reward_scale:      收益/成本缩放因子（1.0=原始）
        battery_unit:      电量离散化单位（百分比），默认2%
        move_battery_pct:  飞行一格消耗电量百分比，默认10%
        wait_battery_pct:  等待一步消耗电量百分比，默认2%
        charge_battery_pct: 充电恢复电量百分比，默认20%
        crash_cost:        电量耗尽惩罚
        timeout_cost:      订单超时惩罚
        deliver_reward:    成功送达奖励
        move_cost:         飞行成本
        wait_cost:         等待成本

    返回:
        dict: 包含问题所有参数的字典，与参考解法兼容
    """
    rng = random.Random(seed)

    # --- 订单概率 ---
    if isinstance(order_probability, str):
        prob_map = {'low': 0.10, 'medium': 0.20, 'high': 0.35}
        assert order_probability in prob_map, \
            f"order_probability 必须为 {list(prob_map.keys())} 或 float"
        order_prob = prob_map[order_probability]
    else:
        order_prob = float(order_probability)
    assert 0 < order_prob < 1, "order_probability 必须在 (0, 1) 之间"

    # --- TTL ---
    if isinstance(ttl_range, str):
        ttl_map = {'short': 5, 'medium': 8, 'long': 12}
        assert ttl_range in ttl_map, \
            f"ttl_range 必须为 {list(ttl_map.keys())} 或 int"
        ttl = ttl_map[ttl_range]
    else:
        ttl = int(ttl_range)
    assert ttl >= 2, "TTL 至少为 2"

    # --- 电量参数（转换为内部单位）---
    max_b = int(round(battery_capacity / battery_unit))
    move_b = int(round(move_battery_pct / battery_unit))
    wait_b = int(round(wait_battery_pct / battery_unit))
    charge_b = int(round(charge_battery_pct / battery_unit))

    assert max_b >= 1, "电量上限至少 1 个内部单位"
    assert move_b >= 1, "飞行消耗至少 1 个内部单位"
    assert wait_b >= 1, "等待消耗至少 1 个内部单位"
    assert charge_b >= 1, "充电恢复至少 1 个内部单位"

    # --- 收益/成本缩放 ---
    scaled_move_cost = move_cost * reward_scale
    scaled_wait_cost = wait_cost * reward_scale
    scaled_crash_cost = crash_cost * reward_scale
    scaled_timeout_cost = timeout_cost * reward_scale
    scaled_deliver_reward = deliver_reward * reward_scale

    # --- 基地 ---
    base = (1, 1)

    # --- 位置列表 ---
    n_positions = grid_size * grid_size
    n_non_base = n_positions - 1
    # 订单概率分解
    n_order_pairs = n_non_base * (n_positions - 1)  # pickup × (all - pickup)
    order_pair_prob = order_prob / n_order_pairs if n_order_pairs > 0 else 0

    # --- 验证可行性 ---
    # 确保从基地到最远点可达（电量够飞最远距离）
    max_dist = 2 * (grid_size - 1)  # 对角线曼哈顿距离
    min_battery_for_max_trip = max_dist * move_b
    if max_b < min_battery_for_max_trip:
        # 虽然不一定要求能飞到最远点，但至少确保能做一些有意义的动作
        pass  # 允许，但记录警告

    instance = {
        'grid_size': grid_size,
        'T': T,
        'TTL': ttl,
        'order_prob': order_prob,
        'order_pair_prob': order_pair_prob,
        'base': base,
        'max_battery': max_b,
        'battery_unit': battery_unit,
        'move_battery': move_b,
        'wait_battery': wait_b,
        'charge_battery': charge_b,
        'move_cost': scaled_move_cost,
        'wait_cost': scaled_wait_cost,
        'crash_cost': scaled_crash_cost,
        'timeout_cost': scaled_timeout_cost,
        'deliver_reward': scaled_deliver_reward,
        'seed': seed,
        'n_positions': n_positions,
        'n_non_base': n_non_base,
        'n_order_pairs': n_order_pairs,
    }
    return instance


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例：在固定 grid_size=4（原始规模）下，
    变化电量参数、订单概率、TTL、收益权重等。

    返回:
        list[dict]: 每个元素是传给 generate_instance 的参数字典
    """
    cases = []

    # --- 1. 订单概率变化 ---
    for p in [0.05, 'low', 'medium', 'high', 0.40]:
        cases.append({
            'grid_size': 4, 'T': 20, 'seed': 42,
            'order_probability': p, 'ttl_range': 'medium',
            'description': f'订单概率={p}'
        })

    # --- 2. TTL 变化 ---
    for ttl in [3, 'short', 6, 'long', 15]:
        cases.append({
            'grid_size': 4, 'T': 20, 'seed': 42,
            'order_probability': 'medium', 'ttl_range': ttl,
            'description': f'TTL={ttl}'
        })

    # --- 3. 电量参数变化 ---
    # 电池容量变化
    for cap in [60, 80, 120]:
        cases.append({
            'grid_size': 4, 'T': 20, 'seed': 42,
            'battery_capacity': cap,
            'description': f'电池容量={cap}%'
        })

    # 飞行电耗变化
    for mpct in [6.0, 12.0, 15.0]:
        cases.append({
            'grid_size': 4, 'T': 20, 'seed': 42,
            'move_battery_pct': mpct,
            'description': f'飞行电耗={mpct}%'
        })

    # 充电恢复量变化
    for cpct in [10.0, 30.0]:
        cases.append({
            'grid_size': 4, 'T': 20, 'seed': 42,
            'charge_battery_pct': cpct,
            'description': f'充电恢复={cpct}%'
        })

    # --- 4. 收益/成本权重变化 ---
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'reward_scale': 0.5,
        'description': '收益缩放=0.5'
    })
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'reward_scale': 2.0,
        'description': '收益缩放=2.0'
    })

    # --- 5. 组合变化 ---
    # 高频订单 + 短TTL（压力测试）
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'order_probability': 'high', 'ttl_range': 'short',
        'description': '高频订单+短TTL'
    })
    # 低频订单 + 长TTL（宽松场景）
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'order_probability': 'low', 'ttl_range': 'long',
        'description': '低频订单+长TTL'
    })
    # 低电量 + 高飞行电耗（电量紧张）
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'battery_capacity': 60, 'move_battery_pct': 15.0,
        'description': '低电量+高飞行电耗'
    })
    # 大电量 + 低飞行电耗（电量充裕）
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'battery_capacity': 150, 'move_battery_pct': 6.0,
        'description': '大电量+低飞行电耗'
    })
    # 高收益 + 高惩罚
    cases.append({
        'grid_size': 4, 'T': 20, 'seed': 42,
        'deliver_reward': 100, 'crash_cost': 500, 'timeout_cost': 50,
        'description': '高收益+高惩罚'
    })

    # 去重
    seen = set()
    unique_cases = []
    for c in cases:
        key = str(sorted([(k, v) for k, v in c.items() if k != 'description']))
        if key not in seen:
            seen.add(key)
            unique_cases.append(c)

    return unique_cases


def get_scale_generalization_cases():
    """
    规模泛化测试用例：变化网格大小 grid_size。
    注意：状态空间随 grid_size 指数增长！

    grid_size=3: 9 positions → 状态较少，DP快速
    grid_size=4: 16 positions → 原始问题
    grid_size=5: 25 positions → 状态约 4x
    grid_size=6: 36 positions → 状态约 10x
    grid_size=7: 49 positions → 可能较慢
    grid_size=8: 64 positions → 可能需要较长时间

    返回:
        list[dict]: 每个元素是传给 generate_instance 的参数字典
    """
    cases = []
    for gs in [3, 4, 5, 6, 7, 8]:
        # 对大网格适当增加时间段数和电量
        T = 20
        battery = 100
        if gs >= 6:
            T = 25  # 大网格需要更多时间
            battery = 120
        if gs >= 7:
            T = 30
            battery = 150

        cases.append({
            'grid_size': gs, 'T': T, 'seed': 42,
            'battery_capacity': battery,
            'description': f'网格大小 {gs}×{gs}'
        })
    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 实例信息打印
# ============================================================

def print_instance_info(instance, verbose=False):
    """打印实例信息摘要。"""
    gs = instance['grid_size']
    n_pos = instance['n_positions']
    n_non_base = instance['n_non_base']
    max_b = instance['max_battery']
    bu = instance['battery_unit']

    # 状态空间估算
    # 位置 × 电量等级 × 时间 × (无订单 + 有订单)
    battery_levels = max_b + 1
    no_order_states = n_pos * battery_levels * instance['T']
    # 有订单: pickup(n_non_base) × dropoff(n_pos-1) × TTL × carrying(2)
    order_combinations = n_non_base * (n_pos - 1) * instance['TTL'] * 2
    with_order_states = n_pos * battery_levels * instance['T'] * order_combinations
    total_states = no_order_states + with_order_states

    print(f"  网格: {gs}×{gs} ({n_pos}个位置)")
    print(f"  时间段: T={instance['T']}, TTL={instance['TTL']}")
    print(f"  订单概率: {instance['order_prob']:.2f}")
    print(f"  电量: max={max_b}×{bu}%={max_b*bu:.0f}%, "
          f"飞行-{instance['move_battery']}×{bu}%={instance['move_battery']*bu:.0f}%, "
          f"等待-{instance['wait_battery']}×{bu}%={instance['wait_battery']*bu:.0f}%, "
          f"充电+{instance['charge_battery']}×{bu}%={instance['charge_battery']*bu:.0f}%")
    print(f"  收益: 送达+{instance['deliver_reward']}, "
          f"超时-{instance['timeout_cost']}, "
          f"耗尽-{instance['crash_cost']}, "
          f"飞行-{instance['move_cost']}/格, "
          f"等待-{instance['wait_cost']}/步")
    print(f"  估算状态数: ~{total_states:,}")

    if verbose:
        print(f"  电量等级数: {battery_levels}")
        print(f"  订单组合数: {order_combinations}")
        print(f"  无订单状态: {no_order_states:,}")
        print(f"  有订单状态: {with_order_states:,}")


# ============================================================
# 验证默认参数能复现原始问题
# ============================================================

def verify_original():
    """验证默认参数生成的实例与原始问题参数完全一致。"""
    inst = generate_instance(grid_size=4, T=20, seed=42)
    orig = ORIGINAL_PARAMS

    checks = [
        ('grid_size', inst['grid_size'], orig['grid_size']),
        ('T', inst['T'], orig['T']),
        ('TTL', inst['TTL'], orig['T']),  # 不对，应该是 TTL
        ('order_prob', inst['order_prob'], orig['order_prob']),
        ('max_battery', inst['max_battery'], orig['max_battery']),
        ('move_battery', inst['move_battery'], orig['move_battery']),
        ('wait_battery', inst['wait_battery'], orig['wait_battery']),
        ('charge_battery', inst['charge_battery'], orig['charge_battery']),
        ('move_cost', inst['move_cost'], orig['move_cost']),
        ('wait_cost', inst['wait_cost'], orig['wait_cost']),
        ('crash_cost', inst['crash_cost'], orig['crash_cost']),
        ('timeout_cost', inst['timeout_cost'], orig['timeout_cost']),
        ('deliver_reward', inst['deliver_reward'], orig['deliver_reward']),
    ]

    all_match = True
    for name, actual, expected in checks:
        if name == 'TTL':
            expected = 8  # fix
        if actual != expected:
            print(f"  ✗ {name}: 期望={expected}, 实际={actual}")
            all_match = False

    return all_match


# ============================================================
# 主程序
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("MDP（无人机医疗配送）测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 验证默认参数复现原始问题 ------
    print("\n【1】默认参数 → 应复现原始问题数据")
    inst = generate_instance(grid_size=4, T=20, seed=42)
    print_instance_info(inst)

    if verify_original():
        print("  ✓ 所有参数与原始问题完全一致")
    else:
        print("  ✗ 存在参数不匹配")

    # 验证关键数值
    assert inst['order_prob'] == 0.2
    assert inst['TTL'] == 8
    assert inst['max_battery'] == 50
    assert inst['move_battery'] == 5
    assert inst['order_pair_prob'] == 0.2 / 225.0
    print("  ✓ 关键数值验证通过")

    # ------ 2. 代表性实例展示 ------
    print("\n" + "=" * 70)
    print("【2】代表性实例")
    print("=" * 70)

    demo_cases = [
        {'grid_size': 4, 'T': 20, 'seed': 42,
         'order_probability': 'high', 'ttl_range': 'short'},
        {'grid_size': 4, 'T': 20, 'seed': 42,
         'battery_capacity': 60, 'move_battery_pct': 15.0},
        {'grid_size': 6, 'T': 25, 'seed': 42,
         'battery_capacity': 120},
        {'grid_size': 3, 'T': 15, 'seed': 42},
    ]

    for params in demo_cases:
        desc = ', '.join(f'{k}={v}' for k, v in params.items())
        inst = generate_instance(**params)
        print(f"\n  --- {desc} ---")
        print_instance_info(inst)

    # ------ 3. 测试用例统计 ------
    print("\n" + "=" * 70)
    print("【3】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    # 打印所有用例摘要
    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    # ------ 4. 批量生成验证 ------
    print("\n" + "=" * 70)
    print("【4】批量生成验证（所有用例）")
    print("=" * 70)

    n_ok = 0
    n_total = len(all_cases)
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        try:
            inst = generate_instance(**params)
            # 基本合法性检查
            assert inst['max_battery'] >= 1
            assert inst['move_battery'] >= 1
            assert inst['T'] >= 1
            assert inst['TTL'] >= 2
            assert 0 < inst['order_prob'] < 1
            n_ok += 1
        except Exception as e:
            print(f"  ✗ 生成失败: {c['description']} → {e}")

    print(f"  合法实例: {n_ok}/{n_total}")
    if n_ok == n_total:
        print("  ✓ 所有测试用例均可正常生成")

    print(f"\n总测试用例数: {len(all_cases)}")
    print("\n完成。")
