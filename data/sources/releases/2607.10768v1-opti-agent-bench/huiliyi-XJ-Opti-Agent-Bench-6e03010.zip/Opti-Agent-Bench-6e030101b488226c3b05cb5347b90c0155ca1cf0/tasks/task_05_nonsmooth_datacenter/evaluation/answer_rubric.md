# Metric-Aligned Answer Rubric：非平滑优化 / 问题1_城市级多数据中心节能协同

## Problem Analysis

本题是一个**多时段、多数据中心任务调度与能源协同优化问题**。若精确建模，核心形式应为 **MILP / 混合整数线性规划**；题面称为非平滑优化，非平滑性主要来自：

- 峰值功率成本中的 `max_t g[j,t]`，可用辅助变量 `p_peak[j] >= g[j,t]` 线性化；
- 电池同一时段充放电互斥，可用二元变量、互斥约束，或在理想电池口径下用可解释的等价净功率变量处理。

关键建模口径：

- 在线任务 `x_on[i,j,t]` 必须当小时完成；
- 离线任务 `x_off[i,j,u,t]` 必须在到达时刻 `u` 与截止时刻 `D[u]` 之间完成；
- 任务量到 IT 功率的映射必须使用 `P_IT[j,t] = 500 * q[j,t]`；
- 站点取电必须满足 `g[j,t] = P_IT[j,t] + c[j,t] - d[j,t]` 且 `g[j,t] >= 0`；
- 电池 SoC 必须逐时段转移、上下界合规，并满足初末一致；
- 在线 SLA 只统计在线任务，不应把离线任务混入 SLA；
- 目标函数应最小化市电电费、峰值惩罚费和常数运营费；
- 若声称每小时 10 秒内滚动重算，应解释求解器、启发式、滚动窗口或 fallback 为什么可行。

关键陷阱：

- 只给规则式可行解，却包装成全局最优求解器；
- 换用与题面不一致的数据结构或硬编码 4 个中心、错误功率量纲；
- 省略来源区域维度或离线任务到达时刻维度；
- 不输出完整 `x_off`、SoC 末态或成本分解，导致无法复现；
- 只写评估脚本，而没有真正的求解器；
- 求解时限设置为 300/600 秒，却声称满足 10 秒重算；
- 只检查字段存在，不独立复算任务完成、功率平衡、SoC 和成本。

## Global Scoring Rules

- 每个统一指标满分为 5 分。
- 每个子项可按 `0 / partial / full` 给分；若证据明显不足，给 0。
- `Scoring Method = Automatic` 表示优先使用代码运行、输出解析、约束复算或依赖检查。
- `Scoring Method = LLM Judge` 表示由大模型根据回答文本进行语义评分。
- `Scoring Method = Hybrid` 表示先抽取代码或运行结果，再由大模型比较文本声明与实际实现。
- 本题当前目录没有 reference、实例生成器或多扰动结果文件；`test.py` 是模型调用入口，不是鲁棒性测试集。因此 `CE.3` 标记为 `NOT_IMPLEMENTED`，不纳入总分。

## ME.1 模型正确性

评估回答是否正确识别问题类型、变量、目标函数、非平滑结构和全部关键约束。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME1-R1 | 明确识别为多时段多数据中心协同调度问题，精确口径为 MILP / 混合整数结构 | response text | LLM Judge | 0.70 |
| ME1-R2 | 正确指出非平滑来源：峰值 `max` 与充放电互斥，而非泛泛称“非平滑” | response text | LLM Judge | 0.65 |
| ME1-R3 | 完整定义 `x_on[i,j,t]` 与 `x_off[i,j,u,t]`，保留来源、执行中心、到达时刻和执行时刻维度 | response text / code | Hybrid | 0.90 |
| ME1-R4 | 目标函数包含市电电费、峰值惩罚和运营费，且方向为最小化总成本 | response text / code | Hybrid | 0.70 |
| ME1-R5 | 正确建模在线完成、离线截止、IT 功率、功率平衡、SoC、互斥、SLA、峰值定义等核心约束 | response text / code | Hybrid | 1.25 |
| ME1-R6 | 正确使用 `P_IT = 500*q`、`0.9*peakIT`、SoC MWh/kW 换算和在线 SLA 统计口径 | response text / code | Hybrid | 0.80 |

ME.1 total: 5 points

## ME.2 模型简洁性

评估回答是否在不丢失关键结构的前提下，使用合适、聚焦且可执行的求解路线。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME2-R1 | 变量体系足够表达题面，但没有无关业务变量或过度泛化目标 | response text / code | LLM Judge | 0.85 |
| ME2-R2 | 对精确 MILP、滚动优化、启发式或 CP-SAT 等路线的选择与 10 秒要求匹配 | response text / code | Hybrid | 1.05 |
| ME2-R3 | 不擅自改题：不删中心、不改负载数据、不改电池单位、不更换输入 schema | response text / code | Hybrid | 1.10 |
| ME2-R4 | 若采用启发式，清楚承认其近似性，不把可行解生成器包装成全局最优 | response text | LLM Judge | 1.05 |
| ME2-R5 | 报告聚焦建模、求解、输出和自检，不被评估器设计、泛泛战略建议或模板文本淹没 | response text | LLM Judge | 0.95 |

ME.2 total: 5 points

## ME.3 模型-代码一致性

评估文字声明、代码实现和输出结果是否相互一致。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME3-R1 | 文本声称的问题类型与代码实际求解模型一致 | response text + code | Hybrid | 0.85 |
| ME3-R2 | 文本中的变量维度、目标和约束与代码实现一致 | response text + code | Hybrid | 1.10 |
| ME3-R3 | 文本声称的运行时限、求解器和精确性与实际代码参数一致 | response text + code | Hybrid | 0.90 |
| ME3-R4 | 文本声称的可行性、成本、延迟和得分能由代码或输出复现 | response text + execution result | Hybrid | 1.15 |
| ME3-R5 | 没有出现“代码只是评估器/规则脚本”但报告宣称“完整优化器/最优方案”的冲突 | response text + code | Hybrid | 1.00 |

ME.3 total: 5 points

## CE.1 代码可行性与正确性

评估代码是否可运行，并能产生满足题面硬约束的可复算结果。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE1-R1 | 提供可抽取、可执行的 Python 求解代码，而不是只有文字或评估脚本 | code block / extracted code | Automatic + LLM fallback | 0.80 |
| CE1-R2 | 原始代码可在题面 JSON 口径下运行，无缺失依赖、错误字段或不可写路径 | execution result | Automatic | 0.85 |
| CE1-R3 | 输出包含题面要求的 `x_on`、`x_off`、`g/c/d/s`、`p_peak`、`avgLatency`、成本分解和总成本 | code / output | Automatic + LLM Judge | 0.85 |
| CE1-R4 | 独立复算任务完成、离线截止、IT 功率、SoC、互斥、SLA 和峰值定义均通过 | execution result / output | Automatic | 1.45 |
| CE1-R5 | 代码真实进行优化或高质量近似调度，而非只做固定规则、硬编码验证或评估脚本 | code / execution result | Hybrid | 1.05 |

CE.1 total: 5 points

## CE.2 代码质量与效率

评估代码结构、依赖、接口、数值处理和工程可维护性。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE2-R1 | 代码结构清楚，数据解析、变量构造、求解、后处理和输出职责分明 | code | LLM Judge | 0.90 |
| CE2-R2 | 输入输出 schema 与题面一致，便于自动评测和后续 wrapper 调用 | code / output | Automatic + LLM Judge | 0.95 |
| CE2-R3 | 依赖选择合理，并处理求解失败、超时、无可行解、数值容差和 fallback | code / execution result | Hybrid | 1.05 |
| CE2-R4 | 计算效率与 10 秒滚动重算要求匹配，避免明显超时配置或指数级纯 Python 搜索 | code / response text | Hybrid | 1.00 |
| CE2-R5 | 包含独立自检或成本/约束复算，能够暴露功率、SoC、SLA 和成本错误 | code / response text | Hybrid | 1.10 |

CE.2 total: 5 points

## CE.3 代码鲁棒性

当前题目目录没有实例生成器、扰动测试集、泛化结果或 reference 脚本，不能对多实例鲁棒性做自动评分。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE3 | Robustness not implemented for this problem folder | folder inspection | Automatic | 5.00 |

CE.3 status: NOT_IMPLEMENTED. Exclude CE.3 from total score.

## RE.1 报告完整性

评估回答是否完整覆盖问题理解、数学模型、求解方法、输出结果和自检。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE1-R1 | 给出问题类型、非平滑来源和 MILP / 混合结构解释 | response text | LLM Judge | 0.80 |
| RE1-R2 | 给出完整数学模型：变量、目标、任务、功率、电池、SLA、峰值约束 | response text | LLM Judge | 1.25 |
| RE1-R3 | 给出可执行求解方法和 10 秒重算策略 | response text / code | LLM Judge + execution | 0.95 |
| RE1-R4 | 给出完整 JSON 输出结构，覆盖全部题面要求字段 | response text / code | LLM Judge + execution | 0.90 |
| RE1-R5 | 给出约束自检说明，逐项说明是否满足硬约束 | response text / output | LLM Judge + execution | 1.10 |

RE.1 total: 5 points

## RE.2 解释清晰度

评估回答是否清楚解释调度逻辑、非平滑处理、实时性与业务含义。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE2-R1 | 清楚解释峰值惩罚为什么需要 `p_peak` 线性化以及其成本含义 | response text | LLM Judge | 0.95 |
| RE2-R2 | 清楚解释电池互斥、SoC 转移和初末一致的物理含义 | response text | LLM Judge | 1.00 |
| RE2-R3 | 清楚解释在线任务 SLA 与离线任务截止弹性的区别 | response text | LLM Judge | 0.85 |
| RE2-R4 | 清楚解释精确求解、启发式、滚动优化或 CP-SAT 在 10 秒要求下的权衡 | response text | LLM Judge | 1.05 |
| RE2-R5 | 文字组织清楚，避免过度模板化、评估器喧宾夺主或与题面无关的长篇战略扩展 | response text | LLM Judge | 1.15 |

RE.2 total: 5 points

## RE.3 结果可复现性

评估报告声称的结果是否可以由代码实际运行和独立检查复现。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE3-R1 | 提供明确运行入口、依赖说明和输入文件口径 | response text / code | Automatic + LLM Judge | 0.85 |
| RE3-R2 | 原始代码可生成结果文件或标准输出，且不需额外补齐核心代码 | execution result | Automatic | 1.05 |
| RE3-R3 | 生成结果中的任务、功率、电池、SLA 和成本可独立复算 | execution result / output | Automatic | 1.25 |
| RE3-R4 | 报告中的总成本、延迟、约束通过情况与代码运行结果一致 | response text + execution result | Hybrid | 1.05 |
| RE3-R5 | 输出字段和索引格式稳定，便于后续自动评测 pipeline 读取 | code / output | Automatic + LLM Judge | 0.80 |

RE.3 total: 5 points

## RE.4 局限承认

评估回答是否诚实说明模型、算法、工程和评估局限。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE4-R1 | 承认精确 MILP 与 10 秒实时要求之间的张力 | response text | LLM Judge | 0.95 |
| RE4-R2 | 承认启发式、规则方案或时间截断求解可能不是全局最优 | response text | LLM Judge | 1.00 |
| RE4-R3 | 承认负载、电价、延迟和电池参数不确定性带来的鲁棒性风险 | response text | LLM Judge | 0.85 |
| RE4-R4 | 如实说明依赖、输入 schema、求解器、超时、缺失代码或输出不完整等实现限制 | response text + code | Hybrid | 1.20 |
| RE4-R5 | 不夸大“最优”“100分”“生产可用”或严格合规结论 | response text | LLM Judge | 1.00 |

RE.4 total: 5 points

## Expected Failure Modes

- 把 5 个中心改成 4 个中心，或使用与题面不同的负载、电价、电池参数。
- 只定义 `x_on[j,t]` / `x_off[j,t]`，丢失来源区域和离线到达时刻。
- 只做低价中心集中规则，不真正利用离线截止窗口和全局成本目标。
- SoC 只做边界钳位或末时段硬拉回初值，破坏能量守恒。
- 设置 300/600 秒求解时限，却声称每小时 10 秒内重算。
- 输出缺少 `x_off`、`avgLatency`、`cost_breakdown` 或 SoC 末态，导致后续评测不能复算。
- 只写评估脚本或评审报告，没有真正生成调度方案。
- 把“满足硬约束”误当成“成本最优”。
