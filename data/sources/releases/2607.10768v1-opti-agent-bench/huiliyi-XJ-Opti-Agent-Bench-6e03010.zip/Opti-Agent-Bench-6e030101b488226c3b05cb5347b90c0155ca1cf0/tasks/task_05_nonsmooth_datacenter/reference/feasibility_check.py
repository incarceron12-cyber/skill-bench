#!/usr/bin/env python3
"""Feasibility + independent cost recompute for the datacenter nonsmooth problem.

Usage:
  python feasibility_check.py --instance ../data/instance.json --solution solution.json
  python feasibility_check.py --solution solution.json   # uses sibling data/instance.json

Expected solution JSON keys (flexible nesting OK):
  x_on, x_off, grid_power|g, charge_power|c, discharge_power|d, soc|s,
  p_peak, avgLatency (optional), cost_breakdown (optional), total_cost (optional)
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


CENTERS = ["A", "B", "C", "D", "E"]
HOURS = list(range(1, 25))
TOL = 1e-4
IT_TOL = 1e-2  # kW; CBC solutions often sit on the util bound
COST_TOL = 1.0  # yuan


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _get(sol: dict, *keys: str, default=None):
    for k in keys:
        if k in sol:
            return sol[k]
    return default


def _as_center_hour_matrix(obj: Any, name: str) -> dict[str, list[float]]:
    """Normalize to {center: [v_t for t=1..24]}."""
    if obj is None:
        raise ValueError(f"missing field: {name}")
    out: dict[str, list[float]] = {}
    if isinstance(obj, dict):
        for j in CENTERS:
            if j not in obj:
                raise ValueError(f"{name}: missing center {j}")
            row = obj[j]
            if isinstance(row, dict):
                vals = [float(row[str(t)] if str(t) in row else row[t]) for t in HOURS]
            else:
                vals = [float(x) for x in row]
                if len(vals) != 24:
                    raise ValueError(f"{name}[{j}] must have 24 values")
            out[j] = vals
        return out
    raise ValueError(f"{name}: unsupported type {type(obj)}")


def _x_on_lookup(x_on: Any, i: str, j: str, t: int) -> float:
    """x_on indexed as [i][j][t] with t in 1..24 or 0..23."""
    if not isinstance(x_on, dict):
        raise ValueError("x_on must be a nested dict")
    row_i = x_on[i]
    if isinstance(row_i, dict):
        row_j = row_i[j]
        if isinstance(row_j, dict):
            if str(t) in row_j:
                return float(row_j[str(t)])
            if t in row_j:
                return float(row_j[t])
            if str(t - 1) in row_j:
                return float(row_j[str(t - 1)])
            return float(row_j[t - 1])
        # list length 24
        return float(row_j[t - 1])
    raise ValueError("x_on nesting not recognized")


def _x_off_lookup(x_off: Any, i: str, j: str, u: int, t: int) -> float:
    """Best-effort lookup for x_off[i][j][u][t] or flattened keys."""
    if x_off is None:
        return 0.0
    if not isinstance(x_off, dict):
        raise ValueError("x_off must be a nested dict")
    node = x_off[i][j]
    # nested dict u -> t -> val
    if isinstance(node, dict):
        # key may be "u,t" or nested
        key = f"{u},{t}"
        if key in node:
            return float(node[key])
        if str(u) in node or u in node:
            sub = node[str(u)] if str(u) in node else node[u]
            if isinstance(sub, dict):
                if str(t) in sub:
                    return float(sub[str(t)])
                if t in sub:
                    return float(sub[t])
                return float(sub[t - 1])
            if isinstance(sub, list):
                # indexed by t-u or by absolute t
                if len(sub) == 24:
                    return float(sub[t - 1])
                return float(sub[t - u])
        return 0.0
    return 0.0


def build_demands(instance: dict) -> tuple[dict[str, list[float]], dict[str, list[float]], list[int]]:
    params = instance["parameters"]
    online = instance["online_Mreq"]
    ratio = float(params["offline_ratio"])
    deadlines = list(instance["offline_deadline_hour_by_arrival"])
    O = {i: [float(x) for x in online[i]] for i in CENTERS}
    B = {i: [ratio * O[i][t] for t in range(24)] for i in CENTERS}
    return O, B, deadlines


def recompute(instance: dict, sol: dict) -> dict:
    params = instance["parameters"]
    centers = instance["centers"]
    init = instance["battery_init_soc_MWh"]
    O, B, deadlines = build_demands(instance)
    pit = float(params["it_power_kW_per_Mreq"])
    util = float(params["it_util_limit"])
    lat_lim = float(params["online_latency_limit_ms"])

    x_on = _get(sol, "x_on")
    x_off = _get(sol, "x_off", default={})
    g = _as_center_hour_matrix(_get(sol, "grid_power", "g"), "grid_power")
    c = _as_center_hour_matrix(_get(sol, "charge_power", "c"), "charge_power")
    d = _as_center_hour_matrix(_get(sol, "discharge_power", "d"), "discharge_power")
    s = _as_center_hour_matrix(_get(sol, "soc", "s"), "soc")
    p_peak_raw = _get(sol, "p_peak")
    if p_peak_raw is None:
        raise ValueError("missing p_peak")
    p_peak = {j: float(p_peak_raw[j]) for j in CENTERS}

    violations: list[str] = []

    # 5.1 online completion
    for i in CENTERS:
        for ti, t in enumerate(HOURS):
            total = sum(_x_on_lookup(x_on, i, j, t) for j in CENTERS)
            if abs(total - O[i][ti]) > TOL:
                violations.append(
                    f"online completion {i},t={t}: got {total:.6f}, need {O[i][ti]:.6f}"
                )

    # 5.1 offline completion
    for i in CENTERS:
        for ui, u in enumerate(HOURS):
            D = int(deadlines[ui])
            total = 0.0
            for j in CENTERS:
                for t in range(u, D + 1):
                    val = _x_off_lookup(x_off, i, j, u, t)
                    if val < -TOL:
                        violations.append(f"negative x_off {i},{j},u={u},t={t}")
                    if t < u or t > D:
                        if abs(val) > TOL:
                            violations.append(f"x_off outside window {i},{j},u={u},t={t}")
                    total += val
            if abs(total - B[i][ui]) > 1e-3:
                violations.append(
                    f"offline completion {i},u={u}: got {total:.6f}, need {B[i][ui]:.6f}"
                )

    # q, IT power, energy balance, battery
    q: dict[str, list[float]] = {j: [0.0] * 24 for j in CENTERS}
    for j in CENTERS:
        for ti, t in enumerate(HOURS):
            qjt = sum(_x_on_lookup(x_on, i, j, t) for i in CENTERS)
            for i in CENTERS:
                for u in range(1, t + 1):
                    qjt += _x_off_lookup(x_off, i, j, u, t)
            q[j][ti] = qjt
            p_it = pit * qjt
            if p_it - util * centers[j]["peakIT_kW"] > IT_TOL:
                violations.append(
                    f"IT util {j},t={t}: P_IT={p_it:.3f} > {util}*peakIT"
                )
            # charge/discharge bounds + mutex
            cj, dj = c[j][ti], d[j][ti]
            lim = centers[j]["battery"]["powerLimit_kW"]
            if cj < -TOL or dj < -TOL or cj - lim > TOL or dj - lim > TOL:
                violations.append(f"battery power bounds {j},t={t}")
            if cj > TOL and dj > TOL:
                violations.append(f"charge/discharge mutex {j},t={t}")
            # grid identity
            g_calc = p_it + cj - dj
            if abs(g_calc - g[j][ti]) > 1e-2:
                violations.append(
                    f"grid identity {j},t={t}: reported {g[j][ti]:.4f}, calc {g_calc:.4f}"
                )
            if g[j][ti] < -TOL:
                violations.append(f"negative grid {j},t={t}")
            if p_peak[j] + TOL < g[j][ti]:
                violations.append(f"p_peak[{j}] < g[{j},{t}]")

    # SoC dynamics: treat s[j][t-1] as end-of-hour t; start from init
    for j in CENTERS:
        soc = float(init[j])
        cap = centers[j]["battery"]["capacity_MWh"]
        for ti, t in enumerate(HOURS):
            soc = soc + (c[j][ti] - d[j][ti]) / 1000.0
            if soc < -TOL or soc - cap > TOL:
                violations.append(f"SoC bounds {j},t={t}: {soc:.6f}")
            if abs(soc - s[j][ti]) > 1e-2:
                violations.append(
                    f"SoC mismatch {j},t={t}: reported {s[j][ti]:.6f}, calc {soc:.6f}"
                )
        if abs(soc - float(init[j])) > 1e-2:
            violations.append(
                f"SoC cyclic {j}: end {soc:.6f} != init {float(init[j]):.6f}"
            )

    # SLA
    lat_num = 0.0
    lat_den = 0.0
    for i in CENTERS:
        for ti, t in enumerate(HOURS):
            lat_den += O[i][ti]
            for j in CENTERS:
                lat_num += centers[j]["latency_ms"] * _x_on_lookup(x_on, i, j, t)
    avg_lat = lat_num / lat_den if lat_den else 0.0
    if avg_lat - lat_lim > TOL:
        violations.append(f"avgLatency {avg_lat:.4f} > {lat_lim}")

    # costs (price * g with g in kW * 1h = kWh)
    energy_cost = 0.0
    peak_cost = 0.0
    ops = 0.0
    for j in CENTERS:
        prices = centers[j]["gridPrice_yuan_per_kWh"]
        for ti in range(24):
            energy_cost += prices[ti] * g[j][ti]
        peak_cost += centers[j]["peakPenalty_yuan_per_kW"] * p_peak[j]
        ops += 0.001 * sum(q[j])
    # all tasks completed => ops is constant; still report
    total = energy_cost + peak_cost + ops

    reported_total = _get(sol, "total_cost")
    if reported_total is not None and abs(float(reported_total) - total) > COST_TOL:
        violations.append(
            f"total_cost mismatch: reported {reported_total}, recomputed {total:.4f}"
        )

    reported_lat = _get(sol, "avgLatency")
    if reported_lat is not None and abs(float(reported_lat) - avg_lat) > 1e-2:
        violations.append(
            f"avgLatency mismatch: reported {reported_lat}, recomputed {avg_lat:.4f}"
        )

    return {
        "feasible": len(violations) == 0,
        "n_violations": len(violations),
        "violations": violations[:50],
        "recomputed": {
            "avgLatency": avg_lat,
            "energy_cost": energy_cost,
            "peak_cost": peak_cost,
            "ops_cost": ops,
            "total_cost": total,
            "p_peak": p_peak,
        },
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--instance", type=Path, default=None)
    ap.add_argument("--solution", type=Path, required=True)
    ap.add_argument("--out", type=Path, default=None)
    args = ap.parse_args()

    here = Path(__file__).resolve().parent
    inst_path = args.instance or (here.parent / "data" / "instance.json")
    instance = _load_json(inst_path)
    sol = _load_json(args.solution)
    report = recompute(instance, sol)
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    print(text)
    raise SystemExit(0 if report["feasible"] else 1)


if __name__ == "__main__":
    main()
