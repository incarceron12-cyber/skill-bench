# Reference — `task_05_nonsmooth_datacenter`

| File | Role |
|------|------|
| `feasibility_check.py` | Validate candidate JSON + independently recompute cost / latency |
| `reference_solve.py` | PuLP+CBC MILP reference solver |
| `reference_solution.json` | Reference feasible solution |
| `optimal_value.json` | Reference objective on the public instance |

```bash
python reference_solve.py
python feasibility_check.py --solution reference_solution.json
```
