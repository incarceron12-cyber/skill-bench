#!/usr/bin/env python3
"""Reference MILP (PuLP) for the datacenter problem + self-check.

Writes:
  reference_solution.json
  optimal_value.json   (best objective found by this reference; not a global proof)
"""

from __future__ import annotations

import json
from pathlib import Path

import pulp

CENTERS = ["A", "B", "C", "D", "E"]
HOURS = list(range(1, 25))


def solve(instance: dict, time_limit: int = 120) -> dict:
    params = instance["parameters"]
    centers = instance["centers"]
    init = instance["battery_init_soc_MWh"]
    deadlines = instance["offline_deadline_hour_by_arrival"]
    O = {i: [float(x) for x in instance["online_Mreq"][i]] for i in CENTERS}
    ratio = float(params["offline_ratio"])
    B = {i: [ratio * O[i][t] for t in range(24)] for i in CENTERS}
    pit = float(params["it_power_kW_per_Mreq"])
    util = float(params["it_util_limit"])
    lat_lim = float(params["online_latency_limit_ms"])

    m = pulp.LpProblem("datacenter", pulp.LpMinimize)

    x_on = pulp.LpVariable.dicts("xon", (CENTERS, CENTERS, HOURS), lowBound=0)
    # offline only for valid windows
    x_off = {}
    for i in CENTERS:
        for j in CENTERS:
            for u in HOURS:
                D = int(deadlines[u - 1])
                for t in range(u, D + 1):
                    x_off[(i, j, u, t)] = pulp.LpVariable(f"xoff_{i}_{j}_{u}_{t}", lowBound=0)

    g = pulp.LpVariable.dicts("g", (CENTERS, HOURS), lowBound=0)
    c = pulp.LpVariable.dicts("c", (CENTERS, HOURS), lowBound=0)
    d = pulp.LpVariable.dicts("d", (CENTERS, HOURS), lowBound=0)
    s = pulp.LpVariable.dicts("s", (CENTERS, HOURS), lowBound=0)
    p_peak = pulp.LpVariable.dicts("peak", CENTERS, lowBound=0)
    z = pulp.LpVariable.dicts("chg", (CENTERS, HOURS), cat="Binary")  # 1 => charge mode

    # online completion
    for i in CENTERS:
        for t in HOURS:
            m += pulp.lpSum(x_on[i][j][t] for j in CENTERS) == O[i][t - 1]

    # offline completion
    for i in CENTERS:
        for u in HOURS:
            D = int(deadlines[u - 1])
            m += (
                pulp.lpSum(x_off[(i, j, u, t)] for j in CENTERS for t in range(u, D + 1))
                == B[i][u - 1]
            )

    # IT + grid + battery
    for j in CENTERS:
        cap = centers[j]["battery"]["capacity_MWh"]
        plim = centers[j]["battery"]["powerLimit_kW"]
        it_cap = util * centers[j]["peakIT_kW"]
        for t in HOURS:
            q = pulp.lpSum(x_on[i][j][t] for i in CENTERS) + pulp.lpSum(
                x_off[(i, j, u, t)]
                for i in CENTERS
                for u in HOURS
                if u <= t <= int(deadlines[u - 1]) and (i, j, u, t) in x_off
            )
            p_it = pit * q
            m += p_it <= it_cap
            m += g[j][t] == p_it + c[j][t] - d[j][t]
            m += c[j][t] <= plim * z[j][t]
            m += d[j][t] <= plim * (1 - z[j][t])
            m += p_peak[j] >= g[j][t]
            if t == 1:
                m += s[j][t] == float(init[j]) + (c[j][t] - d[j][t]) / 1000.0
            else:
                m += s[j][t] == s[j][t - 1] + (c[j][t] - d[j][t]) / 1000.0
            m += s[j][t] <= cap
        m += s[j][24] == float(init[j])

    # SLA
    lat_num = pulp.lpSum(
        centers[j]["latency_ms"] * x_on[i][j][t]
        for i in CENTERS
        for j in CENTERS
        for t in HOURS
    )
    lat_den = sum(sum(O[i]) for i in CENTERS)
    m += lat_num <= lat_lim * lat_den

    # objective
    energy = pulp.lpSum(
        centers[j]["gridPrice_yuan_per_kWh"][t - 1] * g[j][t]
        for j in CENTERS
        for t in HOURS
    )
    peak = pulp.lpSum(centers[j]["peakPenalty_yuan_per_kW"] * p_peak[j] for j in CENTERS)
    ops = 0.001 * pulp.lpSum(
        x_on[i][j][t] for i in CENTERS for j in CENTERS for t in HOURS
    ) + 0.001 * pulp.lpSum(x_off.values())
    m += energy + peak + ops

    solver = pulp.PULP_CBC_CMD(msg=False, timeLimit=time_limit)
    status = m.solve(solver)
    status_name = pulp.LpStatus[status]
    if status_name not in ("Optimal", "Feasible"):
        raise RuntimeError(f"solver status={status_name}")

    def val(v):
        return float(pulp.value(v) or 0.0)

    sol_x_on = {i: {j: [val(x_on[i][j][t]) for t in HOURS] for j in CENTERS} for i in CENTERS}
    sol_x_off = {i: {j: {} for j in CENTERS} for i in CENTERS}
    for (i, j, u, t), var in x_off.items():
        vv = val(var)
        if vv > 1e-9:
            sol_x_off[i][j][f"{u},{t}"] = vv

    g_out = {j: [val(g[j][t]) for t in HOURS] for j in CENTERS}
    c_out = {j: [val(c[j][t]) for t in HOURS] for j in CENTERS}
    d_out = {j: [val(d[j][t]) for t in HOURS] for j in CENTERS}
    s_out = {j: [val(s[j][t]) for t in HOURS] for j in CENTERS}
    peak_out = {j: val(p_peak[j]) for j in CENTERS}
    avg_lat = val(lat_num) / lat_den
    total = val(m.objective)

    return {
        "status": status_name.lower(),
        "method": "pulp_cbc_milp",
        "x_on": sol_x_on,
        "x_off": sol_x_off,
        "grid_power": g_out,
        "charge_power": c_out,
        "discharge_power": d_out,
        "soc": s_out,
        "p_peak": peak_out,
        "avgLatency": avg_lat,
        "cost_breakdown": {
            "energy_cost": val(energy),
            "peak_cost": val(peak),
            "ops_cost": val(ops),
        },
        "total_cost": total,
    }


def main():
    here = Path(__file__).resolve().parent
    instance = json.loads((here.parent / "data" / "instance.json").read_text(encoding="utf-8"))
    sol = solve(instance)
    (here / "reference_solution.json").write_text(
        json.dumps(sol, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (here / "optimal_value.json").write_text(
        json.dumps(
            {
                "sense": "minimize",
                "objective": sol["total_cost"],
                "avgLatency": sol["avgLatency"],
                "solver": "PuLP+CBC MILP",
                "note": "Reference reference objective on the public instance; use feasibility_check.py to validate candidate solutions.",
                "solution_file": "reference_solution.json",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    from feasibility_check import recompute

    report = recompute(instance, sol)
    print(
        json.dumps(
            {"objective": sol["total_cost"], "avgLatency": sol["avgLatency"], "check": report},
            ensure_ascii=False,
            indent=2,
        )
    )
    if not report["feasible"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
