"""
两阶段随机优化测试实例生成器
=============================
为「区域配送网络规划」两阶段随机优化问题生成泛化性测试用例。

问题结构：
  - N_cities 个候选城市（同时是需求区域）
  - 每个城市可选 K 种容量等级的配送中心
  - 第一阶段：选址 + 容量选择 + 初始库存（需求未知时）
  - 第二阶段：调拨 + 配送 + 紧急补货 + 缺货处理（需求实现后）
  - 多个需求情景，各有概率
  - 目标：最大化期望利润

参数字典结构：
  cities            : list[str]         城市代号列表
  capacity_levels   : dict{str:float}   容量等级 → 容量（万件）
  build_cost        : dict{(city,level):float}  建设成本（万元）
  transfer_surcharge: dict{(i,j):float} 跨区域附加费（元/件），双向
  deliver_cost      : dict{(i,j):float} 配送成本（元/件），含基础15+附加
  scenarios         : list[dict]        每个情景 {prob, demand:{city:float}}
  c_stock           : float             库存采购成本（元/件）
  c_base_delivery   : float             基础配送成本（元/件）
  c_emergency       : float             紧急空运成本（元/件）
  c_penalty         : float             缺货惩罚（元/件）
  c_salvage         : float             库存残值（元/件）
  revenue           : float             销售收入（元/件）
  budget            : float             总建设预算（万元）
  min_facilities    : int               最少配送中心数
  max_facilities    : int               最多配送中心数
  emergency_ratio   : float             紧急补货占总需求比例上限
"""

import random
import math

# ============================================================
# 原始问题数据（N_cities=4, 问题描述中的精确数据）
# ============================================================

ORIGINAL_CITIES = ["杭州", "南京", "苏州", "合肥"]

ORIGINAL_CAPACITY = {"小型": 5.0, "中型": 10.0, "大型": 18.0}

ORIGINAL_BUILD_COST = {
    ("杭州", "小型"): 80, ("杭州", "中型"): 150, ("杭州", "大型"): 240,
    ("南京", "小型"): 70, ("南京", "中型"): 140, ("南京", "大型"): 220,
    ("苏州", "小型"): 75, ("苏州", "中型"): 145, ("苏州", "大型"): 230,
    ("合肥", "小型"): 60, ("合肥", "中型"): 120, ("合肥", "大型"): 200,
}

ORIGINAL_SURCHARGE = {
    ("杭州", "南京"): 8, ("南京", "杭州"): 8,
    ("杭州", "苏州"): 6, ("苏州", "杭州"): 6,
    ("杭州", "合肥"): 12, ("合肥", "杭州"): 12,
    ("南京", "苏州"): 7, ("苏州", "南京"): 7,
    ("南京", "合肥"): 9, ("合肥", "南京"): 9,
    ("苏州", "合肥"): 10, ("合肥", "苏州"): 10,
}

ORIGINAL_SCENARIOS = [
    {"prob": 0.3, "demand": {"杭州": 12, "南京": 10, "苏州": 11, "合肥": 8}},
    {"prob": 0.5, "demand": {"杭州": 8, "南京": 7, "苏州": 7.5, "合肥": 5}},
    {"prob": 0.2, "demand": {"杭州": 5, "南京": 4, "苏州": 4.5, "合肥": 3}},
]

ORIGINAL_COSTS = {
    "c_stock": 50, "revenue": 200, "c_base_delivery": 15,
    "c_emergency": 120, "c_penalty": 80, "c_salvage": 30,
    "budget": 500, "min_facilities": 2, "max_facilities": 3,
    "emergency_ratio": 0.2,
}


# ============================================================
# 数据生成器
# ============================================================

def generate_instance(N_cities=4, seed=42, capacity_options=None,
                      demand_variance='medium', cost_scale=1.0,
                      n_scenarios=3, budget_scale=1.0,
                      emergency_ratio=0.2):
    """
    生成一个合法的两阶段随机优化问题实例。

    参数:
        N_cities: 候选城市/配送中心数量（>=3）
        seed: 随机种子（保证可复现）
        capacity_options: 容量等级字典，None则使用默认（小/中/大）
        demand_variance: 需求方差水平 'low'/'medium'/'high'
            - low: 情景间需求差异小（火爆/低迷偏差约±20%）
            - medium: 原始问题级别（火爆/低迷偏差约±40-50%）
            - high: 需求剧烈波动（火爆/低迷偏差约±60-80%）
        cost_scale: 成本缩放因子（影响建设成本和运营成本）
        n_scenarios: 需求情景数量（>=2）
        budget_scale: 预算缩放因子（1.0=原始比例）
        emergency_ratio: 紧急补货占总需求比例上限

    返回:
        dict: 包含问题所有参数的字典
    """
    assert N_cities >= 3, "至少需要3个候选城市"
    assert demand_variance in ('low', 'medium', 'high')
    assert n_scenarios >= 2, "至少需要2个情景"

    rng = random.Random(seed)

    # --- 容量等级 ---
    if capacity_options is not None:
        cap_levels = dict(capacity_options)
    else:
        cap_levels = dict(ORIGINAL_CAPACITY)

    level_names = list(cap_levels.keys())

    # --- 城市列表 ---
    if N_cities == 4 and demand_variance == 'medium' and cost_scale == 1.0 \
            and n_scenarios == 3 and budget_scale == 1.0 \
            and capacity_options is None and emergency_ratio == 0.2:
        # 完全复现原始问题
        return _build_original_instance()

    # 生成城市名称
    city_pool = ["杭州", "南京", "苏州", "合肥", "上海", "无锡",
                 "宁波", "温州", "常州", "徐州", "嘉兴", "绍兴",
                 "泰州", "扬州", "镇江", "湖州", "芜湖", "马鞍山",
                 "盐城", "连云港"]
    if N_cities <= len(city_pool):
        cities = city_pool[:N_cities]
    else:
        cities = city_pool[:]
        for i in range(len(city_pool), N_cities):
            cities.append(f"城市{i+1}")

    # --- 建设成本 ---
    build_cost = {}
    # 基准成本范围（每种等级）
    base_cost_ranges = {
        "小型": (50, 90),
        "中型": (110, 160),
        "大型": (180, 250),
    }
    # 如果有自定义容量等级，按容量比例生成成本
    if capacity_options is not None:
        sorted_levels = sorted(cap_levels.items(), key=lambda x: x[1])
        for ci, city in enumerate(cities):
            for li, (level, cap) in enumerate(sorted_levels):
                # 成本与容量大致正相关，加随机扰动
                base = 40 + cap * 12 * cost_scale
                perturb = rng.uniform(0.85, 1.15)
                build_cost[(city, level)] = round(base * perturb)
    else:
        for ci, city in enumerate(cities):
            if ci < 4:
                # 前4个城市基于原始数据
                orig_city = ORIGINAL_CITIES[ci]
                for level in level_names:
                    orig_cost = ORIGINAL_BUILD_COST[(orig_city, level)]
                    build_cost[(city, level)] = round(orig_cost * cost_scale)
            else:
                for level in level_names:
                    lo, hi = base_cost_ranges[level]
                    base = rng.randint(lo, hi)
                    build_cost[(city, level)] = round(base * cost_scale)

    # --- 跨区域附加费 ---
    transfer_surcharge = {}
    for i, ci in enumerate(cities):
        for j, cj in enumerate(cities):
            if i == j:
                continue
            if i < 4 and j < 4:
                # 前4个城市用原始数据
                oi, oj = ORIGINAL_CITIES[i], ORIGINAL_CITIES[j]
                if (oi, oj) in ORIGINAL_SURCHARGE:
                    transfer_surcharge[(ci, cj)] = ORIGINAL_SURCHARGE[(oi, oj)]
                    continue
            # 随机生成，距离越远（index差越大）费用越高
            dist_factor = abs(i - j) + rng.uniform(0, 2)
            fee = round(4 + dist_factor * 2.5)
            fee = max(5, min(fee, 20))  # 限制在5-20元/件
            transfer_surcharge[(ci, cj)] = fee
            transfer_surcharge[(cj, ci)] = fee

    # --- 配送成本矩阵 ---
    c_base = round(15 * cost_scale)
    deliver_cost = {}
    for ci in cities:
        for cj in cities:
            if ci == cj:
                deliver_cost[(ci, cj)] = c_base
            else:
                deliver_cost[(ci, cj)] = c_base + transfer_surcharge.get((ci, cj), 10)

    # --- 需求情景 ---
    # 生成基准需求（万件）
    base_demands = {}
    for ci, city in enumerate(cities):
        if ci < 4:
            # 基于原始正常情景需求
            orig_city = ORIGINAL_CITIES[ci]
            base_demands[city] = ORIGINAL_SCENARIOS[1]["demand"][orig_city]
        else:
            base_demands[city] = round(rng.uniform(3, 10), 1)

    # 方差级别对应的偏差比例
    variance_config = {
        'low':    (0.15, 0.25),   # 火爆/低迷偏差比例范围
        'medium': (0.35, 0.55),
        'high':   (0.60, 0.90),
    }
    dev_lo, dev_hi = variance_config[demand_variance]

    scenarios = []
    if n_scenarios == 3:
        # 经典三情景：火爆/正常/低迷
        probs = [0.3, 0.5, 0.2]
        multipliers = []
        for label in ['boom', 'normal', 'bust']:
            if label == 'normal':
                multipliers.append({c: 1.0 for c in cities})
            elif label == 'boom':
                m = {}
                for c in cities:
                    dev = rng.uniform(dev_lo, dev_hi)
                    m[c] = 1.0 + dev
                multipliers.append(m)
            else:
                m = {}
                for c in cities:
                    dev = rng.uniform(dev_lo, dev_hi)
                    m[c] = max(0.2, 1.0 - dev)
                multipliers.append(m)

        for pi, mult_dict in enumerate(multipliers):
            demand = {}
            for c in cities:
                demand[c] = round(base_demands[c] * mult_dict[c], 1)
            scenarios.append({"prob": probs[pi], "demand": demand})
    else:
        # 多情景：等概率或随机概率
        raw_probs = [rng.random() for _ in range(n_scenarios)]
        total_p = sum(raw_probs)
        probs = [round(p / total_p, 4) for p in raw_probs]
        # 确保概率和为1
        probs[-1] = round(1.0 - sum(probs[:-1]), 4)

        for si in range(n_scenarios):
            demand = {}
            for c in cities:
                # 围绕基准需求波动
                dev = rng.uniform(-dev_hi, dev_hi)
                demand[c] = round(max(0.5, base_demands[c] * (1.0 + dev)), 1)
            scenarios.append({"prob": probs[si], "demand": demand})

    # --- 预算 ---
    # 基准：能建 max_facilities 个中型仓的成本
    avg_mid_cost = sum(build_cost.get((c, "中型"), build_cost.get((c, level_names[len(level_names)//2]), 100))
                       for c in cities) / len(cities)
    max_fac = min(N_cities, max(3, N_cities // 2 + 1))
    min_fac = 2
    base_budget = avg_mid_cost * max_fac * 1.1
    budget = round(base_budget * budget_scale)

    # 确保至少能建 min_fac 个最小仓
    min_costs_sorted = sorted(build_cost[(c, level_names[0])] for c in cities)
    min_budget_needed = sum(min_costs_sorted[:min_fac])
    budget = max(budget, min_budget_needed + 10)

    # --- 成本参数 ---
    instance = {
        "cities": cities,
        "capacity_levels": cap_levels,
        "build_cost": build_cost,
        "transfer_surcharge": transfer_surcharge,
        "deliver_cost": deliver_cost,
        "scenarios": scenarios,
        "c_stock": round(50 * cost_scale),
        "c_base_delivery": c_base,
        "c_emergency": round(120 * cost_scale),
        "c_penalty": round(80 * cost_scale),
        "c_salvage": round(30 * cost_scale),
        "revenue": 200,  # 收入不随cost_scale变化
        "budget": budget,
        "min_facilities": min_fac,
        "max_facilities": max_fac,
        "emergency_ratio": emergency_ratio,
    }
    return instance


def _build_original_instance():
    """构建完全复现原始问题数据的实例。"""
    cities = list(ORIGINAL_CITIES)
    deliver_cost = {}
    for ci in cities:
        for cj in cities:
            if ci == cj:
                deliver_cost[(ci, cj)] = 15
            else:
                deliver_cost[(ci, cj)] = 15 + ORIGINAL_SURCHARGE[(ci, cj)]

    return {
        "cities": cities,
        "capacity_levels": dict(ORIGINAL_CAPACITY),
        "build_cost": dict(ORIGINAL_BUILD_COST),
        "transfer_surcharge": dict(ORIGINAL_SURCHARGE),
        "deliver_cost": deliver_cost,
        "scenarios": [dict(s) for s in ORIGINAL_SCENARIOS],
        "c_stock": 50,
        "c_base_delivery": 15,
        "c_emergency": 120,
        "c_penalty": 80,
        "c_salvage": 30,
        "revenue": 200,
        "budget": 500,
        "min_facilities": 2,
        "max_facilities": 3,
        "emergency_ratio": 0.2,
    }


# ============================================================
# 辅助：用 PuLP 求解一个实例（验证可行性）
# ============================================================

def solve_instance(instance):
    """
    用 PuLP 求解一个实例，返回 (status, objective_value)。
    如果 PuLP 未安装则返回 None。
    """
    try:
        import pulp
    except ImportError:
        return None

    d = instance
    cities = d["cities"]
    levels = list(d["capacity_levels"].keys())
    cap = d["capacity_levels"]
    scenarios = d["scenarios"]

    model = pulp.LpProblem("TwoStage_DC_Network", pulp.LpMaximize)

    # 第一阶段变量
    y = pulp.LpVariable.dicts("y", [(i, k) for i in cities for k in levels], cat="Binary")
    x = pulp.LpVariable.dicts("x", cities, lowBound=0)

    # 第二阶段变量（每个情景）
    pairs = [(i, j) for i in cities for j in cities if i != j]
    n_sc = len(scenarios)

    t = pulp.LpVariable.dicts("t", [(i, j, s) for (i, j) in pairs for s in range(n_sc)], lowBound=0)
    dd = pulp.LpVariable.dicts("d", [(i, j, s) for i in cities for j in cities for s in range(n_sc)], lowBound=0)
    e = pulp.LpVariable.dicts("e", [(i, s) for i in cities for s in range(n_sc)], lowBound=0)
    u = pulp.LpVariable.dicts("u", [(j, s) for j in cities for s in range(n_sc)], lowBound=0)
    l = pulp.LpVariable.dicts("l", [(i, s) for i in cities for s in range(n_sc)], lowBound=0)

    # 目标函数
    cost_build = pulp.lpSum(d["build_cost"][(i, k)] * y[(i, k)] for i in cities for k in levels)
    cost_stock = pulp.lpSum(d["c_stock"] * x[i] for i in cities)

    expected_ops = []
    for s, sc in enumerate(scenarios):
        prob_s = sc["prob"]
        demand_s = sc["demand"]
        total_demand_s = sum(demand_s.values())

        rev = pulp.lpSum(d["revenue"] * (demand_s[j] - u[(j, s)]) for j in cities)
        cost_trans = pulp.lpSum(d["transfer_surcharge"].get((i, j), 10) * t[(i, j, s)] for (i, j) in pairs)
        cost_del = pulp.lpSum(d["deliver_cost"][(i, j)] * dd[(i, j, s)] for i in cities for j in cities)
        cost_emer = pulp.lpSum(d["c_emergency"] * e[(i, s)] for i in cities)
        cost_pen = pulp.lpSum(d["c_penalty"] * u[(j, s)] for j in cities)
        salvage = pulp.lpSum(d["c_salvage"] * l[(i, s)] for i in cities)

        sc_profit = rev - cost_trans - cost_del - cost_emer - cost_pen + salvage
        expected_ops.append(prob_s * sc_profit)

    model += pulp.lpSum(expected_ops) - cost_build - cost_stock

    # 约束
    for i in cities:
        model += pulp.lpSum(y[(i, k)] for k in levels) <= 1
    model += pulp.lpSum(y[(i, k)] for i in cities for k in levels) >= d["min_facilities"]
    model += pulp.lpSum(y[(i, k)] for i in cities for k in levels) <= d["max_facilities"]
    model += cost_build <= d["budget"]
    for i in cities:
        model += x[i] <= pulp.lpSum(cap[k] * y[(i, k)] for k in levels)

    M_big = max(cap.values()) * 3
    for s, sc in enumerate(scenarios):
        demand_s = sc["demand"]
        total_demand_s = sum(demand_s.values())

        for i in cities:
            inflow = pulp.lpSum(t[(j, i, s)] for j in cities if j != i)
            outflow = pulp.lpSum(t[(i, j, s)] for j in cities if j != i)
            deliver_out = pulp.lpSum(dd[(i, j, s)] for j in cities)
            model += x[i] + e[(i, s)] + inflow == outflow + deliver_out + l[(i, s)]

        for j in cities:
            model += pulp.lpSum(dd[(i, j, s)] for i in cities) + u[(j, s)] == demand_s[j]

        model += pulp.lpSum(e[(i, s)] for i in cities) <= d["emergency_ratio"] * total_demand_s

        for i in cities:
            opened = pulp.lpSum(y[(i, k)] for k in levels)
            model += e[(i, s)] <= M_big * opened
            for j in cities:
                model += dd[(i, j, s)] <= M_big * opened
            for j in cities:
                if j != i:
                    model += t[(i, j, s)] <= M_big * opened
                    model += t[(j, i, s)] <= M_big * opened

    # 求解
    solver = None
    for sname in ["PULP_CBC_CMD", "COIN_CMD", "HiGHS_CMD", "GLPK_CMD"]:
        try:
            sv = pulp.getSolver(sname, msg=0)
            if sv.available():
                solver = sv
                break
        except Exception:
            continue

    if solver is None:
        solver = pulp.PULP_CBC_CMD(msg=0)

    model.solve(solver)
    return pulp.LpStatus[model.status], pulp.value(model.objective)


# ============================================================
# 测试用例集定义
# ============================================================

def get_parameter_generalization_cases():
    """
    参数泛化测试用例：在固定规模 N_cities=4 下，变化各参数。
    """
    cases = []

    # --- 需求方差变化 ---
    for dv in ['low', 'medium', 'high']:
        cases.append({
            'N_cities': 4, 'seed': 42, 'demand_variance': dv,
            'cost_scale': 1.0, 'n_scenarios': 3, 'budget_scale': 1.0,
            'emergency_ratio': 0.2,
            'description': f'需求方差={dv}'
        })

    # --- 成本缩放 ---
    for cs in [0.5, 0.8, 1.2, 1.5, 2.0]:
        cases.append({
            'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': cs, 'n_scenarios': 3, 'budget_scale': 1.0,
            'emergency_ratio': 0.2,
            'description': f'成本缩放={cs}'
        })

    # --- 场景数量 ---
    for ns in [2, 5, 10, 20]:
        cases.append({
            'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': 1.0, 'n_scenarios': ns, 'budget_scale': 1.0,
            'emergency_ratio': 0.2,
            'description': f'场景数={ns}'
        })

    # --- 预算缩放 ---
    for bs in [0.6, 0.8, 1.0, 1.5, 2.0]:
        if bs == 1.0:
            continue
        cases.append({
            'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': 1.0, 'n_scenarios': 3, 'budget_scale': bs,
            'emergency_ratio': 0.2,
            'description': f'预算缩放={bs}'
        })

    # --- 紧急补货比例 ---
    for er in [0.1, 0.3, 0.5]:
        cases.append({
            'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': 1.0, 'n_scenarios': 3, 'budget_scale': 1.0,
            'emergency_ratio': er,
            'description': f'紧急补货比例={er}'
        })

    # --- 组合变化 ---
    combos = [
        {'demand_variance': 'high', 'cost_scale': 1.5, 'description': '高方差+高成本'},
        {'demand_variance': 'low', 'budget_scale': 0.6, 'description': '低方差+紧预算'},
        {'demand_variance': 'high', 'n_scenarios': 10, 'description': '高方差+多场景'},
        {'cost_scale': 0.5, 'emergency_ratio': 0.1, 'description': '低成本+少补货'},
    ]
    for combo in combos:
        desc = combo.pop('description')
        base = {
            'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': 1.0, 'n_scenarios': 3, 'budget_scale': 1.0,
            'emergency_ratio': 0.2,
        }
        base.update(combo)
        base['description'] = desc
        cases.append(base)

    # 去重
    seen = set()
    unique = []
    for c in cases:
        key = (c['N_cities'], c['seed'], c['demand_variance'],
               c['cost_scale'], c['n_scenarios'], c['budget_scale'],
               c['emergency_ratio'])
        if key not in seen:
            seen.add(key)
            unique.append(c)
    return unique


def get_scale_generalization_cases():
    """
    规模泛化测试用例：变化城市数量 N_cities。
    """
    cases = []
    for n in [3, 4, 5, 6, 8, 10]:
        cases.append({
            'N_cities': n, 'seed': 42, 'demand_variance': 'medium',
            'cost_scale': 1.0, 'n_scenarios': 3, 'budget_scale': 1.0,
            'emergency_ratio': 0.2,
            'description': f'规模 N={n}'
        })
    return cases


def get_all_cases():
    """返回所有测试用例（参数泛化 + 规模泛化）。"""
    return get_parameter_generalization_cases() + get_scale_generalization_cases()


# ============================================================
# 主程序：验证生成器
# ============================================================

if __name__ == '__main__':
    print("=" * 70)
    print("两阶段随机优化测试实例生成器 — 验证")
    print("=" * 70)

    # ------ 1. 验证默认参数复现原始问题 ------
    print("\n【1】N_cities=4 默认参数 → 应复现原始问题数据")
    inst = generate_instance(N_cities=4)
    print(f"  城市: {inst['cities']}")
    print(f"  容量等级: {inst['capacity_levels']}")
    print(f"  情景数: {len(inst['scenarios'])}")
    print(f"  预算: {inst['budget']}万元")

    # 逐项对比
    match = True
    for (city, level), cost in ORIGINAL_BUILD_COST.items():
        if inst['build_cost'].get((city, level)) != cost:
            print(f"  ✗ 建设成本不匹配: ({city},{level})")
            match = False
    for sc_orig, sc_gen in zip(ORIGINAL_SCENARIOS, inst['scenarios']):
        if abs(sc_orig['prob'] - sc_gen['prob']) > 0.001:
            print(f"  ✗ 情景概率不匹配")
            match = False
        for c in ORIGINAL_CITIES:
            if abs(sc_orig['demand'][c] - sc_gen['demand'][c]) > 0.01:
                print(f"  ✗ 需求不匹配: {c}")
                match = False
    if inst['budget'] != 500:
        print(f"  ✗ 预算不匹配: {inst['budget']} vs 500")
        match = False
    if match:
        print("  ✓ 所有参数与原始问题完全一致")

    # 求解验证
    result = solve_instance(inst)
    if result:
        status, obj = result
        print(f"  求解状态: {status}, 期望总利润: {obj:.2f} 万元")
        if abs(obj - 3191.65) < 1.0:
            print("  ✓ 目标值与参考答案(3191.65)一致")
        else:
            print(f"  ⚠ 目标值与参考答案(3191.65)有差异: {abs(obj - 3191.65):.2f}")

    # ------ 2. 代表性实例展示 ------
    print("\n" + "=" * 70)
    print("【2】代表性实例")
    print("=" * 70)

    demo_cases = [
        {'N_cities': 4, 'seed': 42, 'demand_variance': 'high',
         'cost_scale': 1.0, 'n_scenarios': 3},
        {'N_cities': 4, 'seed': 42, 'demand_variance': 'medium',
         'cost_scale': 1.0, 'n_scenarios': 10},
        {'N_cities': 6, 'seed': 42, 'demand_variance': 'medium',
         'cost_scale': 1.0, 'n_scenarios': 3},
        {'N_cities': 10, 'seed': 123, 'demand_variance': 'medium',
         'cost_scale': 1.0, 'n_scenarios': 5},
    ]

    for params in demo_cases:
        desc = ', '.join(f'{k}={v}' for k, v in params.items())
        inst = generate_instance(**params)
        print(f"\n  --- {desc} ---")
        print(f"  城市数: {len(inst['cities'])}, "
              f"情景数: {len(inst['scenarios'])}, "
              f"预算: {inst['budget']}万元")
        total_expected_demand = sum(
            sc['prob'] * sum(sc['demand'].values()) for sc in inst['scenarios']
        )
        print(f"  期望总需求: {total_expected_demand:.1f} 万件")

        result = solve_instance(inst)
        if result:
            status, obj = result
            print(f"  求解: {status}, 利润={obj:.2f} 万元")

    # ------ 3. 测试用例统计 ------
    print("\n" + "=" * 70)
    print("【3】测试用例统计")
    print("=" * 70)

    param_cases = get_parameter_generalization_cases()
    scale_cases = get_scale_generalization_cases()
    all_cases = get_all_cases()

    print(f"  参数泛化用例: {len(param_cases)} 个")
    print(f"  规模泛化用例: {len(scale_cases)} 个")
    print(f"  总测试用例:   {len(all_cases)} 个")

    print("\n  参数泛化用例列表:")
    for i, c in enumerate(param_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    print("\n  规模泛化用例列表:")
    for i, c in enumerate(scale_cases):
        print(f"    [{i+1:2d}] {c['description']}")

    # ------ 4. 批量可行性检查 ------
    print("\n" + "=" * 70)
    print("【4】批量可行性检查（所有用例）")
    print("=" * 70)

    n_feasible = 0
    n_total = len(all_cases)
    for c in all_cases:
        params = {k: v for k, v in c.items() if k != 'description'}
        inst = generate_instance(**params)
        result = solve_instance(inst)
        if result:
            status, obj = result
            ok = (status == 'Optimal')
            if ok:
                n_feasible += 1
                # print(f"  ✓ {c['description']}: 利润={obj:.2f}")
            else:
                print(f"  ✗ 不可行: {c['description']} → {status}")
        else:
            n_feasible += 1  # 无 pulp 时跳过

    print(f"  可行实例: {n_feasible}/{n_total}")
    if n_feasible == n_total:
        print("  ✓ 所有测试用例均可行")
    print("\n完成。")
