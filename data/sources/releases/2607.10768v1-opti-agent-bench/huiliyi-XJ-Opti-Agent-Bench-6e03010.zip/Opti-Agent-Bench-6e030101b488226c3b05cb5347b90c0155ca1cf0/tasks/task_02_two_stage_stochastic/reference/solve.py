# 提取自: 两阶段随机优化--区域配送网络规划.md（参考解法）
# 求解器: PuLP (MILP)
# 最优解: 南京中型+苏州大型+合肥小型, 利润3191.65万元

"""
两阶段随机MILP求解：区域配送网络规划（升级版）
使用PuLP求解确定性等价问题(Extensive Form)
"""
import pulp

# ============================================================
# 数据
# ============================================================
cities = ["HZ", "NJ", "SZ", "HF"]
city_names = {"HZ": "杭州", "NJ": "南京", "SZ": "苏州", "HF": "合肥"}
grades = ["S", "M", "L"]
grade_names = {"S": "小型", "M": "中型", "L": "大型"}
scenarios = [1, 2, 3]

# 建设成本 (万元)
build_cost = {
    ("HZ", "S"): 80,  ("HZ", "M"): 150, ("HZ", "L"): 240,
    ("NJ", "S"): 70,  ("NJ", "M"): 140, ("NJ", "L"): 220,
    ("SZ", "S"): 75,  ("SZ", "M"): 145, ("SZ", "L"): 230,
    ("HF", "S"): 60,  ("HF", "M"): 120, ("HF", "L"): 200,
}

# 容量 (万件)
capacity = {"S": 5, "M": 10, "L": 18}

# 单位成本 (元/件)
c_stock = 50      # 采购库存
c_emergency = 120 # 紧急空运
c_penalty = 80    # 缺货惩罚
c_salvage = 30    # 库存残值
revenue = 200     # 销售收入

# 调拨成本 (元/件) — 中心间批量转运
transfer_cost = {
    ("HZ", "NJ"): 8,  ("NJ", "HZ"): 8,
    ("HZ", "SZ"): 6,  ("SZ", "HZ"): 6,
    ("HZ", "HF"): 12, ("HF", "HZ"): 12,
    ("NJ", "SZ"): 7,  ("SZ", "NJ"): 7,
    ("NJ", "HF"): 9,  ("HF", "NJ"): 9,
    ("SZ", "HF"): 10, ("HF", "SZ"): 10,
}

# 配送成本 (元/件) — 配送中心i到区域j的末端配送
# 本地配送便宜(15), 跨区域配送=15+调拨距离成本
deliver_cost = {}
for i in cities:
    for j in cities:
        if i == j:
            deliver_cost[(i, j)] = 15  # 本地
        else:
            deliver_cost[(i, j)] = 15 + transfer_cost[(i, j)]  # 跨区域

# 情景概率
prob = {1: 0.3, 2: 0.5, 3: 0.2}

# 需求 (万件)
demand = {
    ("HZ", 1): 12, ("NJ", 1): 10, ("SZ", 1): 11, ("HF", 1): 8,
    ("HZ", 2): 8,  ("NJ", 2): 7,  ("SZ", 2): 7.5, ("HF", 2): 5,
    ("HZ", 3): 5,  ("NJ", 3): 4,  ("SZ", 3): 4.5, ("HF", 3): 3,
}

total_demand = {s: sum(demand[(j, s)] for j in cities) for s in scenarios}

# ============================================================
# 模型
# ============================================================
model = pulp.LpProblem("Distribution_Network", pulp.LpMaximize)

# --- 第一阶段变量 ---
y = pulp.LpVariable.dicts("y", [(i, k) for i in cities for k in grades],
                          cat="Binary")
x = pulp.LpVariable.dicts("x", cities, lowBound=0, cat="Continuous")

# --- 第二阶段变量 (每个情景) ---
# t[i,j,s]: 调拨  d[i,j,s]: 配送  e[i,s]: 紧急补货
# u[j,s]: 缺货  l[i,s]: 期末库存
pairs = [(i, j) for i in cities for j in cities if i != j]

t = pulp.LpVariable.dicts("t", [(i, j, s) for (i, j) in pairs for s in scenarios],
                          lowBound=0)
d = pulp.LpVariable.dicts("d", [(i, j, s) for i in cities for j in cities for s in scenarios],
                          lowBound=0)
e = pulp.LpVariable.dicts("e", [(i, s) for i in cities for s in scenarios],
                          lowBound=0)
u = pulp.LpVariable.dicts("u", [(j, s) for j in cities for s in scenarios],
                          lowBound=0)
l = pulp.LpVariable.dicts("l", [(i, s) for i in cities for s in scenarios],
                          lowBound=0)

# ============================================================
# 目标函数  (全部以万元为单位: 万件 × 元/件 = 万元)
# ============================================================
# 建设成本
cost_build = pulp.lpSum(build_cost[(i, k)] * y[(i, k)]
                        for i in cities for k in grades)

# 库存采购成本
cost_stock = pulp.lpSum(c_stock * x[i] for i in cities)

# 期望运营利润(含收入)
expected_ops = []
for s in scenarios:
    rev = pulp.lpSum(revenue * (demand[(j, s)] - u[(j, s)]) for j in cities)
    cost_trans = pulp.lpSum(transfer_cost[(i, j)] * t[(i, j, s)] for (i, j) in pairs)
    cost_del = pulp.lpSum(deliver_cost[(i, j)] * d[(i, j, s)] for i in cities for j in cities)
    cost_emer = pulp.lpSum(c_emergency * e[(i, s)] for i in cities)
    cost_pen = pulp.lpSum(c_penalty * u[(j, s)] for j in cities)
    salvage = pulp.lpSum(c_salvage * l[(i, s)] for i in cities)
    scenario_profit = rev - cost_trans - cost_del - cost_emer - cost_pen + salvage
    expected_ops.append(prob[s] * scenario_profit)

model += pulp.lpSum(expected_ops) - cost_build - cost_stock, "Total_Expected_Profit"

# ============================================================
# 约束
# ============================================================
# 1. 每城市最多建一种等级
for i in cities:
    model += pulp.lpSum(y[(i, k)] for k in grades) <= 1, f"OneGrade_{i}"

# 2. 至少2个、最多3个配送中心
model += pulp.lpSum(y[(i, k)] for i in cities for k in grades) >= 2, "MinFacilities"
model += pulp.lpSum(y[(i, k)] for i in cities for k in grades) <= 3, "MaxFacilities"

# 3. 预算限制
model += cost_build <= 500, "Budget"

# 4. 库存 ≤ 容量
for i in cities:
    model += x[i] <= pulp.lpSum(capacity[k] * y[(i, k)] for k in grades), f"Cap_{i}"

# 5. 库存平衡 (每个情景)
for s in scenarios:
    for i in cities:
        inflow = pulp.lpSum(t[(j, i, s)] for j in cities if j != i)
        outflow = pulp.lpSum(t[(i, j, s)] for j in cities if j != i)
        deliver_out = pulp.lpSum(d[(i, j, s)] for j in cities)
        model += (x[i] + e[(i, s)] + inflow
                  == outflow + deliver_out + l[(i, s)]), f"Balance_{i}_{s}"

# 6. 需求满足
for s in scenarios:
    for j in cities:
        model += (pulp.lpSum(d[(i, j, s)] for i in cities) + u[(j, s)]
                  == demand[(j, s)]), f"Demand_{j}_{s}"

# 7. 紧急补货限制 ≤ 总需求20%
for s in scenarios:
    model += (pulp.lpSum(e[(i, s)] for i in cities)
              <= 0.2 * total_demand[s]), f"Emergency_{s}"

# 8. 只有建了仓的城市才能有紧急补货 / 调拨 / 配送(可选，逻辑合理)
#    配送中心i如果没建，则 e[i,s]=0, d[i,j,s]=0, t[i,j,s]=0, t[j,i,s]=0
M_big = 50  # 足够大的上界
for s in scenarios:
    for i in cities:
        opened = pulp.lpSum(y[(i, k)] for k in grades)
        model += e[(i, s)] <= M_big * opened, f"EmerLink_{i}_{s}"
        for j in cities:
            model += d[(i, j, s)] <= M_big * opened, f"DelLink_{i}_{j}_{s}"
        for j in cities:
            if j != i:
                model += t[(i, j, s)] <= M_big * opened, f"TransOut_{i}_{j}_{s}"
                model += t[(j, i, s)] <= M_big * opened, f"TransIn_{j}_{i}_{s}"

# ============================================================
# 求解 — 自动选择可用的求解器
# ============================================================
solver = None
for solver_name in ["PULP_CBC_CMD", "COIN_CMD", "HiGHS_CMD", "GLPK_CMD"]:
    try:
        s = pulp.getSolver(solver_name, msg=0)
        if s.available():
            solver = s
            break
    except Exception:
        continue

if solver is None:
    raise RuntimeError(
        "未找到可用的求解器，请安装 CBC 求解器：\n"
        "  conda install -c conda-forge coin-or-cbc\n"
        "  或 pip install pulp（pip 版本通常自带 CBC）"
    )

model.solve(solver)

print("=" * 70)
print(f"求解状态: {pulp.LpStatus[model.status]}")
print(f"期望总利润: {pulp.value(model.objective):.2f} 万元")
print("=" * 70)

# --- 第一阶段决策 ---
print("\n【第一阶段决策】")
print("-" * 40)
total_build = 0
for i in cities:
    for k in grades:
        if pulp.value(y[(i, k)]) > 0.5:
            bc = build_cost[(i, k)]
            total_build += bc
            print(f"  {city_names[i]}: {grade_names[k]}仓 "
                  f"(容量{capacity[k]}万件, 建设成本{bc}万元)")

print(f"\n  总建设成本: {total_build} 万元")

print("\n  初始库存:")
total_stock = 0
for i in cities:
    xv = pulp.value(x[i])
    if xv > 0.001:
        total_stock += xv
        print(f"    {city_names[i]}: {xv:.2f} 万件")
print(f"  总库存: {total_stock:.2f} 万件")
print(f"  库存成本: {total_stock * c_stock:.2f} 万元")

# --- 第二阶段决策 ---
scenario_names = {1: "市场火爆(p=0.3)", 2: "市场正常(p=0.5)", 3: "市场低迷(p=0.2)"}
for s in scenarios:
    print(f"\n{'=' * 70}")
    print(f"【情景{s}: {scenario_names[s]}】")
    print(f"  总需求: {total_demand[s]} 万件")
    print("-" * 40)

    # 紧急补货
    total_emer = 0
    for i in cities:
        ev = pulp.value(e[(i, s)])
        if ev > 0.001:
            total_emer += ev
            print(f"  紧急补货 → {city_names[i]}: {ev:.2f} 万件")
    if total_emer > 0.001:
        print(f"  紧急补货合计: {total_emer:.2f} 万件 (限制: {0.2*total_demand[s]:.1f})")

    # 调拨
    has_trans = False
    for (i, j) in pairs:
        tv = pulp.value(t[(i, j, s)])
        if tv > 0.001:
            if not has_trans:
                print(f"\n  调拨:")
                has_trans = True
            print(f"    {city_names[i]} → {city_names[j]}: {tv:.2f} 万件 "
                  f"(@{transfer_cost[(i,j)]}元)")

    # 配送
    print(f"\n  配送:")
    for j in cities:
        sources = []
        for i in cities:
            dv = pulp.value(d[(i, j, s)])
            if dv > 0.001:
                sources.append(f"{city_names[i]}:{dv:.2f}")
        uv = pulp.value(u[(j, s)])
        shortage = f", 缺货:{uv:.2f}" if uv > 0.001 else ""
        print(f"    {city_names[j]}区域(需{demand[(j,s)]}): "
              f"{', '.join(sources)}{shortage}")

    # 期末库存
    print(f"\n  期末库存:")
    for i in cities:
        lv = pulp.value(l[(i, s)])
        if lv > 0.001:
            print(f"    {city_names[i]}: {lv:.2f} 万件")

    # 情景利润
    rev_val = sum(revenue * (demand[(j, s)] - pulp.value(u[(j, s)])) for j in cities)
    trans_val = sum(transfer_cost[(i, j)] * pulp.value(t[(i, j, s)]) for (i, j) in pairs)
    del_val = sum(deliver_cost[(i, j)] * pulp.value(d[(i, j, s)]) for i in cities for j in cities)
    emer_val = sum(c_emergency * pulp.value(e[(i, s)]) for i in cities)
    pen_val = sum(c_penalty * pulp.value(u[(j, s)]) for j in cities)
    sal_val = sum(c_salvage * pulp.value(l[(i, s)]) for i in cities)

    print(f"\n  情景{s}运营利润:")
    print(f"    收入:      {rev_val:>10.2f} 万元")
    print(f"    调拨成本:  {trans_val:>10.2f} 万元")
    print(f"    配送成本:  {del_val:>10.2f} 万元")
    print(f"    紧急补货:  {emer_val:>10.2f} 万元")
    print(f"    缺货惩罚:  {pen_val:>10.2f} 万元")
    print(f"    库存残值:  {sal_val:>10.2f} 万元")
    net = rev_val - trans_val - del_val - emer_val - pen_val + sal_val
    print(f"    净运营利润:{net:>10.2f} 万元")

print(f"\n{'=' * 70}")
print("【汇总】")
exp_ops = sum(prob[s] * (
    sum(revenue * (demand[(j, s)] - pulp.value(u[(j, s)])) for j in cities)
    - sum(transfer_cost[(i, j)] * pulp.value(t[(i, j, s)]) for (i, j) in pairs)
    - sum(deliver_cost[(i, j)] * pulp.value(d[(i, j, s)]) for i in cities for j in cities)
    - sum(c_emergency * pulp.value(e[(i, s)]) for i in cities)
    - sum(c_penalty * pulp.value(u[(j, s)]) for j in cities)
    + sum(c_salvage * pulp.value(l[(i, s)]) for i in cities)
) for s in scenarios)
print(f"  期望运营利润: {exp_ops:.2f} 万元")
print(f"  建设成本:     {total_build:.2f} 万元")
print(f"  库存成本:     {total_stock * c_stock:.2f} 万元")
print(f"  期望总利润:   {exp_ops - total_build - total_stock * c_stock:.2f} 万元")
print(f"  (验证) 目标值: {pulp.value(model.objective):.2f} 万元")
