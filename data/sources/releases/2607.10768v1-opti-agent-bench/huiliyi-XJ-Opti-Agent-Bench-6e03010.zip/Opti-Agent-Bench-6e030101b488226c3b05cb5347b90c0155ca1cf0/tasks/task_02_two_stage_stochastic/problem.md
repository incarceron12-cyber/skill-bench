# 两阶段随机优化--区域配送网络规划

# 一、问题描述

### 业务背景

一家电商公司计划在华东地区建立区域配送网络。公司需要在年初决定在哪些城市建立配送中心，并确定每个配送中心的容量等级和初始库存水平。旺季到来后，市场需求将显现，公司需要根据实际需求进行库存调拨、配送以及紧急补货。

公司希望在不确定需求下制定一个长期稳健的运营方案，使预期利润最大化。

### 决策时间线

**阶段1（年初，需求未知时）：**

在需求未知的情况下，公司需要做出以下决策：

*   选择在哪些候选城市建立配送中心（候选城市：杭州、南京、苏州、合肥）
    
*   为每个配送中心选择容量等级（小型/中型/大型）
    
*   决定每个配送中心的初始库存量
    

**阶段2（旺季，需求显现后）：**

在实际需求已知后，公司可以采取以下行动：

*   在配送中心之间调拨库存
    
*   从供应商进行紧急空运补货（到已建成的配送中心）
    
*   从配送中心向各区域配送商品
    
*   如果仍无法满足需求，则产生缺货损失
    

### 成本与收益结构

**建设成本（年初一次性投入，单位：万元）：**

{

  "建设成本": {

    "说明": "年初一次性建设投入",

    "单位": "万元",

    "城市数据": \[

      {

        "城市": "杭州",

        "小型仓": 80,

        "中型仓": 150,

        "大型仓": 240

      },

      {

        "城市": "南京",

        "小型仓": 70,

        "中型仓": 140,

        "大型仓": 220

      },

      {

        "城市": "苏州",

        "小型仓": 75,

        "中型仓": 145,

        "大型仓": 230

      },

      {

        "城市": "合肥",

        "小型仓": 60,

        "中型仓": 120,

        "大型仓": 200

      }

    \]

  }

}

**容量：**

*   小型仓：5万件
    
*   中型仓：10万件
    
*   大型仓：18万件
    

**库存采购成本：** 50元/件（采购+运输到配送中心）

**销售收入：** 200元/件

**配送成本：**

*   配送中心向本区域配送：15元/件
    
*   配送中心向其他区域配送：15元/件 + 跨区域运输附加费（见下表）
    

**跨区域运输附加费（元/件），同样适用于配送中心之间的库存调拨：**    

{

  "跨区域运输附加费": {

    "单位": "元/件",

    "是否双向成本相同": true,

    "路线": \[

      {

        "起点城市": "杭州",

        "终点城市": "南京",

        "附加费": 8

      },

      {

        "起点城市": "杭州",

        "终点城市": "苏州",

        "附加费": 6

      },

      {

        "起点城市": "杭州",

        "终点城市": "合肥",

        "附加费": 12

      },

      {

        "起点城市": "南京",

        "终点城市": "苏州",

        "附加费": 7

      },

      {

        "起点城市": "南京",

        "终点城市": "合肥",

        "附加费": 9

      },

      {

        "起点城市": "苏州",

        "终点城市": "合肥",

        "附加费": 10

      }

    \]

  }

}

**紧急空运补货：** 120元/件（可补货到任一已建成的配送中心）

**缺货惩罚：** 80元/件（客户满意度损失）

**库存残值：** 旺季结束后未售出的库存可回收，残值30元/件

### 市场需求不确定性

公司市场部预测了三种可能的市场情景：

**情景1：市场火爆（概率30%）**

*   杭州区域需求：12万件
    
*   南京区域需求：10万件
    
*   苏州区域需求：11万件
    
*   合肥区域需求：8万件
    

**情景2：市场正常（概率50%）**

*   杭州区域需求：8万件
    
*   南京区域需求：7万件
    
*   苏州区域需求：7.5万件
    
*   合肥区域需求：5万件
    

**情景3：市场低迷（概率20%）**

*   杭州区域需求：5万件
    
*   南京区域需求：4万件
    
*   苏州区域需求：4.5万件
    
*   合肥区域需求：3万件
    

### 约束条件

1.  至少建设2个配送中心（风险分散要求）
    
2.  最多建设3个配送中心（管理能力限制）
    
3.  总建设预算不超过500万元
    
4.  每个配送中心的初始库存不能超过其容量
    
5.  每个区域的需求可以由多个配送中心共同满足
    
6.  紧急空运补货总量不能超过该情景总需求的20%（供应商产能限制）
    

### 问题

请说明你的建模方法和求解思路。请为该公司设计最优决策方案：

1.  应在哪些城市建立配送中心？选择什么容量等级？
    
2.  每个配送中心的初始库存应该是多少？
    
3.  在不同需求情景下，应如何进行调拨与配送？
    
4.  预期总利润是多少？
    

---

# 二、解决方法

### 问题类型

两阶段随机混合整数规划（Two-Stage Stochastic Mixed Integer Program）

*   第一阶段：设施选址（Facility Location）+ 容量选择 + 库存决策
    
*   第二阶段：网络流（Transportation/Transshipment）+ 紧急补货（Recourse）
    

### 数学模型

**集合：**

*   $I = \{杭州, 南京, 苏州, 合肥\}$：候选城市（同时也是需求区域）
    
*   $K = \{S, M, L\}$：容量等级
    
*   $\Omega = \{1, 2, 3\}$：需求情景
    

**第一阶段决策变量：**

*   $y\_{ik} \in \{0,1\}$：城市 $i$ 是否建设等级 $k$ 的配送中心
    
*   $x\_i \geq 0$：城市 $i$ 配送中心的初始库存量
    

**第二阶段决策变量（情景** $s$ **下）：**

*   $t\_{ij}^s \geq 0$：从城市 $i$ 调拨到城市 $j$ 的货物量
    
*   $d\_{ij}^s \geq 0$：从城市 $i$ 配送到区域 $j$ 的货物量
    
*   $e\_i^s \geq 0$：城市 $i$ 的紧急空运补货量
    
*   $u\_j^s \geq 0$：区域 $j$ 的缺货量
    
*   $l\_i^s \geq 0$：城市 $i$ 的期末剩余库存
    

**参数：**

*   $f\_{ik}$：建设成本
    
*   $cap\_k$：等级 $k$ 的容量
    
*   $c^{stock} = 50$：库存单位成本（元/件）
    
*   $c^{base} = 15$：基础配送成本（元/件）
    
*   $c^{trans}\_{ij}$：跨区域运输附加费（元/件）
    
*   $c^{emer} = 120$：紧急空运成本（元/件）
    
*   $c^{pen} = 80$：缺货惩罚（元/件）
    
*   $c^{sal} = 30$：库存残值（元/件）
    
*   $r = 200$：销售收入（元/件）
    
*   $D\_j^s$：情景 $s$ 下区域 $j$ 的需求
    
*   $p\_s$：情景 $s$ 的概率
    

**配送成本矩阵：**

$c^{del}\_{ij} = \begin{cases} c^{base} & \text{if } i = j \\ c^{base} + c^{trans}\_{ij} & \text{if } i \neq j \end{cases}$

**目标函数（利润最大化）：**

$\max Z = \sum\_{s \in \Omega} p\_s \cdot Q\_s(x, y) - \sum\_{i,k} f\_{ik} y\_{ik} - c^{stock} \sum\_i x\_i$

其中情景 $s$ 的运营利润 $Q\_s$ 为：

$Q\_s = r \sum\_j (D\_j^s - u\_j^s) - \sum\_{i \neq j} c^{trans}\_{ij} t\_{ij}^s - \sum\_{i,j} c^{del}\_{ij} d\_{ij}^s - c^{emer} \sum\_i e\_i^s - c^{pen} \sum\_j u\_j^s + c^{sal} \sum\_i l\_i^s$

**约束条件：**

第一阶段约束：

$\sum\_{k \in K} y\_{ik} \leq 1, \quad \forall i \in I \quad \text{（每个城市最多建一种等级）}$

$2 \leq \sum\_{i \in I}\sum\_{k \in K} y\_{ik} \leq 3 \quad \text{（配送中心数量限制）}$

$\sum\_{i \in I}\sum\_{k \in K} f\_{ik} y\_{ik} \leq 500 \quad \text{（预算限制）}$

$x\_i \leq \sum\_{k \in K} cap\_k \cdot y\_{ik}, \quad \forall i \in I \quad \text{（库存不超过容量）}$

第二阶段约束（每个情景 $s$）：

$x\_i + e\_i^s + \sum\_{j \neq i} t\_{ji}^s = \sum\_{j \neq i} t\_{ij}^s + \sum\_{j \in I} d\_{ij}^s + l\_i^s, \quad \forall i \in I \quad \text{（库存平衡）}$

$\sum\_{i \in I} d\_{ij}^s + u\_j^s = D\_j^s, \quad \forall j \in I \quad \text{（需求满足）}$

$\sum\_{i \in I} e\_i^s \leq 0.2 \sum\_{j \in I} D\_j^s \quad \text{（紧急补货限制）}$

$e\_i^s, t\_{ij}^s, d\_{ij}^s \leq M \cdot \sum\_{k} y\_{ik}, \quad \forall i \in I \quad \text{（仅已建中心可操作）}$

$t\_{ij}^s, d\_{ij}^s, e\_i^s, u\_j^s, l\_i^s \geq 0$

### 求解方法

该问题是两阶段随机混合整数规划，标准求解方法包括：

1.  **确定性等价问题（Extensive Form）**：将所有情景展开，直接用MILP求解器求解
    
2.  **L-shaped方法（Benders分解）**：将问题分解为主问题（第一阶段）和子问题（各情景的LP）
    
3.  **样本平均近似法（SAA）**：当情景数量很大时使用
    

本问题仅3个情景，可直接求解Extensive Form。

### 求解代码

见配套文件 `problem_01_solve.py`，使用PuLP + CBC求解器。

### 最优解（求解器验证）

**第一阶段决策：**

| 城市 | 选址决策 | 容量等级 | 容量(万件) | 建设成本(万元) | 初始库存(万件) |
| --- | --- | --- | --- | --- | --- |
| 杭州 | ✗ | — | — | — | — |
| 南京 | ✓ | 中型 | 10 | 140 | 10.00 |
| 苏州 | ✓ | 大型 | 18 | 230 | 18.00 |
| 合肥 | ✓ | 小型 | 5 | 60 | 5.00 |

*   总建设成本：**430万元**（预算500万元以内）
    
*   总库存：**33万件**
    
*   库存成本：33 × 50 = **1650万元**
    

**第二阶段决策（按情景）：**

**情景1：市场火爆（概率30%，总需求41万件）**

紧急补货：苏州5万件，合肥3万件（合计8万件，限额8.2万件）

| 配送中心 → 区域 | 配送量(万件) | 单位成本(元) |
| --- | --- | --- |
| 苏州 → 杭州 | 12.00 | 21 (15+6) |
| 南京 → 南京 | 10.00 | 15 |
| 苏州 → 苏州 | 11.00 | 15 |
| 合肥 → 合肥 | 8.00 | 15 |

情景1运营利润：**6553万元**

**情景2：市场正常（概率50%，总需求27.5万件）**

无紧急补货

| 配送中心 → 区域 | 配送量(万件) | 单位成本(元) |
| --- | --- | --- |
| 苏州 → 杭州 | 8.00 | 21 |
| 南京 → 南京 | 7.00 | 15 |
| 苏州 → 苏州 | 7.50 | 15 |
| 合肥 → 合肥 | 5.00 | 15 |

期末库存：南京3万件，苏州2.5万件（残值165万元）

情景2运营利润：**5204.5万元**

**情景3：市场低迷（概率20%，总需求16.5万件）**

无紧急补货

| 配送中心 → 区域 | 配送量(万件) | 单位成本(元) |
| --- | --- | --- |
| 苏州 → 杭州 | 5.00 | 21 |
| 南京 → 南京 | 4.00 | 15 |
| 苏州 → 苏州 | 4.50 | 15 |
| 合肥 → 合肥 | 3.00 | 15 |

期末库存：南京6万件，苏州8.5万件，合肥2万件（残值495万元）

情景3运营利润：**3517.5万元**

**期望总利润：**

$\text{期望运营利润} = 0.3 \times 6553 + 0.5 \times 5204.5 + 0.2 \times 3517.5 = 5271.65 \text{万元}$

$\text{期望总利润} = 5271.65 - 430 - 1650 = \textbf{3191.65万元}$

### 关键洞察

1.  **不建杭州仓是反直觉的**：虽然杭州需求最大，但苏州仓可以低成本（附加6元/件）覆盖杭州区域，而苏州大型仓建设成本（230万）远低于同时建杭州仓和苏州仓。
    
2.  **库存策略偏向满仓**：由于库存采购成本（50元）远低于紧急空运（120元），且有库存残值（30元），实际持有成本仅20元/件，模型倾向于尽量多备货。
    
3.  **紧急补货是关键缓冲**：在火爆情景下，8万件紧急补货（接近上限8.2万件）是满足需求的关键手段。
    
4.  **三中心互补格局**：南京覆盖本地，苏州覆盖本地+杭州（利用地理邻近），合肥覆盖本地——形成成本最优的网络布局。
    

### 评分标准

**结构识别（20分）：**

*   识别两阶段决策结构（先建设后运营）（10分）
    
*   理解需求不确定性和情景概率的作用（10分）
    

**建模能力（30分）：**

*   正确定义第一阶段和第二阶段决策变量（10分）
    
*   建立合理的期望利润目标函数（10分）
    
*   完整的约束条件（库存平衡、需求满足、容量、预算等）（10分）
    

**求解方法（25分）：**

*   提出合理的求解方法（Extensive Form / Benders / SAA等）（15分）
    
*   实际求解或给出详细求解步骤（10分）
    

**方案质量（15分）：**

*   方案合理性（选址和库存策略经济上说得通）（10分）
    
*   方案完整性（覆盖所有情景的运营方案）（5分）
    

**分析深度（10分）：**

*   敏感性分析或情景分析（5分）
    
*   管理洞察（如选址逻辑、库存策略解释）（5分）
    

---

## 测试说明

### 测试目的

评估AI模型在复杂运筹优化问题上的综合能力：

*   **问题抽象**：能否从业务描述中抽象出数学优化问题
    
*   **建模能力**：能否正确建立两阶段随机规划模型
    
*   **算法认知**：能否提出合理的求解方法
    
*   **数值推理**：能否给出合理的数值解
    
*   **商业洞察**：能否从优化结果中提取管理启示
    

### 预期表现

*   **优秀模型（80-100分）**：识别两阶段结构，建立完整数学模型，提出MILP求解方法，给出接近最优的方案
    
*   **良好模型（60-79分）**：理解问题结构，提出合理的建模框架，给出可行方案
    
*   **一般模型（40-59分）**：理解基本问题，但建模不完整或求解方法有缺陷
    
*   **较差模型（<40分）**：无法识别问题结构，或方案严重不可行
    

### 使用方法

1.  仅向测试模型提供"**问题描述**"部分（第1~108行）
    
2.  记录模型的完整回答
    
3.  根据评分标准打分
    
4.  对比最优解分析差异
    
5.  可运行 `problem_01_solve.py` 验证最优解
    

# 三、代码与执行结果

## claude版本代码

```python
"""
两阶段随机MILP求解：区域配送网络规划（升级版）
使用PuLP求解确定性等价问题(Extensive Form)
"""
import pulp

# ============================================================
# 数据
# ============================================================
cities = ["HZ", "NJ", "SZ", "HF"]
city_names = {"HZ": "杭州", "NJ": "南京", "SZ": "苏州", "HF": "合肥"}
grades = ["S", "M", "L"]
grade_names = {"S": "小型", "M": "中型", "L": "大型"}
scenarios = [1, 2, 3]

# 建设成本 (万元)
build_cost = {
    ("HZ", "S"): 80,  ("HZ", "M"): 150, ("HZ", "L"): 240,
    ("NJ", "S"): 70,  ("NJ", "M"): 140, ("NJ", "L"): 220,
    ("SZ", "S"): 75,  ("SZ", "M"): 145, ("SZ", "L"): 230,
    ("HF", "S"): 60,  ("HF", "M"): 120, ("HF", "L"): 200,
}

# 容量 (万件)
capacity = {"S": 5, "M": 10, "L": 18}

# 单位成本 (元/件)
c_stock = 50      # 采购库存
c_emergency = 120 # 紧急空运
c_penalty = 80    # 缺货惩罚
c_salvage = 30    # 库存残值
revenue = 200     # 销售收入

# 调拨成本 (元/件) — 中心间批量转运
transfer_cost = {
    ("HZ", "NJ"): 8,  ("NJ", "HZ"): 8,
    ("HZ", "SZ"): 6,  ("SZ", "HZ"): 6,
    ("HZ", "HF"): 12, ("HF", "HZ"): 12,
    ("NJ", "SZ"): 7,  ("SZ", "NJ"): 7,
    ("NJ", "HF"): 9,  ("HF", "NJ"): 9,
    ("SZ", "HF"): 10, ("HF", "SZ"): 10,
}

# 配送成本 (元/件) — 配送中心i到区域j的末端配送
# 本地配送便宜(15), 跨区域配送=15+调拨距离成本
deliver_cost = {}
for i in cities:
    for j in cities:
        if i == j:
            deliver_cost[(i, j)] = 15  # 本地
        else:
            deliver_cost[(i, j)] = 15 + transfer_cost[(i, j)]  # 跨区域

# 情景概率
prob = {1: 0.3, 2: 0.5, 3: 0.2}

# 需求 (万件)
demand = {
    ("HZ", 1): 12, ("NJ", 1): 10, ("SZ", 1): 11, ("HF", 1): 8,
    ("HZ", 2): 8,  ("NJ", 2): 7,  ("SZ", 2): 7.5, ("HF", 2): 5,
    ("HZ", 3): 5,  ("NJ", 3): 4,  ("SZ", 3): 4.5, ("HF", 3): 3,
}

total_demand = {s: sum(demand[(j, s)] for j in cities) for s in scenarios}

# ============================================================
# 模型
# ============================================================
model = pulp.LpProblem("Distribution_Network", pulp.LpMaximize)

# --- 第一阶段变量 ---
y = pulp.LpVariable.dicts("y", [(i, k) for i in cities for k in grades],
                          cat="Binary")
x = pulp.LpVariable.dicts("x", cities, lowBound=0, cat="Continuous")

# --- 第二阶段变量 (每个情景) ---
# t[i,j,s]: 调拨  d[i,j,s]: 配送  e[i,s]: 紧急补货
# u[j,s]: 缺货  l[i,s]: 期末库存
pairs = [(i, j) for i in cities for j in cities if i != j]

t = pulp.LpVariable.dicts("t", [(i, j, s) for (i, j) in pairs for s in scenarios],
                          lowBound=0)
d = pulp.LpVariable.dicts("d", [(i, j, s) for i in cities for j in cities for s in scenarios],
                          lowBound=0)
e = pulp.LpVariable.dicts("e", [(i, s) for i in cities for s in scenarios],
                          lowBound=0)
u = pulp.LpVariable.dicts("u", [(j, s) for j in cities for s in scenarios],
                          lowBound=0)
l = pulp.LpVariable.dicts("l", [(i, s) for i in cities for s in scenarios],
                          lowBound=0)

# ============================================================
# 目标函数  (全部以万元为单位: 万件 × 元/件 = 万元)
# ============================================================
# 建设成本
cost_build = pulp.lpSum(build_cost[(i, k)] * y[(i, k)]
                        for i in cities for k in grades)

# 库存采购成本
cost_stock = pulp.lpSum(c_stock * x[i] for i in cities)

# 期望运营利润(含收入)
expected_ops = []
for s in scenarios:
    rev = pulp.lpSum(revenue * (demand[(j, s)] - u[(j, s)]) for j in cities)
    cost_trans = pulp.lpSum(transfer_cost[(i, j)] * t[(i, j, s)] for (i, j) in pairs)
    cost_del = pulp.lpSum(deliver_cost[(i, j)] * d[(i, j, s)] for i in cities for j in cities)
    cost_emer = pulp.lpSum(c_emergency * e[(i, s)] for i in cities)
    cost_pen = pulp.lpSum(c_penalty * u[(j, s)] for j in cities)
    salvage = pulp.lpSum(c_salvage * l[(i, s)] for i in cities)
    scenario_profit = rev - cost_trans - cost_del - cost_emer - cost_pen + salvage
    expected_ops.append(prob[s] * scenario_profit)

model += pulp.lpSum(expected_ops) - cost_build - cost_stock, "Total_Expected_Profit"

# ============================================================
# 约束
# ============================================================
# 1. 每城市最多建一种等级
for i in cities:
    model += pulp.lpSum(y[(i, k)] for k in grades) <= 1, f"OneGrade_{i}"

# 2. 至少2个、最多3个配送中心
model += pulp.lpSum(y[(i, k)] for i in cities for k in grades) >= 2, "MinFacilities"
model += pulp.lpSum(y[(i, k)] for i in cities for k in grades) <= 3, "MaxFacilities"

# 3. 预算限制
model += cost_build <= 500, "Budget"

# 4. 库存 ≤ 容量
for i in cities:
    model += x[i] <= pulp.lpSum(capacity[k] * y[(i, k)] for k in grades), f"Cap_{i}"

# 5. 库存平衡 (每个情景)
for s in scenarios:
    for i in cities:
        inflow = pulp.lpSum(t[(j, i, s)] for j in cities if j != i)
        outflow = pulp.lpSum(t[(i, j, s)] for j in cities if j != i)
        deliver_out = pulp.lpSum(d[(i, j, s)] for j in cities)
        model += (x[i] + e[(i, s)] + inflow
                  == outflow + deliver_out + l[(i, s)]), f"Balance_{i}_{s}"

# 6. 需求满足
for s in scenarios:
    for j in cities:
        model += (pulp.lpSum(d[(i, j, s)] for i in cities) + u[(j, s)]
                  == demand[(j, s)]), f"Demand_{j}_{s}"

# 7. 紧急补货限制 ≤ 总需求20%
for s in scenarios:
    model += (pulp.lpSum(e[(i, s)] for i in cities)
              <= 0.2 * total_demand[s]), f"Emergency_{s}"

# 8. 只有建了仓的城市才能有紧急补货 / 调拨 / 配送(可选，逻辑合理)
#    配送中心i如果没建，则 e[i,s]=0, d[i,j,s]=0, t[i,j,s]=0, t[j,i,s]=0
M_big = 50  # 足够大的上界
for s in scenarios:
    for i in cities:
        opened = pulp.lpSum(y[(i, k)] for k in grades)
        model += e[(i, s)] <= M_big * opened, f"EmerLink_{i}_{s}"
        for j in cities:
            model += d[(i, j, s)] <= M_big * opened, f"DelLink_{i}_{j}_{s}"
        for j in cities:
            if j != i:
                model += t[(i, j, s)] <= M_big * opened, f"TransOut_{i}_{j}_{s}"
                model += t[(j, i, s)] <= M_big * opened, f"TransIn_{j}_{i}_{s}"

# ============================================================
# 求解 — 自动选择可用的求解器
# ============================================================
solver = None
for solver_name in ["PULP_CBC_CMD", "COIN_CMD", "HiGHS_CMD", "GLPK_CMD"]:
    try:
        s = pulp.getSolver(solver_name, msg=0)
        if s.available():
            solver = s
            break
    except Exception:
        continue

if solver is None:
    raise RuntimeError(
        "未找到可用的求解器，请安装 CBC 求解器：\n"
        "  conda install -c conda-forge coin-or-cbc\n"
        "  或 pip install pulp（pip 版本通常自带 CBC）"
    )

model.solve(solver)

print("=" * 70)
print(f"求解状态: {pulp.LpStatus[model.status]}")
print(f"期望总利润: {pulp.value(model.objective):.2f} 万元")
print("=" * 70)

# --- 第一阶段决策 ---
print("\n【第一阶段决策】")
print("-" * 40)
total_build = 0
for i in cities:
    for k in grades:
        if pulp.value(y[(i, k)]) > 0.5:
            bc = build_cost[(i, k)]
            total_build += bc
            print(f"  {city_names[i]}: {grade_names[k]}仓 "
                  f"(容量{capacity[k]}万件, 建设成本{bc}万元)")

print(f"\n  总建设成本: {total_build} 万元")

print("\n  初始库存:")
total_stock = 0
for i in cities:
    xv = pulp.value(x[i])
    if xv > 0.001:
        total_stock += xv
        print(f"    {city_names[i]}: {xv:.2f} 万件")
print(f"  总库存: {total_stock:.2f} 万件")
print(f"  库存成本: {total_stock * c_stock:.2f} 万元")

# --- 第二阶段决策 ---
scenario_names = {1: "市场火爆(p=0.3)", 2: "市场正常(p=0.5)", 3: "市场低迷(p=0.2)"}
for s in scenarios:
    print(f"\n{'=' * 70}")
    print(f"【情景{s}: {scenario_names[s]}】")
    print(f"  总需求: {total_demand[s]} 万件")
    print("-" * 40)

    # 紧急补货
    total_emer = 0
    for i in cities:
        ev = pulp.value(e[(i, s)])
        if ev > 0.001:
            total_emer += ev
            print(f"  紧急补货 → {city_names[i]}: {ev:.2f} 万件")
    if total_emer > 0.001:
        print(f"  紧急补货合计: {total_emer:.2f} 万件 (限制: {0.2*total_demand[s]:.1f})")

    # 调拨
    has_trans = False
    for (i, j) in pairs:
        tv = pulp.value(t[(i, j, s)])
        if tv > 0.001:
            if not has_trans:
                print(f"\n  调拨:")
                has_trans = True
            print(f"    {city_names[i]} → {city_names[j]}: {tv:.2f} 万件 "
                  f"(@{transfer_cost[(i,j)]}元)")

    # 配送
    print(f"\n  配送:")
    for j in cities:
        sources = []
        for i in cities:
            dv = pulp.value(d[(i, j, s)])
            if dv > 0.001:
                sources.append(f"{city_names[i]}:{dv:.2f}")
        uv = pulp.value(u[(j, s)])
        shortage = f", 缺货:{uv:.2f}" if uv > 0.001 else ""
        print(f"    {city_names[j]}区域(需{demand[(j,s)]}): "
              f"{', '.join(sources)}{shortage}")

    # 期末库存
    print(f"\n  期末库存:")
    for i in cities:
        lv = pulp.value(l[(i, s)])
        if lv > 0.001:
            print(f"    {city_names[i]}: {lv:.2f} 万件")

    # 情景利润
    rev_val = sum(revenue * (demand[(j, s)] - pulp.value(u[(j, s)])) for j in cities)
    trans_val = sum(transfer_cost[(i, j)] * pulp.value(t[(i, j, s)]) for (i, j) in pairs)
    del_val = sum(deliver_cost[(i, j)] * pulp.value(d[(i, j, s)]) for i in cities for j in cities)
    emer_val = sum(c_emergency * pulp.value(e[(i, s)]) for i in cities)
    pen_val = sum(c_penalty * pulp.value(u[(j, s)]) for j in cities)
    sal_val = sum(c_salvage * pulp.value(l[(i, s)]) for i in cities)

    print(f"\n  情景{s}运营利润:")
    print(f"    收入:      {rev_val:>10.2f} 万元")
    print(f"    调拨成本:  {trans_val:>10.2f} 万元")
    print(f"    配送成本:  {del_val:>10.2f} 万元")
    print(f"    紧急补货:  {emer_val:>10.2f} 万元")
    print(f"    缺货惩罚:  {pen_val:>10.2f} 万元")
    print(f"    库存残值:  {sal_val:>10.2f} 万元")
    net = rev_val - trans_val - del_val - emer_val - pen_val + sal_val
    print(f"    净运营利润:{net:>10.2f} 万元")

print(f"\n{'=' * 70}")
print("【汇总】")
exp_ops = sum(prob[s] * (
    sum(revenue * (demand[(j, s)] - pulp.value(u[(j, s)])) for j in cities)
    - sum(transfer_cost[(i, j)] * pulp.value(t[(i, j, s)]) for (i, j) in pairs)
    - sum(deliver_cost[(i, j)] * pulp.value(d[(i, j, s)]) for i in cities for j in cities)
    - sum(c_emergency * pulp.value(e[(i, s)]) for i in cities)
    - sum(c_penalty * pulp.value(u[(j, s)]) for j in cities)
    + sum(c_salvage * pulp.value(l[(i, s)]) for i in cities)
) for s in scenarios)
print(f"  期望运营利润: {exp_ops:.2f} 万元")
print(f"  建设成本:     {total_build:.2f} 万元")
print(f"  库存成本:     {total_stock * c_stock:.2f} 万元")
print(f"  期望总利润:   {exp_ops - total_build - total_stock * c_stock:.2f} 万元")
print(f"  (验证) 目标值: {pulp.value(model.objective):.2f} 万元")
```

## 求解状态: Optimal

## 期望总利润: 3191.65 万元

## 【第一阶段决策】

南京: 中型仓 (容量10万件, 建设成本140万元)  苏州: 大型仓 (容量18万件, 建设成本230万元)  合肥: 小型仓 (容量5万件, 建设成本60万元)

总建设成本: 430 万元

初始库存:  南京: 10.00 万件  苏州: 18.00 万件  合肥: 5.00 万件  总库存: 33.00 万件  库存成本: 1650.00 万元

## 【情景1: 市场火爆(p=0.3)】总需求: 41 万件

紧急补货 → 苏州: 5.00 万件  紧急补货 → 合肥: 3.00 万件  紧急补货合计: 8.00 万件 (限制: 8.2)

配送:  杭州区域(需12): 苏州:12.00  南京区域(需10): 南京:10.00  苏州区域(需11): 苏州:11.00  合肥区域(需8): 合肥:8.00

期末库存:

情景1运营利润:  收入: 8200.00 万元  调拨成本: 0.00 万元  配送成本: 687.00 万元  紧急补货: 960.00 万元  缺货惩罚: 0.00 万元  库存残值: 0.00 万元  净运营利润: 6553.00 万元

## 【情景2: 市场正常(p=0.5)】总需求: 27.5 万件

配送:  杭州区域(需8): 苏州:8.00  南京区域(需7): 南京:7.00  苏州区域(需7.5): 苏州:7.50  合肥区域(需5): 合肥:5.00

期末库存:  南京: 3.00 万件  苏州: 2.50 万件

情景2运营利润:  收入: 5500.00 万元  调拨成本: 0.00 万元  配送成本: 460.50 万元  紧急补货: 0.00 万元  缺货惩罚: 0.00 万元  库存残值: 165.00 万元  净运营利润: 5204.50 万元

## 【情景3: 市场低迷(p=0.2)】总需求: 16.5 万件

配送:  杭州区域(需5): 苏州:5.00  南京区域(需4): 南京:4.00  苏州区域(需4.5): 苏州:4.50  合肥区域(需3): 合肥:3.00

期末库存:  南京: 6.00 万件  苏州: 8.50 万件  合肥: 2.00 万件

情景3运营利润:  收入: 3300.00 万元  调拨成本: 0.00 万元  配送成本: 277.50 万元  紧急补货: 0.00 万元  缺货惩罚: 0.00 万元  库存残值: 495.00 万元  净运营利润: 3517.50 万元

## 【汇总】

期望运营利润: 5271.65 万元 建设成本: 430.00 万元 库存成本: 1650.00 万元 期望总利润: 3191.65 万元 (验证) 目标值: 3191.65 万元