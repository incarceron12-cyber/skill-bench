# Reference — `task_02_two_stage_stochastic`

## Included

- `generate_instances.py`
- `optimal_value.json`
- `solve.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
