# Evaluation for `task_02_two_stage_stochastic`

- `rubric.md` — task-specific ORAC / failure-oriented checklist
- `auto_eval.py` — optional wrappers around feasibility + gap checks
