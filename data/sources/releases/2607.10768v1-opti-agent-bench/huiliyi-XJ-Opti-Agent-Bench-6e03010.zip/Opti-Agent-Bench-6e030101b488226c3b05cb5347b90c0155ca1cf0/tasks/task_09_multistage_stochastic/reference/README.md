# Reference — `task_09_multistage_stochastic`

## Included

- `analyze_difficulty.py`
- `solve.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
