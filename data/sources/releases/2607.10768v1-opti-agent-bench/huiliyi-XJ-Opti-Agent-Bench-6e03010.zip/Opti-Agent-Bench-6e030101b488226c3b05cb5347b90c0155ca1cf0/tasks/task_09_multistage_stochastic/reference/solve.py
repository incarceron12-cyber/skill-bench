"""
多阶段随机优化 Benchmark 求解器
电商干线运力规划与库存管理 — 后向递推动态规划 (Backward Induction DP)

状态: (t, I_{t-1}, D_{t-1})
决策: x_t (预订车辆数, 整数)
内层: 给定 x_t 和实现的 D_t, 最优化 y_t, z_t, s_t
"""

import numpy as np
from itertools import product
import math

# ============================================================
# 参数定义
# ============================================================
T = 5  # 计划期天数
DEMAND_LEVELS = [6, 14, 24]  # 低/中/高需求 (拉大差距: 6 vs 24)
D_IDX = {6: 0, 14: 1, 24: 2}  # 需求值 -> 索引

# 第1天初始分布
INIT_PROB = {6: 0.25, 14: 0.50, 24: 0.25}

# 马尔可夫转移概率矩阵 — 增强惯性
# P[i][j] = P(D_t = DEMAND_LEVELS[j] | D_{t-1} = DEMAND_LEVELS[i])
TRANS_PROB = [
    [0.65, 0.25, 0.10],  # 低->低概率大
    [0.15, 0.50, 0.35],  # 中等, 略偏高
    [0.05, 0.20, 0.75],  # 高->高概率很大
]

# 成本参数
C_BOOK_TIERS = [(10, 1.2), (10, 0.9), (float('inf'), 0.7)]  # (数量上限, 单价)
C_SPOT = {6: 1.5, 14: 2.5, 24: 4.0}      # 现货单价(依赖需求)
Y_MAX  = {6: 5,   14: 3,   24: 2}         # 现货上限(依赖需求)
C_AIR  = 6.0      # 航空兜底成本
C_HOLD = 0.5      # 库存持有成本 (提高, 让存货更贵)
I_MAX  = 8         # 仓库容量
R_SALV = 0.3       # 清仓回收价
R_END  = 0.5       # 期末库存残值
I_0    = 3         # 初始库存

# x_t 搜索上界 (最大可能需求 + 余量)
X_MAX = 28


def booking_cost(x):
    """三段阶梯折扣买断成本"""
    if x <= 0:
        return 0.0
    cost = 0.0
    remaining = x
    for qty_limit, price in C_BOOK_TIERS:
        take = min(remaining, qty_limit)
        cost += take * price
        remaining -= take
        if remaining <= 0:
            break
    return cost


def inner_optimal(I_prev, x, d):
    """
    给定库存I_prev, 预订x, 需求实现d,
    求解最优 (y, z, s) 及其成本(不含booking_cost).
    
    逻辑:
    1. 可用供给 = I_prev + x
    2. 缺口 = max(0, d - 可用供给) -> 先用现货y补, 再用航空z
    3. 剩余 = 可用供给 + y + z - d -> 超出I_MAX的部分清仓s
    4. I_t = 剩余 - s
    """
    supply = I_prev + x
    shortfall = max(0, d - supply)
    
    # 现货补货
    y = min(shortfall, Y_MAX[d])
    remaining_shortfall = shortfall - y
    
    # 航空兜底
    z = remaining_shortfall
    
    # 结余库存
    total_after = supply + y + z - d  # = max(0, supply - d) 当shortfall>0时为0; 否则为supply-d
    
    # 清仓处理
    s = max(0, total_after - I_MAX)
    I_t = total_after - s
    
    # 成本 (不含booking)
    cost = (C_SPOT[d] * y + C_AIR * z + C_HOLD * I_t - R_SALV * s)
    
    return y, z, s, I_t, cost


# ============================================================
# 后向递推动态规划
# ============================================================
# 状态空间: (I_{t-1}, D_{t-1})
# I_{t-1} 取整数值 0..I_MAX
# D_{t-1} 取 {8, 14, 20} (第1天之前用 None 表示)
#
# V[t][(I, d_prev)] = 从第t天开始到第T天结束的最小期望成本
# policy[t][(I, d_prev)] = 最优预订量 x_t*

def solve_dp():
    """后向递推求解最优策略"""
    V = [{} for _ in range(T + 2)]  # V[1]..V[T+1]
    policy = [{} for _ in range(T + 2)]
    
    # 边界条件: V[T+1][(I, d_prev_idx)] = -R_END * I  (期末残值回收)
    for I in range(I_MAX + 1):
        for d_idx in range(3):
            V[T + 1][(I, d_idx)] = -R_END * I
    
    # 后向递推: t = T, T-1, ..., 1
    for t in range(T, 0, -1):
        print(f"  求解第 {t} 天...")
        
        if t == 1:
            states = [(I_0, None)]
        else:
            states = [(I, d_idx) for I in range(I_MAX + 1) for d_idx in range(3)]
        
        for (I, d_prev_idx) in states:
            best_cost = float('inf')
            best_x = 0
            
            if t == 1:
                probs = [INIT_PROB[d] for d in DEMAND_LEVELS]
            else:
                probs = TRANS_PROB[d_prev_idx]
            
            for x in range(0, X_MAX + 1):
                c_book = booking_cost(x)
                expected_future = 0.0
                
                for j, d in enumerate(DEMAND_LEVELS):
                    p = probs[j]
                    if p == 0:
                        continue
                    y, z, s, I_next, stage_cost = inner_optimal(I, x, d)
                    future_cost = V[t + 1][(I_next, j)]
                    expected_future += p * (stage_cost + future_cost)
                
                total_cost = c_book + expected_future
                if total_cost < best_cost:
                    best_cost = total_cost
                    best_x = x
            
            V[t][(I, d_prev_idx)] = best_cost
            policy[t][(I, d_prev_idx)] = best_x
    
    return V, policy


def print_optimal_policy(V, policy):
    """打印最优策略"""
    print("\n" + "=" * 70)
    print("最优策略求解结果")
    print("=" * 70)
    
    I, d_prev = I_0, None
    opt_cost = V[1][(I, d_prev)]
    opt_x1 = policy[1][(I, d_prev)]
    print(f"\n第1天: 库存={I}, 最优预订 x1* = {opt_x1}")
    print(f"  买断成本 = {booking_cost(opt_x1):.2f} 万元")
    print(f"  从第1天起的期望总成本 = {opt_cost:.2f} 万元")
    
    for t in range(2, T + 1):
        print(f"\n第{t}天最优预订策略 x{t}*(I, D_{{t-1}}):")
        print(f"  {'库存I':>6} | {'D=8(低)':>8} | {'D=14(中)':>8} | {'D=20(高)':>8}")
        print(f"  {'-'*6} | {'-'*8} | {'-'*8} | {'-'*8}")
        for I in range(I_MAX + 1):
            vals = [policy[t].get((I, j), '-') for j in range(3)]
            print(f"  {I:>6} | {vals[0]:>8} | {vals[1]:>8} | {vals[2]:>8}")


# ============================================================
# 蒙特卡洛模拟：评估任意策略的期望成本
# ============================================================

def simulate_policy(policy_func, n_sim=200000, seed=42):
    """
    蒙特卡洛模拟评估给定策略的期望总成本.
    policy_func(t, I, d_prev_idx) -> x_t
    """
    rng = np.random.default_rng(seed)
    total_costs = np.zeros(n_sim)
    
    for sim in range(n_sim):
        I = I_0
        d_prev_idx = None
        cost = 0.0
        
        for t in range(1, T + 1):
            # 决策 x_t
            x = policy_func(t, I, d_prev_idx)
            cost += booking_cost(x)
            
            # 需求实现
            if t == 1:
                probs = [INIT_PROB[d] for d in DEMAND_LEVELS]
            else:
                probs = TRANS_PROB[d_prev_idx]
            d_idx = rng.choice(3, p=probs)
            d = DEMAND_LEVELS[d_idx]
            
            # 内层最优
            y, z, s, I_next, stage_cost = inner_optimal(I, x, d)
            cost += stage_cost
            
            I = I_next
            d_prev_idx = d_idx
        
        # 期末残值
        cost -= R_END * I
        total_costs[sim] = cost
    
    return np.mean(total_costs), np.std(total_costs) / np.sqrt(n_sim)


def dp_policy_func(policy):
    """将DP策略表转为函数"""
    def func(t, I, d_prev_idx):
        if t == 1:
            return policy[1][(I_0, None)]
        return policy[t].get((I, d_prev_idx), 10)
    return func


# --- 启发式策略定义 ---

def heuristic_A(t, I, d_prev_idx):
    """策略A（均值匹配）: 预订 max(0, ceil(E[D_t]) - I)"""
    if t == 1:
        probs = [INIT_PROB[d] for d in DEMAND_LEVELS]
    else:
        probs = TRANS_PROB[d_prev_idx]
    e_d = sum(p * d for p, d in zip(probs, DEMAND_LEVELS))
    return max(0, math.ceil(e_d) - I)


def heuristic_B(t, I, d_prev_idx):
    """策略B（保守低订）: 每天固定预订8辆"""
    return 8


def heuristic_C(t, I, d_prev_idx):
    """策略C（激进高订）: 每天固定预订18辆"""
    return 18


def compare_strategies(V, policy):
    """对比最优策略与启发式"""
    print("\n" + "=" * 70)
    print("策略对比 (蒙特卡洛模拟, 20万次)")
    print("=" * 70)
    
    strategies = [
        ("最优DP策略", dp_policy_func(policy)),
        ("策略A(均值匹配)", heuristic_A),
        ("策略B(保守低订=8)", heuristic_B),
        ("策略C(激进高订=18)", heuristic_C),
    ]
    
    results = {}
    for name, func in strategies:
        mean_cost, se = simulate_policy(func)
        results[name] = mean_cost
        print(f"  {name:20s}: 期望成本 = {mean_cost:.2f} 万元 (±{1.96*se:.2f})")
    
    # DP精确值
    dp_exact = V[1][(I_0, None)]
    print(f"\n  DP精确期望成本 = {dp_exact:.2f} 万元")
    
    # 节省百分比
    print("\n  相对节省:")
    dp_cost = results["最优DP策略"]
    for name, cost in results.items():
        if name != "最优DP策略":
            saving = (cost - dp_cost) / cost * 100
            print(f"    vs {name}: 节省 {saving:.1f}%")
    
    return results


# ============================================================
# 灵敏度分析
# ============================================================

def sensitivity_warehouse_capacity():
    """仓库容量从4变化到12时，最优成本如何变化"""
    global I_MAX
    print("\n" + "=" * 70)
    print("灵敏度分析1: 仓库容量 I_MAX 对最优成本的影响")
    print("=" * 70)
    
    original_I_MAX = I_MAX
    results = []
    
    for cap in range(4, 13):
        I_MAX = cap
        V, pol = solve_dp()
        cost = V[1][(I_0, None)]
        results.append((cap, cost))
        print(f"  I_MAX = {cap:2d} -> 期望总成本 = {cost:.2f} 万元")
    
    I_MAX = original_I_MAX
    return results


def sensitivity_air_cost():
    """航空成本从4.0变化到8.0时，最优策略如何变化"""
    global C_AIR
    print("\n" + "=" * 70)
    print("灵敏度分析2: 航空成本 C_AIR 对最优成本和策略的影响")
    print("=" * 70)
    
    original_C_AIR = C_AIR
    results = []
    
    for c in [4.0, 5.0, 6.0, 7.0, 8.0]:
        C_AIR = c
        V, pol = solve_dp()
        cost = V[1][(I_0, None)]
        x1 = pol[1][(I_0, None)]
        results.append((c, cost, x1))
        print(f"  C_AIR = {c:.1f} -> 期望总成本 = {cost:.2f} 万元, 第1天最优预订 x1* = {x1}")
    
    C_AIR = original_C_AIR
    return results


# ============================================================
# 精确期望成本计算（场景树枚举验证）
# ============================================================

def exact_expected_cost(policy):
    """通过枚举所有 3^5=243 个场景精确计算DP策略的期望成本"""
    total_cost = 0.0
    
    for scenario in product(range(3), repeat=T):
        # scenario = (d1_idx, d2_idx, ..., d5_idx)
        # 计算该场景的概率
        prob = INIT_PROB[DEMAND_LEVELS[scenario[0]]]
        for t in range(1, T):
            prob *= TRANS_PROB[scenario[t-1]][scenario[t]]
        
        # 模拟该场景下的成本
        I = I_0
        d_prev_idx = None
        cost = 0.0
        
        for t in range(1, T + 1):
            if t == 1:
                x = policy[1][(I_0, None)]
            else:
                x = policy[t][(I, d_prev_idx)]
            
            cost += booking_cost(x)
            d = DEMAND_LEVELS[scenario[t-1]]
            y, z, s, I_next, stage_cost = inner_optimal(I, x, d)
            cost += stage_cost
            I = I_next
            d_prev_idx = scenario[t-1]
        
        # 期末残值
        cost -= R_END * I
        total_cost += prob * cost
    
    return total_cost


# ============================================================
# 主函数
# ============================================================

if __name__ == "__main__":
    print("=" * 70)
    print("多阶段随机优化 Benchmark 求解器")
    print("电商干线运力规划与库存管理")
    print("=" * 70)
    
    # 1. 求解最优策略
    print("\n[1] 后向递推动态规划求解...")
    V, policy = solve_dp()
    print_optimal_policy(V, policy)
    
    # 2. 精确验证
    print("\n[2] 场景树精确枚举验证...")
    exact_cost = exact_expected_cost(policy)
    dp_cost = V[1][(I_0, None)]
    print(f"  DP值函数给出的期望成本:  {dp_cost:.4f} 万元")
    print(f"  场景树枚举验证的期望成本: {exact_cost:.4f} 万元")
    print(f"  差异: {abs(dp_cost - exact_cost):.6f} (应为0)")
    
    # 3. 策略对比
    print("\n[3] 策略对比...")
    compare_strategies(V, policy)
    
    # 4. 灵敏度分析
    print("\n[4] 灵敏度分析...")
    sensitivity_warehouse_capacity()
    sensitivity_air_cost()
    
    print("\n" + "=" * 70)
    print("求解完毕!")
    print("=" * 70)