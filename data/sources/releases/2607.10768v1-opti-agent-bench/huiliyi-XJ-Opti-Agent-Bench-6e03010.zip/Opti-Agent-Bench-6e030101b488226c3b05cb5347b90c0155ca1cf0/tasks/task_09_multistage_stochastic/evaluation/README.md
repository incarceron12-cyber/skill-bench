# Evaluation for `task_09_multistage_stochastic`

- `rubric.md` — task-specific ORAC / failure-oriented checklist
- `auto_eval.py` — optional wrappers around feasibility + gap checks
