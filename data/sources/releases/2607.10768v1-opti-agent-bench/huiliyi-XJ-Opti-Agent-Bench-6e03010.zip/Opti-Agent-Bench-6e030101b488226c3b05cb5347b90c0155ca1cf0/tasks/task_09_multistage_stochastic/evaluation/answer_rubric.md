# Metric-Aligned Answer Rubric：多阶段随机优化 / 问题1_电商干线运力规划

## Problem Analysis

本题是一个**多阶段随机库存-运力联合优化**问题，也可等价建模为有限期马尔可夫决策过程或场景树随机整数规划。

关键结构：

- 提前决策：每日 `x_t` 在当天需求 `D_t` 揭示前决定，只能依赖历史需求和期初库存。
- 追补决策：`y_t, z_t, s_t` 在当天需求揭示后决定，分别表示现货、航空兜底和清仓。
- 状态耦合：库存 `I_t` 跨期结转，需求状态按马尔可夫链转移。
- 成本陷阱：买断成本是边际成本递减的阶梯折扣，不能当作普通凸分段线性成本随意线性化。
- 验证目标：参考 DP 解的基准结果为最优期望成本约 `104.4533` 万元，第 1 天最优预订量为 `21` 辆。

关键陷阱：

- 不能把五天拆成独立单期报童问题。
- 不能让 `x_t` 使用当天或未来需求，否则违反非预期性。
- 不能漏掉清仓收益、库存持有成本或期末回收。
- 不能把策略 B 改成非题面要求的固定 `8` 辆。
- 不能用错误的分段线性建模把全部买断量放入最低价阶梯。
- 数值结果必须能由代码、DP/场景树或精确枚举复现。

## Global Scoring Rules

- 每个统一指标满分为 5 分。
- 每个子项可按 `0 / partial / full` 给分；若证据明显不足，给 0。
- `Scoring Method = Automatic` 表示优先使用代码运行、reference 复算、临时代码抽取或独立数值检查。
- `Scoring Method = LLM Judge` 表示由大模型根据回答文本进行语义评分。
- `Scoring Method = Hybrid` 表示先抽取代码或运行结果，再由大模型比较文本声明与实际实现。
- 本题题面明确要求仓库容量和航空成本灵敏度分析，因此 `CE.3` 正式评分并纳入总分。

## ME.1 模型正确性

评估回答是否正确理解并建模多阶段随机库存-运力联合优化问题。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME1-R1 | 识别为多阶段随机优化 / 有限期 MDP / 场景树随机整数规划，而不是独立单期优化 | response text | LLM Judge | 0.70 |
| ME1-R2 | 正确刻画马尔可夫需求：第 1 天初始分布、第 2-5 天条件转移概率 | response text / code | Hybrid | 0.70 |
| ME1-R3 | 正确区分 `x_t` 的事前决策和 `y_t,z_t,s_t` 的事后追补决策 | response text / code | Hybrid | 0.75 |
| ME1-R4 | 完整包含期望总成本：买断、现货、航空、持有、清仓收益、期末回收 | response text / code | Hybrid | 0.95 |
| ME1-R5 | 正确处理库存流量平衡、需求满足、仓库容量、现货上限和整数非负约束 | response text / code | Hybrid | 1.00 |
| ME1-R6 | 严格体现非预期性：`x_t` 只依赖历史需求与期初库存，不泄露当天/未来需求 | response text / code | Hybrid | 0.90 |

ME.1 total: 5 points

## ME.2 模型简洁性

评估建模和算法是否聚焦、必要、不过度复杂，并能避开本题的反模板陷阱。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME2-R1 | 选择适合小规模有限状态问题的后向 DP，或清楚说明等价的场景树 MIP | response text / code | LLM Judge | 1.00 |
| ME2-R2 | 状态表示紧凑，例如 `(I_{t-1}, D_{t-1})`，而非无必要地膨胀完整历史 | response text / code | LLM Judge | 0.90 |
| ME2-R3 | 分段阶梯买断成本处理正确且简洁：枚举、显式函数或带顺序约束的整数建模 | response text / code | Hybrid | 1.15 |
| ME2-R4 | 事后子问题处理清楚，现货、航空、清仓和容量逻辑不引入额外不必要变量或错误假设 | response text / code | Hybrid | 1.00 |
| ME2-R5 | 回答聚焦求解本题，不用大量评估器设计、管理建议或无关战略分析稀释核心解法 | response text | LLM Judge | 0.95 |

ME.2 total: 5 points

## ME.3 模型-代码一致性

评估报告声明的方法、数值结果和实际代码是否一致。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| ME3-R1 | 文本声称的 DP / MIP / 场景树方法与代码实际实现一致 | response text + code | Hybrid | 0.90 |
| ME3-R2 | 文本中的状态、变量、约束与代码中的索引和状态转移一致 | response text + code | Hybrid | 1.05 |
| ME3-R3 | 文本中的成本函数和分段阶梯处理与代码实现一致 | response text + code | Hybrid | 1.05 |
| ME3-R4 | 报告中的最优成本、第 1 天决策、启发式对比与代码运行或 reference 复算一致 | response text + execution result | Hybrid | 1.20 |
| ME3-R5 | 灵敏度分析声明与实际代码重求解逻辑一致，而不是硬编码或只写趋势判断 | response text + code | Hybrid | 0.80 |

ME.3 total: 5 points

## CE.1 代码可行性与正确性

评估代码是否可运行，并能求出合法、目标正确、接近参考解的策略。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE1-R1 | 提供可抽取、可执行的 Python 求解代码，而不是只有伪代码或评测说明 | code block / extracted code | Automatic + LLM fallback | 0.85 |
| CE1-R2 | 代码能在当前环境或明确依赖环境中运行到主要结果输出 | execution result | Automatic | 0.95 |
| CE1-R3 | 输出的最优期望成本接近 reference `104.4533` 万元，第 1 天预订量接近 `21` | execution result / reference | Automatic | 1.10 |
| CE1-R4 | 代码生成的策略满足库存平衡、容量、现货上限、需求满足和非预期性 | execution result / code inspection | Automatic + LLM Judge | 1.10 |
| CE1-R5 | 启发式 A/B/C 对比按题面定义执行，尤其策略 B 必须是固定 `8` 辆 | execution result / response text | Hybrid | 1.00 |

CE.1 total: 5 points

## CE.2 代码质量与效率

评估代码结构、可维护性、效率和可复用性。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE2-R1 | 模块化清楚，成本函数、单期追补、DP/MIP、策略评估和灵敏度分析分工明确 | code | LLM Judge | 1.00 |
| CE2-R2 | 索引体系和边界条件稳定，尤其 `t=1`、`t=5`、`V_6` 和需求状态键不出错 | code / execution result | Automatic + LLM Judge | 1.10 |
| CE2-R3 | 算法复杂度适合本题规模，DP 枚举或场景树 MIP 不产生无谓超时 | code / execution result | Automatic + LLM Judge | 1.00 |
| CE2-R4 | 代码依赖、输入输出和运行入口清楚，不依赖不可写绝对路径或缺失环境 | code / execution result | Automatic + LLM Judge | 0.95 |
| CE2-R5 | 代码有基本自检、复算、场景树验证或趋势检查，能暴露主要逻辑错误 | code / execution result | Hybrid | 0.95 |

CE.2 total: 5 points

## CE.3 代码鲁棒性

评估代码是否完成题面要求的参数扰动和灵敏度分析。本题以仓库容量 `4..12` 和航空成本 `4.0..8.0` 的重求解结果作为主要证据。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| CE3-R1 | 仓库容量 `I_MAX=4..12` 下重新求最优解，并呈现成本随容量非增 | execution result / response text | Automatic + LLM Judge | 1.20 |
| CE3-R2 | 航空成本 `c_air=4.0..8.0` 下重新求最优解，并呈现成本随航空成本非减 | execution result / response text | Automatic + LLM Judge | 1.20 |
| CE3-R3 | 灵敏度分析使用真实重求解而不是硬编码、只写趋势或只给示例 JSON | code / execution result | Hybrid | 1.00 |
| CE3-R4 | 参数改变时仍保持约束可行和数值自洽，例如基准点与 baseline 一致 | execution result / code | Automatic + LLM Judge | 0.90 |
| CE3-R5 | 对扩展规模、参数变化、分布漂移或求解依赖的局限有合理说明 | response text | LLM Judge | 0.70 |

CE.3 total: 5 points

## RE.1 报告完整性

评估回答是否完整覆盖题目要求的建模、算法、数值、对比和灵敏度分析。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE1-R1 | 清楚重述业务流程、随机需求、成本结构、初始库存和计划期 | response text | LLM Judge | 0.70 |
| RE1-R2 | 给出完整数学模型或 Bellman 方程，包括变量、目标、约束和非预期性 | response text | LLM Judge | 1.10 |
| RE1-R3 | 给出具体求解算法和复杂度/状态空间分析 | response text | LLM Judge | 0.90 |
| RE1-R4 | 给出完整数值结果：最优成本、第 1 天决策、后续策略规则表或可查询策略 | response text / output | LLM Judge + execution | 1.10 |
| RE1-R5 | 给出 A/B/C 启发式对比和两类灵敏度分析 | response text / output | LLM Judge + execution | 1.20 |

RE.1 total: 5 points

## RE.2 解释清晰度

评估回答是否清楚解释多阶段结构、马尔可夫信息价值和业务含义。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE2-R1 | 清楚解释为什么库存结转和马尔可夫需求使问题必须多阶段处理 | response text | LLM Judge | 1.10 |
| RE2-R2 | 清楚解释非预期性约束和事前/事后决策时序 | response text | LLM Judge | 1.00 |
| RE2-R3 | 清楚解释阶梯折扣、现货稀缺和航空兜底之间的经济权衡 | response text | LLM Judge | 1.00 |
| RE2-R4 | 清楚解释最优策略与均值匹配、固定低订、固定高订的差异 | response text | LLM Judge | 0.95 |
| RE2-R5 | 文字组织清晰，不过度混入无关评估协议、模板说明或泛泛战略建议 | response text | LLM Judge | 0.95 |

RE.2 total: 5 points

## RE.3 结果可复现性

评估报告声称的结果是否可以由代码、reference 或独立运行复现。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE3-R1 | 提供明确运行入口、依赖说明或可直接运行的主程序 | response text / code | Automatic + LLM Judge | 0.90 |
| RE3-R2 | 最优成本和第 1 天决策能由代码实际复现 | execution result / reference | Automatic | 1.20 |
| RE3-R3 | 启发式对比能由代码实际复现，并符合题面策略定义 | execution result / reference | Automatic | 1.05 |
| RE3-R4 | 灵敏度分析能由代码实际复现，基准参数点与主结果一致 | execution result / code | Automatic | 1.05 |
| RE3-R5 | 报告没有虚报执行成功、最优性、成本节省或代码能力 | response text + execution result | Hybrid | 0.80 |

RE.3 total: 5 points

## RE.4 局限承认

评估回答是否诚实说明建模、代码、评估和业务落地局限。

| Rubric ID | Checkpoint | Evidence Source | Scoring Method | Points |
|---|---|---|---|---:|
| RE4-R1 | 承认精确 DP / 场景树方法在更长周期、更细状态、更大需求空间下会扩展困难 | response text | LLM Judge | 1.05 |
| RE4-R2 | 承认马尔可夫转移概率、成本参数和三点需求分布的估计误差风险 | response text | LLM Judge | 1.00 |
| RE4-R3 | 承认风险中性期望成本目标未覆盖 CVaR、服务水平、延迟和客户流失等现实目标 | response text | LLM Judge | 0.90 |
| RE4-R4 | 如实说明代码依赖、运行失败、硬编码、启发式改写或分段成本建模风险 | response text + code | Hybrid | 1.20 |
| RE4-R5 | 不夸大泛化能力、满分、生产可用性或评估可靠性 | response text | LLM Judge | 0.85 |

RE.4 total: 5 points

## Expected Failure Modes

- 把问题拆成五个独立单期优化，忽略库存状态和马尔可夫信息。
- `x_t` 按当天需求或完整场景路径逐场景决策，违反非预期性。
- 目标函数漏掉清仓收益、期末回收或持有成本。
- 分段买断成本线性化错误，把所有车辆放入最低价阶梯。
- 代码运行失败，或能运行但最优成本远离 `104.4533`。
- 将策略 B 从固定 `8` 辆改成其他数值，导致对比验证失真。
- 灵敏度分析只写趋势、不重求解，或基准点与主结果不一致。
- 报告大量讨论评测器、战略路线图或泛泛业务建议，却没有完整给出本题策略和数值结果。
