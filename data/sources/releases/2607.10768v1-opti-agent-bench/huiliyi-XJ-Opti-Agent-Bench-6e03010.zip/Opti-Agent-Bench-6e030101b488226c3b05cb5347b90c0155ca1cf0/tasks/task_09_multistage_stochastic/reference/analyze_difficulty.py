"""分析当前 benchmark 问题的难度"""
from solve import *

print('=== 问题难度诊断 ===')
print()

# 1. 状态空间
n_states = (I_MAX + 1) * 3
print(f'1. 每阶段状态数: {I_MAX+1} x 3 = {n_states}')
print(f'   总场景数: 3^{T} = {3**T}')
print(f'   决策枚举范围: 0~{X_MAX} = {X_MAX+1} 个值')
print(f'   总计算量: {T} x {n_states} x {X_MAX+1} x 3 = {T*n_states*(X_MAX+1)*3}')
print()

# 2. 内层问题
print('2. 内层优化: y,z,s 的求解')
print('   -> 纯贪心, 无需求解器, O(1) 复杂度')
print('   -> 因为 c_spot < c_air, 总是先用现货再用航空')
print()

# 3. 马尔可夫区分度
V, policy = solve_dp()
print()
print('3. 马尔可夫区分度 (策略因需求状态不同的库存水平数/总数):')
for t in range(1, T+1):
    if t == 1:
        print(f'   第{t}天: 固定状态, 单一决策 x1*={policy[1][(I_0, None)]}')
        continue
    diffs = 0
    for I in range(I_MAX+1):
        vals = [policy[t][(I, j)] for j in range(3)]
        if len(set(vals)) > 1:
            diffs += 1
    print(f'   第{t}天: {diffs}/{I_MAX+1} 个库存水平上策略因需求状态不同')

# 4. order-up-to 结构检测
print()
print('4. 策略结构 (I + x = order-up-to level):')
for t in [2, 3, 4, 5]:
    for j in range(3):
        levels = set()
        for I in range(I_MAX+1):
            x = policy[t][(I, j)]
            levels.add(I + x)
        d_name = ['D_prev=6(low)', 'D_prev=14(mid)', 'D_prev=24(high)'][j]
        if len(levels) == 1:
            print(f'   t={t}, {d_name}: 纯order-up-to = {levels.pop()}')
        else:
            print(f'   t={t}, {d_name}: I+x in {sorted(levels)} (非单一order-up-to)')

# 5. 三种需求状态的策略差异
print()
print('5. 三种需求状态策略差异明细 (I=0时):')
for t in [2, 3, 4, 5]:
    vals = [policy[t][(0, j)] for j in range(3)]
    print(f'   t={t}: x*(I=0, D_prev=6)={vals[0]}, x*(I=0, D_prev=14)={vals[1]}, x*(I=0, D_prev=24)={vals[2]}')

