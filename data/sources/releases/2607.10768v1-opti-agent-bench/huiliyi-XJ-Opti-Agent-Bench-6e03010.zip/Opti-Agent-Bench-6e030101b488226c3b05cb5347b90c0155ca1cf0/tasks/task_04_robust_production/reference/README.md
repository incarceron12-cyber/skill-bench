# Reference — `task_04_robust_production`

## Included

- `problem_01_solve.py`
- `verify_optimality_proof.py`
- `verify_standard.py`

## Notes

- Scrubbed for public release (no internal hosts / absolute user paths).
- Full model responses and raw robustness dumps are not shipped.
