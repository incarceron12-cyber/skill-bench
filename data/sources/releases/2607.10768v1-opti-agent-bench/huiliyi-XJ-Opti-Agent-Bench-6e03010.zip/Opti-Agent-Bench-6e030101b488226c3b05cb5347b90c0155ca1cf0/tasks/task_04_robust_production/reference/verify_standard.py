"""
验证异构算力调度标准答案
1. 运行标准代码的CP-SAT求解器
2. 用PuLP/CBC重新求解做交叉验证
3. 手工验证约束是否满足
4. 分析标准答案的经济合理性
"""

import numpy as np

# ============================================================
# 问题数据（与标准答案一致）
# ============================================================
data = {
    "N": 6,
    "w":   [1200, 800, 600, 900, 700, 500],
    "q":   [1000, 700, 450, 750, 500, 350],
    "p":   [50,   80,  30,  60,  40,  90],
    "s":   [2000, 1500, 1000, 2500, 1200, 1800],

    "muC":  [40,  35, 30, 38, 32, 28],
    "muG1": [220, 180, 140, 200, 160, 120],
    "muG2": [140, 120, 100, 130, 110, 90],

    "kC":  2.0,
    "kG1": 30.0,
    "kG2": 18.0,

    "Ccpu": 120.0,
    "Cg1":  6.0,
    "Cg2":  8.0,

    "thetaC": 0.90,
    "thetaG1": 0.70,
    "thetaG2": 0.75,

    "B": 900.0,
    "phi": 0.65,
}

N = data["N"]
w = data["w"]
q = data["q"]
p = data["p"]
s = data["s"]
muC = data["muC"]
muG1 = data["muG1"]
muG2 = data["muG2"]
kC, kG1, kG2 = data["kC"], data["kG1"], data["kG2"]
Ccpu, Cg1, Cg2 = data["Ccpu"], data["Cg1"], data["Cg2"]
thetaC, thetaG1, thetaG2 = data["thetaC"], data["thetaG1"], data["thetaG2"]
B_net, phi = data["B"], data["phi"]

print("=" * 70)
print("Step 1: 验证标准答案声称的结果")
print("=" * 70)

# 标准答案：全部任务只完成SLA最低量，全放CPU
std_uC = [1000, 700, 450, 750, 500, 350]
std_uG1 = [0, 0, 0, 0, 0, 0]
std_uG2 = [0, 0, 0, 0, 0, 0]

# 验证CPU消耗
cpu_hours = sum(std_uC[i] / (thetaC * muC[i]) for i in range(N))
g1_hours = sum(std_uG1[i] / (thetaG1 * muG1[i]) for i in range(N))
g2_hours = sum(std_uG2[i] / (thetaG2 * muG2[i]) for i in range(N))

print(f"\nCPU消耗: {cpu_hours:.4f} / {Ccpu} ({'OK' if cpu_hours <= Ccpu else 'VIOLATED'})")
print(f"G1消耗:  {g1_hours:.4f} / {Cg1}")
print(f"G2消耗:  {g2_hours:.4f} / {Cg2}")

# 逐任务CPU消耗
print("\n逐任务CPU消耗 (核·小时):")
for i in range(N):
    h = std_uC[i] / (thetaC * muC[i])
    print(f"  Task {i}: {std_uC[i]}/{thetaC:.2f}/{muC[i]} = {h:.4f}")

# 资源成本
resource_cost = kC * cpu_hours + kG1 * g1_hours + kG2 * g2_hours
startup_cost = 0  # 无GPU使用
shortfall = [max(0, q[i] - std_uC[i] - std_uG1[i] - std_uG2[i]) for i in range(N)]
penalty_cost = sum(p[i] * shortfall[i] for i in range(N))
total_cost = resource_cost + startup_cost + penalty_cost

print(f"\n资源成本: {resource_cost:.2f}")
print(f"启动成本: {startup_cost:.2f}")
print(f"罚金成本: {penalty_cost:.2f}")
print(f"总成本:   {total_cost:.2f}")
print(f"标准答案声称: 239.69")
print(f"差异: {abs(total_cost - 239.69):.4f}")

# 网络约束
v = [0] * N  # 纯CPU无拆分
net_used = sum(v)
print(f"\n网络使用: {net_used} / {phi * B_net} (OK)")

print("\n" + "=" * 70)
print("Step 2: 分析是否真的全CPU最优")
print("=" * 70)

# 计算各任务在不同资源池上的单位工作量成本（最坏情况）
print("\n各任务各资源池的单位工作量成本 (元/工作量单位):")
print(f"{'Task':>5} | {'CPU成本':>10} | {'G1成本':>10} | {'G2成本':>10} | {'G1+启动':>12} | {'G2+启动':>12} | {'最优池':>6}")
for i in range(N):
    cost_cpu = kC / (thetaC * muC[i])
    cost_g1 = kG1 / (thetaG1 * muG1[i])
    cost_g2 = kG2 / (thetaG2 * muG2[i])
    # 含启动费摊销到q_i
    cost_g1_full = cost_g1 + s[i] / q[i]
    cost_g2_full = cost_g2 + s[i] / q[i]
    best = "CPU" if cost_cpu <= min(cost_g1_full, cost_g2_full) else ("G1" if cost_g1_full < cost_g2_full else "G2")
    print(f"  {i:>3} | {cost_cpu:>10.4f} | {cost_g1:>10.4f} | {cost_g2:>10.4f} | {cost_g1_full:>12.4f} | {cost_g2_full:>12.4f} | {best:>6}")

print("\n" + "=" * 70)
print("Step 3: 检查CPU容量是否足够完成所有SLA")
print("=" * 70)

total_cpu_for_sla = sum(q[i] / (thetaC * muC[i]) for i in range(N))
print(f"\n完成所有SLA所需CPU: {total_cpu_for_sla:.4f}")
print(f"CPU容量:              {Ccpu}")
print(f"{'足够' if total_cpu_for_sla <= Ccpu else '不够'}")

# 如果CPU不够，哪些任务需要GPU或接受罚金？
if total_cpu_for_sla > Ccpu:
    print(f"\n超出量: {total_cpu_for_sla - Ccpu:.4f} 核·小时")
    # 计算"放弃"每单位SLA的罚金 vs 节省的CPU成本
    print("\n各任务的边际权衡 (放弃1单位SLA: 节省CPU成本 vs 支付罚金):")
    for i in range(N):
        cpu_saved = 1 / (thetaC * muC[i])  # 核·小时
        cost_saved = kC * cpu_saved  # 元
        print(f"  Task {i}: CPU成本节省 {cost_saved:.4f} 元/单位, 罚金 {p[i]} 元/单位, 比值={p[i]/cost_saved:.2f}x")

print("\n" + "=" * 70)
print("Step 4: 运行CP-SAT标准代码")
print("=" * 70)

