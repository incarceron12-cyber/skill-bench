"""
鲁棒优化 Problem 01: 新产品线投产规划
使用 Bertsimas-Sim 预算不确定性集合的鲁棒线性优化

问题描述：
- 4种新产品(A, B, C, D)的生产量决策
- 3种资源约束(原料、工时、设备)
- 售价不确定：只有范围[c_min, c_max]，没有概率分布
- 预算不确定性集合：最多Γ个产品同时出现最坏售价
- 目标：最大化最坏情况下的总利润

数学模型（Bertsimas-Sim鲁棒对等式）：
    max  Σ_j (p̄_j - cost_j) x_j - Γ q - Σ_j r_j
    s.t. q + r_j >= p̂_j x_j    ∀j ∈ J_uncertain
         r_j >= 0               ∀j
         q >= 0
         Σ_j a_{ij} x_j <= b_i  ∀i (资源约束)
         x_j >= L_j              ∀j (最低产量)
         x_j <= U_j              ∀j (最大产量)

    其中：
    - p̄_j = 名义售价（区间中点）
    - p̂_j = 售价半偏差（(max-min)/2）
    - cost_j = 单位生产成本
    - Γ = 不确定性预算（最多几个产品同时偏差）
"""

from pulp import *

# ============================================================
# 数据定义
# ============================================================

products = ['A', 'B', 'C', 'D']
resources = ['原料', '工时', '设备']

# 售价不确定性（元/件）
# 产品D是独家专利产品，售价确定
price_range = {
    'A': (140, 200),   # 名义180, 偏差30 → 实际不确定利润
    'B': (250, 350),   # 名义300, 偏差50
    'C': (180, 260),   # 名义220, 偏差40
    'D': (400, 400),   # 确定售价400（独家产品）
}

# 单位生产成本（元/件）—— 确定参数
unit_cost = {'A': 120, 'B': 200, 'C': 160, 'D': 300}

# 名义售价和偏差
p_bar = {j: (price_range[j][0] + price_range[j][1]) / 2 for j in products}
p_hat = {j: (price_range[j][1] - price_range[j][0]) / 2 for j in products}

# 名义单位利润
nominal_profit = {j: p_bar[j] - unit_cost[j] for j in products}

# 资源消耗矩阵 a[i][j] = 产品j消耗资源i的数量
resource_usage = {
    '原料': {'A': 2, 'B': 5, 'C': 3, 'D': 7},
    '工时': {'A': 3, 'B': 4, 'C': 5, 'D': 6},
    '设备': {'A': 1, 'B': 3, 'C': 2, 'D': 4},
}

# 资源可用量
resource_avail = {'原料': 800, '工时': 900, '设备': 500}

# 产量约束
min_production = {'A': 20, 'B': 10, 'C': 15, 'D': 5}   # 合同最低
max_production = {'A': 150, 'B': 100, 'C': 120, 'D': 60}  # 市场上限

# 不确定性预算 Gamma
Gamma = 2

# 有不确定性的产品集合
uncertain_products = [j for j in products if p_hat[j] > 0]

print("=" * 60)
print("参数检查")
print("=" * 60)
for j in products:
    print(f"产品{j}: 售价范围[{price_range[j][0]}, {price_range[j][1]}], "
          f"成本{unit_cost[j]}, 名义利润{nominal_profit[j]}, 偏差{p_hat[j]}")
print(f"\n不确定性预算 Γ = {Gamma}")
print(f"受不确定性影响的产品: {uncertain_products}")
print()

# ============================================================
# Bertsimas-Sim 鲁棒对等式
# ============================================================

model = LpProblem("Robust_Production_Planning", LpMaximize)

# 决策变量
x = {j: LpVariable(f"x_{j}", lowBound=min_production[j], upBound=max_production[j])
     for j in products}

# 鲁棒对等式的辅助变量
q = LpVariable("q", lowBound=0)  # 对偶变量对应Gamma约束
r = {j: LpVariable(f"r_{j}", lowBound=0) for j in uncertain_products}

# 目标函数：最大化 最坏情况利润
# = Σ 名义利润*x - Γ*q - Σ r_j
model += (
    lpSum(nominal_profit[j] * x[j] for j in products)
    - Gamma * q
    - lpSum(r[j] for j in uncertain_products),
    "worst_case_profit"
)

# 鲁棒约束：q + r_j >= p̂_j * x_j
for j in uncertain_products:
    model += q + r[j] >= p_hat[j] * x[j], f"robust_{j}"

# 资源约束
for i in resources:
    model += (
        lpSum(resource_usage[i][j] * x[j] for j in products) <= resource_avail[i],
        f"resource_{i}"
    )

# ============================================================
# 求解
# ============================================================
model.solve(PULP_CBC_CMD(msg=0))

print("=" * 60)
print(f"求解状态: {LpStatus[model.status]}")
print(f"最坏情况总利润: {value(model.objective):.2f} 元")
print("=" * 60)

# ============================================================
# 输出详细结果
# ============================================================

print("\n【生产方案】")
total_cost = 0
for j in products:
    qty = value(x[j])
    cost = qty * unit_cost[j]
    total_cost += cost
    nom_rev = qty * p_bar[j]
    print(f"  产品{j}: 生产 {qty:.1f} 件, "
          f"成本 {cost:.0f}元, "
          f"名义收入 {nom_rev:.0f}元")

print(f"\n  总生产成本: {total_cost:.0f} 元")

print("\n【鲁棒对等式辅助变量】")
print(f"  q (全局保护变量) = {value(q):.2f}")
for j in uncertain_products:
    print(f"  r_{j} = {value(r[j]):.2f}")

print(f"\n  鲁棒性代价 = Γ*q + Σr = {Gamma * value(q) + sum(value(r[j]) for j in uncertain_products):.2f}")

print("\n【资源使用情况】")
for i in resources:
    used = sum(resource_usage[i][j] * value(x[j]) for j in products)
    print(f"  {i}: {used:.0f} / {resource_avail[i]} ({used/resource_avail[i]*100:.1f}%)")

# ============================================================
# 对比分析：名义优化 vs 鲁棒优化
# ============================================================

print("\n" + "=" * 60)
print("对比分析：名义优化 vs 鲁棒优化")
print("=" * 60)

# 名义优化（不考虑不确定性）
model_nom = LpProblem("Nominal_Production", LpMaximize)
x_nom = {j: LpVariable(f"xn_{j}", lowBound=min_production[j], upBound=max_production[j])
         for j in products}

model_nom += lpSum(nominal_profit[j] * x_nom[j] for j in products), "nominal_profit"

for i in resources:
    model_nom += (
        lpSum(resource_usage[i][j] * x_nom[j] for j in products) <= resource_avail[i],
        f"resource_{i}"
    )

model_nom.solve(PULP_CBC_CMD(msg=0))

print(f"\n名义最优利润: {value(model_nom.objective):.2f} 元")
print("名义最优方案:")
for j in products:
    print(f"  产品{j}: {value(x_nom[j]):.1f} 件")

# 计算名义方案在最坏情况下的利润
nom_solution = {j: value(x_nom[j]) for j in products}

# 最坏情况：选Γ个不确定产品使利润偏差最大
deviations = [(j, p_hat[j] * nom_solution[j]) for j in uncertain_products]
deviations.sort(key=lambda x: x[1], reverse=True)
worst_deviation = sum(d[1] for _, d in zip(range(Gamma), deviations))

nom_worst_profit = value(model_nom.objective) - worst_deviation
print(f"\n名义方案的最坏情况利润: {nom_worst_profit:.2f} 元")
print(f"鲁棒方案的最坏情况利润: {value(model.objective):.2f} 元")
print(f"鲁棒性提升: {value(model.objective) - nom_worst_profit:.2f} 元")
print(f"名义利润代价(Price of Robustness): {value(model_nom.objective) - value(model.objective):.2f} 元")

# ============================================================
# 最坏情况场景验证
# ============================================================

print("\n" + "=" * 60)
print("最坏情况场景验证")
print("=" * 60)

robust_solution = {j: value(x[j]) for j in products}
rob_deviations = [(j, p_hat[j] * robust_solution[j]) for j in uncertain_products]
rob_deviations.sort(key=lambda x: x[1], reverse=True)

print("\n各产品的潜在利润偏差（按严重程度排序）:")
for j, dev in rob_deviations:
    print(f"  产品{j}: 偏差 = {p_hat[j]:.0f} × {robust_solution[j]:.1f} = {dev:.2f}")

print(f"\n最坏情况：前{Gamma}个产品同时取最低售价")
worst_products = [j for j, _ in rob_deviations[:Gamma]]
print(f"  最坏产品: {worst_products}")

worst_profit = sum(nominal_profit[j] * robust_solution[j] for j in products)
worst_loss = sum(p_hat[j] * robust_solution[j] for j in worst_products)
print(f"  名义利润: {worst_profit:.2f}")
print(f"  最坏偏差: -{worst_loss:.2f}")
print(f"  最坏利润: {worst_profit - worst_loss:.2f}")
print(f"  鲁棒模型目标值: {value(model.objective):.2f}")
