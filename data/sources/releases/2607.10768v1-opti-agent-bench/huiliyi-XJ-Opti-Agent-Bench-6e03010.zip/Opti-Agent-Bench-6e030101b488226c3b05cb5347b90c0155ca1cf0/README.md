# Opti-Agent-Bench

Benchmark for evaluating LLM / R&D-agent **end-to-end optimization** ability:

> business-language problem → mathematical model → code → execution → report

Evaluated with the **ORAC** checklist (formulation validity + solution validity), not objective value alone.

Paper (arXiv): [https://arxiv.org/abs/2607.10768](https://arxiv.org/abs/2607.10768)

## Layout

```
opti-agent-bench-public/
├── pipeline/          # four-stage harness (OpenAI-compatible APIs)
├── tasks/             # core suite (11 open + 1 holdout)
├── extras/            # additional problems (选品 / SDP / nonsmooth / MDP)
├── docs/              # ORAC map, release checklist & status
├── results/paper_tables/
└── scripts/
```

## Quick start

```bash
pip install -r requirements.txt

export LLM_BASE_URL="https://api.openai.com/v1"
export LLM_API_KEY="sk-..."
export LLM_MODEL="gpt-4o"

python -m pipeline.run \
  --task tasks/task_robust_scheduling \
  --output results/demo/task_robust_scheduling
```

## Core tasks

| ID | Name | Role |
|----|------|------|
| `task_01_drone_delivery` | Medical drone delivery (MDP) | Main |
| `task_11_cable_cutting` | Cable reel scheduling | Main (anti-template; full solver delayed) |
| `task_robust_scheduling` | Heterogeneous compute scheduling | Main |
| `task_02` … `task_07`, `task_09`, `task_10` | Appendix suite | Open |
| `task_08_cinema_hidden` | Cinema (hidden constraints) | **Holdout** |

See `tasks/registry.json` and `docs/RELEASE_STATUS.md` for reference completeness.

## Extras

22 additional problems under `extras/` (product selection, SDP, extra nonsmooth & MDP).  
See `extras/README.md`.

## Release policy (short)

| Ship | Withhold |
|------|----------|
| `problem.md`, agent-visible `data/`, checkers, most reference solvers | Full cable `cable_optimizer.py` |
| Aggregated paper tables | Raw model transcripts / robustness dumps |
| Holdout README for task_08 | Hidden cinema statement (request-only) |
| Hidden truth for grocery leakage → `reference/` only | Internal hosts / absolute paths |

Details: `docs/RELEASE_CHECKLIST.md`, `docs/RELEASE_STATUS.md`.

## Contamination notice

Public statements may enter future training data. Report scores with the release tag you used. Keep holdout tasks separate when comparing models.

## Citation

```bibtex
@misc{fu2026optiagentbench,
  title        = {Opti-Agent-Bench: Benchmarking End-to-End Optimization R\&D Agents on Real-World Business Problems},
  author       = {Fu, Yongchang and Huang, Xinjie and Dai, Chengjun and Feng, Chengzhe and Zhang, Junshao and Zhu, Hong},
  year         = {2026},
  eprint       = {2607.10768},
  archivePrefix= {arXiv},
  primaryClass = {cs.AI},
  url          = {https://arxiv.org/abs/2607.10768},
  doi          = {10.48550/arXiv.2607.10768}
}
```

## License

- Code (`pipeline/`, scripts): Apache-2.0 — `LICENSE`
- Problem text & data: CC-BY-4.0 — `LICENSE-DATA`
