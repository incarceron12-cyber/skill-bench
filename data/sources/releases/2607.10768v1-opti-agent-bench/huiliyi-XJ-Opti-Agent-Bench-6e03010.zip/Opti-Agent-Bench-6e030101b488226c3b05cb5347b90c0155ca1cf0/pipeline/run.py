#!/usr/bin/env python3
"""
Opti-Agent-Bench 评测 Pipeline 主入口。

用法:
    # 对单个任务运行单个模型
    python -m pipeline.run --task tasks/task_robust_scheduling --output results/codex/task_robust_scheduling

    # 指定运行某些阶段（调试用）
    python -m pipeline.run --task tasks/task_robust_scheduling --stages 1,2,3,4

    # 仅运行评估（已有结果）
    python -m pipeline.run --task tasks/task_robust_scheduling --output results/codex/task_robust_scheduling --stages eval

环境变量:
    LLM_BASE_URL  — OpenAI 兼容接口的 base_url
    LLM_API_KEY   — API Key
    LLM_MODEL     — 模型名称
"""

import argparse
import json
import logging
import sys
from pathlib import Path

# 确保项目根目录在 sys.path 中
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from pipeline.llm_client import LLMClient
from pipeline.stages import formulation, implementation, execution, report
from pipeline.evaluation import gateway
from pipeline import config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("pipeline")


def load_task(task_dir: Path) -> tuple[str, dict[str, str] | None]:
    """加载任务：problem.md + data/ 目录。"""
    problem_path = task_dir / "problem.md"
    if not problem_path.exists():
        raise FileNotFoundError(f"找不到 {problem_path}")

    problem_md = problem_path.read_text(encoding="utf-8")

    data_files = None
    data_dir = task_dir / "data"
    if data_dir.exists() and any(data_dir.iterdir()):
        data_files = {}
        for f in sorted(data_dir.iterdir()):
            if f.is_file() and not f.name.startswith("."):
                try:
                    data_files[f.name] = f.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    data_files[f.name] = f"(二进制文件, {f.stat().st_size} bytes)"

    return problem_md, data_files


def run_pipeline(
    task_dir: Path,
    output_dir: Path,
    stages: list[int] | None = None,
    llm: LLMClient | None = None,
):
    """
    运行完整的四阶段 Pipeline。

    参数:
        task_dir:   任务目录 (含 problem.md)
        output_dir: 输出目录
        stages:     要运行的阶段列表 [1,2,3,4]，None 表示全部
        llm:        LLM 客户端
    """
    if stages is None:
        stages = [1, 2, 3, 4]

    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("Opti-Agent-Bench Pipeline")
    logger.info("  任务: %s", task_dir)
    logger.info("  输出: %s", output_dir)
    logger.info("  阶段: %s", stages)
    logger.info("  模型: %s", llm.model if llm else "N/A")
    logger.info("=" * 60)

    # 加载任务
    problem_md, data_files = load_task(task_dir)
    data_dir = task_dir / "data" if (task_dir / "data").exists() else None

    # ── Stage 1: 数学建模 ──────────────────────────────────
    model_md = ""
    model_path = output_dir / "model.md"

    if 1 in stages:
        logger.info("▶ Stage 1: 数学建模 (Formulation)")
        model_md = formulation.run(llm, problem_md, data_files)
        model_path.write_text(model_md, encoding="utf-8")
        logger.info("  ✓ 已保存 model.md (%d 字符)", len(model_md))
    elif model_path.exists():
        model_md = model_path.read_text(encoding="utf-8")
        logger.info("  ⏭ Stage 1: 跳过 (使用已有 model.md)")

    # ── Stage 2: 代码实现 ──────────────────────────────────
    solution_code = ""
    solution_path = output_dir / "solution.py"

    if 2 in stages:
        if not model_md:
            logger.error("Stage 2 需要 model.md，但 Stage 1 未运行且无已有文件")
            return
        logger.info("▶ Stage 2: 代码实现 (Implementation)")
        solution_code = implementation.run(llm, problem_md, model_md, data_files)
        solution_path.write_text(solution_code, encoding="utf-8")
        logger.info("  ✓ 已保存 solution.py (%d 行)", solution_code.count("\n") + 1)
    elif solution_path.exists():
        solution_code = solution_path.read_text(encoding="utf-8")
        logger.info("  ⏭ Stage 2: 跳过 (使用已有 solution.py)")

    # ── Stage 3: 代码执行 ──────────────────────────────────
    result_json = {}
    result_path = output_dir / "result.json"

    if 3 in stages:
        if not solution_code:
            logger.error("Stage 3 需要 solution.py，但 Stage 2 未运行且无已有文件")
            return
        logger.info("▶ Stage 3: 代码执行 (Execution)")
        result_json = execution.run(solution_code, data_dir)
        result_path.write_text(
            json.dumps(result_json, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )
        logger.info(
            "  ✓ 已保存 result.json (status=%s)",
            result_json.get("status", "unknown"),
        )
    elif result_path.exists():
        result_json = json.loads(result_path.read_text(encoding="utf-8"))
        logger.info("  ⏭ Stage 3: 跳过 (使用已有 result.json)")

    # ── Stage 4: 分析报告 ──────────────────────────────────
    report_path = output_dir / "report.md"

    if 4 in stages:
        if not (model_md and solution_code and result_json):
            logger.error("Stage 4 需要前三阶段的所有产物")
            return
        logger.info("▶ Stage 4: 分析报告 (Report)")
        report_md = report.run(llm, problem_md, model_md, solution_code, result_json)
        report_path.write_text(report_md, encoding="utf-8")
        logger.info("  ✓ 已保存 report.md (%d 字符)", len(report_md))

    # ── Gateway 评估 ───────────────────────────────────────
    logger.info("▶ Gateway 评估")
    gw_result = gateway.check(output_dir)
    gw_path = output_dir / "gateway.json"
    gw_path.write_text(
        json.dumps(gw_result, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    logger.info("  Gateway: %s", "PASS" if gw_result["pass"] else "FAIL")
    for k, v in gw_result["checks"].items():
        status = "✓" if v["pass"] else "✗"
        logger.info("    %s %s: %s", status, k, v.get("detail", ""))

    logger.info("=" * 60)
    logger.info("Pipeline 完成！所有产物保存在: %s", output_dir)
    logger.info("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        description="Opti-Agent-Bench 评测 Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--task",
        type=str,
        required=True,
        help="任务目录路径 (含 problem.md)",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="输出目录 (默认: results/<model>/<task_name>)",
    )
    parser.add_argument(
        "--stages",
        type=str,
        default="1,2,3,4",
        help="要运行的阶段，逗号分隔 (如 '1,2,3,4' 或 '3,4')",
    )
    parser.add_argument(
        "--base-url",
        type=str,
        default=None,
        help="LLM API base_url (也可通过 LLM_BASE_URL 环境变量设置)",
    )
    parser.add_argument(
        "--api-key",
        type=str,
        default=None,
        help="LLM API key (也可通过 LLM_API_KEY 环境变量设置)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default=None,
        help="LLM 模型名称 (也可通过 LLM_MODEL 环境变量设置)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=None,
        help=f"代码执行超时秒数 (默认: {config.EXECUTION_TIMEOUT})",
    )

    args = parser.parse_args()

    # 解析阶段
    stages = [int(s.strip()) for s in args.stages.split(",")]

    # 需要 LLM 的阶段
    need_llm = any(s in stages for s in [1, 2, 4])

    llm = None
    if need_llm:
        llm = LLMClient(
            base_url=args.base_url,
            api_key=args.api_key,
            model=args.model,
        )

    # 路径处理
    task_dir = Path(args.task)
    if not task_dir.is_absolute():
        task_dir = PROJECT_ROOT / task_dir

    if args.output:
        output_dir = Path(args.output)
        if not output_dir.is_absolute():
            output_dir = PROJECT_ROOT / output_dir
    else:
        model_name = llm.model if llm else "unknown"
        output_dir = config.RESULTS_DIR / model_name / task_dir.name

    if args.timeout:
        config.EXECUTION_TIMEOUT = args.timeout

    # 运行
    run_pipeline(task_dir, output_dir, stages, llm)


if __name__ == "__main__":
    main()
