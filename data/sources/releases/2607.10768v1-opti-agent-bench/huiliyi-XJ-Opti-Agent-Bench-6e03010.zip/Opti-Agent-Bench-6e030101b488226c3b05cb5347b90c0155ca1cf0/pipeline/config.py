"""
Pipeline 全局配置。

LLM 配置通过环境变量注入：
    LLM_BASE_URL  — OpenAI 兼容接口的 base_url
    LLM_API_KEY   — API Key
    LLM_MODEL     — 模型名称
"""

import os
from pathlib import Path

# ── 路径 ──────────────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
PIPELINE_DIR = Path(__file__).resolve().parent
TASKS_DIR = PROJECT_ROOT / "tasks"
RESULTS_DIR = PROJECT_ROOT / "results"
PROMPTS_DIR = PIPELINE_DIR / "prompts"

# ── LLM 默认参数 ─────────────────────────────────────────────
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "")
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "")

LLM_TEMPERATURE = 0
LLM_SEED = 42

# 各阶段的 max_tokens 限制
MAX_TOKENS = {
    "formulation": 8192,
    "implementation": 16384,
    "report": 8192,
}

# ── 执行环境 ──────────────────────────────────────────────────
EXECUTION_TIMEOUT = 1800       # solution.py 最大运行秒数（30 分钟）
EXECUTION_MEMORY_MB = 32768    # 32 GB

# ── 允许的求解库（写入 Stage 2 Prompt） ──────────────────────
ALLOWED_PACKAGES = [
    "pulp", "scipy", "cvxpy", "ortools", "numpy", "pandas",
    "json", "csv", "math", "itertools", "collections", "typing",
]
