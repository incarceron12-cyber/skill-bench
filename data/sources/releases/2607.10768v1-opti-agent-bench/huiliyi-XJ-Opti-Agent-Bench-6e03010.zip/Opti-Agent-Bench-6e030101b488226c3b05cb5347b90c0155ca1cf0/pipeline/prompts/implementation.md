# Stage 2: 代码实现

你是一位运筹优化工程师。请根据下面的**问题描述**和**数学模型**，编写完整的 Python 求解代码。

## 核心要求

1. **严格按照数学模型实现**：代码中的变量、约束、目标函数必须与 model.md 中的数学模型一一对应。
2. **代码必须可以独立运行**：直接 `python solution.py` 即可执行
3. **输出标准化结果**：运行后在当前目录生成 `result.json`
4. **代码结构**：必须包含 `load_data()`、`build_model()`、`solve()` 三个核心函数

## 允许使用的库

{allowed_packages}

## 数据读取

- 如果问题描述中包含具体数据，直接在代码中定义
- 如果有独立数据文件，从 `./data/` 目录读取

## 输出格式（result.json）

代码运行后必须在当前目录生成 `result.json`，格式如下：

```json
{{
  "status": "optimal | feasible | infeasible | error",
  "objective_value": 12345.67,
  "variables": {{
    "变量名": "变量值（列表或字典）"
  }},
  "solve_time_seconds": 15.3,
  "solver_info": {{
    "solver_name": "使用的求解器名称",
    "gap": 0.001
  }}
}}
```

## 代码模板

```python
import json
import time

def load_data():
    """加载数据。"""
    # ...
    return data

def build_model(data):
    """根据数学模型构建优化模型。"""
    # ...
    return model

def solve(model):
    """求解模型，返回结果字典。"""
    # ...
    return result

def main():
    data = load_data()
    model = build_model(data)

    t0 = time.time()
    result = solve(model)
    solve_time = time.time() - t0

    output = {{
        "status": result["status"],
        "objective_value": result["objective_value"],
        "variables": result["variables"],
        "solve_time_seconds": round(solve_time, 3),
        "solver_info": result.get("solver_info", {{}})
    }}

    with open("result.json", "w") as f:
        json.dump(output, f, indent=2, ensure_ascii=False)

    print(f"Status: {{output['status']}}")
    print(f"Objective: {{output['objective_value']}}")
    print(f"Solve time: {{solve_time:.3f}}s")

if __name__ == "__main__":
    main()
```

请直接输出完整的 Python 代码（不要用 markdown 代码块包裹，直接输出纯代码）。

## 问题描述

{problem}

## 数学模型（来自 Stage 1）

{model}

## 数据文件

{data_files}
