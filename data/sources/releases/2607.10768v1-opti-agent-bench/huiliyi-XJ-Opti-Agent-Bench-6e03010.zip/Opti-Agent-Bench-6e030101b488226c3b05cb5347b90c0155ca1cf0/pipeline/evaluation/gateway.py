"""
Gateway 门槛检查 — Pipeline 输出的基础质量验证。

检查项:
1. model.md 是否存在且非空
2. solution.py 是否存在且为合法 Python
3. result.json 是否存在且格式合规
4. report.md 是否存在且非空
5. 代码执行是否成功（非 error/timeout 状态）
"""

import ast
import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

REQUIRED_RESULT_KEYS = {"status", "objective_value"}
VALID_STATUS = {"optimal", "feasible", "infeasible", "timeout", "error"}


def check(output_dir: Path) -> dict:
    """
    对 Pipeline 输出进行 Gateway 检查。

    参数:
        output_dir: 包含 model.md / solution.py / result.json / report.md 的目录

    返回:
        dict: {
            "pass": bool,
            "checks": {
                "model_md": {"pass": bool, "detail": str},
                "solution_py": {"pass": bool, "detail": str},
                "result_json": {"pass": bool, "detail": str},
                "report_md": {"pass": bool, "detail": str},
                "execution_success": {"pass": bool, "detail": str},
            }
        }
    """
    output_dir = Path(output_dir)
    checks = {}

    # 1. model.md
    model_path = output_dir / "model.md"
    if model_path.exists() and model_path.stat().st_size > 50:
        checks["model_md"] = {"pass": True, "detail": f"{model_path.stat().st_size} 字节"}
    else:
        checks["model_md"] = {
            "pass": False,
            "detail": "文件不存在或内容过短" if not model_path.exists() else "内容不足 50 字节",
        }

    # 2. solution.py
    solution_path = output_dir / "solution.py"
    if solution_path.exists():
        code = solution_path.read_text(encoding="utf-8")
        try:
            ast.parse(code)
            checks["solution_py"] = {"pass": True, "detail": f"{code.count(chr(10))+1} 行, 语法合法"}
        except SyntaxError as e:
            checks["solution_py"] = {"pass": False, "detail": f"语法错误: {e}"}
    else:
        checks["solution_py"] = {"pass": False, "detail": "文件不存在"}

    # 3. result.json
    result_path = output_dir / "result.json"
    if result_path.exists():
        try:
            result = json.loads(result_path.read_text(encoding="utf-8"))
            missing = REQUIRED_RESULT_KEYS - set(result.keys())
            if missing:
                checks["result_json"] = {
                    "pass": False,
                    "detail": f"缺少必要字段: {missing}",
                }
            elif result.get("status") not in VALID_STATUS:
                checks["result_json"] = {
                    "pass": False,
                    "detail": f"无效 status: {result.get('status')}",
                }
            else:
                checks["result_json"] = {
                    "pass": True,
                    "detail": f"status={result['status']}, obj={result.get('objective_value')}",
                }
        except json.JSONDecodeError as e:
            checks["result_json"] = {"pass": False, "detail": f"JSON 解析失败: {e}"}
    else:
        checks["result_json"] = {"pass": False, "detail": "文件不存在"}

    # 4. report.md
    report_path = output_dir / "report.md"
    if report_path.exists() and report_path.stat().st_size > 50:
        checks["report_md"] = {"pass": True, "detail": f"{report_path.stat().st_size} 字节"}
    else:
        checks["report_md"] = {
            "pass": False,
            "detail": "文件不存在或内容过短",
        }

    # 5. 代码执行成功
    if checks.get("result_json", {}).get("pass"):
        result = json.loads(result_path.read_text(encoding="utf-8"))
        status = result.get("status", "error")
        if status in ("optimal", "feasible"):
            checks["execution_success"] = {
                "pass": True,
                "detail": f"status={status}, objective={result.get('objective_value')}",
            }
        else:
            checks["execution_success"] = {
                "pass": False,
                "detail": f"status={status}, error={result.get('error', 'N/A')[:200]}",
            }
    else:
        checks["execution_success"] = {
            "pass": False,
            "detail": "result.json 不可用",
        }

    all_pass = all(c["pass"] for c in checks.values())

    return {"pass": all_pass, "checks": checks}
