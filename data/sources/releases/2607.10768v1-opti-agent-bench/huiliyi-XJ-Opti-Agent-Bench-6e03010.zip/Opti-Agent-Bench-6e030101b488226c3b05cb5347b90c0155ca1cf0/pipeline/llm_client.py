"""
统一 LLM 调用层。

使用 OpenAI Python SDK 的兼容模式，支持所有提供 OpenAI 兼容接口的模型。
配置通过环境变量注入（见 config.py）。
"""

import time
import logging
from openai import OpenAI

from . import config

logger = logging.getLogger(__name__)


class LLMClient:
    """OpenAI 兼容接口的统一 LLM 客户端。"""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
    ):
        self.base_url = base_url or config.LLM_BASE_URL
        self.api_key = api_key or config.LLM_API_KEY
        self.model = model or config.LLM_MODEL

        if not self.base_url:
            raise ValueError(
                "LLM_BASE_URL 未设置。请通过环境变量或参数传入。"
            )
        if not self.api_key:
            raise ValueError(
                "LLM_API_KEY 未设置。请通过环境变量或参数传入。"
            )
        if not self.model:
            raise ValueError(
                "LLM_MODEL 未设置。请通过环境变量或参数传入。"
            )

        self.client = OpenAI(base_url=self.base_url, api_key=self.api_key)

    def call(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 4096,
    ) -> str:
        """
        调用 LLM，返回纯文本响应。

        参数:
            system_prompt: 系统提示
            user_prompt:   用户输入
            max_tokens:    最大生成 token 数

        返回:
            str: 模型响应文本
        """
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

        logger.info(
            "LLM call: model=%s, system_len=%d, user_len=%d",
            self.model,
            len(system_prompt),
            len(user_prompt),
        )

        t0 = time.time()
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=config.LLM_TEMPERATURE,
            max_tokens=max_tokens,
            seed=config.LLM_SEED,
        )
        elapsed = time.time() - t0

        content = response.choices[0].message.content or ""
        usage = response.usage
        logger.info(
            "LLM done: %.1fs, prompt_tokens=%s, completion_tokens=%s",
            elapsed,
            getattr(usage, "prompt_tokens", "?"),
            getattr(usage, "completion_tokens", "?"),
        )
        return content
