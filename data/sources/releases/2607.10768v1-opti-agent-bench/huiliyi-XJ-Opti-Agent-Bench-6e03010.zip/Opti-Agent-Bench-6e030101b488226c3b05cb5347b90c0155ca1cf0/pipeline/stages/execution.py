"""Stage 3: 代码执行 — 在隔离环境中运行 solution.py，收集结果。

此阶段不调用 LLM，纯机械执行。
"""

import json
import shutil
import subprocess
import sys
import tempfile
import time
import logging
from pathlib import Path

from .. import config

logger = logging.getLogger(__name__)


def run(
    solution_code: str,
    data_dir: Path | None = None,
    timeout: int | None = None,
) -> dict:
    """
    执行 solution.py 并收集结果。

    参数:
        solution_code: solution.py 的源代码内容
        data_dir:      数据文件目录（如有）
        timeout:       超时秒数，默认使用 config.EXECUTION_TIMEOUT

    返回:
        dict: 标准化的 result.json 内容 + 执行元信息
    """
    timeout = timeout or config.EXECUTION_TIMEOUT
    workdir = Path(tempfile.mkdtemp(prefix="opti_bench_"))

    try:
        # 1. 写入 solution.py
        solution_path = workdir / "solution.py"
        solution_path.write_text(solution_code, encoding="utf-8")

        # 2. 复制数据文件（如有）
        if data_dir and data_dir.exists():
            dest = workdir / "data"
            shutil.copytree(data_dir, dest)

        # 3. 执行
        logger.info(
            "Stage 3 (Execution): 运行 solution.py, timeout=%ds, workdir=%s",
            timeout,
            workdir,
        )

        t0 = time.time()
        proc = subprocess.run(
            [sys.executable, "solution.py"],
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        wall_time = time.time() - t0

        execution_log = {
            "stdout": proc.stdout[-5000:] if proc.stdout else "",
            "stderr": proc.stderr[-5000:] if proc.stderr else "",
            "exit_code": proc.returncode,
            "wall_time_seconds": round(wall_time, 3),
        }

        # 4. 读取 result.json
        result_path = workdir / "result.json"
        if result_path.exists():
            try:
                result = json.loads(result_path.read_text(encoding="utf-8"))
                result["execution_log"] = execution_log
                logger.info(
                    "Stage 3: 成功, status=%s, objective=%s, wall_time=%.1fs",
                    result.get("status"),
                    result.get("objective_value"),
                    wall_time,
                )
                return result
            except json.JSONDecodeError as e:
                logger.error("Stage 3: result.json 解析失败: %s", e)

        # 5. 执行失败或未生成 result.json
        logger.warning(
            "Stage 3: 代码执行失败或未生成 result.json (exit_code=%d)",
            proc.returncode,
        )
        return {
            "status": "error",
            "objective_value": None,
            "variables": {},
            "solve_time_seconds": 0,
            "solver_info": {},
            "execution_log": execution_log,
            "error": proc.stderr[-2000:] if proc.stderr else "未生成 result.json",
        }

    except subprocess.TimeoutExpired:
        wall_time = time.time() - t0
        logger.error("Stage 3: 执行超时 (%ds)", timeout)
        return {
            "status": "timeout",
            "objective_value": None,
            "variables": {},
            "solve_time_seconds": 0,
            "solver_info": {},
            "execution_log": {
                "stdout": "",
                "stderr": f"执行超时: 超过 {timeout} 秒",
                "exit_code": -1,
                "wall_time_seconds": round(wall_time, 3),
            },
            "error": f"执行超时: 超过 {timeout} 秒",
        }

    except Exception as e:
        logger.exception("Stage 3: 未预期的执行错误")
        return {
            "status": "error",
            "objective_value": None,
            "variables": {},
            "solve_time_seconds": 0,
            "solver_info": {},
            "execution_log": {"error": str(e)},
            "error": str(e),
        }

    finally:
        # 清理临时目录
        try:
            shutil.rmtree(workdir)
        except OSError:
            pass
