"""Stage 2: 代码实现 — 基于数学模型生成可执行的求解代码。"""

import ast
import re
import logging

from ..llm_client import LLMClient
from .. import config

logger = logging.getLogger(__name__)


def _load_prompt_template() -> str:
    path = config.PROMPTS_DIR / "implementation.md"
    return path.read_text(encoding="utf-8")


def _extract_python_code(text: str) -> str:
    """从 LLM 响应中提取 Python 代码。

    优先提取 ```python ... ``` 代码块；
    如果没有代码块，假设整个响应就是纯代码。
    """
    pattern = r"```python\s*\n(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    if matches:
        code = max(matches, key=len)
        return code.strip()
    return text.strip()


def _validate_python(code: str) -> bool:
    """检查是否为合法 Python 代码。"""
    try:
        ast.parse(code)
        return True
    except SyntaxError as e:
        logger.warning("代码语法错误: %s", e)
        return False


def run(
    llm: LLMClient,
    problem_md: str,
    model_md: str,
    data_files: dict[str, str] | None = None,
) -> str:
    """
    执行 Stage 2: 代码实现。

    参数:
        llm:         LLM 客户端
        problem_md:  问题描述
        model_md:    Stage 1 输出的数学模型
        data_files:  数据文件内容

    返回:
        str: 可执行的 Python 求解代码 (solution.py 内容)
    """
    template = _load_prompt_template()

    data_section = "（数据已包含在问题描述中，请在代码中直接定义）"
    if data_files:
        parts = []
        for fname, content in data_files.items():
            parts.append(f"### {fname}\n```\n{content}\n```")
        data_section = "\n\n".join(parts)

    packages_str = ", ".join(config.ALLOWED_PACKAGES)

    user_prompt = (
        template.replace("{problem}", problem_md)
        .replace("{model}", model_md)
        .replace("{data_files}", data_section)
        .replace("{allowed_packages}", packages_str)
    )

    system_prompt = (
        "你是一位运筹优化工程师。"
        "请严格按照给定的数学模型编写可执行的 Python 求解代码。"
        "代码必须能独立运行并输出标准化的 result.json。"
        "直接输出纯 Python 代码，不要额外的解释文字。"
    )

    logger.info("Stage 2 (Implementation): 开始调用 LLM ...")
    raw = llm.call(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_tokens=config.MAX_TOKENS["implementation"],
    )

    code = _extract_python_code(raw)

    if not _validate_python(code):
        logger.error("Stage 2: LLM 生成的代码存在语法错误，保留原始输出")

    logger.info("Stage 2 (Implementation): 完成, 代码 %d 行", code.count("\n") + 1)
    return code
