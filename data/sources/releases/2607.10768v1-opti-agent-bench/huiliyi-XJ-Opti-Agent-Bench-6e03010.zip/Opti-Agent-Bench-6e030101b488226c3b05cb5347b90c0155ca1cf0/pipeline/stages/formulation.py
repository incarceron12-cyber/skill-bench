"""Stage 1: 数学建模 — 将业务问题描述转化为结构化数学模型。"""

import logging

from ..llm_client import LLMClient
from .. import config

logger = logging.getLogger(__name__)


def _load_prompt_template() -> str:
    path = config.PROMPTS_DIR / "formulation.md"
    return path.read_text(encoding="utf-8")


def run(
    llm: LLMClient,
    problem_md: str,
    data_files: dict[str, str] | None = None,
) -> str:
    """
    执行 Stage 1: 数学建模。

    参数:
        llm:         LLM 客户端
        problem_md:  问题描述 (problem.md 全文)
        data_files:  数据文件内容 {文件名: 内容}，可为空

    返回:
        str: 结构化数学模型 (model.md 内容)
    """
    template = _load_prompt_template()

    data_section = "（数据已包含在问题描述中）"
    if data_files:
        parts = []
        for fname, content in data_files.items():
            parts.append(f"### {fname}\n```\n{content}\n```")
        data_section = "\n\n".join(parts)

    user_prompt = template.replace("{problem}", problem_md).replace(
        "{data_files}", data_section
    )

    system_prompt = (
        "你是一位运筹优化领域的资深研究员。"
        "请仔细分析业务问题，构建严格完整的数学模型。"
        "注意：不要遗漏任何隐含约束。"
    )

    logger.info("Stage 1 (Formulation): 开始调用 LLM ...")
    result = llm.call(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_tokens=config.MAX_TOKENS["formulation"],
    )
    logger.info("Stage 1 (Formulation): 完成, 输出 %d 字符", len(result))
    return result
