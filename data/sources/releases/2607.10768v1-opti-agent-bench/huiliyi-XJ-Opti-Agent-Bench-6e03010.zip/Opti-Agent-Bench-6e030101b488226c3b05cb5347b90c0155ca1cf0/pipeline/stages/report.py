"""Stage 4: 分析报告 — 基于全部前序产物生成综合分析报告。"""

import json
import logging

from ..llm_client import LLMClient
from .. import config

logger = logging.getLogger(__name__)


def _load_prompt_template() -> str:
    path = config.PROMPTS_DIR / "report.md"
    return path.read_text(encoding="utf-8")


def run(
    llm: LLMClient,
    problem_md: str,
    model_md: str,
    solution_code: str,
    result_json: dict,
) -> str:
    """
    执行 Stage 4: 分析报告。

    参数:
        llm:            LLM 客户端
        problem_md:     问题描述
        model_md:       Stage 1 输出的数学模型
        solution_code:  Stage 2 输出的求解代码
        result_json:    Stage 3 输出的执行结果

    返回:
        str: 分析报告 (report.md 内容)
    """
    template = _load_prompt_template()

    result_str = json.dumps(result_json, indent=2, ensure_ascii=False, default=str)

    # 截断过长的内容，避免超出 token 限制
    if len(solution_code) > 15000:
        solution_code = solution_code[:15000] + "\n# ... (代码截断) ..."
    if len(result_str) > 10000:
        result_str = result_str[:10000] + "\n... (结果截断) ..."

    user_prompt = (
        template.replace("{problem}", problem_md)
        .replace("{model}", model_md)
        .replace("{solution}", solution_code)
        .replace("{result}", result_str)
    )

    system_prompt = (
        "你是一位运筹优化顾问。"
        "请根据所有材料撰写一份专业的求解分析报告。"
        "重点对结果进行业务层面的解读，坦诚说明局限性。"
    )

    logger.info("Stage 4 (Report): 开始调用 LLM ...")
    result = llm.call(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        max_tokens=config.MAX_TOKENS["report"],
    )
    logger.info("Stage 4 (Report): 完成, 输出 %d 字符", len(result))
    return result
