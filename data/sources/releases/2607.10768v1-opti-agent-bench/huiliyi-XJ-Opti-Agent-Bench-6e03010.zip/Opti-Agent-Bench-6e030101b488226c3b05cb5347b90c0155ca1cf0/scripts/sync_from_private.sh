#!/usr/bin/env bash
# Helper: copy scrubbed problem.md + metadata (+ optional data) from private tree.
# Usage: ./scripts/sync_from_private.sh task_01_drone_delivery
set -euo pipefail
TASK="${1:?task id required}"
PRIV="${PRIV:-$HOME/HXJ/agent/opti-agent-bench}"
PUB="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$PRIV/tasks/$TASK"
DST="$PUB/tasks/$TASK"
[[ -d "$SRC" ]] || { echo "missing $SRC"; exit 1; }
mkdir -p "$DST/data" "$DST/reference" "$DST/evaluation"
cp "$SRC/problem.md" "$DST/problem.md"
cp "$SRC/metadata.json" "$DST/metadata.json"
if [[ -d "$SRC/data" ]]; then
  find "$SRC/data" -maxdepth 1 -type f \( -name '*.csv' -o -name '*.json' -o -name '*.txt' \) \
    -exec cp {} "$DST/data/" \;
fi
echo "Synced statement/data for $TASK (reference NOT copied)."
