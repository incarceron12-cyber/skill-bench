# Self-GC arXiv source package

Main file: `self-gc.tex`

This source package contains only the files needed to compile the arXiv preprint:

- `self-gc.tex`
- `self-gc.bib`
- `self-gc.bst`
- `aaai2027.sty`
- `math_commands.tex`
- `section/*.tex`
- `figure/*.png`

Local note: this package keeps the AAAI preprint style, with the bibliography style reference adjusted to `self-gc.bst`. The AAAI style includes a PDFLaTeX engine guard. arXiv's standard PDFLaTeX build should use the style as-is. For local Tectonic preview only, comment out `\RequirePDFTeX` in a temporary copy of `aaai2027.sty`.
